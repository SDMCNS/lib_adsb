"""Adversarial challenge and stress-test suite for Milestone 1.

Targets:
1. CRC-24 parity calculation, 223 syndrome correction, short-frame overflow, and AP recovery.
2. CPR encoding/decoding: extreme latitudes, 58 NL boundary transitions, and false-positive straddle bug.
3. Gillham altitude decoding: boundary values, invalid pulse {0, 5, 7} rejection, and 100-ft round-trip.
4. Bit slicing edge cases: off-by-one checks, boundary bit values, non-byte-aligned BitBuffer.
"""

from __future__ import annotations

import pytest

from adsb.core.bits import BitBuffer, extract_bits, set_bits
from adsb.protocol.cpr import (
    _NL_TRANSITION_TABLE,
    decode_cpr_global_airborne,
    encode_cpr_airborne,
    nl_lat,
)
from adsb.protocol.crc import (
    compute_crc24,
    compute_syndrome,
    correct_syndrome_errors,
    verify_crc24,
)
from adsb.protocol.gillham import (
    decode_gillham_altitude,
    encode_gillham_altitude,
)
from adsb.protocol.modes import decode_mode_s


class TestCRCAdversarial:
    """Stress tests and adversarial inputs for CRC-24 and error correction."""

    def test_all_112_single_bit_error_patterns_on_long_frame(self) -> None:
        """Verify all 112 single-bit error patterns on a valid 112-bit frame."""
        clean_frame = bytes.fromhex("8D4840D6202CC371C32CE0576098")
        assert verify_crc24(clean_frame)

        for p in range(112):
            corrupted_int = int.from_bytes(clean_frame, "big") ^ (1 << p)
            corrupted_bytes = corrupted_int.to_bytes(14, "big")
            corrected, err_count = correct_syndrome_errors(corrupted_bytes)
            assert corrected == clean_frame, f"Failed correcting single-bit flip at pos {p}"
            assert err_count == 1

    def test_all_111_adjacent_2bit_burst_patterns_on_long_frame(self) -> None:
        """Verify all 111 adjacent 2-bit burst error patterns on a valid 112-bit frame."""
        clean_frame = bytes.fromhex("8D4840D6202CC371C32CE0576098")
        assert verify_crc24(clean_frame)

        for p in range(111):
            corrupted_int = int.from_bytes(clean_frame, "big") ^ (3 << p)
            corrupted_bytes = corrupted_int.to_bytes(14, "big")
            corrected, err_count = correct_syndrome_errors(corrupted_bytes)
            assert corrected == clean_frame, f"Failed correcting 2-bit burst at pos {p}"
            assert err_count == 2

    def test_short_frame_error_correction_safety(self) -> None:
        """Verify that correct_syndrome_errors correctly handles 7-byte frames without overflow."""
        clean_gv06 = bytes.fromhex("5D4840D6F8740F")
        assert verify_crc24(clean_gv06)

        # Test single bit error correction across all 56 bit positions
        base_int = int.from_bytes(clean_gv06, "big")
        for p in range(56):
            corrupted = (base_int ^ (1 << p)).to_bytes(7, "big")
            corrected, count = correct_syndrome_errors(corrupted)
            assert count == 1, f"Expected 1 corrected error for bit {p}, got {count}"
            assert corrected == clean_gv06, f"Failed correcting single-bit flip on 7-byte frame at pos {p}"

        # Test adjacent 2-bit burst error correction across all 55 positions
        for p in range(55):
            corrupted = (base_int ^ (3 << p)).to_bytes(7, "big")
            corrected, count = correct_syndrome_errors(corrupted)
            assert count == 2, f"Expected 2 corrected errors for burst at {p}, got {count}"
            assert corrected == clean_gv06, f"Failed correcting 2-bit burst on 7-byte frame at pos {p}"

    def test_gv06_single_bit_and_burst_error_correction(self) -> None:
        """Verify that GV-06 correctly detects and repairs single-bit and 2-bit burst errors."""
        gv06 = bytes.fromhex("5D4840D6F8740F")
        assert compute_syndrome(gv06) == 0

        # Flip bit 0 of byte 0
        corrupted = bytearray(gv06)
        corrupted[0] ^= 1
        corrupted_bytes = bytes(corrupted)

        corrected, count = correct_syndrome_errors(corrupted_bytes)
        assert corrected == gv06
        assert count == 1

    def test_ap_address_recovery_under_corruption(self) -> None:
        """Verify AP recovery behavior on DF 4 when corrupted."""
        # DF 4 frame: DF=4, FS=0, AC=FL350, AP = CRC ^ ICAO(0x4840D6)
        # Construct clean frame
        icao = 0x4840D6
        val = (4 << 51) | (0 << 48) | (encode_gillham_altitude(35000, resolution_25ft=True) << 24)
        frame_bytes = val.to_bytes(7, "big")
        crc = compute_crc24(frame_bytes)
        ap = crc ^ icao
        clean_df4 = (val | ap).to_bytes(7, "big")

        # Decode with whitelist containing true ICAO
        msg_clean = decode_mode_s(clean_df4, active_whitelist={icao})
        assert msg_clean.crc_valid is True
        assert msg_clean.icao24 == icao

        # Corrupt 1 bit
        corrupted = bytearray(clean_df4)
        corrupted[1] ^= 0x01
        msg_corrupted = decode_mode_s(bytes(corrupted), active_whitelist={icao})
        # Should be rejected because recovered ICAO != true ICAO
        assert msg_corrupted.crc_valid is False
        assert msg_corrupted.icao24 != icao


class TestCPRAdversarial:
    """Stress tests and boundary checks for CPR algorithms."""

    def test_cpr_extreme_latitudes(self) -> None:
        """Test CPR round-trip at extreme latitudes (+/-89.9 deg and poles +/-90.0 deg)."""
        test_coords = [
            (89.9, 10.0),
            (-89.9, -45.0),
            (90.0, 0.0),
            (-90.0, 0.0),
            (0.0, 179.99),
            (0.0, -179.99),
        ]
        for lat, lon in test_coords:
            yz0, xz0 = encode_cpr_airborne(lat, lon, 0)
            yz1, xz1 = encode_cpr_airborne(lat, lon, 1)

            # Global decode
            dlat, dlon = decode_cpr_global_airborne(
                yz0 / 131072.0, xz0 / 131072.0, yz1 / 131072.0, xz1 / 131072.0, most_recent=1
            )
            assert abs(dlat - lat) < 0.001, f"Lat error at {lat}: got {dlat}"
            if abs(lat) < 89.0:
                assert abs(dlon - lon) < 0.005, f"Lon error at ({lat}, {lon}): got {dlon}"

    def test_all_58_nl_boundary_transitions(self) -> None:
        """Stress-test crossing each of the 58 NL latitude boundaries."""
        for b in _NL_TRANSITION_TABLE:
            lat0 = b - 0.02
            lat1 = b + 0.02
            lon = 20.0
            yz0, xz0 = encode_cpr_airborne(lat0, lon, 0)
            yz1, xz1 = encode_cpr_airborne(lat1, lon, 1)

            if nl_lat(lat0) != nl_lat(lat1):
                # Boundary straddle MUST be rejected
                with pytest.raises(ValueError, match="straddle"):
                    decode_cpr_global_airborne(
                        yz0 / 131072.0, xz0 / 131072.0, yz1 / 131072.0, xz1 / 131072.0, most_recent=1
                    )

    def test_cpr_valid_coordinates_no_false_straddle(self) -> None:
        """Verify that valid coordinates around lat -6.23 deg do not trigger false straddle error."""
        # A legitimate aircraft at lat -6.24 transmits yz0/131072 = 0.96 and yz1/131072 = 0.98
        # Since NL(-6.24) == 59 and NL(-6.22) == 59 (no straddle), it must decode successfully.
        res = decode_cpr_global_airborne(0.96, 0.1, 0.98, 0.1, most_recent=1)
        assert res is not None
        lat, lon = res
        assert -7.0 < lat < -5.0
        assert -180.0 <= lon <= 180.0


class TestGillhamAdversarial:
    """Stress tests and boundary checks for Gillham altitude codecs."""

    def test_q_bit_one_boundary_values(self) -> None:
        """Test Q=1 25-ft boundary altitudes."""
        # Min valid altitude: -1000 ft
        code_min = encode_gillham_altitude(-1000, resolution_25ft=True)
        assert decode_gillham_altitude(code_min) == -1000

        # Max valid altitude: 50175 ft
        code_max = encode_gillham_altitude(50175, resolution_25ft=True)
        assert decode_gillham_altitude(code_max) == 50175

        # Sea level: 0 ft
        code_0 = encode_gillham_altitude(0, resolution_25ft=True)
        assert decode_gillham_altitude(code_0) == 0

        # Unavailable: code 0
        assert decode_gillham_altitude(0) is None

    def test_invalid_gillham_pulses_rejected(self) -> None:
        """Verify that G_100 in {0, 5, 7} are rejected across all G_500 combinations."""
        for g100 in (0, 5, 7):
            c1 = (g100 >> 2) & 1
            c2 = (g100 >> 1) & 1
            c4 = g100 & 1
            for g500 in (0, 1, 2, 4, 8, 16, 32, 64, 128, 255):
                d2 = (g500 >> 7) & 1
                d4 = (g500 >> 6) & 1
                a1 = (g500 >> 5) & 1
                a2 = (g500 >> 4) & 1
                a4 = (g500 >> 3) & 1
                b1 = (g500 >> 2) & 1
                b2 = (g500 >> 1) & 1
                b4 = g500 & 1
                alt_code = (
                    (c1 << 11) | (a1 << 10) | (c2 << 9) | (a2 << 8) |
                    (c4 << 7) | (a4 << 6) | (b1 << 5) | (0 << 4) |
                    (b2 << 3) | (d2 << 2) | (b4 << 1) | d4
                )
                if alt_code != 0:
                    assert decode_gillham_altitude(alt_code) is None

    def test_gillham_100ft_round_trip_off_by_one_failure(self) -> None:
        """Demonstrate that 20% of altitudes fail round-trip in encode_gillham_altitude."""
        failures: list[tuple[int, int | None]] = []
        for alt in range(-1000, 50000, 100):
            code = encode_gillham_altitude(alt, resolution_25ft=False)
            dec = decode_gillham_altitude(code)
            if dec != alt:
                failures.append((alt, dec))

        # We empirically expect failures whenever (alt + 1300) % 500 == 0
        assert len(failures) > 0, "Expected failures due to off-by-one in encode_gillham_altitude"
        # Verify that all failures occur exactly at multiples of 500 ft offset
        for alt, dec in failures:
            assert (alt + 1300) % 500 == 0
            assert dec == alt + 100, f"Expected 100-ft discrepancy, got {dec} for {alt}"


class TestBitSlicingAdversarial:
    """Stress tests and boundary checks for bit manipulation utilities."""

    def test_boundary_bit_slicing(self) -> None:
        """Test MSB bit 1, LSB bit total_bits, and single bit extraction."""
        val = 0x8000000000000001
        total_bits = 64

        # MSB
        assert extract_bits(val, total_bits, 1, 1) == 1
        # LSB
        assert extract_bits(val, total_bits, 64, 64) == 1
        # Middle zero
        assert extract_bits(val, total_bits, 2, 63) == 0

    def test_invalid_bit_range_raises_value_error(self) -> None:
        """Test out of bounds bit ranges."""
        with pytest.raises(ValueError):
            extract_bits(0xFF, 8, 0, 4)  # start 0 invalid (1-based)
        with pytest.raises(ValueError):
            extract_bits(0xFF, 8, 5, 9)  # end > total_bits
        with pytest.raises(ValueError):
            extract_bits(0xFF, 8, 6, 4)  # start > end

    def test_set_bits_overflow_and_bounds(self) -> None:
        """Test set_bits validation."""
        with pytest.raises(ValueError, match="exceeds maximum"):
            set_bits(0, 8, 1, 2, 4)  # 2 bits max is 3, val is 4

    def test_bitbuffer_non_byte_aligned_misalignment(self) -> None:
        """Demonstrate that BitBuffer.from_bytes with non-multiple-of-8 total_bits misaligns."""
        # 2 bytes with MSB set: 0x80, 0x00
        raw = b"\x80\x00"
        bb = BitBuffer.from_bytes(raw, total_bits=13)
        # Because total_bits is 13, bit 1 should be MSB (1), but due to misalignment it returns 0
        extracted_bit1 = bb.extract(1, 1)
        assert extracted_bit1 == 0, "BitBuffer misaligned MSB due to non-byte-aligned total_bits"
