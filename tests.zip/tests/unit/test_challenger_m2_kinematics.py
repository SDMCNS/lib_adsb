"""Adversarial stress tests for Milestone 2 (Requirement R3: Airport Database & Terminal Procedure Kinematics).

Written by Challenger Agent (`challenger_enh_m2_1`) to empirically challenge and verify:
1. Strict runway heading hold (< 0.1° deviation) during the initial 5.0 NM departure corridor
   across diverse runway orientations, latitudes, and aircraft categories.
2. ILS final approach intercept precision (17.0 NM @ 3,000 ft aligned with runway heading < 0.1°)
   across all 31 catalog airports, high-elevation hubs, below-sea-level hubs, and reciprocal runway alignments.
3. Route extremes: ultra-short haul (<35 NM), short haul (<100 NM), transcontinental, and long haul (>6,000 NM,
   equator and date-line crossing).
4. Airport database queries: case-insensitivity, whitespace tolerance, invalid codes, malformed queries,
   and geodetic threshold-to-midpoint geometries.
5. REST API flight creation validation edge cases (octal squawk, hex address, same-airport rejection).
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from adsb.api.app import app
from adsb.constants import NM_TO_METERS
from adsb.core.geodesy import haversine_distance, initial_bearing
from adsb.synthesis.airports import (
    get_airport,
    has_airport,
    list_airports,
    search_airports,
)
from adsb.synthesis.terminal import (
    compute_glide_slope_intercept_distance_m,
)
from adsb.synthesis.trajectory import (
    FlightPhase,
    generate_terminal_routed_trajectory,
)

# ===========================================================================
# 1. Adversarial Departure Corridor & Heading Hold Stress Tests
# ===========================================================================

class TestDepartureHeadingHoldAdversarial:
    """Stress-test departure kinematics and heading hold across all runway orientations."""

    def test_all_31_airports_departure_corridor_heading_hold(self) -> None:
        """Every airport in the database must maintain heading deviation < 0.1 deg for 5.0 NM."""
        all_airports = list_airports()
        assert len(all_airports) == 31

        for apt in all_airports:
            # Pick a distinct destination
            dest = all_airports[0] if apt.icao != all_airports[0].icao else all_airports[1]
            rwy = apt.primary_runway

            states = generate_terminal_routed_trajectory(
                origin_icao=apt.icao,
                dest_icao=dest.icao,
                aircraft_type="B738",
                callsign=f"DEP_{apt.icao}",
            )

            dep_states = [
                s for s in states
                if s.phase in (FlightPhase.TAKEOFF_ROLL, FlightPhase.INITIAL_CLIMB)
            ]
            assert len(dep_states) >= 30, f"{apt.icao}: insufficient departure states ({len(dep_states)})"

            max_dist_observed_nm = 0.0
            for s in dep_states:
                dist_nm = haversine_distance(
                    rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, s.lat_deg, s.lon_deg
                ) / NM_TO_METERS
                max_dist_observed_nm = max(max_dist_observed_nm, dist_nm)

                if dist_nm < 5.0:
                    hdg_dev = abs((s.true_heading_deg - rwy.true_heading_deg + 180.0) % 360.0 - 180.0)
                    trk_dev = abs((s.true_track_deg - rwy.true_heading_deg + 180.0) % 360.0 - 180.0)
                    assert hdg_dev < 0.1, (
                        f"Airport {apt.icao} rwy {rwy.designation} (hdg {rwy.true_heading_deg}°): "
                        f"heading deviation {hdg_dev:.4f}° at distance {dist_nm:.2f} NM exceeds 0.1°"
                    )
                    assert trk_dev < 0.1, (
                        f"Airport {apt.icao} rwy {rwy.designation}: "
                        f"track deviation {trk_dev:.4f}° at distance {dist_nm:.2f} NM exceeds 0.1°"
                    )
                    assert s.roll_angle_deg == 0.0, f"{apt.icao}: non-zero roll {s.roll_angle_deg}° in corridor"
                    assert s.track_angle_rate_dps == 0.0, f"{apt.icao}: non-zero turn rate {s.track_angle_rate_dps}"

            # Verify the departure corridor genuinely spans up to ~5.0 NM
            assert max_dist_observed_nm >= 4.9, (
                f"{apt.icao}: departure corridor prematurely aborted at {max_dist_observed_nm:.2f} NM"
            )

    @pytest.mark.parametrize(
        "aircraft_type",
        ["A320", "B350", "B738", "B77W", "C172", "CONC", "DH8D", "E75L", "EC35", "F16", "GLID", "R44", "SR22"],
    )
    def test_departure_heading_hold_across_aircraft_categories(self, aircraft_type: str) -> None:
        """Verify heading hold (<0.1 deg) across all aircraft categories from gliders to supersonic."""
        states = generate_terminal_routed_trajectory(
            origin_icao="EGLL",
            dest_icao="LFPG",
            aircraft_type=aircraft_type,
            callsign=f"TST{aircraft_type[:4]}",
        )
        rwy = get_airport("EGLL").primary_runway

        dep_states = [
            s for s in states
            if s.phase in (FlightPhase.TAKEOFF_ROLL, FlightPhase.INITIAL_CLIMB)
        ]
        assert len(dep_states) > 0

        for s in dep_states:
            dist_nm = haversine_distance(
                rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, s.lat_deg, s.lon_deg
            ) / NM_TO_METERS
            if dist_nm < 5.0:
                assert abs(s.true_heading_deg - rwy.true_heading_deg) < 0.1
                assert abs(s.true_track_deg - rwy.true_heading_deg) < 0.1
                assert s.roll_angle_deg == 0.0


# ===========================================================================
# 2. Adversarial ILS Intercept Precision Stress Tests
# ===========================================================================

class TestIlsInterceptPrecisionAdversarial:
    """Stress-test ILS intercept precision (17 NM @ 3,000 ft aligned with runway) across hubs."""

    def test_all_31_airports_ils_intercept_precision(self) -> None:
        """Every airport in the database must receive arrivals intercepting ILS at 17.0 NM @ 3,000 ft."""
        all_airports = list_airports()

        for apt in all_airports:
            origin = all_airports[0] if apt.icao != all_airports[0].icao else all_airports[1]
            rwy = apt.primary_runway

            states = generate_terminal_routed_trajectory(
                origin_icao=origin.icao,
                dest_icao=apt.icao,
                aircraft_type="A320",
                callsign=f"ARR_{apt.icao}",
            )

            approach_states = [s for s in states if s.phase == FlightPhase.APPROACH]
            assert len(approach_states) > 0, f"{apt.icao}: no approach phase states generated"

            s_int = approach_states[0]
            dist_int_nm = haversine_distance(
                rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, s_int.lat_deg, s_int.lon_deg
            ) / NM_TO_METERS

            # Assert 17.0 NM +/- 0.1 NM intercept distance
            assert abs(dist_int_nm - 17.0) < 0.1, (
                f"{apt.icao} rwy {rwy.designation}: ILS intercept distance {dist_int_nm:.3f} NM is not 17.0 NM"
            )

            # Assert 3,000 ft +/- 25 ft intercept altitude
            assert abs(s_int.alt_baro_ft - 3000.0) < 25.0, (
                f"{apt.icao}: ILS intercept altitude {s_int.alt_baro_ft:.1f} ft is not 3,000 ft"
            )

            # Assert track alignment with runway heading (< 0.1 deg)
            trk_dev = abs((s_int.true_track_deg - rwy.true_heading_deg + 180.0) % 360.0 - 180.0)
            assert trk_dev < 0.1, (
                f"{apt.icao}: ILS intercept track {s_int.true_track_deg}° deviates from runway {rwy.true_heading_deg}°"
            )

            # Touchdown verification
            rollout_states = [s for s in states if s.phase == FlightPhase.LANDING_ROLLOUT]
            assert len(rollout_states) > 0, f"{apt.icao}: no landing rollout states"
            s_td = rollout_states[0]
            td_miss_m = haversine_distance(
                rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, s_td.lat_deg, s_td.lon_deg
            )
            assert td_miss_m < 50.0, (
                f"{apt.icao}: touchdown miss distance {td_miss_m:.2f} m exceeds 50 m limit"
            )
            assert abs(s_td.alt_baro_ft - apt.elevation_ft) < 10.0, (
                f"{apt.icao}: touchdown altitude {s_td.alt_baro_ft:.1f} ft vs aerodrome elevation {apt.elevation_ft:.1f} ft"
            )

    def test_ils_glide_slope_geometry_solver(self) -> None:
        """Verify mathematical solver for ILS 3.0-degree glide slope intercept distance."""
        # For sea-level: 3000 ft * 0.3048 / tan(3 deg) ~ 17448.2 m ~ 9.421 NM
        d_sea = compute_glide_slope_intercept_distance_m(0.0, 3000.0, 3.0)
        assert abs(d_sea / NM_TO_METERS - 9.421) < 0.01

        # For LEMD (elev = 2001.3 ft): delta_h = 998.7 ft -> 304.4 m -> 5808.7 m ~ 3.136 NM
        d_lemd = compute_glide_slope_intercept_distance_m(2001.3, 3000.0, 3.0)
        assert abs(d_lemd / NM_TO_METERS - 3.136) < 0.01

        # For an airport above 3000 ft, delta_h is 0, distance is 0 m (immediate descent)
        d_high = compute_glide_slope_intercept_distance_m(3500.0, 3000.0, 3.0)
        assert d_high == 0.0


# ===========================================================================
# 3. Route Extremes: Short, Long, High-Elevation, Below Sea Level, Reciprocal
# ===========================================================================

class TestRouteExtremesAndElevations:
    """Stress-test extreme route profiles, elevations, and runway alignments."""

    def test_ultra_short_route_rjaa_to_rjtt(self) -> None:
        """Ultra-short route Narita -> Haneda (32.3 NM) with reciprocal runway orientations."""
        states = generate_terminal_routed_trajectory(
            origin_icao="RJAA",
            dest_icao="RJTT",
            aircraft_type="B738",
            callsign="ANA32",
        )
        assert len(states) > 500
        # Cruise altitude must be heavily capped (below 8,000 ft) to fit profile
        max_alt = max(s.alt_baro_ft for s in states)
        assert max_alt <= 8000.0

        phases = {s.phase for s in states}
        assert FlightPhase.TAKEOFF_ROLL in phases
        assert FlightPhase.INITIAL_CLIMB in phases
        assert FlightPhase.APPROACH in phases
        assert FlightPhase.LANDING_ROLLOUT in phases

    def test_long_haul_cross_equator_and_dateline_yssy_to_klax(self) -> None:
        """Long-haul transpacific route Sydney -> Los Angeles (~6,500 NM) crossing equator."""
        states = generate_terminal_routed_trajectory(
            origin_icao="YSSY",
            dest_icao="KLAX",
            aircraft_type="B77W",
            callsign="QFA11",
            cruise_alt_ft=38000.0,
        )
        assert len(states) > 40000

        # Departure corridor holds Sydney 16R heading (155.0 deg)
        dep_rwy = get_airport("YSSY").primary_runway
        dep_states = [s for s in states if s.phase in (FlightPhase.TAKEOFF_ROLL, FlightPhase.INITIAL_CLIMB)]
        for s in dep_states:
            dist_nm = haversine_distance(
                dep_rwy.midpoint_lat_deg, dep_rwy.midpoint_lon_deg, s.lat_deg, s.lon_deg
            ) / NM_TO_METERS
            if dist_nm < 5.0:
                assert abs(s.true_heading_deg - dep_rwy.true_heading_deg) < 0.1

        # Arrival intercepts Los Angeles 25R (249.0 deg) at 17.0 NM @ 3,000 ft
        arr_rwy = get_airport("KLAX").primary_runway
        app_states = [s for s in states if s.phase == FlightPhase.APPROACH]
        s_int = app_states[0]
        dist_nm = haversine_distance(
            arr_rwy.midpoint_lat_deg, arr_rwy.midpoint_lon_deg, s_int.lat_deg, s_int.lon_deg
        ) / NM_TO_METERS
        assert abs(dist_nm - 17.0) < 0.1
        assert abs(s_int.alt_baro_ft - 3000.0) < 25.0
        assert abs(s_int.true_track_deg - arr_rwy.true_heading_deg) < 0.1

    def test_high_elevation_hub_madrid_barajas(self) -> None:
        """Arrival at LEMD (elevation 2,001.3 ft MSL) correctly levels at 3,000 ft and touches down at 2,001 ft."""
        states = generate_terminal_routed_trajectory(
            origin_icao="LFPG",
            dest_icao="LEMD",
            aircraft_type="A320",
            callsign="IBE3401",
        )
        lemd = get_airport("LEMD")
        rwy = lemd.primary_runway

        app_states = [s for s in states if s.phase == FlightPhase.APPROACH]
        s_int = app_states[0]
        assert abs(s_int.alt_baro_ft - 3000.0) < 25.0
        assert abs(s_int.true_track_deg - rwy.true_heading_deg) < 0.1

        td_states = [s for s in states if s.phase == FlightPhase.LANDING_ROLLOUT]
        s_td = td_states[0]
        assert abs(s_td.alt_baro_ft - lemd.elevation_ft) < 10.0

    def test_below_sea_level_hub_amsterdam_schiphol(self) -> None:
        """Departure and arrival at EHAM (-11.0 ft MSL) handles negative elevation seamlessly."""
        states = generate_terminal_routed_trajectory(
            origin_icao="EGLL",
            dest_icao="EHAM",
            aircraft_type="B738",
            callsign="KLM1001",
        )
        eham = get_airport("EHAM")
        rwy = eham.primary_runway

        td_states = [s for s in states if s.phase == FlightPhase.LANDING_ROLLOUT]
        assert len(td_states) > 0
        s_td = td_states[0]
        # Aerodrome elevation is -11.0 ft MSL (-3.35 m)
        assert abs(s_td.alt_baro_ft - eham.elevation_ft) < 10.0
        assert s_td.alt_msl_m < 0.0
        miss_m = haversine_distance(
            rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, s_td.lat_deg, s_td.lon_deg
        )
        assert miss_m < 50.0

    def test_reciprocal_opposing_runway_alignment(self) -> None:
        """EGLL (departing west 269.8°) flying east to EDDF (arriving west 249.0°)."""
        states = generate_terminal_routed_trajectory(
            origin_icao="EGLL",
            dest_icao="EDDF",
            aircraft_type="A320",
            callsign="DLH901",
        )
        egll_rwy = get_airport("EGLL").primary_runway
        eddf_rwy = get_airport("EDDF").primary_runway

        # Initial climb is strictly westward along 269.8°
        dep_states = [s for s in states if s.phase == FlightPhase.INITIAL_CLIMB]
        s_init = dep_states[10]
        assert abs(s_init.true_heading_deg - egll_rwy.true_heading_deg) < 0.1

        # Approach intercepts Frankfurt from the east, heading west-southwest along 249.0°
        app_states = [s for s in states if s.phase == FlightPhase.APPROACH]
        s_app = app_states[0]
        assert abs(s_app.true_track_deg - eddf_rwy.true_heading_deg) < 0.1
        assert abs(s_app.alt_baro_ft - 3000.0) < 25.0


# ===========================================================================
# 4. Airport Database Robustness & Malformed Query Stress Tests
# ===========================================================================

class TestAirportDatabaseAdversarialRobustness:
    """Stress-test database query normalization, edge cases, and geodetic data integrity."""

    @pytest.mark.parametrize(
        ("raw_code", "expected_icao"),
        [
            ("egll", "EGLL"),
            ("EGLL", "EGLL"),
            ("EgLl", "EGLL"),
            ("  egll  ", "EGLL"),
            ("\t\negll\r\n", "EGLL"),
            ("lhr", "EGLL"),
            ("LHR", "EGLL"),
            (" LhR \t", "EGLL"),
            ("eham", "EHAM"),
            ("ams", "EHAM"),
            ("jfk", "KJFK"),
            ("KJFK", "KJFK"),
            ("syd", "YSSY"),
            ("YSSY", "YSSY"),
        ],
    )
    def test_airport_lookup_case_and_whitespace_insensitivity(
        self, raw_code: str, expected_icao: str
    ) -> None:
        """Lookup must tolerate arbitrary case, leading/trailing whitespace, and tabs."""
        apt = get_airport(raw_code)
        assert apt.icao == expected_icao
        assert has_airport(raw_code) is True

    @pytest.mark.parametrize(
        "invalid_code",
        [
            "ZZZZ",
            "1234",
            "ABCD",
            "XX",
            "TOOLONGCODE",
            "EGLL;",
            "<script>",
            "EGLL\x00",
            "LHRX",
        ],
    )
    def test_airport_lookup_invalid_codes_raise_keyerror(self, invalid_code: str) -> None:
        """Non-existent or malformed airport codes must raise KeyError."""
        with pytest.raises(KeyError):
            get_airport(invalid_code)
        assert has_airport(invalid_code) is False

    @pytest.mark.parametrize("empty_input", ["", "   ", "\t\t", "\n\r"])
    def test_airport_lookup_empty_or_whitespace_raises_valueerror(self, empty_input: str) -> None:
        """Empty or whitespace-only strings must raise ValueError."""
        with pytest.raises(ValueError, match="non-empty string"):
            get_airport(empty_input)
        assert has_airport(empty_input) is False

    @pytest.mark.parametrize("non_string", [None, 1234, 3.14, [], {}, True])
    def test_airport_lookup_non_string_types_rejected(self, non_string: object) -> None:
        """Non-string types must raise ValueError or return False in has_airport."""
        with pytest.raises(ValueError):
            get_airport(non_string)  # type: ignore[arg-type]
        assert has_airport(non_string) is False  # type: ignore[arg-type]

    def test_search_airports_adversarial_queries(self) -> None:
        """Search query handles None, empty, whitespace, special chars, and partial tokens."""
        # Whitespace / None / empty query returns full database
        assert len(search_airports("")) == 31
        assert len(search_airports("   ")) == 31
        assert len(search_airports(None)) == 31  # type: ignore[arg-type]

        # Case-insensitive substring matching
        assert len(search_airports("pArIs")) == 1
        assert search_airports("pArIs")[0].icao == "LFPG"

        # Regex / special characters do not crash
        assert len(search_airports(".*")) == 0
        assert len(search_airports("[A-Z]")) == 0
        assert len(search_airports("!@#$%^&*()")) == 0

    def test_all_31_airports_runway_geometry_precision(self) -> None:
        """Mathematically verify runway threshold, midpoint, and true heading consistency."""
        for apt in list_airports():
            rwy = apt.primary_runway
            # Threshold to midpoint distance must equal exactly length_m / 2 within 1 meter
            d_mid = haversine_distance(
                rwy.threshold_lat, rwy.threshold_lon, rwy.midpoint_lat, rwy.midpoint_lon
            )
            expected_half_len = rwy.length_m / 2.0
            assert abs(d_mid - expected_half_len) < 1.0, (
                f"{apt.icao} rwy {rwy.designation}: threshold to midpoint distance {d_mid:.2f} m "
                f"differs from half length {expected_half_len:.2f} m"
            )

            # Bearing from threshold to midpoint must match true_heading_deg within 0.2 deg
            brg = initial_bearing(
                rwy.threshold_lat, rwy.threshold_lon, rwy.midpoint_lat, rwy.midpoint_lon
            )
            brg_diff = abs((brg - rwy.true_heading_deg + 180.0) % 360.0 - 180.0)
            assert brg_diff < 0.2, (
                f"{apt.icao} rwy {rwy.designation}: calculated bearing {brg:.2f}° "
                f"differs from true heading {rwy.true_heading_deg}°"
            )


# ===========================================================================
# 5. REST API Flight Creation Adversarial Validation Tests
# ===========================================================================

class TestFlightCreationApiAdversarial:
    """Stress-test REST API payload validation and edge case rejection."""

    @pytest.fixture
    def client(self) -> TestClient:
        return TestClient(app)

    def test_flight_creation_same_origin_and_destination_rejected(self, client: TestClient) -> None:
        """Flight creation where origin == destination must return HTTP 400 Bad Request."""
        resp = client.post(
            "/api/v1/flights",
            json={
                "origin_icao": "EGLL",
                "destination_icao": "EGLL",
                "aircraft_type": "B738",
            },
        )
        assert resp.status_code == 400
        assert "different" in resp.json()["detail"].lower()

    def test_flight_creation_invalid_squawk_code(self, client: TestClient) -> None:
        """Squawk codes containing non-octal digits (e.g. 8 or 9) or invalid length must return 400."""
        for bad_sq in ["8900", "7788", "123", "12345", "ABCD"]:
            resp = client.post(
                "/api/v1/flights",
                json={
                    "origin_icao": "EGLL",
                    "destination_icao": "LFPG",
                    "aircraft_type": "B738",
                    "squawk": bad_sq,
                },
            )
            assert resp.status_code == 400, f"Expected 400 for bad squawk {bad_sq}"
            assert "squawk" in resp.json()["detail"].lower()

    def test_flight_creation_invalid_icao_hex(self, client: TestClient) -> None:
        """ICAO 24-bit hex addresses with invalid hex chars or length must return 400."""
        for bad_hex in ["XYZ123", "12345", "1234567", "GGGGGG"]:
            resp = client.post(
                "/api/v1/flights",
                json={
                    "origin_icao": "EGLL",
                    "destination_icao": "LFPG",
                    "aircraft_type": "B738",
                    "icao_hex": bad_hex,
                },
            )
            assert resp.status_code == 400, f"Expected 400 for bad icao_hex {bad_hex}"
            assert "hex" in resp.json()["detail"].lower()

    def test_flight_creation_unknown_airports_and_aircraft(self, client: TestClient) -> None:
        """Unknown airport codes or aircraft types return 400."""
        resp1 = client.post(
            "/api/v1/flights",
            json={"origin_icao": "ZZZZ", "destination_icao": "LFPG", "aircraft_type": "B738"},
        )
        assert resp1.status_code == 400
        assert "origin" in resp1.json()["detail"].lower()

        resp2 = client.post(
            "/api/v1/flights",
            json={"origin_icao": "EGLL", "destination_icao": "ZZZZ", "aircraft_type": "B738"},
        )
        assert resp2.status_code == 400
        assert "destination" in resp2.json()["detail"].lower()

        resp3 = client.post(
            "/api/v1/flights",
            json={"origin_icao": "EGLL", "destination_icao": "LFPG", "aircraft_type": "SPACESHIP"},
        )
        assert resp3.status_code == 400
        assert "aircraft type" in resp3.json()["detail"].lower()
