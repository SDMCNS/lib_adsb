"""Adversarial and empirical stress tests for SquitterScheduler and MultiAircraftScheduler.

Verifies:
1. CPR Format strict alternation (0 -> 1 -> 0 -> 1) across long trajectories, ground/air
   transitions, and varying random seeds.
2. Uniform random jitter distribution: position and velocity squitter intervals strictly
   in [0.40, 0.60] s, initial offsets, and Kolmogorov-Smirnov uniformity tests.
3. Default emitted frame size (14 bytes DF17) ensuring 100% compatibility with Beast binary
   frame_type="3" streaming without stream desynchronization.
4. Linear state interpolation at t_tx: verifies continuity (no step jumps at 1s intervals),
   anti-meridian longitude wrapping, track wrapping through 0/360, and endpoint clamping.
5. MultiAircraftScheduler: chronological event sorting (timestamp_s and timestamp_ns monotonicity)
   and proper aircraft interleaving across 10-aircraft and 25-aircraft scenarios.
6. Deterministic RNG seeding: 100% byte-for-byte reproducibility of squitter event streams.
"""

from __future__ import annotations

import math

import numpy as np
from scipy import stats  # type: ignore[import-untyped]

from adsb.protocol.modes import decode_mode_s
from adsb.synthesis.performance import get_aircraft_profile
from adsb.synthesis.scenario import load_scenario
from adsb.synthesis.scheduler import (
    MultiAircraftScheduler,
    SquitterScheduler,
    _interpolate_state,
)
from adsb.synthesis.trajectory import (
    AircraftTruthState,
    FlightPhase,
    generate_simple_climb_trajectory,
    generate_straight_flight,
)
from adsb.wire.beast import parse_beast_stream, serialize_beast_frame

# ==============================================================================
# Helper Factories
# ==============================================================================


def _build_ground_to_air_trajectory(duration_s: float = 60.0) -> list[AircraftTruthState]:
    """Construct a trajectory that transitions from ground (taxi/takeoff) to airborne."""
    states: list[AircraftTruthState] = []
    for t in range(int(duration_s) + 1):
        t_s = float(t)
        on_ground = t_s < 20.0  # Takeoff roll at t=20s
        speed_kt = 20.0 + t_s * 3.0 if on_ground else 80.0 + (t_s - 20.0) * 4.0
        alt_baro_ft = 0.0 if on_ground else (t_s - 20.0) * 50.0
        vr_fpm = 0.0 if on_ground else 3000.0

        states.append(
            AircraftTruthState(
                timestamp_s=t_s,
                lat_deg=52.3105 + t_s * 0.0001,
                lon_deg=4.7683 + t_s * 0.0001,
                alt_msl_m=alt_baro_ft * 0.3048,
                alt_hae_m=alt_baro_ft * 0.3048,
                alt_baro_ft=alt_baro_ft,
                groundspeed_mps=speed_kt * 0.514444,
                tas_mps=speed_kt * 0.514444,
                ias_mps=speed_kt * 0.514444,
                mach=0.2,
                true_track_deg=45.0,
                true_heading_deg=45.0,
                vertical_rate_baro_mps=vr_fpm * 0.00508,
                phase=FlightPhase.TAKEOFF_ROLL if on_ground else FlightPhase.INITIAL_CLIMB,
                on_ground=on_ground,
            )
        )
    return states


# ==============================================================================
# 1. CPR Format Strict Alternation Tests
# ==============================================================================


class TestCPRParityStrictAlternation:
    """Stress tests verifying that position message CPR format strictly alternates 0 -> 1 -> 0 -> 1."""

    def test_cpr_alternation_continuous_airborne_long_flight(self) -> None:
        """Verify strict CPR format alternation over a 300s flight (>500 position frames)."""
        rng = np.random.default_rng(101)
        b738 = get_aircraft_profile("B738")
        states = generate_simple_climb_trajectory(
            profile=b738,
            origin_lat=52.3105,
            origin_lon=4.7683,
            target_alt_ft=30000.0,
            duration_s=300.0,
            rng=rng,
        )

        scheduler = SquitterScheduler(icao24=0x4840A1, callsign="KLM300", rng=rng)
        events = scheduler.generate_squitters(states)

        cpr_formats: list[int] = []
        for ev in events:
            decoded = decode_mode_s(ev.raw_bytes)
            if decoded.tc == 11:
                # Direct check on decoded struct
                cpr_formats.append(decoded.cpr_format)
                # Bit-level verification: in 1090ES DF17, CPR format is Bit 54 (ME Bit 22)
                # In 14-byte frame, Byte 6 contains ME bits 17..24. Bit 22 is bit index 2 from LSB (mask 0x04)
                raw_cpr = (ev.raw_bytes[6] >> 2) & 1
                assert decoded.cpr_format == raw_cpr

        assert len(cpr_formats) >= 500
        # First position message must start at 0 (Even)
        assert cpr_formats[0] == 0

        # Verify strict alternation for every single consecutive pair
        for i in range(len(cpr_formats) - 1):
            assert cpr_formats[i + 1] == 1 - cpr_formats[i], (
                f"CPR alternation violation at index {i}: cpr[{i}]={cpr_formats[i]}, cpr[{i+1}]={cpr_formats[i+1]}"
            )

    def test_cpr_alternation_ground_to_air_transition(self) -> None:
        """Verify CPR alternation is unbroken across ground-to-air transition."""
        rng = np.random.default_rng(202)
        states = _build_ground_to_air_trajectory(duration_s=60.0)

        scheduler = SquitterScheduler(icao24=0x4840A2, callsign="KLM_G2A", rng=rng)
        events = scheduler.generate_squitters(states)

        pos_events = [ev for ev in events if decode_mode_s(ev.raw_bytes).tc in (8, 11)]
        assert len(pos_events) > 80

        cpr_sequence: list[int] = []
        tc_sequence: list[int] = []
        for ev in pos_events:
            dec = decode_mode_s(ev.raw_bytes)
            cpr_sequence.append(dec.cpr_format)
            tc_sequence.append(dec.tc)

        # Must have both surface (TC 8) and airborne (TC 11) frames
        assert 8 in tc_sequence
        assert 11 in tc_sequence

        # Verify strict alternation with 0 resets or drops across the transition
        for i in range(len(cpr_sequence) - 1):
            assert cpr_sequence[i + 1] == 1 - cpr_sequence[i], (
                f"Transition CPR glitch at frame {i}: tc={tc_sequence[i]}->{tc_sequence[i+1]}, "
                f"cpr={cpr_sequence[i]}->{cpr_sequence[i+1]}"
            )

    def test_cpr_alternation_multi_seed_monte_carlo(self) -> None:
        """Verify strict CPR alternation across 20 distinct random seeds."""
        for seed in range(500, 520):
            rng = np.random.default_rng(seed)
            states = generate_straight_flight(
                start_lat=40.0,
                start_lon=-74.0,
                heading_deg=90.0,
                speed_kt=450.0,
                alt_ft=35000.0,
                duration_s=40.0,
                rng=rng,
            )
            scheduler = SquitterScheduler(icao24=0x484000 + seed, callsign=f"TST{seed}", rng=rng)
            events = scheduler.generate_squitters(states)
            cprs = [decode_mode_s(ev.raw_bytes).cpr_format for ev in events if decode_mode_s(ev.raw_bytes).tc == 11]

            assert len(cprs) > 60
            for i in range(len(cprs) - 1):
                assert cprs[i + 1] == 1 - cprs[i]


# ==============================================================================
# 2. Uniform Random Jitter Distribution Tests
# ==============================================================================


class TestJitterDistributionsAndTiming:
    """Stress tests verifying uniform random jitter bounds, distribution, and timers."""

    def test_position_squitter_interval_bounds_and_uniformity(self) -> None:
        """Verify airborne position squitter intervals are strictly in [0.40, 0.60] s and uniform."""
        rng = np.random.default_rng(303)
        # Long trajectory to collect a large sample of intervals
        states = generate_straight_flight(
            start_lat=52.0,
            start_lon=4.0,
            heading_deg=180.0,
            speed_kt=400.0,
            alt_ft=30000.0,
            duration_s=600.0,
            rng=rng,
        )

        scheduler = SquitterScheduler(icao24=0x4840B1, callsign="JITPOS", rng=rng)
        events = scheduler.generate_squitters(states)

        pos_timestamps = [
            ev.timestamp_s for ev in events if decode_mode_s(ev.raw_bytes).tc == 11
        ]
        assert len(pos_timestamps) >= 1000

        intervals = np.diff(pos_timestamps)

        # 1. Strict mathematical bounds check
        min_interval = float(np.min(intervals))
        max_interval = float(np.max(intervals))
        assert min_interval >= 0.40 - 1e-9, f"Position interval underflow: {min_interval} < 0.40"
        assert max_interval <= 0.60 + 1e-9, f"Position interval overflow: {max_interval} > 0.60"

        # 2. Empirical moments check for Uniform(0.40, 0.60)
        # Expected mean = 0.50 s, expected variance = (0.60 - 0.40)^2 / 12 = 0.04 / 12 = 0.003333...
        mean_val = float(np.mean(intervals))
        var_val = float(np.var(intervals))
        assert 0.490 <= mean_val <= 0.510, f"Empirical mean deviated: {mean_val}"
        assert 0.0028 <= var_val <= 0.0039, f"Empirical variance deviated: {var_val}"

        # 3. Kolmogorov-Smirnov test against Uniform(loc=0.40, scale=0.20)
        ks_res = stats.kstest(intervals, "uniform", args=(0.40, 0.20))
        assert ks_res.pvalue > 0.01, f"Rejected uniformity hypothesis (p-value={ks_res.pvalue})"

    def test_velocity_squitter_interval_bounds_and_uniformity(self) -> None:
        """Verify airborne velocity squitter intervals are strictly in [0.40, 0.60] s and uniform."""
        rng = np.random.default_rng(404)
        states = generate_straight_flight(
            start_lat=52.0,
            start_lon=4.0,
            heading_deg=180.0,
            speed_kt=400.0,
            alt_ft=30000.0,
            duration_s=600.0,
            rng=rng,
        )

        scheduler = SquitterScheduler(icao24=0x4840B2, callsign="JITVEL", rng=rng)
        events = scheduler.generate_squitters(states)

        vel_timestamps = [
            ev.timestamp_s for ev in events if decode_mode_s(ev.raw_bytes).tc == 19
        ]
        assert len(vel_timestamps) >= 1000

        intervals = np.diff(vel_timestamps)

        # 1. Strict bounds
        min_interval = float(np.min(intervals))
        max_interval = float(np.max(intervals))
        assert min_interval >= 0.40 - 1e-9, f"Velocity interval underflow: {min_interval} < 0.40"
        assert max_interval <= 0.60 + 1e-9, f"Velocity interval overflow: {max_interval} > 0.60"

        # 2. Empirical moments
        mean_val = float(np.mean(intervals))
        var_val = float(np.var(intervals))
        assert 0.490 <= mean_val <= 0.510
        assert 0.0028 <= var_val <= 0.0039

        # 3. Kolmogorov-Smirnov test
        ks_res = stats.kstest(intervals, "uniform", args=(0.40, 0.20))
        assert ks_res.pvalue > 0.01

    def test_initial_jitter_phase_offsets(self) -> None:
        """Verify initial transmission phase jitter across 100 runs."""
        pos_offsets: list[float] = []
        vel_offsets: list[float] = []
        id_offsets: list[float] = []

        for seed in range(100):
            rng = np.random.default_rng(seed)
            states = generate_straight_flight(
                start_lat=52.0,
                start_lon=4.0,
                heading_deg=90.0,
                speed_kt=250.0,
                alt_ft=10000.0,
                duration_s=5.0,
                rng=rng,
            )
            scheduler = SquitterScheduler(icao24=0x4840C1, callsign="INITJIT", rng=rng)
            events = scheduler.generate_squitters(states)

            # First events of each TC
            first_pos = next(ev for ev in events if decode_mode_s(ev.raw_bytes).tc == 11)
            first_vel = next(ev for ev in events if decode_mode_s(ev.raw_bytes).tc == 19)
            first_id = next(ev for ev in events if decode_mode_s(ev.raw_bytes).tc == 4)

            pos_offsets.append(first_pos.timestamp_s)
            vel_offsets.append(first_vel.timestamp_s)
            id_offsets.append(first_id.timestamp_s)

        # DO-260B / scheduler specifications:
        # pos: uniform(0.0, 0.20)
        # vel: uniform(0.10, 0.30)
        # id:  uniform(0.0, 0.50)
        assert min(pos_offsets) >= 0.0 and max(pos_offsets) <= 0.20
        assert min(vel_offsets) >= 0.10 and max(vel_offsets) <= 0.30
        assert min(id_offsets) >= 0.0 and max(id_offsets) <= 0.50

    def test_identification_squitter_intervals(self) -> None:
        """Verify identification squitter interval in [4.80, 5.20] s for airborne aircraft."""
        rng = np.random.default_rng(505)
        states = generate_straight_flight(
            start_lat=52.0,
            start_lon=4.0,
            heading_deg=90.0,
            speed_kt=300.0,
            alt_ft=20000.0,
            duration_s=300.0,
            rng=rng,
        )
        scheduler = SquitterScheduler(icao24=0x4840C2, callsign="IDINT", rng=rng)
        events = scheduler.generate_squitters(states)

        id_timestamps = [
            ev.timestamp_s for ev in events if decode_mode_s(ev.raw_bytes).tc == 4
        ]
        assert len(id_timestamps) >= 50

        intervals = np.diff(id_timestamps)
        assert float(np.min(intervals)) >= 4.80 - 1e-9
        assert float(np.max(intervals)) <= 5.20 + 1e-9


# ==============================================================================
# 3. Default Frame Size & Beast Binary Compatibility Tests
# ==============================================================================


class TestDefaultFrameSizeAndBeastStreamCompatibility:
    """Stress tests verifying that default frames are strictly 14 bytes (DF17) with 0 Beast desync."""

    def test_all_default_frames_are_strictly_14_bytes_df17(self) -> None:
        """Verify 100% of emitted frames with default settings are 14 bytes with DF=17."""
        rng = np.random.default_rng(601)
        profiles = ["B738", "A320", "C172", "EC35"]
        for p_name in profiles:
            prof = get_aircraft_profile(p_name)
            states = generate_simple_climb_trajectory(
                profile=prof,
                origin_lat=52.3105,
                origin_lon=4.7683,
                target_alt_ft=min(12000.0, prof.service_ceiling_ft),
                duration_s=40.0,
                rng=rng,
            )
            scheduler = SquitterScheduler(icao24=0x484100, callsign=p_name, rng=rng)
            # Default options: include_df11=False, enable_uat=False
            assert not scheduler.include_df11
            assert not scheduler.enable_uat

            events = scheduler.generate_squitters(states)
            assert len(events) > 50

            for ev in events:
                # Byte length must be 14
                assert len(ev.raw_bytes) == 14, f"Frame length {len(ev.raw_bytes)} != 14"
                # Downlink Format must be DF17 (Bit 1..5 = 17 = 0b10001)
                df = ev.raw_bytes[0] >> 3
                assert df == 17, f"Downlink format {df} != 17"

    def test_beast_binary_streaming_zero_desynchronization(self) -> None:
        """Verify seamless Beast binary frame_type='3' stream parsing across 1500+ frames."""
        rng = np.random.default_rng(602)
        states = generate_straight_flight(
            start_lat=52.3105,
            start_lon=4.7683,
            heading_deg=45.0,
            speed_kt=300.0,
            alt_ft=15000.0,
            duration_s=300.0,
            rng=rng,
        )
        scheduler = SquitterScheduler(icao24=0x484200, callsign="BEAST3", rng=rng)
        events = scheduler.generate_squitters(states)
        assert len(events) >= 1000

        # Serialize all emitted frames into a single continuous Beast binary stream
        stream_chunks: list[bytes] = []
        for ev in events:
            # 12 MHz Beast timestamp (approx 48-bit timestamp)
            beast_ts = int(ev.timestamp_s * 12_000_000) & 0xFFFFFFFFFFFF
            rssi = 150  # -75 dBm
            frame_wire = serialize_beast_frame(
                frame_type="3",
                mlat_timestamp=beast_ts,
                rssi_byte=rssi,
                payload=ev.raw_bytes,
            )
            stream_chunks.append(frame_wire)

        full_stream = b"".join(stream_chunks)

        # Parse full stream back
        parsed_frames = parse_beast_stream(full_stream)

        # Zero dropped frames, zero stream desynchronization
        assert len(parsed_frames) == len(events), (
            f"Beast stream desynchronization: expected {len(events)} frames, parsed {len(parsed_frames)}"
        )

        for original_ev, parsed in zip(events, parsed_frames):
            assert parsed.frame_type == "3"
            assert parsed.payload == original_ev.raw_bytes
            assert len(parsed.payload) == 14

    def test_df11_framing_contrast(self) -> None:
        """Verify that enabling include_df11 produces 7-byte frames (DF11) requiring frame_type='2'."""
        rng = np.random.default_rng(603)
        states = generate_straight_flight(
            start_lat=52.0,
            start_lon=4.0,
            heading_deg=90.0,
            speed_kt=200.0,
            alt_ft=5000.0,
            duration_s=20.0,
            rng=rng,
        )
        scheduler = SquitterScheduler(
            icao24=0x484300,
            callsign="DF11TST",
            rng=rng,
            include_df11=True,
        )
        events = scheduler.generate_squitters(states)

        lengths = {len(ev.raw_bytes) for ev in events}
        assert lengths == {7, 14}, f"Expected lengths {7, 14}, got {lengths}"

        df11_events = [ev for ev in events if len(ev.raw_bytes) == 7]
        assert len(df11_events) > 10
        for ev in df11_events:
            df = ev.raw_bytes[0] >> 3
            assert df == 11


# ==============================================================================
# 4. State Linear Interpolation at Transmission Time Tests
# ==============================================================================


class TestStateInterpolationAtTx:
    """Stress tests verifying linear state interpolation at irregular transmission times."""

    def test_interpolation_fine_resolution_continuity(self) -> None:
        """Verify no step jump or discontinuity across 1-second state boundaries."""
        # Create discrete 1-second trajectory states with constant climb and turn
        states: list[AircraftTruthState] = []
        for t in range(5):
            states.append(
                AircraftTruthState(
                    timestamp_s=float(t),
                    lat_deg=52.0 + t * 0.01,
                    lon_deg=4.0 + t * 0.015,
                    alt_msl_m=1000.0 + t * 50.0,
                    alt_hae_m=1000.0 + t * 50.0,
                    alt_baro_ft=3280.84 + t * 164.042,
                    groundspeed_mps=150.0 + t * 2.0,
                    tas_mps=150.0 + t * 2.0,
                    ias_mps=140.0 + t * 2.0,
                    mach=0.45,
                    true_track_deg=(60.0 + t * 5.0) % 360.0,
                    true_heading_deg=(60.0 + t * 5.0) % 360.0,
                    vertical_rate_baro_mps=10.0,
                    phase=FlightPhase.ENROUTE_CLIMB,
                    on_ground=False,
                )
            )

        # Sample at fine grid around boundary t = 1.0 s
        t_samples = np.linspace(0.8, 1.2, 81)  # step = 0.005 s
        interpolated = [_interpolate_state(states, float(t)) for t in t_samples]

        altitudes = [res[2] for res in interpolated]
        latitudes = [res[0] for res in interpolated]
        longitudes = [res[1] for res in interpolated]
        speeds = [res[3] for res in interpolated]
        tracks = [res[4] for res in interpolated]

        # Verify derivative / difference continuity: max absolute jump between 0.005s steps
        # Max expected alt change per 0.005s is 164.042 * 0.005 = ~0.82 ft
        diff_alt = np.diff(altitudes)
        assert np.all(np.abs(diff_alt - 164.042 * 0.005) < 1e-4)

        diff_lat = np.diff(latitudes)
        assert np.all(np.abs(diff_lat - 0.01 * 0.005) < 1e-6)

        diff_lon = np.diff(longitudes)
        assert np.all(np.abs(diff_lon - 0.015 * 0.005) < 1e-6)

        diff_spd = np.diff(speeds)
        expected_spd_rate_kt = (2.0 / 0.514444) * 0.005
        assert np.all(np.abs(diff_spd - expected_spd_rate_kt) < 1e-4)

        diff_trk = np.diff(tracks)
        assert np.all(np.abs(diff_trk - 5.0 * 0.005) < 1e-6)

    def test_interpolation_antimeridian_crossing(self) -> None:
        """Verify circular interpolation across the antimeridian (+179.95 to -179.95 lon)."""
        s0 = AircraftTruthState(
            timestamp_s=0.0,
            lat_deg=20.0,
            lon_deg=179.95,
            alt_msl_m=10000.0,
            alt_hae_m=10000.0,
            alt_baro_ft=32808.0,
            groundspeed_mps=250.0,
            tas_mps=250.0,
            ias_mps=240.0,
            mach=0.8,
            true_track_deg=90.0,
            true_heading_deg=90.0,
            vertical_rate_baro_mps=0.0,
            phase=FlightPhase.CRUISE,
        )
        s1 = AircraftTruthState(
            timestamp_s=1.0,
            lat_deg=20.0,
            lon_deg=-179.95,
            alt_msl_m=10000.0,
            alt_hae_m=10000.0,
            alt_baro_ft=32808.0,
            groundspeed_mps=250.0,
            tas_mps=250.0,
            ias_mps=240.0,
            mach=0.8,
            true_track_deg=90.0,
            true_heading_deg=90.0,
            vertical_rate_baro_mps=0.0,
            phase=FlightPhase.CRUISE,
        )
        states = [s0, s1]

        # Total distance is 0.10 deg eastward. At t=0.5s, lon should be exactly +/-180.0 deg
        res_mid = _interpolate_state(states, 0.5)
        lon_mid = res_mid[1]
        assert math.isclose(abs(lon_mid), 180.0, abs_tol=1e-5)

        # At t=0.25s, lon = 179.975
        res_q1 = _interpolate_state(states, 0.25)
        assert math.isclose(res_q1[1], 179.975, abs_tol=1e-5)

        # At t=0.75s, lon = -179.975
        res_q3 = _interpolate_state(states, 0.75)
        assert math.isclose(res_q3[1], -179.975, abs_tol=1e-5)

    def test_interpolation_track_angle_through_north(self) -> None:
        """Verify circular interpolation of track angle across North (355 deg to 5 deg)."""
        s0 = AircraftTruthState(
            timestamp_s=0.0,
            lat_deg=50.0,
            lon_deg=0.0,
            alt_msl_m=5000.0,
            alt_hae_m=5000.0,
            alt_baro_ft=16404.0,
            groundspeed_mps=200.0,
            tas_mps=200.0,
            ias_mps=190.0,
            mach=0.6,
            true_track_deg=355.0,
            true_heading_deg=355.0,
            vertical_rate_baro_mps=0.0,
            phase=FlightPhase.CRUISE,
        )
        s1 = AircraftTruthState(
            timestamp_s=1.0,
            lat_deg=50.0,
            lon_deg=0.0,
            alt_msl_m=5000.0,
            alt_hae_m=5000.0,
            alt_baro_ft=16404.0,
            groundspeed_mps=200.0,
            tas_mps=200.0,
            ias_mps=190.0,
            mach=0.6,
            true_track_deg=5.0,
            true_heading_deg=5.0,
            vertical_rate_baro_mps=0.0,
            phase=FlightPhase.CRUISE,
        )
        states = [s0, s1]

        # Right turn of 10 deg: at t=0.5s, track should be exactly 0.0 (360.0 % 360)
        res_mid = _interpolate_state(states, 0.5)
        track_mid = res_mid[4]
        assert math.isclose(track_mid, 0.0, abs_tol=1e-5)

        # At t=0.2s, track = 357.0 deg
        res_02 = _interpolate_state(states, 0.2)
        assert math.isclose(res_02[4], 357.0, abs_tol=1e-5)

        # At t=0.8s, track = 3.0 deg
        res_08 = _interpolate_state(states, 0.8)
        assert math.isclose(res_08[4], 3.0, abs_tol=1e-5)

    def test_interpolation_clamping_and_single_state(self) -> None:
        """Verify boundary clamping when t_tx is before t_start or after t_end."""
        s0 = AircraftTruthState(
            timestamp_s=10.0,
            lat_deg=52.0,
            lon_deg=4.0,
            alt_msl_m=1000.0,
            alt_hae_m=1000.0,
            alt_baro_ft=3280.0,
            groundspeed_mps=100.0,
            tas_mps=100.0,
            ias_mps=95.0,
            mach=0.3,
            true_track_deg=90.0,
            true_heading_deg=90.0,
            vertical_rate_baro_mps=0.0,
            phase=FlightPhase.CRUISE,
        )
        s1 = AircraftTruthState(
            timestamp_s=20.0,
            lat_deg=53.0,
            lon_deg=5.0,
            alt_msl_m=2000.0,
            alt_hae_m=2000.0,
            alt_baro_ft=6561.0,
            groundspeed_mps=120.0,
            tas_mps=120.0,
            ias_mps=115.0,
            mach=0.35,
            true_track_deg=95.0,
            true_heading_deg=95.0,
            vertical_rate_baro_mps=0.0,
            phase=FlightPhase.CRUISE,
        )

        # Single state clamping
        res_single = _interpolate_state([s0], 15.0)
        assert res_single[0] == s0.lat_deg

        # Clamping before t_start
        res_before = _interpolate_state([s0, s1], 5.0)
        assert res_before[0] == s0.lat_deg
        assert res_before[1] == s0.lon_deg

        # Clamping after t_end
        res_after = _interpolate_state([s0, s1], 25.0)
        assert res_after[0] == s1.lat_deg
        assert res_after[1] == s1.lon_deg


# ==============================================================================
# 5. MultiAircraftScheduler Scenario Emission Tests
# ==============================================================================


class TestMultiAircraftSchedulerAdversarial:
    """Stress tests verifying MultiAircraftScheduler scenario emission and sorting."""

    def test_clean_10_aircraft_strictly_chronological(self) -> None:
        """Verify clean_tma_10_aircraft emits strictly sorted events with all aircraft."""
        rng = np.random.default_rng(701)
        scenario = load_scenario("clean_tma_10_aircraft", rng=rng)
        scheduler = MultiAircraftScheduler(scenario=scenario, rng=rng)
        events = scheduler.generate_all_events()

        assert len(events) >= 1500

        # Monotonicity check on seconds and nanoseconds
        for i in range(len(events) - 1):
            assert events[i].timestamp_s <= events[i + 1].timestamp_s, (
                f"Chronological inversion at {i}: {events[i].timestamp_s} > {events[i+1].timestamp_s}"
            )
            assert events[i].timestamp_ns <= events[i + 1].timestamp_ns

        # Verify all 10 aircraft emitted squitters
        seen_icaos = {ev.icao24 for ev in events}
        expected_icaos = {ac.icao24 for ac in scenario.aircraft}
        assert seen_icaos == expected_icaos
        assert len(seen_icaos) == 10

    def test_congested_25_aircraft_strictly_chronological(self) -> None:
        """Verify congested_tma_25_aircraft emits strictly sorted events with high traffic."""
        rng = np.random.default_rng(702)
        scenario = load_scenario("congested_tma_25_aircraft", rng=rng)
        scheduler = MultiAircraftScheduler(scenario=scenario, rng=rng)
        events = scheduler.generate_all_events()

        assert len(events) >= 4000

        for i in range(len(events) - 1):
            assert events[i].timestamp_s <= events[i + 1].timestamp_s

        seen_icaos = {ev.icao24 for ev in events}
        expected_icaos = {ac.icao24 for ac in scenario.aircraft}
        assert seen_icaos == expected_icaos
        assert len(seen_icaos) == 25

    def test_multi_aircraft_traffic_interleaving(self) -> None:
        """Verify aircraft squitter events are naturally interleaved and not sequential blocks."""
        rng = np.random.default_rng(703)
        scenario = load_scenario("clean_tma_10_aircraft", rng=rng)
        scheduler = MultiAircraftScheduler(scenario=scenario, rng=rng)
        events = scheduler.generate_all_events()

        # In a 10-aircraft scenario with ~0.5s intervals, events from the same aircraft
        # should rarely occur back-to-back.
        consecutive_same_aircraft_count = 0
        for i in range(len(events) - 1):
            if events[i].icao24 == events[i + 1].icao24:
                consecutive_same_aircraft_count += 1

        # The overwhelming majority (>90%) of consecutive events should be interleaved
        interleaving_ratio = 1.0 - (consecutive_same_aircraft_count / len(events))
        assert interleaving_ratio > 0.85, f"Poor interleaving ratio: {interleaving_ratio}"


# ==============================================================================
# 6. Deterministic RNG Seeding Tests
# ==============================================================================


class TestDeterministicRNGSeeding:
    """Stress tests verifying 100% byte-for-byte reproducibility of squitter event streams."""

    def test_squitter_scheduler_byte_for_byte_reproducibility(self) -> None:
        """Verify two SquitterScheduler runs with identical seed produce 100% identical streams."""
        b738 = get_aircraft_profile("B738")

        # Run 1
        rng1 = np.random.default_rng(seed=99999)
        states1 = generate_simple_climb_trajectory(
            profile=b738,
            origin_lat=52.3105,
            origin_lon=4.7683,
            target_alt_ft=15000.0,
            duration_s=60.0,
            rng=rng1,
        )
        sched1 = SquitterScheduler(icao24=0x484999, callsign="SEED99", rng=rng1)
        events1 = sched1.generate_squitters(states1)

        # Run 2 with identical seed
        rng2 = np.random.default_rng(seed=99999)
        states2 = generate_simple_climb_trajectory(
            profile=b738,
            origin_lat=52.3105,
            origin_lon=4.7683,
            target_alt_ft=15000.0,
            duration_s=60.0,
            rng=rng2,
        )
        sched2 = SquitterScheduler(icao24=0x484999, callsign="SEED99", rng=rng2)
        events2 = sched2.generate_squitters(states2)

        assert len(events1) == len(events2)
        assert len(events1) > 100

        for idx, (e1, e2) in enumerate(zip(events1, events2)):
            assert e1.timestamp_s == e2.timestamp_s, f"Timestamp mismatch at {idx}: {e1.timestamp_s} != {e2.timestamp_s}"
            assert e1.raw_bytes == e2.raw_bytes, f"Byte mismatch at {idx}: {e1.raw_bytes.hex()} != {e2.raw_bytes.hex()}"
            assert e1.icao24 == e2.icao24
            assert e1.rf_freq_hz == e2.rf_freq_hz
            assert e1.tx_power_dbm == e2.tx_power_dbm

    def test_multi_aircraft_byte_for_byte_reproducibility(self) -> None:
        """Verify MultiAircraftScheduler with identical seed produces byte-for-byte identical scenario stream."""
        seed = 88888

        # Run 1
        rng1 = np.random.default_rng(seed=seed)
        scenario1 = load_scenario("clean_tma_10_aircraft", rng=rng1)
        sched1 = MultiAircraftScheduler(scenario=scenario1, rng=rng1)
        events1 = sched1.generate_all_events()

        # Run 2
        rng2 = np.random.default_rng(seed=seed)
        scenario2 = load_scenario("clean_tma_10_aircraft", rng=rng2)
        sched2 = MultiAircraftScheduler(scenario=scenario2, rng=rng2)
        events2 = sched2.generate_all_events()

        assert len(events1) == len(events2)
        assert len(events1) > 1500

        for e1, e2 in zip(events1, events2):
            assert e1.timestamp_s == e2.timestamp_s
            assert e1.raw_bytes == e2.raw_bytes
            assert e1.icao24 == e2.icao24

    def test_seed_sensitivity_divergence(self) -> None:
        """Verify that different seeds produce distinct jitter and timestamp streams."""
        b738 = get_aircraft_profile("B738")

        rng1 = np.random.default_rng(seed=12345)
        states1 = generate_simple_climb_trajectory(
            profile=b738,
            origin_lat=52.3105,
            origin_lon=4.7683,
            target_alt_ft=15000.0,
            duration_s=30.0,
            rng=rng1,
        )
        sched1 = SquitterScheduler(icao24=0x484123, callsign="SEED1", rng=rng1)
        events1 = sched1.generate_squitters(states1)

        rng2 = np.random.default_rng(seed=54321)
        states2 = generate_simple_climb_trajectory(
            profile=b738,
            origin_lat=52.3105,
            origin_lon=4.7683,
            target_alt_ft=15000.0,
            duration_s=30.0,
            rng=rng2,
        )
        sched2 = SquitterScheduler(icao24=0x484123, callsign="SEED1", rng=rng2)
        events2 = sched2.generate_squitters(states2)

        # Timestamps must diverge due to independent random jitter
        ts1 = [e.timestamp_s for e in events1]
        ts2 = [e.timestamp_s for e in events2]
        assert ts1 != ts2
