"""Empirical adversarial challenger stress tests for Milestone 3 Stage A.

Target modules:
- `src/adsb/impairment/avionics.py` (AV-01 through AV-07)
- `src/adsb/impairment/spoofing.py` (Ghost, Shadow, Flood, Replay injectors)
- `src/adsb/impairment/avionics_faults.py` (Re-export interface)

Author: challenger_m3_2 (teamwork_challenger subagent)
Scope:
1. CRC Parity Invariance across 1,000 randomized fault injections (AV-01..AV-07).
2. Stale GPS Latch (AV-01): State and squitter position freezing, velocity independence, and jump upon release.
3. Gillham Gray code bit stuck states (AV-04): Exhaustive 11-wire stuck bit scan, valid vs illegal Gray code dropouts.
4. CPR Zone Straddle (AV-03): Latitude straddle crossings at 51.893425 deg boundary, global failure vs local recovery.
5. GhostTrackInjector: 800 m/s kinematic trajectory, squitter scheduling, alternating CPR decoding, and velocity bounds.
6. Multi-fault combinations, simultaneous all-7 faults, boundary inputs, and spoofing stress.
"""

from __future__ import annotations

import numpy as np
import pytest

from adsb.core.bits import bytes_to_uint, extract_bits, set_bits, uint_to_bytes
from adsb.core.geodesy import haversine_distance
from adsb.impairment.avionics import (
    GILLHAM_WIRE_BITS,
    AltitudeInversionConfig,
    AvionicsFaultConfig,
    AvionicsFaultInjector,
    CPRDesyncConfig,
    CPRDesyncMode,
    CPRStraddleConfig,
    DuplicateICAOConfig,
    GillhamGlitchConfig,
    GPSJammingConfig,
    StaleGPSConfig,
    apply_cpr_straddle_fault,
    apply_gillham_stuck_bit_fault,
    apply_stale_gps_fault,
    apply_stale_gps_to_states,
    recompute_frame_crc,
)
from adsb.impairment.spoofing import (
    FloodDenialInjector,
    GhostTrackInjector,
    ReplayInjector,
    ShadowTrackHijacker,
)
from adsb.protocol.cpr import (
    decode_cpr_global_airborne,
    decode_cpr_local,
    nl_lat,
)
from adsb.protocol.crc import compute_syndrome, verify_crc24
from adsb.protocol.gillham import decode_gillham_altitude, encode_gillham_altitude
from adsb.protocol.modes import (
    decode_mode_s,
    encode_1090es_airborne_position,
    encode_1090es_airborne_velocity,
    encode_1090es_df11,
    encode_1090es_identification,
)
from adsb.synthesis.scheduler import SquitterEvent
from adsb.synthesis.trajectory import AircraftTruthState, FlightPhase

# ==============================================================================
# Helper Factories
# ==============================================================================


def _create_synthetic_squitter_pool(
    icao24: int = 0x4840D6,
    base_lat: float = 52.3105,
    base_lon: float = 4.7683,
    base_alt_ft: int = 12000,
) -> list[SquitterEvent]:
    """Generate a diverse pool of standard Mode S squitter frames."""
    events: list[SquitterEvent] = []

    # 1. DF11 All-Call (7 bytes)
    df11_bytes = encode_1090es_df11(icao24)
    events.append(SquitterEvent(timestamp_s=0.0, raw_bytes=df11_bytes, icao24=icao24))

    # 2. DF17 TC 4 Identification (14 bytes)
    id_bytes = encode_1090es_identification(icao24, "TEST99")
    events.append(SquitterEvent(timestamp_s=0.2, raw_bytes=id_bytes, icao24=icao24))

    # 3. DF17 TC 11 Airborne Position Even (14 bytes)
    pos_even = encode_1090es_airborne_position(
        icao24=icao24,
        altitude_ft=base_alt_ft,
        lat_deg=base_lat,
        lon_deg=base_lon,
        cpr_format=0,
    )
    events.append(SquitterEvent(timestamp_s=0.4, raw_bytes=pos_even, icao24=icao24))

    # 4. DF17 TC 11 Airborne Position Odd (14 bytes)
    pos_odd = encode_1090es_airborne_position(
        icao24=icao24,
        altitude_ft=base_alt_ft + 50,
        lat_deg=base_lat + 0.001,
        lon_deg=base_lon + 0.001,
        cpr_format=1,
    )
    events.append(SquitterEvent(timestamp_s=0.9, raw_bytes=pos_odd, icao24=icao24))

    # 5. DF17 TC 19 Airborne Velocity (14 bytes)
    vel_bytes = encode_1090es_airborne_velocity(
        icao24=icao24,
        v_ew_kt=180.0,
        v_ns_kt=220.0,
        vertical_rate_fpm=640,
    )
    events.append(SquitterEvent(timestamp_s=1.1, raw_bytes=vel_bytes, icao24=icao24))

    return events


def _create_truth_states(
    duration_s: float = 10.0,
    dt_s: float = 1.0,
    speed_mps: float = 200.0,
    origin_lat: float = 52.3105,
    origin_lon: float = 4.7683,
) -> list[AircraftTruthState]:
    """Generate linear truth states for kinematics testing."""
    states: list[AircraftTruthState] = []
    num_steps = int(duration_s / dt_s)
    for i in range(num_steps):
        t = i * dt_s
        d_lat = (speed_mps * t) / 111_139.0
        states.append(
            AircraftTruthState(
                timestamp_s=t,
                lat_deg=origin_lat + d_lat,
                lon_deg=origin_lon,
                alt_msl_m=3048.0 + t * 5.0,
                alt_hae_m=3090.0 + t * 5.0,
                alt_baro_ft=10000.0 + t * 16.4,
                groundspeed_mps=speed_mps,
                tas_mps=speed_mps + 10.0,
                ias_mps=speed_mps - 15.0,
                mach=0.62,
                true_track_deg=0.0,
                true_heading_deg=0.0,
                vertical_rate_baro_mps=5.0,
                icao_hex="4840D6",
                callsign="KLM123",
                squawk="1200",
                phase=FlightPhase.CLIMB,
            )
        )
    return states


# ==============================================================================
# 1. CRC Parity Invariance (1,000 Randomized Injections)
# ==============================================================================


class TestCRCParityInvariance1000Trials:
    """Empirical verification that 100% of Stage A faulted frames retain valid CRC-24."""

    def test_randomized_fault_crc_invariance_1000_trials(self) -> None:
        """Inject 1,000 randomized fault configurations across mixed squitter types.

        Invariants tested:
        - len(raw_bytes) in (7, 14)
        - compute_syndrome(raw_bytes) == 0
        - verify_crc24(raw_bytes) is True
        - decode_mode_s(raw_bytes).crc_valid is True
        """
        rng = np.random.default_rng(9999)
        base_squitters = _create_synthetic_squitter_pool()

        gillham_keys = list(GILLHAM_WIRE_BITS.keys())
        desync_modes = list(CPRDesyncMode)

        for trial in range(1000):
            # Pick a random subset of faults (at least one)
            fault_choice = int(rng.integers(0, 7))

            stale_gps_cfg: StaleGPSConfig | None = None
            cpr_desync_cfg: CPRDesyncConfig | None = None
            cpr_straddle_cfg: CPRStraddleConfig | None = None
            gillham_cfg: GillhamGlitchConfig | None = None
            alt_inv_cfg: AltitudeInversionConfig | None = None
            gps_jam_cfg: GPSJammingConfig | None = None
            dup_icao_cfg: DuplicateICAOConfig | None = None

            if fault_choice == 0 or rng.random() < 0.2:
                stale_gps_cfg = StaleGPSConfig(
                    start_time_s=float(rng.uniform(-1.0, 1.0)),
                    duration_s=float(rng.uniform(0.1, 5.0)),
                )
            if fault_choice == 1 or rng.random() < 0.2:
                mode_choice = desync_modes[int(rng.integers(0, len(desync_modes)))]
                cpr_desync_cfg = CPRDesyncConfig(
                    mode=mode_choice,
                    start_time_s=float(rng.uniform(-0.5, 0.5)),
                    duration_s=float(rng.uniform(0.5, 3.0)),
                )
            if fault_choice == 2 or rng.random() < 0.2:
                cpr_straddle_cfg = CPRStraddleConfig(
                    transition_lat_deg=float(rng.uniform(50.0, 53.0)),
                    delta_lat_deg=float(rng.uniform(0.001, 0.1)),
                )
            if fault_choice == 3 or rng.random() < 0.2:
                num_wires = int(rng.integers(1, 4))
                chosen_wires = rng.choice(gillham_keys, size=num_wires, replace=False)
                stuck_dict = {str(w): int(rng.integers(0, 2)) for w in chosen_wires}
                gillham_cfg = GillhamGlitchConfig(
                    stuck_wires=stuck_dict,
                    force_q_zero=bool(rng.choice([True, False])),
                )
            if fault_choice == 4 or rng.random() < 0.2:
                alt_inv_cfg = AltitudeInversionConfig(
                    swap_baro_geo=bool(rng.choice([True, False])),
                    qnh_offset_hpa=float(rng.uniform(960.0, 1040.0)),
                )
            if fault_choice == 5 or rng.random() < 0.2:
                gps_jam_cfg = GPSJammingConfig(
                    center_lat=52.3,
                    center_lon=4.7,
                    radius_m=10000.0,
                    target_tc=int(rng.integers(9, 19)),
                )
            if fault_choice == 6 or rng.random() < 0.2:
                dup_icao_cfg = DuplicateICAOConfig(
                    conflict_icao24=int(rng.integers(0x100000, 0xFFFFFF)),
                )

            agg_config = AvionicsFaultConfig(
                stale_gps=stale_gps_cfg,
                cpr_desync=cpr_desync_cfg,
                cpr_straddle=cpr_straddle_cfg,
                gillham_glitch=gillham_cfg,
                altitude_inversion=alt_inv_cfg,
                gps_jamming=gps_jam_cfg,
                duplicate_icao=dup_icao_cfg,
            )

            injector = AvionicsFaultInjector(config=agg_config, rng=rng)
            faulted_events = injector.apply_to_squitters(base_squitters)

            assert len(faulted_events) == len(base_squitters), f"Trial {trial}: Event count mismatch"

            for ev in faulted_events:
                # 1. Byte length check
                assert len(ev.raw_bytes) in (7, 14), f"Trial {trial}: invalid frame length {len(ev.raw_bytes)}"

                # 2. Direct CRC syndrome == 0
                syndrome = compute_syndrome(ev.raw_bytes)
                assert syndrome == 0, f"Trial {trial}: non-zero syndrome 0x{syndrome:06X}"

                # 3. Direct verify_crc24
                assert verify_crc24(ev.raw_bytes) is True, f"Trial {trial}: verify_crc24 returned False"

                # 4. Decoder recognition and crc_valid flag
                decoded = decode_mode_s(ev.raw_bytes)
                assert decoded.crc_valid is True, f"Trial {trial}: decoded.crc_valid is False"


# ==============================================================================
# 2. Stale GPS Latch Adversarial Stress (AV-01)
# ==============================================================================


class TestStaleGPSAdversarialStress:
    """Stress testing coordinate freeze, kinematics, and unfreeze discontinuity."""

    def test_state_coordinate_freeze_and_kinematic_jump(self) -> None:
        """Verify position locks during fault while velocity/altitude update, followed by teleport."""
        speed_mps = 250.0  # ~486 knots
        states = _create_truth_states(duration_s=20.0, dt_s=1.0, speed_mps=speed_mps)

        # Freeze from t=5.0s to t=15.0s (10 seconds)
        cfg = StaleGPSConfig(start_time_s=5.0, duration_s=10.0)
        faulted = apply_stale_gps_to_states(states, cfg)

        assert len(faulted) == len(states)

        # Before freeze: normal propagation
        for i in range(5):
            assert faulted[i].lat_deg == states[i].lat_deg
            assert faulted[i].lon_deg == states[i].lon_deg

        # During freeze: lat/lon frozen to states[5]
        frozen_lat = states[5].lat_deg
        frozen_lon = states[5].lon_deg
        for i in range(5, 15):
            assert faulted[i].lat_deg == frozen_lat
            assert faulted[i].lon_deg == frozen_lon
            # Crucial: groundspeed and baro altitude must NOT freeze
            assert faulted[i].groundspeed_mps == speed_mps
            assert faulted[i].alt_baro_ft == states[i].alt_baro_ft

        # Immediate jump upon release at t=15
        s_prev = faulted[14]
        s_curr = faulted[15]
        assert s_prev.lat_deg == frozen_lat
        assert s_curr.lat_deg == states[15].lat_deg

        # Distance of teleport jump should be ~ speed * duration = 250 m/s * 10s = 2500m
        jump_dist_m = haversine_distance(s_prev.lat_deg, s_prev.lon_deg, s_curr.lat_deg, s_curr.lon_deg)
        expected_dist_m = speed_mps * 10.0
        assert abs(jump_dist_m - expected_dist_m) < 50.0

    def test_squitter_level_cpr_latch_and_release(self) -> None:
        """Verify CPR position squitters freeze bitwise, then jump back to true track."""
        events: list[SquitterEvent] = []
        icao = 0x123456
        lat0, lon0 = 50.0, 10.0
        # 20 airborne position squitters at 0.5s intervals (10 seconds total)
        for i in range(20):
            t = i * 0.5
            lat = lat0 + i * 0.005  # moving north
            lon = lon0 + i * 0.002
            raw = encode_1090es_airborne_position(icao, 15000, lat, lon, cpr_format=i % 2)
            events.append(SquitterEvent(timestamp_s=t, raw_bytes=raw, icao24=icao))

        # Fault active from t=2.0s to t=6.0s (indices 4..11)
        cfg = StaleGPSConfig(start_time_s=2.0, duration_s=4.0)
        faulted = apply_stale_gps_fault(events, cfg)

        # Extract CPR lat/lon
        cpr_coords: list[tuple[int, int]] = []
        for ev in faulted:
            val, tb = bytes_to_uint(ev.raw_bytes)
            cpr_lat = extract_bits(val, tb, 55, 71)
            cpr_lon = extract_bits(val, tb, 72, 88)
            cpr_coords.append((cpr_lat, cpr_lon))

        # Check freeze in range [4, 12)
        frozen_even_cpr = cpr_coords[4]
        frozen_odd_cpr = cpr_coords[5]

        for idx in range(4, 12):
            if idx % 2 == 0:
                assert cpr_coords[idx] == frozen_even_cpr, f"Even frame {idx} CPR coordinates not frozen"
            else:
                assert cpr_coords[idx] == frozen_odd_cpr, f"Odd frame {idx} CPR coordinates not frozen"

        # Verify Global CPR decode over frozen frames
        m_ev = decode_mode_s(faulted[4].raw_bytes)
        m_od = decode_mode_s(faulted[5].raw_bytes)
        assert m_ev.cpr_lat is not None and m_ev.cpr_lon is not None
        assert m_od.cpr_lat is not None and m_od.cpr_lon is not None
        dec_lat, dec_lon = decode_cpr_global_airborne(
            m_ev.cpr_lat / 131072.0,
            m_ev.cpr_lon / 131072.0,
            m_od.cpr_lat / 131072.0,
            m_od.cpr_lon / 131072.0,
            most_recent=1,
        )
        assert abs(dec_lat - (lat0 + 4 * 0.005)) < 0.0001
        assert abs(dec_lon - (lon0 + 4 * 0.002)) < 0.0001

        # Frame 12 (t=6.0s) should jump
        assert cpr_coords[12] != frozen_even_cpr

    def test_prolonged_30s_freeze_cpr_accuracy_and_teleport(self) -> None:
        """AV-01: Prolonged 30-second freeze stress-test.

        Verifies:
        - During 30s freeze window, ALL adjacent Even/Odd pairs decode via
          Global CPR to static coordinates within 0.0001 deg.
        - Upon release at t=35s, unfreeze produces accurate kinematic teleport jump
          matching velocity * duration (200 m/s * 30s = 6000 m).
        - 100% of frames retain valid Mode S CRC-24.
        """
        speed_mps = 200.0  # ~388 kt
        duration_total = 40.0
        dt = 0.5  # 2 Hz squitters -> 80 position frames
        icao = 0x4840D6
        lat0, lon0 = 52.3105, 4.7683

        events: list[SquitterEvent] = []
        num_frames = int(duration_total / dt)
        for i in range(num_frames):
            t = i * dt
            # Flight moving strictly north for clean distance tracking
            dist = speed_mps * t
            d_lat = dist / 111_139.0
            lat = lat0 + d_lat
            lon = lon0
            raw = encode_1090es_airborne_position(
                icao24=icao,
                altitude_ft=12000,
                lat_deg=lat,
                lon_deg=lon,
                cpr_format=i % 2,
            )
            events.append(SquitterEvent(timestamp_s=t, raw_bytes=raw, icao24=icao))

        # Freeze for 30s from t=5.0s to t=35.0s (indices 10 to 69)
        cfg = StaleGPSConfig(start_time_s=5.0, duration_s=30.0)
        faulted = apply_stale_gps_fault(events, cfg)

        assert len(faulted) == len(events)

        # Frozen position coordinates at t=5.0s (index 10)
        expected_frozen_lat = lat0 + (speed_mps * 5.0) / 111_139.0
        expected_frozen_lon = lon0

        # Verify CRC and decode every adjacent pair in the freeze window [5.0, 35.0)
        frozen_events = [ev for ev in faulted if 5.0 <= ev.timestamp_s < 35.0]
        assert len(frozen_events) == 60  # 30s at 2 Hz

        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            assert decode_mode_s(ev.raw_bytes).crc_valid is True

        for i in range(len(frozen_events) - 1):
            m_a = decode_mode_s(frozen_events[i].raw_bytes)
            m_b = decode_mode_s(frozen_events[i + 1].raw_bytes)
            assert m_a.cpr_lat is not None and m_a.cpr_lon is not None
            assert m_b.cpr_lat is not None and m_b.cpr_lon is not None

            if m_a.cpr_format == 0:
                dec_lat, dec_lon = decode_cpr_global_airborne(
                    m_a.cpr_lat / 131072.0,
                    m_a.cpr_lon / 131072.0,
                    m_b.cpr_lat / 131072.0,
                    m_b.cpr_lon / 131072.0,
                    most_recent=1,
                )
            else:
                dec_lat, dec_lon = decode_cpr_global_airborne(
                    m_b.cpr_lat / 131072.0,
                    m_b.cpr_lon / 131072.0,
                    m_a.cpr_lat / 131072.0,
                    m_a.cpr_lon / 131072.0,
                    most_recent=0,
                )

            assert abs(dec_lat - expected_frozen_lat) < 0.0001, (
                f"Pair {i}: decoded lat {dec_lat:.6f} vs expected {expected_frozen_lat:.6f}"
            )
            assert abs(dec_lon - expected_frozen_lon) < 0.0001, (
                f"Pair {i}: decoded lon {dec_lon:.6f} vs expected {expected_frozen_lon:.6f}"
            )

        # Unfreeze jump at index 70 (t=35.0s)
        # Pair right after unfreeze: index 70 (t=35.0) and 71 (t=35.5) -> true track
        m_post0 = decode_mode_s(faulted[70].raw_bytes)
        m_post1 = decode_mode_s(faulted[71].raw_bytes)
        assert m_post0.cpr_lat is not None and m_post0.cpr_lon is not None
        assert m_post1.cpr_lat is not None and m_post1.cpr_lon is not None

        post_lat, post_lon = decode_cpr_global_airborne(
            m_post0.cpr_lat / 131072.0,
            m_post0.cpr_lon / 131072.0,
            m_post1.cpr_lat / 131072.0,
            m_post1.cpr_lon / 131072.0,
            most_recent=1,
        )

        expected_post_lat = lat0 + (speed_mps * 35.5) / 111_139.0
        assert abs(post_lat - expected_post_lat) < 0.0005

        # Distance of teleport jump: between frozen position and post-release position
        jump_dist_m = haversine_distance(expected_frozen_lat, expected_frozen_lon, post_lat, post_lon)
        expected_jump_m = speed_mps * 30.5
        assert abs(jump_dist_m - expected_jump_m) < 50.0

    def test_stale_gps_boundary_durations(self) -> None:
        """Test zero-duration and out-of-range timestamps."""
        events = _create_synthetic_squitter_pool()

        # Zero duration -> no change
        cfg_zero = StaleGPSConfig(start_time_s=0.5, duration_s=0.0)
        out_zero = apply_stale_gps_fault(events, cfg_zero)
        assert [e.raw_bytes for e in out_zero] == [e.raw_bytes for e in events]

        # Start time far in future -> no change
        cfg_future = StaleGPSConfig(start_time_s=1000.0, duration_s=50.0)
        out_future = apply_stale_gps_fault(events, cfg_future)
        assert [e.raw_bytes for e in out_future] == [e.raw_bytes for e in events]

        # Empty event list
        assert apply_stale_gps_fault([], cfg_zero) == []
        assert apply_stale_gps_to_states([], cfg_zero) == []


# ==============================================================================
# 3. Gillham Gray Code Stuck States Adversarial Stress (AV-04)
# ==============================================================================


class TestGillhamStuckBitsAdversarialStress:
    """Exhaustive stress-testing of Gillham parallel wire faults and illegal code handling."""

    @pytest.mark.parametrize("wire_name", list(GILLHAM_WIRE_BITS.keys()))
    @pytest.mark.parametrize("stuck_val", [0, 1])
    def test_exhaustive_gillham_wire_stuck_states(self, wire_name: str, stuck_val: int) -> None:
        """Sweep all 11 Gillham wires stuck at 0 and 1 across an altitude ladder.

        Verifies:
        - CRC parity remains 100% valid.
        - Decoded altitude is either an integer altitude (with distortion) OR None
          (legal DO-260B / ICAO Annex 10 rejection of non-standard Gray code patterns).
        """
        icao = 0xAA2233
        cfg = GillhamGlitchConfig(
            stuck_wires={wire_name: stuck_val},
            force_q_zero=True,
        )

        # Test altitudes across typical flight profile
        test_alts = [1000, 5000, 10000, 18000, 24000, 35000, 41000]
        events: list[SquitterEvent] = []
        for i, alt in enumerate(test_alts):
            raw = encode_1090es_airborne_position(icao, alt, 52.0, 4.0, cpr_format=i % 2)
            events.append(SquitterEvent(timestamp_s=float(i), raw_bytes=raw, icao24=icao))

        faulted = apply_gillham_stuck_bit_fault(events, cfg)

        has_valid_decoded = False
        has_rejected_code = False

        for ev in faulted:
            # 1. CRC must be intact
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid is True

            # 2. Altitude must be int or None (if illegal Gray code)
            if decoded.altitude_ft is None:
                has_rejected_code = True
            else:
                assert isinstance(decoded.altitude_ft, int)
                has_valid_decoded = True

        # Across the altitude ladder, at least one code must be evaluated
        assert has_valid_decoded or has_rejected_code

    def test_gillham_force_q_zero_behavior(self) -> None:
        """Verify that forcing Q=0 transitions 25-ft encoded altitudes into 100-ft Gray code."""
        icao = 0x556677
        # Original altitude: 10,025 ft (25-ft increment)
        raw = encode_1090es_airborne_position(icao, 10025, 52.0, 4.0, cpr_format=0)
        decoded_orig = decode_mode_s(raw)
        assert decoded_orig.altitude_ft == 10025

        # Force Q=0 without wire faults
        cfg = GillhamGlitchConfig(stuck_wires={}, force_q_zero=True)
        faulted = apply_gillham_stuck_bit_fault([SquitterEvent(0.0, raw, icao)], cfg)

        decoded_faulted = decode_mode_s(faulted[0].raw_bytes)
        assert compute_syndrome(faulted[0].raw_bytes) == 0
        # When decoded as 100-ft Gillham, altitude will either be a 100-ft multiple or None
        if decoded_faulted.altitude_ft is not None:
            assert decoded_faulted.altitude_ft % 100 == 0

    def test_multi_wire_stuck_fault(self) -> None:
        """Test multiple simultaneous stuck wires (e.g. C1 stuck 1, C4 stuck 0, D2 stuck 1)."""
        icao = 0x998877
        cfg = GillhamGlitchConfig(
            stuck_wires={"C1": 1, "C4": 0, "D2": 1},
            force_q_zero=True,
        )
        raw = encode_1090es_airborne_position(icao, 25000, 52.0, 4.0, cpr_format=0)
        faulted = apply_gillham_stuck_bit_fault([SquitterEvent(0.0, raw, icao)], cfg)

        assert compute_syndrome(faulted[0].raw_bytes) == 0
        decoded = decode_mode_s(faulted[0].raw_bytes)
        assert decoded.crc_valid is True
        # Verify internal decoder handles the multi-wire mutation safely
        val, tb = bytes_to_uint(faulted[0].raw_bytes)
        alt_code = extract_bits(val, tb, 41, 52)
        res = decode_gillham_altitude(alt_code)
        assert res == decoded.altitude_ft

    def test_gillham_pulses_step_errors_and_illegal_codes(self) -> None:
        """AV-04: Stress-test bit sticks on C1..D4 pulses.

        Verifies:
        - Bit sticks on C1, C2, C4 that produce illegal 100-ft Gray codes
          (G_100 in {0, 5, 7}) cause decode_gillham_altitude and decode_mode_s
          to return None (graceful rejection conforming to ICAO Annex 10).
        - Bit sticks that produce valid Gray code pulse combinations produce
          exact, predictable altitude step shifts.
        - Bit sticks on 500-ft pulses (D2, D4, A1, A2, A4, B1, B2, B4) produce
          discrete altitude errors in multiples of 500 ft.
        - Mode S CRC-24 parity remains 100% valid across all bit stuck combinations.
        """
        icao = 0x887766
        # Encode clean 10,000 ft in 100-ft Gillham code (Q=0)
        # 10,000 ft offset = 11300, b500 = 22, rem = 300 -> step 3 (G_100 = 2 = 010_2: C1=0, C2=1, C4=0)
        raw_base = encode_1090es_airborne_position(icao, 10000, 52.0, 4.0, cpr_format=0)
        val, tb = bytes_to_uint(raw_base)
        alt_code = encode_gillham_altitude(10000, resolution_25ft=False)
        val = set_bits(val, tb, 41, 52, alt_code)
        raw_10k_gillham = recompute_frame_crc(uint_to_bytes(val, 14))

        base_ev = SquitterEvent(0.0, raw_10k_gillham, icao)
        base_decoded = decode_mode_s(base_ev.raw_bytes)
        assert base_decoded.altitude_ft == 10000

        # 1. Illegal Gray code test: G_100 in {0, 5, 7}
        # C1=0, C2=0, C4=0 -> G_100 = 0 (illegal)
        cfg_illegal_0 = GillhamGlitchConfig(stuck_wires={"C1": 0, "C2": 0, "C4": 0}, force_q_zero=True)
        ev_ill_0 = apply_gillham_stuck_bit_fault([base_ev], cfg_illegal_0)[0]
        assert compute_syndrome(ev_ill_0.raw_bytes) == 0
        dec_ill_0 = decode_mode_s(ev_ill_0.raw_bytes)
        assert dec_ill_0.crc_valid is True
        assert dec_ill_0.altitude_ft is None, "Illegal G_100=0 must decode to None"

        # C1=1, C2=0, C4=1 -> G_100 = 5 (illegal)
        cfg_illegal_5 = GillhamGlitchConfig(stuck_wires={"C1": 1, "C2": 0, "C4": 1}, force_q_zero=True)
        ev_ill_5 = apply_gillham_stuck_bit_fault([base_ev], cfg_illegal_5)[0]
        dec_ill_5 = decode_mode_s(ev_ill_5.raw_bytes)
        assert dec_ill_5.altitude_ft is None, "Illegal G_100=5 must decode to None"

        # C1=1, C2=1, C4=1 -> G_100 = 7 (illegal)
        cfg_illegal_7 = GillhamGlitchConfig(stuck_wires={"C1": 1, "C2": 1, "C4": 1}, force_q_zero=True)
        ev_ill_7 = apply_gillham_stuck_bit_fault([base_ev], cfg_illegal_7)[0]
        dec_ill_7 = decode_mode_s(ev_ill_7.raw_bytes)
        assert dec_ill_7.altitude_ft is None, "Illegal G_100=7 must decode to None"

        # 2. Known 100-ft step shifts:
        # Base 10,000 ft has C1=0, C2=1, C4=0 (G_100=2 -> step 3).
        # Flipping C1 stuck to 1: C1=1, C2=1, C4=0 -> G_100 = 6 -> step 4.
        # Expected altitude: 500*22 + 100*4 - 1300 = 10,100 ft (+100 ft shift).
        cfg_step_up = GillhamGlitchConfig(stuck_wires={"C1": 1}, force_q_zero=True)
        ev_step_up = apply_gillham_stuck_bit_fault([base_ev], cfg_step_up)[0]
        dec_step_up = decode_mode_s(ev_step_up.raw_bytes)
        assert dec_step_up.altitude_ft == 10100

        # Flipping C4 stuck to 1: C1=0, C2=1, C4=1 -> G_100 = 3 -> step 2.
        # Expected altitude: 500*22 + 100*2 - 1300 = 9,900 ft (-100 ft shift).
        cfg_step_dn = GillhamGlitchConfig(stuck_wires={"C4": 1}, force_q_zero=True)
        ev_step_dn = apply_gillham_stuck_bit_fault([base_ev], cfg_step_dn)[0]
        dec_step_dn = decode_mode_s(ev_step_dn.raw_bytes)
        assert dec_step_dn.altitude_ft == 9900

        # 3. 500-ft pulse bit sticks: D2, D4, A1, A2, A4, B1, B2, B4
        # In 10,000 ft (b500 = 22 = 00010110_2, g500 = 29 = 00011101_2):
        # Wires: d2=0, d4=0, a1=0, a2=1, a4=1, b1=1, b2=0, b4=1.
        # Flipping D2 stuck at 1 alters g500 bit 7 (MSB), producing a large multi-500ft step.
        cfg_d2 = GillhamGlitchConfig(stuck_wires={"D2": 1}, force_q_zero=True)
        ev_d2 = apply_gillham_stuck_bit_fault([base_ev], cfg_d2)[0]
        dec_d2 = decode_mode_s(ev_d2.raw_bytes)
        assert dec_d2.altitude_ft is not None
        alt_shift = dec_d2.altitude_ft - 10000
        assert alt_shift % 500 == 0
        assert alt_shift != 0

        # Flipping B2 stuck at 1 (originally 0)
        cfg_b2 = GillhamGlitchConfig(stuck_wires={"B2": 1}, force_q_zero=True)
        ev_b2 = apply_gillham_stuck_bit_fault([base_ev], cfg_b2)[0]
        dec_b2 = decode_mode_s(ev_b2.raw_bytes)
        assert dec_b2.altitude_ft is not None
        alt_shift_b2 = dec_b2.altitude_ft - 10000
        assert alt_shift_b2 % 500 == 0
        assert alt_shift_b2 != 0


# ==============================================================================
# 4. CPR Zone Straddle Boundary Transitions (AV-03)
# ==============================================================================


class TestCPRZoneStraddleAdversarialStress:
    """Stress testing CPR latitude boundary transitions at 51.893425 deg."""

    def test_exact_boundary_nl_change(self) -> None:
        """Verify the exact transition latitude between NL=37 and NL=36."""
        transition_lat = 51.893425
        eps = 0.0001
        nl_south = nl_lat(transition_lat - eps)
        nl_north = nl_lat(transition_lat + eps)

        assert nl_south == 37, f"Expected NL=37 south of boundary, got {nl_south}"
        assert nl_north == 36, f"Expected NL=36 north of boundary, got {nl_north}"

    def test_straddle_global_failure_and_local_recovery(self) -> None:
        """Straddling pair must fail Global CPR but resolve cleanly via Local CPR."""
        icao = 0x334455
        cfg = CPRStraddleConfig(transition_lat_deg=51.893425, delta_lat_deg=0.002)

        # Create Even and Odd frames
        lon0 = 4.7683
        raw_even = encode_1090es_airborne_position(icao, 12000, 51.0, lon0, 0)
        raw_odd = encode_1090es_airborne_position(icao, 12000, 51.0, lon0, 1)
        events = [
            SquitterEvent(0.0, raw_even, icao),
            SquitterEvent(0.5, raw_odd, icao),
        ]

        faulted = apply_cpr_straddle_fault(events, cfg)

        assert len(faulted) == 2
        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            assert decode_mode_s(ev.raw_bytes).crc_valid is True

        dec_even = decode_mode_s(faulted[0].raw_bytes)
        dec_odd = decode_mode_s(faulted[1].raw_bytes)

        lat_cpr0 = dec_even.cpr_lat / 131072.0
        lon_cpr0 = dec_even.cpr_lon / 131072.0
        lat_cpr1 = dec_odd.cpr_lat / 131072.0
        lon_cpr1 = dec_odd.cpr_lon / 131072.0

        # Global CPR MUST detect zone straddle and raise ValueError
        with pytest.raises(ValueError, match="CPR zone boundary straddle"):
            decode_cpr_global_airborne(lat_cpr0, lon_cpr0, lat_cpr1, lon_cpr1, most_recent=1)

        # Local CPR with receiver reference at Schiphol (52.3, 4.7) must succeed for both
        ref_lat, ref_lon = 51.9, 4.7683
        local_lat_even, local_lon_even = decode_cpr_local(lat_cpr0, lon_cpr0, 0, ref_lat, ref_lon)
        local_lat_odd, local_lon_odd = decode_cpr_local(lat_cpr1, lon_cpr1, 1, ref_lat, ref_lon)

        expected_even_lat = cfg.transition_lat_deg - cfg.delta_lat_deg
        expected_odd_lat = cfg.transition_lat_deg + cfg.delta_lat_deg

        assert abs(local_lat_even - expected_even_lat) < 0.01
        assert abs(local_lat_odd - expected_odd_lat) < 0.01
        assert abs(local_lon_even - 4.7683) < 0.05
        assert abs(local_lon_odd - 4.7683) < 0.05

    def test_non_straddling_pairs_succeed_globally(self) -> None:
        """Verify that when both frames lie on the same side of 51.89 deg, Global CPR succeeds."""
        lat_same_side = 51.890  # Both NL=37
        raw0 = encode_1090es_airborne_position(0x111111, 10000, lat_same_side, 4.0, 0)
        raw1 = encode_1090es_airborne_position(0x111111, 10000, lat_same_side + 0.001, 4.0, 1)

        dec0 = decode_mode_s(raw0)
        dec1 = decode_mode_s(raw1)

        lat_dec, lon_dec = decode_cpr_global_airborne(
            dec0.cpr_lat / 131072.0,
            dec0.cpr_lon / 131072.0,
            dec1.cpr_lat / 131072.0,
            dec1.cpr_lon / 131072.0,
            most_recent=1,
        )
        assert abs(lat_dec - (lat_same_side + 0.001)) < 0.005
        assert abs(lon_dec - 4.0) < 0.05

    @pytest.mark.parametrize(
        ("city_name", "target_lon"),
        [
            ("Calgary", -114.06),
            ("London", -0.12),
            ("Tokyo", 139.7),
            ("Schiphol", 4.7683),
        ],
    )
    def test_straddle_boundary_across_worldwide_longitudes(
        self, city_name: str, target_lon: float
    ) -> None:
        """AV-03: Stress-test flight crossing exact 51.893425 deg NL boundary worldwide.

        Tests worldwide longitudes (Calgary -114.06, London -0.12, Tokyo 139.7, Schiphol 4.7683):
        - Even frame south of boundary (NL=37), Odd frame north of boundary (NL=36).
        - Global CPR decoding MUST detect zone straddle and raise ValueError("CPR zone boundary straddle detected").
        - Local CPR decoding relative to local receiver MUST recover correct flight coordinates within 0.01 deg.
        - CRC-24 parity remains strictly valid (syndrome == 0).
        """
        transition_lat = 51.893425
        delta_lat = 0.005
        lat_even = transition_lat - delta_lat  # 51.888425 (NL=37)
        lat_odd = transition_lat + delta_lat   # 51.898425 (NL=36)

        assert nl_lat(lat_even) == 37
        assert nl_lat(lat_odd) == 36

        icao = 0xABCDEF
        raw_even = encode_1090es_airborne_position(icao, 15000, 51.85, target_lon, 0)
        raw_odd = encode_1090es_airborne_position(icao, 15000, 51.85, target_lon, 1)

        events = [
            SquitterEvent(0.0, raw_even, icao),
            SquitterEvent(0.5, raw_odd, icao),
        ]

        cfg = CPRStraddleConfig(transition_lat_deg=transition_lat, delta_lat_deg=delta_lat)
        faulted = apply_cpr_straddle_fault(events, cfg)

        assert len(faulted) == 2
        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            assert decode_mode_s(ev.raw_bytes).crc_valid is True

        dec_even = decode_mode_s(faulted[0].raw_bytes)
        dec_odd = decode_mode_s(faulted[1].raw_bytes)
        assert dec_even.cpr_lat is not None and dec_even.cpr_lon is not None
        assert dec_odd.cpr_lat is not None and dec_odd.cpr_lon is not None

        lat_cpr0 = dec_even.cpr_lat / 131072.0
        lon_cpr0 = dec_even.cpr_lon / 131072.0
        lat_cpr1 = dec_odd.cpr_lat / 131072.0
        lon_cpr1 = dec_odd.cpr_lon / 131072.0

        # 1. Global CPR MUST raise ValueError("CPR zone boundary straddle detected")
        with pytest.raises(ValueError, match="CPR zone boundary straddle"):
            decode_cpr_global_airborne(lat_cpr0, lon_cpr0, lat_cpr1, lon_cpr1, most_recent=1)

        # 2. Local CPR with reference receiver near target_lon
        rec_lat_even, rec_lon_even = decode_cpr_local(
            lat_cpr0, lon_cpr0, 0, ref_lat=51.9, ref_lon=target_lon
        )
        rec_lat_odd, rec_lon_odd = decode_cpr_local(
            lat_cpr1, lon_cpr1, 1, ref_lat=51.9, ref_lon=target_lon
        )

        assert abs(rec_lat_even - lat_even) < 0.01, f"{city_name}: Even lat error {abs(rec_lat_even - lat_even)}"
        assert abs(rec_lat_odd - lat_odd) < 0.01, f"{city_name}: Odd lat error {abs(rec_lat_odd - lat_odd)}"
        assert abs(rec_lon_even - target_lon) < 0.01, f"{city_name}: Even lon error {abs(rec_lon_even - target_lon)}"
        assert abs(rec_lon_odd - target_lon) < 0.01, f"{city_name}: Odd lon error {abs(rec_lon_odd - target_lon)}"



# ==============================================================================
# 5. GhostTrackInjector Kinematics & Squitter Validation
# ==============================================================================


class TestGhostTrackInjectorKinematics:
    """Stress testing the high-speed (800 m/s) synthetic ghost spoofer."""

    def test_ghost_track_800mps_trajectory_and_cpr_roundtrip(self) -> None:
        """Verify 800 m/s trajectory, timing, altitude, and global CPR decodability."""
        ghost = GhostTrackInjector(
            target_icao=0xFA11ED,
            speed_mps=800.0,
            origin_lat=52.3105,
            origin_lon=4.7683,
            origin_alt_ft=15000.0,
            track_deg=90.0,  # Eastbound
            callsign="GHOST800",
        )

        duration = 10.0
        events = ghost.generate_ghost_squitters(duration_s=duration)

        assert len(events) > 0

        # Verify time-ordered timestamps
        timestamps = [e.timestamp_s for e in events]
        assert timestamps == sorted(timestamps)
        assert timestamps[0] >= 0.0
        assert timestamps[-1] < duration

        # Verify all frames have target ICAO and valid CRC
        pos_events: list[SquitterEvent] = []
        vel_events: list[SquitterEvent] = []
        id_events: list[SquitterEvent] = []

        for ev in events:
            assert ev.icao24 == 0xFA11ED
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid is True
            assert decoded.icao24 == 0xFA11ED

            if decoded.tc == 4:
                id_events.append(ev)
                assert decoded.callsign == "GHOST800"
            elif decoded.tc == 19:
                vel_events.append(ev)
            elif decoded.tc == 11:
                pos_events.append(ev)

        # Check identification count: at t=0, 5.0 -> 2 events
        assert len(id_events) == 2

        # Check velocity count: 2 Hz -> ~20 events
        assert len(vel_events) == 20

        # Check position count: 2 Hz -> ~20 events
        assert len(pos_events) == 20

        # Verify position squitters alternate CPR format
        cpr_formats = [decode_mode_s(e.raw_bytes).cpr_format for e in pos_events]
        expected_formats = [i % 2 for i in range(len(pos_events))]
        assert cpr_formats == expected_formats

        # Decode consecutive pairs using Global CPR and verify position progression
        for i in range(len(pos_events) - 1):
            ev0 = pos_events[i]
            ev1 = pos_events[i + 1]
            dec0 = decode_mode_s(ev0.raw_bytes)
            dec1 = decode_mode_s(ev1.raw_bytes)

            even_dec = dec0 if dec0.cpr_format == 0 else dec1
            odd_dec = dec1 if dec0.cpr_format == 0 else dec0
            most_recent = 1 if dec1.cpr_format == 1 else 0

            lat_dec, lon_dec = decode_cpr_global_airborne(
                even_dec.cpr_lat / 131072.0,
                even_dec.cpr_lon / 131072.0,
                odd_dec.cpr_lat / 131072.0,
                odd_dec.cpr_lon / 131072.0,
                most_recent=most_recent,
            )

            # Altitude should remain at 15000 ft
            assert dec0.altitude_ft == 15000
            assert dec1.altitude_ft == 15000

            # Latitude should be close to origin 52.3105 (track is Eastbound)
            assert abs(lat_dec - 52.3105) < 0.05
            # Longitude must advance eastbound over time
            assert lon_dec >= 4.7683

    def test_ghost_track_edge_parameters(self) -> None:
        """Test zero duration, negative duration, and extreme headings."""
        ghost = GhostTrackInjector(target_icao=0xFA11ED, speed_mps=1500.0)

        assert ghost.generate_ghost_squitters(duration_s=0.0) == []
        assert ghost.generate_ghost_squitters(duration_s=-5.0) == []

        # Southbound track at Mach 3
        ghost_south = GhostTrackInjector(track_deg=180.0, speed_mps=1000.0)
        events = ghost_south.generate_ghost_squitters(duration_s=2.0)
        assert len(events) > 0
        for ev in events:
            assert compute_syndrome(ev.raw_bytes) == 0


# ==============================================================================
# 6. Multi-Fault Combinations and Spoofing Stress
# ==============================================================================


class TestMultiFaultAndSpoofingStress:
    """Stress testing simultaneous multi-fault injection and electronic warfare generators."""

    def test_all_seven_faults_simultaneous_activation(self) -> None:
        """Simultaneously activate all 7 avionics faults on a squitter stream."""
        config = AvionicsFaultConfig(
            stale_gps=StaleGPSConfig(start_time_s=0.0, duration_s=10.0),
            cpr_desync=CPRDesyncConfig(mode=CPRDesyncMode.INVERTED_TOGGLE),
            cpr_straddle=CPRStraddleConfig(transition_lat_deg=51.893425),
            gillham_glitch=GillhamGlitchConfig(stuck_wires={"A1": 1, "C2": 0}),
            altitude_inversion=AltitudeInversionConfig(qnh_offset_hpa=1020.0),
            gps_jamming=GPSJammingConfig(center_lat=52.0, center_lon=4.0, radius_m=5000.0, target_tc=18),
            duplicate_icao=DuplicateICAOConfig(conflict_icao24=0xBEEF99),
        )

        injector = AvionicsFaultInjector(config=config, rng=np.random.default_rng(123))
        squitters = _create_synthetic_squitter_pool()

        mutated = injector.apply_to_squitters(squitters)
        assert len(mutated) == len(squitters)

        for ev in mutated:
            # 100% CRC validity must be preserved despite 7 overlapping mutations
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid is True
            # Duplicate ICAO should be applied to DF11 and DF17
            assert ev.icao24 == 0xBEEF99

    def test_shadow_track_hijacker_stress(self) -> None:
        """Verify ShadowTrackHijacker higher power, time offset, and ICAO targeting."""
        events = _create_synthetic_squitter_pool(icao24=0x4840D6)
        hijacker = ShadowTrackHijacker(
            target_icao=0x4840D6,
            tx_power_dbm=60.0,
        )

        # Divergence starts at t=0.3s (should clone events at t=0.4, 0.9, 1.1)
        shadows = hijacker.generate_shadow_squitters(events, divergence_start_s=0.3)
        assert len(shadows) == 3

        for s in shadows:
            assert s.tx_power_dbm == 60.0
            assert s.icao24 == 0x4840D6
            assert compute_syndrome(s.raw_bytes) == 0

        # When target ICAO does not match, return empty
        hijacker_mismatch = ShadowTrackHijacker(target_icao=0x999999)
        assert hijacker_mismatch.generate_shadow_squitters(events) == []

    def test_flood_denial_high_density(self) -> None:
        """Verify high burst rate denial flood (1,000 Hz for 1s = 1,000 frames)."""
        injector = FloodDenialInjector(
            num_targets=100,
            burst_rate_hz=1000.0,
            rng=np.random.default_rng(42),
        )
        events = injector.generate_flood(duration_s=1.0)
        assert len(events) == 1000

        # Verify all frames are valid DF11 All-Call squitters
        for ev in events[:100]:  # check first 100
            assert len(ev.raw_bytes) == 7
            assert compute_syndrome(ev.raw_bytes) == 0
            dec = decode_mode_s(ev.raw_bytes)
            assert dec.crc_valid is True
            assert dec.df == 11

    def test_replay_injector_temporal_shift(self) -> None:
        """Verify ReplayInjector accurately delays timestamps and filters by ICAO."""
        events = _create_synthetic_squitter_pool(icao24=0x112233)
        injector = ReplayInjector(delay_s=45.0, target_icao=0x112233)

        replayed = injector.replay(events)
        assert len(replayed) == len(events)

        for orig, rep in zip(events, replayed, strict=False):
            assert rep.timestamp_s == orig.timestamp_s + 45.0
            assert rep.raw_bytes == orig.raw_bytes
            assert compute_syndrome(rep.raw_bytes) == 0

        # Replay with non-matching target ICAO
        inj_none = ReplayInjector(target_icao=0x999999)
        assert inj_none.replay(events) == []

    @pytest.mark.parametrize(
        ("divergence_deg", "alt_rate_fpm", "expected_climb"),
        [
            (15.0, 2000.0, True),    # Lateral divergence right + Climb
            (-20.0, -2500.0, False),  # Lateral divergence left + Descent
        ],
    )
    def test_shadow_track_lateral_and_vertical_divergence_climb_and_descent(
        self, divergence_deg: float, alt_rate_fpm: float, expected_climb: bool
    ) -> None:
        """Verify ShadowTrackHijacker divergent lateral track (> 200m) and climb/descent with valid CRC-24."""
        icao = 0x4840D6
        lat0, lon0 = 52.3105, 4.7683
        # Generate 12 position squitters (6s duration at 2 Hz)
        base_squitters: list[SquitterEvent] = []
        for i in range(12):
            t = i * 0.5
            lat = lat0 + i * 0.001
            lon = lon0 + i * 0.001
            raw = encode_1090es_airborne_position(
                icao24=icao,
                altitude_ft=12000,
                lat_deg=lat,
                lon_deg=lon,
                cpr_format=i % 2,
            )
            base_squitters.append(SquitterEvent(timestamp_s=t, raw_bytes=raw, icao24=icao))

        hijacker = ShadowTrackHijacker(
            target_icao=icao,
            divergence_track_deg=divergence_deg,
            alt_rate_fpm=alt_rate_fpm,
            tx_power_dbm=57.0,
        )

        divergence_start = 2.0
        shadows = hijacker.generate_shadow_squitters(base_squitters, divergence_start_s=divergence_start)

        # Base events at t >= 2.0s are indices 4..11 (8 events)
        assert len(shadows) == 8

        # 1. 100% of shadow frames have valid Mode S CRC-24 and +6 dB power advantage
        for sev in shadows:
            assert sev.tx_power_dbm == 57.0
            assert sev.icao24 == icao
            assert compute_syndrome(sev.raw_bytes) == 0
            assert decode_mode_s(sev.raw_bytes).crc_valid is True

        # 2. Vertical divergence verification
        # At final shadow event (t = 5.501s, dt = 3.5s from start):
        base_final = decode_mode_s(base_squitters[-1].raw_bytes)
        shad_final = decode_mode_s(shadows[-1].raw_bytes)
        assert base_final.altitude_ft is not None
        assert shad_final.altitude_ft is not None
        d_alt = shad_final.altitude_ft - base_final.altitude_ft
        expected_d_alt_nominal = alt_rate_fpm * (3.5 / 60.0)

        if expected_climb:
            assert d_alt > 0
            assert abs(d_alt - expected_d_alt_nominal) < 50.0
        else:
            assert d_alt < 0
            assert abs(d_alt - expected_d_alt_nominal) < 50.0

        # 3. Lateral divergence verification
        # Global CPR decode on final adjacent pair (indices -2 and -1)
        base_m_ev = decode_mode_s(base_squitters[-2].raw_bytes)
        base_m_od = decode_mode_s(base_squitters[-1].raw_bytes)
        assert base_m_ev.cpr_lat is not None and base_m_ev.cpr_lon is not None
        assert base_m_od.cpr_lat is not None and base_m_od.cpr_lon is not None
        base_lat, base_lon = decode_cpr_global_airborne(
            base_m_ev.cpr_lat / 131072.0,
            base_m_ev.cpr_lon / 131072.0,
            base_m_od.cpr_lat / 131072.0,
            base_m_od.cpr_lon / 131072.0,
            most_recent=1,
        )

        shad_m_ev = decode_mode_s(shadows[-2].raw_bytes)
        shad_m_od = decode_mode_s(shadows[-1].raw_bytes)
        assert shad_m_ev.cpr_lat is not None and shad_m_ev.cpr_lon is not None
        assert shad_m_od.cpr_lat is not None and shad_m_od.cpr_lon is not None
        shad_lat, shad_lon = decode_cpr_global_airborne(
            shad_m_ev.cpr_lat / 131072.0,
            shad_m_ev.cpr_lon / 131072.0,
            shad_m_od.cpr_lat / 131072.0,
            shad_m_od.cpr_lon / 131072.0,
            most_recent=1,
        )

        separation_dist_m = haversine_distance(base_lat, base_lon, shad_lat, shad_lon)
        assert separation_dist_m > 200.0, f"Separation {separation_dist_m:.2f} m must exceed 200 m"

    def test_replay_injector_temporal_vs_spatial_translation(self) -> None:
        """Verify ReplayInjector: pure temporal shift (identical bytes) vs spatial translation (valid CRC)."""
        icao = 0x334455
        base_squitters = [
            SquitterEvent(
                0.0, encode_1090es_airborne_position(icao, 10000, 52.31, 4.76, 0), icao
            ),
            SquitterEvent(
                0.5, encode_1090es_airborne_position(icao, 10000, 52.311, 4.761, 1), icao
            ),
        ]

        # 1. Pure temporal shift
        inj_temporal = ReplayInjector(delay_s=60.0, delta_lat_deg=0.0, delta_lon_deg=0.0)
        replayed_temp = inj_temporal.replay(base_squitters)
        assert len(replayed_temp) == len(base_squitters)
        for orig, rep in zip(base_squitters, replayed_temp, strict=False):
            assert rep.timestamp_s == orig.timestamp_s + 60.0
            assert rep.raw_bytes == orig.raw_bytes  # Identical bytes
            assert compute_syndrome(rep.raw_bytes) == 0

        # 2. Spatial translation (+2.5 deg lat, -3.0 deg lon)
        inj_spatial = ReplayInjector(
            delay_s=30.0, delta_lat_deg=2.5, delta_lon_deg=-3.0, target_icao=icao
        )
        replayed_spat = inj_spatial.replay(base_squitters)
        assert len(replayed_spat) == len(base_squitters)

        for orig, rep in zip(base_squitters, replayed_spat, strict=False):
            assert rep.timestamp_s == orig.timestamp_s + 30.0
            assert rep.raw_bytes != orig.raw_bytes  # Re-encoded coordinates
            assert compute_syndrome(rep.raw_bytes) == 0
            assert decode_mode_s(rep.raw_bytes).crc_valid is True

        # Decode original global CPR
        m0 = decode_mode_s(base_squitters[0].raw_bytes)
        m1 = decode_mode_s(base_squitters[1].raw_bytes)
        assert m0.cpr_lat is not None and m0.cpr_lon is not None
        assert m1.cpr_lat is not None and m1.cpr_lon is not None
        orig_lat, orig_lon = decode_cpr_global_airborne(
            m0.cpr_lat / 131072.0,
            m0.cpr_lon / 131072.0,
            m1.cpr_lat / 131072.0,
            m1.cpr_lon / 131072.0,
            most_recent=1,
        )

        # Decode translated global CPR
        r0 = decode_mode_s(replayed_spat[0].raw_bytes)
        r1 = decode_mode_s(replayed_spat[1].raw_bytes)
        assert r0.cpr_lat is not None and r0.cpr_lon is not None
        assert r1.cpr_lat is not None and r1.cpr_lon is not None
        trans_lat, trans_lon = decode_cpr_global_airborne(
            r0.cpr_lat / 131072.0,
            r0.cpr_lon / 131072.0,
            r1.cpr_lat / 131072.0,
            r1.cpr_lon / 131072.0,
            most_recent=1,
        )

        assert abs((trans_lat - orig_lat) - 2.5) < 0.001
        assert abs((trans_lon - orig_lon) - (-3.0)) < 0.001

    def test_flood_denial_exact_event_counts_both_modes(self) -> None:
        """Verify FloodDenialInjector exact event count duration_s * burst_rate_hz in DF11 and DF17 ring modes."""
        # Mode 1: DF11 All-Call saturation mode
        inj_df11 = FloodDenialInjector(
            num_targets=25,
            burst_rate_hz=400.0,
            emit_positions=False,
            rng=np.random.default_rng(101),
        )
        duration_1 = 2.5
        events_df11 = inj_df11.generate_flood(duration_s=duration_1)
        expected_count_1 = round(duration_1 * 400.0)  # 1000 events
        assert len(events_df11) == expected_count_1 == 1000

        for ev in events_df11:
            assert len(ev.raw_bytes) == 7
            assert compute_syndrome(ev.raw_bytes) == 0
            dec = decode_mode_s(ev.raw_bytes)
            assert dec.crc_valid is True
            assert dec.df == 11

        # Mode 2: DF17 Airborne Position geometric ring mode
        center_lat, center_lon = 52.3105, 4.7683
        ring_radius_m = 20000.0
        inj_df17 = FloodDenialInjector(
            num_targets=10,
            burst_rate_hz=200.0,
            center_lat=center_lat,
            center_lon=center_lon,
            radius_m=ring_radius_m,
            emit_positions=True,
            rng=np.random.default_rng(202),
        )
        duration_2 = 1.5
        events_df17 = inj_df17.generate_flood(duration_s=duration_2)
        expected_count_2 = round(duration_2 * 200.0)  # 300 events
        assert len(events_df17) == expected_count_2 == 300

        for ev in events_df17:
            assert len(ev.raw_bytes) == 14
            assert compute_syndrome(ev.raw_bytes) == 0
            dec = decode_mode_s(ev.raw_bytes)
            assert dec.crc_valid is True
            assert dec.df == 17
            assert dec.tc == 11
            assert dec.cpr_lat is not None and dec.cpr_lon is not None and dec.cpr_format is not None

            # Local CPR resolution against center
            d_lat, d_lon = decode_cpr_local(
                dec.cpr_lat / 131072.0,
                dec.cpr_lon / 131072.0,
                dec.cpr_format,
                center_lat,
                center_lon,
            )
            dist_to_center = haversine_distance(d_lat, d_lon, center_lat, center_lon)
            assert abs(dist_to_center - ring_radius_m) < 15.0

