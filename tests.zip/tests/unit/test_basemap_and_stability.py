"""Automated Unit Tests for Milestone 1: Basemap Default (R1) & Scenario Stability (R2).

Authoritative reference:
- ORIGINAL_REQUEST.md (Requirements R1 and R2)
- AGENTS.md
- docs/01_ARCHITECTURE_AND_DESIGN.md
- docs/05_TRACKING_AND_STATE_ESTIMATION.md
"""

from __future__ import annotations

import re
from collections.abc import Generator
from pathlib import Path

import numpy as np
import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import (
    SimulationConfig,
    SimulationManager,
    reset_simulation_manager,
)
from adsb.protocol.modes import decode_mode_s
from adsb.synthesis.scenario import load_scenario
from adsb.tracker.engine import TrackingEngine
from adsb.tracker.lifecycle import TrackState

STATIC_DIR = Path(__file__).resolve().parent.parent.parent / "src" / "adsb" / "api" / "static"
LEAFLET_JS_PATH = STATIC_DIR / "js" / "leaflet_map.js"


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Provide clean FastAPI TestClient."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


# ==============================================================================
# R1: Basemap Default and Cleanup Unit Tests
# ==============================================================================


@pytest.mark.tier1
def test_leaflet_map_strict_esri_default() -> None:
    """Verify leaflet_map.js instantiates and defaults strictly to ESRI World Dark Gray Canvas."""
    assert LEAFLET_JS_PATH.exists(), f"Missing {LEAFLET_JS_PATH}"
    content = LEAFLET_JS_PATH.read_text(encoding="utf-8")

    esri_url = (
        "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}"
    )
    assert esri_url in content, "ESRI World Dark Gray Base tile URL not found in leaflet_map.js"

    # Verify default addition to map
    assert re.search(r"esriDarkLayer\.addTo\(this\.map\)", content) is not None, (
        "esriDarkLayer must be added directly to this.map on initialization"
    )

    # Verify attribution
    assert "Tiles &copy; Esri" in content or "Esri, DeLorme, NAVTEQ" in content, (
        "ESRI tile attribution missing"
    )


@pytest.mark.tier1
def test_leaflet_map_zero_carto_references() -> None:
    """Verify leaflet_map.js contains zero references to CARTO (URLs, keys, layers, or options)."""
    assert LEAFLET_JS_PATH.exists()
    content = LEAFLET_JS_PATH.read_text(encoding="utf-8")

    carto_matches = re.findall(r"carto", content, re.IGNORECASE)
    assert not carto_matches, (
        f"Found {len(carto_matches)} CARTO references in leaflet_map.js: {carto_matches}"
    )

    forbidden_tokens = [
        "basemaps.cartocdn.com",
        "cartoApiKey",
        "carto_key",
        "carto_api_key",
        "CARTO_API_KEY",
        "CARTO Dark Matter",
        "carto.com",
    ]
    for token in forbidden_tokens:
        assert token not in content, f"Forbidden CARTO token '{token}' found in leaflet_map.js"


@pytest.mark.tier1
def test_all_frontend_static_assets_zero_carto() -> None:
    """Verify all HTML, JS, and CSS files under static/ contain zero CARTO references."""
    assert STATIC_DIR.exists()
    scanned_extensions = {".html", ".js", ".css"}
    scanned_files = [p for p in STATIC_DIR.rglob("*") if p.suffix.lower() in scanned_extensions]
    assert len(scanned_files) >= 5, f"Expected static files, found {len(scanned_files)}"

    for file_path in scanned_files:
        content = file_path.read_text(encoding="utf-8")
        matches = re.findall(r"carto", content, re.IGNORECASE)
        assert not matches, (
            f"Found {len(matches)} CARTO references in {file_path.relative_to(STATIC_DIR)}: {matches}"
        )


@pytest.mark.tier1
def test_leaflet_static_asset_http_delivery(client: TestClient) -> None:
    """Verify leaflet_map.js is delivered over HTTP with status 200 and clean ESRI default."""
    res = client.get("/js/leaflet_map.js")
    assert res.status_code == 200
    assert "application/javascript" in res.headers.get("content-type", "")
    assert "carto" not in res.text.lower()
    assert "server.arcgisonline.com" in res.text


# ==============================================================================
# R2: Simulation Engine Stability Unit Tests
# ==============================================================================


@pytest.mark.tier1
@pytest.mark.parametrize(
    "scenario_name",
    [
        "clean_tma_10_aircraft",
        "congested_tma_25_aircraft",
        "fault_and_spoofing_test",
    ],
)
def test_scenario_definitions_extended_duration(scenario_name: str) -> None:
    """Verify all pre-configured scenarios default to duration >= 3600s (1 hour)."""
    rng = np.random.default_rng(42)
    scenario = load_scenario(scenario_name, rng=rng)
    assert scenario.duration_s >= 3600.0, (
        f"Scenario '{scenario_name}' duration {scenario.duration_s}s is less than 3600.0s"
    )

    # Verify trajectory states extend beyond 70s
    for ac in scenario.aircraft:
        assert len(ac.states) > 70, f"Aircraft {ac.callsign} has only {len(ac.states)} states"
        assert ac.states[-1].timestamp_s >= 70.0, (
            f"Aircraft {ac.callsign} max timestamp {ac.states[-1].timestamp_s}s < 70s"
        )


@pytest.mark.tier1
def test_scenario_duration_override() -> None:
    """Verify load_scenario allows explicit caller override of duration_s."""
    rng = np.random.default_rng(42)
    scenario_short = load_scenario("clean_tma_10_aircraft", rng=rng, duration_s=60.0)
    assert scenario_short.duration_s == 60.0
    for ac in scenario_short.aircraft:
        assert ac.states[-1].timestamp_s <= 60.0


@pytest.mark.asyncio
@pytest.mark.tier1
@pytest.mark.parametrize(
    "scenario_name, expected_aircraft_count",
    [
        ("clean_tma_10_aircraft", 10),
        ("congested_tma_25_aircraft", 25),
        ("fault_and_spoofing_test", 3),
    ],
)
async def test_simulation_manager_continuous_stepping_past_70s(
    scenario_name: str, expected_aircraft_count: int
) -> None:
    """Verify SimulationManager steps continuously past 70s to 100s across all scenarios."""
    mgr = SimulationManager(SimulationConfig(scenario_name=scenario_name, seed=42))
    assert mgr.engine is not None

    # Step through 50s, 75s, and 100s
    await mgr.step(50.0)
    assert mgr.sim_time_s == 50.0

    await mgr.step(25.0)
    assert mgr.sim_time_s == 75.0

    await mgr.step(25.0)
    assert mgr.sim_time_s == 100.0

    # Verify tracks remain active and updated past 70s
    all_tracks = mgr.engine.all_tracks(include_tentative=True)
    assert len(all_tracks) >= expected_aircraft_count, (
        f"Expected at least {expected_aircraft_count} tracks, got {len(all_tracks)}"
    )

    # Assert squitters were actively decoded past 70s
    tracks_seen_past_70 = [t for t in all_tracks if t.last_seen_s > 70.0]
    assert len(tracks_seen_past_70) == len(all_tracks), (
        f"Only {len(tracks_seen_past_70)}/{len(all_tracks)} tracks received updates past 70s"
    )


@pytest.mark.asyncio
@pytest.mark.tier2
async def test_simulation_manager_track_movement_past_70s() -> None:
    """Verify aircraft positions actively advance between 70s and 100s (no freezing)."""
    mgr = SimulationManager(SimulationConfig(scenario_name="clean_tma_10_aircraft", seed=42))
    assert mgr.engine is not None

    # Advance to 70s
    await mgr.step(70.0)
    tracks_70 = {
        t.icao24: (t.lat_deg, t.lon_deg, t.last_seen_s)
        for t in mgr.engine.all_tracks()
        if t.has_position
    }
    assert len(tracks_70) == 10

    # Advance to 100s
    await mgr.step(30.0)
    tracks_100 = {
        t.icao24: (t.lat_deg, t.lon_deg, t.last_seen_s)
        for t in mgr.engine.all_tracks()
        if t.has_position
    }
    assert len(tracks_100) == 10

    # Assert significant movement occurred
    for icao24, (lat70, lon70, seen70) in tracks_70.items():
        lat100, lon100, seen100 = tracks_100[icao24]
        assert seen100 > 70.0, f"Track {icao24:06X} last_seen_s {seen100} did not advance"
        assert seen100 > seen70, f"Track {icao24:06X} timestamp did not increase"

        # Difference in position must be non-zero
        delta_lat = abs(lat100 - lat70)
        delta_lon = abs(lon100 - lon70)
        assert delta_lat > 0.005 or delta_lon > 0.005, (
            f"Track {icao24:06X} position frozen between 70s and 100s: "
            f"lat={lat70}->{lat100}, lon={lon70}->{lon100}"
        )


@pytest.mark.asyncio
@pytest.mark.tier2
async def test_simulation_manager_wire_emission_past_70s() -> None:
    """Verify raw wire broadcast emits frames past 70 seconds."""
    mgr = SimulationManager(SimulationConfig(scenario_name="clean_tma_10_aircraft", seed=42))
    emitted_frames: list[bytes] = []

    async def mock_broadcast_wire(raw_bytes: bytes, raw_str: str | None = None) -> None:
        if raw_bytes:
            emitted_frames.append(raw_bytes)

    mgr.broadcast_wire = mock_broadcast_wire  # type: ignore[method-assign]

    # Advance from 0 to 70s
    await mgr.step(70.0)
    count_at_70 = len(emitted_frames)
    assert count_at_70 > 1000

    # Advance from 70s to 100s
    await mgr.step(30.0)
    frames_between_70_and_100 = emitted_frames[count_at_70:]
    assert len(frames_between_70_and_100) > 500, (
        f"Expected >500 wire frames emitted between 70s and 100s, got {len(frames_between_70_and_100)}"
    )

    # Validate Mode S CRC on sampled emitted frames
    for raw in frames_between_70_and_100[:50]:
        decoded = decode_mode_s(raw)
        assert decoded.crc_valid is True


@pytest.mark.tier2
def test_tracking_engine_decoupled_timeout_stepping() -> None:
    """Verify TrackingEngine.step_time evaluates timeouts independently of frame arrivals."""
    engine = TrackingEngine(ref_lat=52.3105, ref_lon=4.7683)

    # Inject 3 position frames for KLM1023 to establish CONFIRMED track at t=11.0s
    raw_even = bytes.fromhex("8D40621D58C382D690C8AC2863A7")
    raw_odd = bytes.fromhex("8D40621D58C386435CC412692AD6")

    engine.update(10.0, decode_mode_s(raw_even))
    engine.update(10.5, decode_mode_s(raw_odd))
    engine.update(11.0, decode_mode_s(raw_even))

    def get_track_state(icao: int) -> TrackState:
        return engine._tracks[icao].state

    assert get_track_state(0x40621D) == TrackState.CONFIRMED

    # Advance time to 20.0s (9.0s since last seen at 11.0s; coasting_timeout is 5.0s)
    engine.step_time(20.0)
    assert get_track_state(0x40621D) == TrackState.COASTING

    # Advance time to 45.0s (34.0s since last seen at 11.0s; deletion_timeout is 30.0s)
    engine.step_time(45.0)
    assert get_track_state(0x40621D) == TrackState.DELETED
    assert engine.get_track(0x40621D) is None
