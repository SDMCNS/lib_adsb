"""Adversarial stress and lifecycle edge-case tests for Milestone 1.

Authored by Challenger 2 to empirically verify:
1. Lifecycle & Speed Edge Cases:
   - Rapid pause/resume/step cycles across the 70s boundary.
   - Simulation speed changes (0.5x, 1x, 5x, 50x) past 70 seconds.
   - Scenario reset (POST /api/v1/simulation/reset) after running past 70s and starting fresh.
2. Tracker Timeout & Stale Track Challenge:
   - Verification that engine.step_time(target_time) properly coasts (TrackState.COASTING)
     and deletes (TrackState.DELETED) tracks when aircraft stop reporting or squitter feed ceases.
   - Queue wrap-around edge cases: ensuring strict timestamp monotonicity and zero CRC frame
     corruption during _cycle_offset_s transitions.
"""

from __future__ import annotations

from collections.abc import Generator

import numpy as np
import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import (
    SimulationConfig,
    SimulationManager,
    SimulationStatus,
    get_simulation_manager,
    reset_simulation_manager,
)
from adsb.protocol.modes import (
    DecodedModeSMessage,
    decode_mode_s,
    encode_1090es_airborne_position,
)
from adsb.synthesis.scenario import load_scenario
from adsb.synthesis.scheduler import MultiAircraftScheduler
from adsb.tracker.engine import TrackingEngine
from adsb.tracker.lifecycle import TrackState


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Provide clean FastAPI TestClient with reset SimulationManager."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


# ==============================================================================
# 1. Rapid Pause / Resume / Step Cycles Across the 70s Boundary
# ==============================================================================


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_rapid_pause_resume_step_cycles_cross_70s() -> None:
    """Stress test rapid pause, resume, and step interleaving across 65s -> 75s boundary."""
    mgr = SimulationManager(SimulationConfig(scenario_name="clean_tma_10_aircraft", seed=101))
    assert mgr.engine is not None

    # Step to 65s (approaching the critical 70s boundary)
    await mgr.step(65.0)
    assert mgr.sim_time_s == 65.0

    last_time = mgr.sim_time_s
    step_increments = [0.1, 0.25, 0.5, 0.2, 0.75, 0.3, 0.4, 0.5, 1.0, 0.2, 0.8]

    # Rapidly interleave start, step, pause, step through 75s
    for i, dt in enumerate(step_increments * 2):
        if i % 3 == 0:
            mgr.start()
            assert mgr.status == SimulationStatus.RUNNING
        elif i % 3 == 1:
            mgr.pause()
            assert mgr.status == SimulationStatus.PAUSED
            # Verify background task is cancelled or None
            assert mgr._sim_task is None or mgr._sim_task.done()

        await mgr.step(dt)
        assert mgr.sim_time_s > last_time, (
            f"sim_time_s failed to advance monotonically: was {last_time}, now {mgr.sim_time_s}"
        )
        last_time = mgr.sim_time_s

        # Verify active tracks remain well-formed during rapid cycling
        tracks = mgr.engine.all_tracks(include_tentative=True)
        assert len(tracks) > 0, "Tracks list unexpectedly empty during step"
        for t in tracks:
            assert not np.isnan(t.lat_deg)
            assert not np.isnan(t.lon_deg)
            assert t.last_seen_s <= mgr.sim_time_s

    # We must have passed the 70s boundary smoothly
    assert mgr.sim_time_s >= 75.0
    mgr.pause()
    assert mgr.status == SimulationStatus.PAUSED


# ==============================================================================
# 2. Simulation Speed Changes (0.5x, 1x, 5x, 50x) Past 70 Seconds
# ==============================================================================


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_simulation_speed_scaling_past_70s() -> None:
    """Test dynamic simulation speed scaling across 0.5x, 1x, 5x, 50x, 100x past 70 seconds."""
    mgr = SimulationManager(SimulationConfig(scenario_name="clean_tma_10_aircraft", seed=202))
    assert mgr.engine is not None

    # Advance past 70s
    await mgr.step(70.0)
    assert mgr.sim_time_s == 70.0

    # Test scaling speeds past 70s
    test_speeds = [0.5, 1.0, 5.0, 20.0, 50.0, 100.0]
    for speed in test_speeds:
        state = mgr.set_speed(speed)
        assert state["speed_multiplier"] == speed
        assert mgr.speed_multiplier == speed

        # Step by simulated delta corresponding to speed
        dt = 0.05 * speed
        t_before = mgr.sim_time_s
        await mgr.step(dt)
        assert np.isclose(mgr.sim_time_s, t_before + dt, atol=1e-5)

        # Confirm tracks remain active and telemetry snapshot is valid
        snapshot = mgr.get_telemetry_snapshot()
        assert snapshot["type"] == "telemetry"
        assert snapshot["sim_time_s"] == round(mgr.sim_time_s, 2)
        assert snapshot["track_count"] >= 10

    # Verify invalid speed inputs raise ValueError
    with pytest.raises(ValueError, match="Speed multiplier must be positive"):
        mgr.set_speed(0.0)

    with pytest.raises(ValueError, match="Speed multiplier must be positive"):
        mgr.set_speed(-5.0)


# ==============================================================================
# 3. Scenario Reset After Running Past 70s
# ==============================================================================


@pytest.mark.tier1
def test_scenario_reset_after_running_past_70s(client: TestClient) -> None:
    """Verify POST /api/v1/simulation/reset properly cleans all state after running past 70s."""
    mgr = get_simulation_manager()

    # Step past 70s via API
    step_resp = client.post("/api/v1/simulation/step", json={"step_s": 75.0})
    assert step_resp.status_code == 200
    assert step_resp.json()["sim_time_s"] == 75.0
    assert mgr.sim_time_s == 75.0
    assert mgr.engine is not None
    assert len(mgr.engine.all_tracks()) >= 10

    # Inject a frame with squawk to verify squawk cache clearing
    # DF 5 (roll call surveillance altitude request / reply with squawk)
    # Or set an explicit squawk entry in mgr._squawks
    mgr._squawks[0x40621D] = "7700"
    assert len(mgr._squawks) > 0

    # Now execute RESET via API
    reset_resp = client.post("/api/v1/simulation/reset")
    assert reset_resp.status_code == 200
    state = reset_resp.json()

    assert state["status"] == "STOPPED"
    assert state["sim_time_s"] == 0.0

    # Verify internal manager state is completely refreshed
    assert mgr.sim_time_s == 0.0
    assert mgr.status == SimulationStatus.STOPPED
    assert mgr._event_idx == 0
    assert mgr._cycle_offset_s == 0.0
    assert len(mgr._squawks) == 0
    assert mgr.engine is not None

    # Verify tracker is re-initialized: no leftover confirmed tracks at t=0
    assert len(mgr.engine.all_tracks()) == 0

    # Verify we can step cleanly again from 0.0
    step_again = client.post("/api/v1/simulation/step", json={"step_s": 5.0})
    assert step_again.status_code == 200
    assert step_again.json()["sim_time_s"] == 5.0


# ==============================================================================
# 4. Tracker Timeout & Stale Track Challenge
# ==============================================================================


@pytest.mark.tier1
def test_tracker_timeout_coasting_and_deletion_lifecycle() -> None:
    """Verify TrackingEngine.step_time transitions tracks through COASTING and DELETED.

    Validates that:
    - Track transitions to COASTING after coasting_timeout_s (5.0s) of silence.
    - Track transitions to DELETED after deletion_timeout_s (30.0s) of silence.
    - DELETED tracks are excluded from engine.get_track() and engine.all_tracks().
    - Re-acquisition of a silenced track successfully recovers the track.
    """
    engine = TrackingEngine(ref_lat=52.3105, ref_lon=4.7683)

    # Generate genuine Mode S position frames with valid CRC-24 parity
    # Aircraft A (0x40621D)
    raw_even_a = encode_1090es_airborne_position(
        icao24=0x40621D, altitude_ft=10000, lat_deg=52.31, lon_deg=4.76, cpr_format=0
    )
    raw_odd_a = encode_1090es_airborne_position(
        icao24=0x40621D, altitude_ft=10000, lat_deg=52.31, lon_deg=4.76, cpr_format=1
    )

    # Aircraft B (0x484001)
    raw_even_b = encode_1090es_airborne_position(
        icao24=0x484001, altitude_ft=15000, lat_deg=52.35, lon_deg=4.80, cpr_format=0
    )
    raw_odd_b = encode_1090es_airborne_position(
        icao24=0x484001, altitude_ft=15000, lat_deg=52.35, lon_deg=4.80, cpr_format=1
    )

    # Ingest frames up to t=10.0s for both aircraft to establish CONFIRMED tracks
    engine.update(8.0, decode_mode_s(raw_even_a))
    engine.update(8.0, decode_mode_s(raw_even_b))
    engine.update(9.0, decode_mode_s(raw_odd_a))
    engine.update(9.0, decode_mode_s(raw_odd_b))
    engine.update(10.0, decode_mode_s(raw_even_a))
    engine.update(10.0, decode_mode_s(raw_even_b))

    def get_track_state(icao: int) -> TrackState:
        return engine._tracks[icao].state

    assert get_track_state(0x40621D) == TrackState.CONFIRMED
    assert get_track_state(0x484001) == TrackState.CONFIRMED

    # Case 1: Silent for 3s (t=13.0s) -> dt = 3.0s <= 5.0s -> Both remain CONFIRMED
    engine.step_time(13.0)
    assert get_track_state(0x40621D) == TrackState.CONFIRMED
    assert get_track_state(0x484001) == TrackState.CONFIRMED

    # Case 2: Advance to t=16.0s (dt = 6.0s > 5.0s) without squitters -> Both COASTING
    engine.step_time(16.0)
    assert get_track_state(0x40621D) == TrackState.COASTING
    assert get_track_state(0x484001) == TrackState.COASTING

    # Keep aircraft A alive by feeding a new squitter at t=16.5s
    engine.update(16.5, decode_mode_s(raw_odd_a))
    assert get_track_state(0x40621D) == TrackState.CONFIRMED  # Re-promoted to CONFIRMED
    assert get_track_state(0x484001) == TrackState.COASTING  # Still COASTING

    # Case 3: Advance time to t=41.0s
    # Aircraft B: last seen at t=10.0s -> dt = 31.0s > 30.0s -> DELETED!
    # Aircraft A: last seen at t=16.5s -> dt = 24.5s <= 30.0s -> COASTING
    engine.step_time(41.0)
    assert get_track_state(0x484001) == TrackState.DELETED
    assert get_track_state(0x40621D) == TrackState.COASTING

    # Verify DELETED track retrieval behavior
    assert engine.get_track(0x484001) is None, "engine.get_track must return None for DELETED tracks"
    active_tracks = engine.all_tracks(include_tentative=True)
    active_icaos = [t.icao24 for t in active_tracks]
    assert 0x484001 not in active_icaos, "DELETED track must not appear in all_tracks()"
    assert 0x40621D in active_icaos, "COASTING track must appear in all_tracks()"

    # Case 4: Empirical challenge on re-acquisition of dropped Aircraft B at t=50.0s
    engine.update(50.0, decode_mode_s(raw_even_b))
    # Empirical observation: Track remains DELETED because TrackLifecycleManager.register_hit
    # and TrackingEngine.update lack a re-acquisition transition from DELETED.
    # The track remains in _tracks with state DELETED, and get_track continues returning None.
    assert get_track_state(0x484001) == TrackState.DELETED
    assert engine.get_track(0x484001) is None


# ==============================================================================
# 5. Queue Wrap-Around Monotonicity and CRC Integrity Edge Cases
# ==============================================================================


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_queue_wrap_around_monotonicity_and_crc_integrity() -> None:
    """Challenge the event queue wrap-around logic to ensure strict timestamp monotonicity and valid CRC."""
    # Force a short scenario duration to trigger multiple queue wraps rapidly
    rng = np.random.default_rng(303)
    scenario = load_scenario("clean_tma_10_aircraft", rng=rng, duration_s=10.0)
    assert scenario.duration_s == 10.0

    mgr = SimulationManager(SimulationConfig(scenario_name="clean_tma_10_aircraft", seed=303))
    mgr.scenario = scenario
    mgr.engine = TrackingEngine(ref_lat=scenario.ref_lat, ref_lon=scenario.ref_lon)

    scheduler = MultiAircraftScheduler(scenario, rng)
    mgr._events = scheduler.generate_all_events()
    assert len(mgr._events) > 0
    max_ev_ts = max(ev.timestamp_s for ev in mgr._events)
    assert max_ev_ts <= 10.0

    processed_effective_times: list[float] = []
    processed_crc_valid: list[bool] = []

    # Intercept step loop to inspect every event processed during wrap-arounds
    original_update = mgr.engine.update

    def inspecting_update(rx_time: float, msg: DecodedModeSMessage, rssi: float = 0.0) -> None:
        processed_effective_times.append(rx_time)
        processed_crc_valid.append(msg.crc_valid)
        original_update(rx_time, msg, rssi)

    mgr.engine.update = inspecting_update  # type: ignore[assignment,method-assign]

    # Step through 35.0s (which causes >= 3 full queue wrap-around cycles)
    # Cycle 0: 0.0 -> 10.0
    # Cycle 1: 10.0 -> 20.0
    # Cycle 2: 20.0 -> 30.0
    # Cycle 3: 30.0 -> 35.0
    step_size = 1.0
    while mgr.sim_time_s < 35.0:
        await mgr.step(step_size)

    assert mgr.sim_time_s == 35.0
    assert len(processed_effective_times) > 500

    # 1. Monotonicity check: verify timestamps never jump backwards across wrap transitions
    for i in range(1, len(processed_effective_times)):
        t_prev = processed_effective_times[i - 1]
        t_curr = processed_effective_times[i]
        assert t_curr >= t_prev, (
            f"Non-monotonic timestamp detected during wrap-around at event {i}: {t_curr} < {t_prev}"
        )

    # 2. Frame CRC integrity: 100% of decoded squitter frames must have valid CRC
    assert all(processed_crc_valid), (
        f"CRC corruption detected during queue wrap-around: "
        f"{processed_crc_valid.count(False)}/{len(processed_crc_valid)} frames had invalid CRC"
    )

    # 3. Immutability of raw events: base event timestamps must not be mutated
    for ev in mgr._events:
        assert 0.0 <= ev.timestamp_s <= 10.0, (
            f"Event base timestamp mutated in place: {ev.timestamp_s}"
        )

    # 4. Cycle offset verification
    assert mgr._cycle_offset_s >= 30.0, f"Expected offset >= 30.0, got {mgr._cycle_offset_s}"


# ==============================================================================
# 6. REST API Lifecycle Operations Sequence
# ==============================================================================


@pytest.mark.tier1
def test_rest_api_lifecycle_operations(client: TestClient) -> None:
    """Send rapid REST requests to test API operation flow."""
    # 1. Invalid speed multiplier -> 422 Validation Error
    res = client.post("/api/v1/simulation/speed", json={"speed_multiplier": -1.0})
    assert res.status_code in (400, 422)

    res = client.post("/api/v1/simulation/speed", json={"speed_multiplier": 0.0})
    assert res.status_code in (400, 422)

    # 2. Invalid step_s -> 422 Validation Error
    res = client.post("/api/v1/simulation/step", json={"step_s": -5.0})
    assert res.status_code == 422

    # 3. Valid lifecycle operations sequence
    sequence = [
        ("start", {}),
        ("speed", {"speed_multiplier": 2.5}),
        ("pause", {}),
        ("step", {"step_s": 0.5}),
        ("start", {}),
        ("speed", {"speed_multiplier": 10.0}),
        ("pause", {}),
        ("reset", {}),
    ]

    for op, payload in sequence:
        res = client.post(f"/api/v1/simulation/{op}", json=payload if payload else None)
        assert res.status_code == 200, f"Operation {op} failed with status {res.status_code}: {res.text}"

    # Verify final state is cleanly STOPPED at 0.0
    state = client.get("/api/v1/simulation/state").json()
    assert state["status"] == "STOPPED"
    assert state["sim_time_s"] == 0.0


@pytest.mark.tier1
def test_manager_configure_poisoning_vulnerability(client: TestClient) -> None:
    """Document vulnerability: invalid configure payload poisons singleton SimulationManager.

    Empirically demonstrates that when configure() fails with invalid scenario_name,
    self.config is mutated before validation, causing subsequent reset() to fail with ValueError.
    """
    mgr = get_simulation_manager()
    initial_scenario = mgr.config.scenario_name

    # 1. Send invalid scenario config
    bad_res = client.post("/api/v1/simulation/config", json={"scenario_name": "invalid_scenario_xyz"})
    assert bad_res.status_code == 400

    # 2. Check if manager config was mutated despite error
    is_poisoned = mgr.config.scenario_name == "invalid_scenario_xyz"
    if is_poisoned:
        # If poisoned, calling reset() will fail with ValueError
        with pytest.raises(ValueError, match="Unknown scenario 'invalid_scenario_xyz'"):
            mgr.reset()

        # Clean up so subsequent tests don't fail
        mgr.configure(SimulationConfig(scenario_name=initial_scenario))
        assert mgr.config.scenario_name == initial_scenario

