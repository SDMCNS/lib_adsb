"""Unit tests for Mode S protocol decoders, CRC-24, Gillham, CPR, and Comm-B BDS."""

from __future__ import annotations

import math

import pytest

from adsb.protocol.bds import (
    BDS10Data,
    BDS20Data,
    BDS40Data,
    classify_bds,
    decode_bds_10,
    decode_bds_20,
    decode_bds_40,
)
from adsb.protocol.cpr import (
    cpr_nl_table,
    decode_cpr_airborne,
    decode_cpr_local,
    encode_cpr_airborne,
    nl_lat,
)
from adsb.protocol.crc import (
    CRC24_POLY,
    CRC24_TABLE,
    SYNDROME_TABLE,
    compute_crc24,
    compute_syndrome,
    correct_syndrome_errors,
    verify_crc24,
)
from adsb.protocol.gillham import (
    binary_to_gray,
    decode_gillham_altitude,
    decode_mode_s_identity,
    encode_gillham_altitude,
    encode_squawk_code,
    gray_to_binary,
)
from adsb.protocol.modes import (
    decode_mode_s,
    encode_1090es_airborne_position,
    encode_1090es_identification,
)


class TestCRC:
    """Test Mode S CRC-24 parity, syndromes, and error correction."""

    def test_crc_table_initialized(self) -> None:
        assert len(CRC24_TABLE) == 256
        assert CRC24_POLY == 0xFFF409

    def test_syndrome_table_size(self) -> None:
        # Exactly 223 entries (112 single-bit + 111 adjacent 2-bit bursts)
        assert len(SYNDROME_TABLE) == 223

    def test_clean_frame_syndrome_is_zero(self) -> None:
        data = b"\x8d\x48\x40\xd6\x20\x2c\xc3\x71\xc3\x2c\xe0"
        parity = compute_crc24(data + b"\x00\x00\x00")
        frame = data + parity.to_bytes(3, "big")
        assert compute_syndrome(frame) == 0
        assert verify_crc24(frame) is True

    def test_error_correction_single_and_burst(self) -> None:
        data = b"\x8d\x48\x40\xd6\x20\x2c\xc3\x71\xc3\x2c\xe0"
        parity = compute_crc24(data + b"\x00\x00\x00")
        clean_frame = data + parity.to_bytes(3, "big")
        clean_int = int.from_bytes(clean_frame, "big")

        # Invert bit 42
        corrupted = (clean_int ^ (1 << 42)).to_bytes(14, "big")
        corrected, n_err = correct_syndrome_errors(corrupted)
        assert n_err == 1
        assert corrected == clean_frame

        # Invert adjacent bits 50, 51
        burst_corrupted = (clean_int ^ (3 << 50)).to_bytes(14, "big")
        b_corrected, b_err = correct_syndrome_errors(burst_corrupted)
        assert b_err == 2
        assert b_corrected == clean_frame


class TestGillhamAndSquawk:
    """Test 25-ft and 100-ft Gillham altitude and octal squawk decoding."""

    def test_q_bit_one_25ft(self) -> None:
        # Zero code returns None
        assert decode_gillham_altitude(0) is None

        # 35,000 ft: N = (35000 + 1000) // 25 = 1440 = 0x5A0
        alt_code = encode_gillham_altitude(35000, resolution_25ft=True)
        assert (alt_code >> 4) & 1 == 1  # Q=1
        assert decode_gillham_altitude(alt_code) == 35000

        # -1000 ft (minimum valid 25ft altitude)
        min_code = encode_gillham_altitude(-1000, resolution_25ft=True)
        assert decode_gillham_altitude(min_code) == -1000

    def test_q_bit_zero_100ft_gray(self) -> None:
        # Encode FL380 in 100ft Gillham mode
        code = encode_gillham_altitude(38000, resolution_25ft=False)
        assert (code >> 4) & 1 == 0  # Q=0
        dec = decode_gillham_altitude(code)
        assert dec == 38000

    def test_invalid_gillham_pulses_rejected(self) -> None:
        # G100 in {0, 5, 7} are invalid
        invalid_0 = 0x000  # Q=0 and all pulses 0
        assert decode_gillham_altitude(invalid_0) is None

    def test_gray_binary_conversion(self) -> None:
        for val in range(256):
            gray = binary_to_gray(val)
            assert gray_to_binary(gray) == val

    def test_squawk_code_round_trip(self) -> None:
        test_squawks = ["1200", "7000", "7500", "7600", "7700", "0000", "7777"]
        for sq in test_squawks:
            encoded = encode_squawk_code(sq)
            assert decode_mode_s_identity(encoded) == sq

        with pytest.raises(ValueError):
            encode_squawk_code("8888")  # Non-octal


class TestCPRMath:
    """Test CPR NL table, encoding, and global/local decoding."""

    def test_nl_table_bounds(self) -> None:
        assert len(cpr_nl_table) == 58
        assert nl_lat(0.0) == 59
        assert nl_lat(87.0) == 2
        assert nl_lat(88.0) == 1
        assert nl_lat(-45.0) == nl_lat(45.0)

    def test_airborne_cpr_round_trip(self) -> None:
        lat, lon = 52.3105, 4.7683  # Schiphol
        # Even
        yz0, xz0 = encode_cpr_airborne(lat, lon, 0)
        # Odd
        yz1, xz1 = encode_cpr_airborne(lat, lon, 1)

        dec_lat, dec_lon = decode_cpr_airborne(
            yz0 / 131072.0, xz0 / 131072.0, yz1 / 131072.0, xz1 / 131072.0, most_recent=1
        )
        assert math.isclose(dec_lat, lat, abs_tol=1e-4)
        assert math.isclose(dec_lon, lon, abs_tol=1e-4)

    def test_local_cpr_airborne(self) -> None:
        lat, lon = 40.6413, -73.7781  # JFK
        yz, xz = encode_cpr_airborne(lat, lon, 0)
        d_lat, d_lon = decode_cpr_local(
            yz / 131072.0, xz / 131072.0, 0, ref_lat=40.5, ref_lon=-73.5, surface=False
        )
        assert math.isclose(d_lat, lat, abs_tol=1e-4)
        assert math.isclose(d_lon, lon, abs_tol=1e-4)


class Test1090ESAndBDS:
    """Test Mode S extended squitter and Comm-B BDS codecs."""

    def test_encode_and_decode_identification(self) -> None:
        icao = 0x4840D6
        callsign = "KLM1023 "
        raw = encode_1090es_identification(icao, callsign)
        assert len(raw) == 14
        assert verify_crc24(raw) is True

        msg = decode_mode_s(raw)
        assert msg.df == 17
        assert msg.tc == 4
        assert msg.icao24 == icao
        assert msg.callsign.rstrip() == "KLM1023"

    def test_encode_and_decode_airborne_position(self) -> None:
        icao = 0x40621D
        raw = encode_1090es_airborne_position(
            icao, altitude_ft=28000, lat_deg=52.0, lon_deg=4.0, cpr_format=0
        )
        assert len(raw) == 14
        assert verify_crc24(raw) is True

        msg = decode_mode_s(raw)
        assert msg.df == 17
        assert msg.tc == 11
        assert msg.icao24 == icao
        assert msg.altitude_ft == 28000
        assert msg.cpr_format == 0

    def test_bds_classification_and_decoding(self) -> None:
        # BDS 1,0
        mb_10 = bytes([0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
        assert classify_bds(mb_10) == (1, 0)
        res_10 = decode_bds_10(mb_10)
        assert isinstance(res_10, BDS10Data)

        # BDS 2,0
        # Callsign 'KLM1023 '
        # 0x20 in byte 0
        mb_20 = bytearray(7)
        mb_20[0] = 0x20
        assert classify_bds(bytes(mb_20)) == (2, 0)
        res_20 = decode_bds_20(bytes(mb_20))
        assert isinstance(res_20, BDS20Data)

        # BDS 4,0
        # MCP alt active: bit 1 is 1, val = 1000 (16000 ft)
        # val bits 2..13: 1000 = 0x3E8
        # byte 0 = 0x80 | (0x3E8 >> 5) = 0x80 | 0x1F = 0x9F
        # byte 1 = (0x3E8 & 0x1F) << 3 = 0x08 << 3 = 0x40
        # baro active: bit 27 is 1, baro val = 1013 hPa -> (1013 - 800) / 0.1 = 2130 = 0x852
        val_40 = (1 << 55) | (1000 << 43) | (1 << 29) | (2130 << 17)
        mb_40_bytes = val_40.to_bytes(7, "big")
        assert classify_bds(mb_40_bytes) == (4, 0)
        res_40 = decode_bds_40(mb_40_bytes)
        assert isinstance(res_40, BDS40Data)
        assert res_40.mcp_altitude_ft == 16000
        assert math.isclose(res_40.baro_setting_hpa or 0.0, 1013.0, abs_tol=0.2)
