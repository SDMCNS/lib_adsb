"""Adversarial stress tests for Beast binary wire framing and codecs.

Verifies:
1. Mode S Beast binary wire framing with 0x1A escape sequences across all fields (timestamp, RSSI, payload).
2. Timestamp boundary conditions and 48-bit rollover behavior.
3. Signal level bytes (RSSI) edge cases (0, 26 [0x1A], 255).
4. Multi-frame streaming parser robustness against noise, corrupted escapes, and truncations.
"""

from __future__ import annotations

import random

import pytest

from adsb.wire.beast import (
    parse_beast_frame,
    parse_beast_stream,
    serialize_beast_frame,
)


class TestBeastBinaryFramingStress:
    """Stress tests and boundary condition verification for Beast wire format."""

    @pytest.mark.parametrize("frame_type,payload_len", [("1", 2), ("2", 7), ("3", 14)])
    def test_all_0x1a_payload_and_fields(self, frame_type: str, payload_len: int) -> None:
        """Verify serialization and parsing when timestamp, RSSI, and payload are all 0x1A."""
        mlat_ts = 0x1A1A1A1A1A1A  # 6 bytes of 0x1A
        rssi_byte = 0x1A          # 1 byte of 0x1A
        payload = b"\x1a" * payload_len

        encoded = serialize_beast_frame(frame_type, mlat_ts, rssi_byte, payload)

        # In wire encoding:
        # Header: 0x1A + frame_type (2 bytes)
        # Timestamp: 6 * 2 = 12 bytes
        # RSSI: 1 * 2 = 2 bytes
        # Payload: payload_len * 2 bytes
        expected_len = 2 + 12 + 2 + payload_len * 2
        assert len(encoded) == expected_len

        decoded = parse_beast_frame(encoded)
        assert decoded.frame_type == frame_type
        assert decoded.mlat_timestamp == mlat_ts
        assert decoded.rssi_byte == rssi_byte
        assert decoded.payload == payload

    @pytest.mark.parametrize("rssi", [0, 1, 26, 128, 254, 255])
    def test_rssi_signal_level_boundaries(self, rssi: int) -> None:
        """Verify signal level RSSI byte boundary values and escaping of 0x1A (26)."""
        payload = bytes(range(14))
        ts = 123456789
        encoded = serialize_beast_frame("3", ts, rssi, payload)
        decoded = parse_beast_frame(encoded)

        assert decoded.rssi_byte == rssi
        assert decoded.mlat_timestamp == ts
        assert decoded.payload == payload

    def test_timestamp_48bit_boundary_and_rollover(self) -> None:
        """Assert Beast 48-bit timestamp boundaries (0, max 2^48-1) roundtrip accurately."""
        max_48bit = (1 << 48) - 1  # 0xFFFFFFFFFFFF
        zero_ts = 0
        mid_ts = 0x800000000000

        for ts in (zero_ts, 1, mid_ts, max_48bit - 1, max_48bit):
            enc = serialize_beast_frame("3", ts, 120, b"TEST_PAYLOAD14")
            dec = parse_beast_frame(enc)
            assert dec.mlat_timestamp == ts

    def test_beast_stream_across_timestamp_rollover(self) -> None:
        """Verify that streaming parser seamlessly handles frames crossing 48-bit rollover."""
        max_48bit = (1 << 48) - 1
        ts_before_rollover = max_48bit - 50
        ts_at_rollover = max_48bit
        ts_after_rollover = 25  # Counter wrapped to 25

        f1 = serialize_beast_frame("2", ts_before_rollover, 180, bytes(range(7)))
        f2 = serialize_beast_frame("3", ts_at_rollover, 190, bytes(range(14)))
        f3 = serialize_beast_frame("1", ts_after_rollover, 200, b"\xaa\xbb")

        stream = f1 + f2 + f3
        parsed = parse_beast_stream(stream)

        assert len(parsed) == 3
        assert parsed[0].mlat_timestamp == ts_before_rollover
        assert parsed[0].frame_type == "2"
        assert parsed[1].mlat_timestamp == ts_at_rollover
        assert parsed[1].frame_type == "3"
        assert parsed[2].mlat_timestamp == ts_after_rollover
        assert parsed[2].frame_type == "1"

    def test_randomized_escape_fuzzing(self) -> None:
        """Fuzz Beast encoding/decoding with pseudo-random payloads containing scattered 0x1A bytes."""
        rng = random.Random(9999)

        for _ in range(200):
            ftype = rng.choice(["1", "2", "3"])
            plen = 2 if ftype == "1" else (7 if ftype == "2" else 14)

            # Generate random payload with high density of 0x1A bytes
            raw_payload = bytearray(rng.randbytes(plen))
            for i in range(plen):
                if rng.random() < 0.35:
                    raw_payload[i] = 0x1A

            ts = rng.randint(0, (1 << 48) - 1)
            # Inject 0x1A into timestamp bytes occasionally
            if rng.random() < 0.3:
                ts_bytes = bytearray(ts.to_bytes(6, "big"))
                ts_bytes[rng.randrange(6)] = 0x1A
                ts = int.from_bytes(ts_bytes, "big")

            rssi = 0x1A if rng.random() < 0.3 else rng.randint(0, 255)

            encoded = serialize_beast_frame(ftype, ts, rssi, bytes(raw_payload))
            decoded = parse_beast_frame(encoded)

            assert decoded.frame_type == ftype
            assert decoded.mlat_timestamp == ts
            assert decoded.rssi_byte == rssi
            assert decoded.payload == bytes(raw_payload)

    def test_invalid_escapes_rejection(self) -> None:
        """Verify parse_beast_frame raises ValueError on corrupted or invalid 0x1A escapes."""
        # 1. Not starting with 0x1A
        with pytest.raises(ValueError, match="Invalid Beast frame"):
            parse_beast_frame(b"\x1b2\x00\x00\x00\x00\x00\x01\x10" + b"\x00" * 7)

        # 2. Frame too short
        with pytest.raises(ValueError, match="Invalid Beast frame"):
            parse_beast_frame(b"\x1a")

        # 3. Single 0x1A followed by non-0x1A byte in body
        corrupted = b"\x1a2\x00\x00\x1a\x33\x00\x01\x10" + b"\x00" * 7
        with pytest.raises(ValueError, match="Invalid 0x1A escape sequence"):
            parse_beast_frame(corrupted)

        # 4. Truncated escape at the end of the frame
        truncated = b"\x1a2\x00\x00\x00\x00\x00\x01\x10\x01\x02\x03\x04\x05\x06\x1a"
        with pytest.raises(ValueError, match="Invalid 0x1A escape sequence"):
            parse_beast_frame(truncated)

        # 5. Body too short after unescaping
        too_short_body = b"\x1a2\x00\x00\x00\x00"
        with pytest.raises(ValueError, match="Beast frame body too short"):
            parse_beast_frame(too_short_body)

    def test_beast_stream_resilience_to_garbage_and_corruption(self) -> None:
        """Verify stream parser recovers valid frames amid noise, garbage prefixes, and corrupt frames."""
        f1 = serialize_beast_frame("1", 1001, 10, b"\x01\x02")
        f2 = serialize_beast_frame("2", 2002, 20, bytes(range(7)))
        f3 = serialize_beast_frame("3", 3003, 30, bytes(range(14)))

        # Bad frame: invalid escape sequence
        bad_frame = b"\x1a3\x00\x00\x00\x00\x00\x01\x10\x1a\x44\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        # Truncated frame
        truncated_frame = b"\x1a2\x00\x00"

        stream = (
            b"NOISE_PREFIX_12345\x00\xff\x1a"  # Unmatched 0x1A
            + f1
            + b"\xaa\xbb\xcc\xdd"
            + bad_frame
            + b"RANDOM_INTERLEAVED_BYTES"
            + f2
            + truncated_frame
            + f3
            + b"\x1a3\x00"  # Incomplete trailing frame
        )

        frames = parse_beast_stream(stream)
        assert len(frames) == 3
        assert frames[0].mlat_timestamp == 1001
        assert frames[0].payload == b"\x01\x02"
        assert frames[1].mlat_timestamp == 2002
        assert frames[1].payload == bytes(range(7))
        assert frames[2].mlat_timestamp == 3003
        assert frames[2].payload == bytes(range(14))
