"""Unit tests for Stage A avionics fault simulation and adversarial spoofing injectors.

Authoritative reference: docs/04_ERROR_AND_ANOMALY_SIMULATION.md Section 1 and Section 4.
"""

from __future__ import annotations

import numpy as np
import pytest

from adsb.core.geodesy import haversine_distance
from adsb.impairment.avionics import (
    AltitudeInversionConfig,
    AvionicsFaultConfig,
    AvionicsFaultInjector,
    CPRDesyncConfig,
    CPRDesyncMode,
    CPRStraddleConfig,
    DuplicateICAOConfig,
    GillhamGlitchConfig,
    GPSJammingConfig,
    StaleGPSConfig,
    apply_altitude_inversion_fault,
    apply_cpr_desync_fault,
    apply_cpr_straddle_fault,
    apply_duplicate_icao_fault,
    apply_gillham_stuck_bit_fault,
    apply_gps_jamming_fault,
    apply_gps_jamming_to_states,
    apply_stale_gps_fault,
    apply_stale_gps_to_states,
    recompute_frame_crc,
)
from adsb.impairment.spoofing import (
    FloodDenialInjector,
    GhostTrackInjector,
    ReplayInjector,
    ShadowTrackHijacker,
)
from adsb.protocol.cpr import (
    decode_cpr_global_airborne,
    decode_cpr_local,
    nl_lat,
)
from adsb.protocol.crc import compute_syndrome, verify_crc24
from adsb.protocol.modes import (
    decode_mode_s,
    encode_1090es_airborne_position,
    encode_1090es_df11,
)
from adsb.synthesis.scheduler import SquitterEvent
from adsb.synthesis.trajectory import AircraftTruthState, FlightPhase


@pytest.fixture
def sample_states() -> list[AircraftTruthState]:
    """Generate 10 seconds of synthetic truth states at 1 Hz."""
    states: list[AircraftTruthState] = []
    lat0, lon0 = 52.3105, 4.7683
    for i in range(10):
        t = float(i)
        states.append(
            AircraftTruthState(
                timestamp_s=t,
                lat_deg=lat0 + i * 0.002,  # Moving north
                lon_deg=lon0 + i * 0.003,  # Moving east
                alt_msl_m=3048.0,  # 10,000 ft
                alt_hae_m=3090.0,
                alt_baro_ft=10000.0 + i * 20.0,
                groundspeed_mps=200.0,
                tas_mps=210.0,
                ias_mps=180.0,
                mach=0.65,
                true_track_deg=56.0,
                true_heading_deg=55.0,
                vertical_rate_baro_mps=2.0,
                icao_hex="4840D6",
                callsign="KLM123",
                squawk="1200",
                phase=FlightPhase.CRUISE,
            )
        )
    return states


@pytest.fixture
def sample_squitters() -> list[SquitterEvent]:
    """Generate 6 seconds of alternating Even/Odd airborne position squitters."""
    events: list[SquitterEvent] = []
    lat0, lon0 = 52.3105, 4.7683
    icao = 0x4840D6

    for i in range(12):
        t = i * 0.5
        cpr_format = i % 2
        lat = lat0 + i * 0.001
        lon = lon0 + i * 0.001
        raw = encode_1090es_airborne_position(
            icao24=icao,
            altitude_ft=10000,
            lat_deg=lat,
            lon_deg=lon,
            cpr_format=cpr_format,
        )
        events.append(SquitterEvent(timestamp_s=t, raw_bytes=raw, icao24=icao))

    return events


class TestStageAInvariant:
    """Verify that all Stage A faulted frames recompute valid Mode S CRC-24 parity."""

    def test_recompute_frame_crc(self) -> None:
        raw = encode_1090es_df11(0xABCDEF)
        # Mutate some payload bytes
        byte_arr = bytearray(raw)
        byte_arr[1] ^= 0xFF
        mutated = bytes(byte_arr)

        assert not verify_crc24(mutated)
        assert compute_syndrome(mutated) != 0

        # Recompute CRC
        recomputed = recompute_frame_crc(mutated)
        assert verify_crc24(recomputed)
        assert compute_syndrome(recomputed) == 0
        decoded = decode_mode_s(recomputed)
        assert decoded.crc_valid


class TestAvionicsFaultModels:
    """Verify individual fault models AV-01 through AV-07."""

    def test_av01_stale_gps_position_freeze_and_jump(
        self, sample_states: list[AircraftTruthState], sample_squitters: list[SquitterEvent]
    ) -> None:
        """AV-01: Position freezes from t=2s to t=6s, while velocity advances."""
        cfg = StaleGPSConfig(start_time_s=2.0, duration_s=4.0)

        # 1. State-level freeze
        faulted_states = apply_stale_gps_to_states(sample_states, cfg)
        s_freeze = faulted_states[2]
        for s in faulted_states[2:6]:
            assert s.lat_deg == s_freeze.lat_deg
            assert s.lon_deg == s_freeze.lon_deg
            # Velocity and altitude still advance
            assert s.groundspeed_mps == 200.0
            assert s.alt_baro_ft > 10000.0

        # Unfreezes at t=6s with teleport jump
        s_unfreeze = faulted_states[6]
        assert s_unfreeze.lat_deg > s_freeze.lat_deg

        # 2. Frame-level freeze
        faulted_squitters = apply_stale_gps_fault(sample_squitters, cfg)
        for ev in faulted_squitters:
            # Stage A invariant
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid

        # Expected frozen position at t=2.0s (index 4 in sample_squitters)
        expected_lat0 = 52.3105 + 4 * 0.001  # 52.3145
        expected_lon0 = 4.7683 + 4 * 0.001   # 4.7723

        # Filter faulted frames within the freeze window [2.0s, 6.0s)
        frozen_events = [ev for ev in faulted_squitters if 2.0 <= ev.timestamp_s < 6.0]
        assert len(frozen_events) >= 2, "Need at least 2 squitters to test CPR pair decoding"

        # Verify that all adjacent Even/Odd pairs within the freeze window decode to (expected_lat0, expected_lon0)
        for i in range(len(frozen_events) - 1):
            ev_a = frozen_events[i]
            ev_b = frozen_events[i + 1]
            m_a = decode_mode_s(ev_a.raw_bytes)
            m_b = decode_mode_s(ev_b.raw_bytes)

            assert m_a.cpr_format != m_b.cpr_format, "Consecutive squitters must alternate Even/Odd"
            assert m_a.cpr_lat is not None and m_a.cpr_lon is not None
            assert m_b.cpr_lat is not None and m_b.cpr_lon is not None
            if m_a.cpr_format == 0:
                dlat, dlon = decode_cpr_global_airborne(
                    m_a.cpr_lat / 131072.0,
                    m_a.cpr_lon / 131072.0,
                    m_b.cpr_lat / 131072.0,
                    m_b.cpr_lon / 131072.0,
                    most_recent=1,
                )
            else:
                dlat, dlon = decode_cpr_global_airborne(
                    m_b.cpr_lat / 131072.0,
                    m_b.cpr_lon / 131072.0,
                    m_a.cpr_lat / 131072.0,
                    m_a.cpr_lon / 131072.0,
                    most_recent=0,
                )

            # Assert decoding accuracy within 0.0001 deg (~10 meters)
            assert abs(dlat - expected_lat0) < 0.0001, (
                f"Decoded lat {dlat:.5f} deviates from frozen lat {expected_lat0:.5f} by {abs(dlat - expected_lat0):.6f} deg"
            )
            assert abs(dlon - expected_lon0) < 0.0001, (
                f"Decoded lon {dlon:.5f} deviates from frozen lon {expected_lon0:.5f} by {abs(dlon - expected_lon0):.6f} deg"
            )

    def test_av02_cpr_desync_stuck_even_toggle(
        self, sample_squitters: list[SquitterEvent]
    ) -> None:
        """AV-02: Stuck toggle forces all frames to CPR Even (F=0)."""
        cfg = CPRDesyncConfig(mode=CPRDesyncMode.STUCK_EVEN)
        faulted = apply_cpr_desync_fault(sample_squitters, cfg)

        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid
            assert decoded.cpr_format == 0  # Forced to Even

    def test_av02_cpr_desync_longitude_lag(
        self, sample_squitters: list[SquitterEvent]
    ) -> None:
        """AV-02: Longitude lag desynchronizes CPR latitude and longitude."""
        cfg = CPRDesyncConfig(mode=CPRDesyncMode.LONGITUDE_LAG)
        faulted = apply_cpr_desync_fault(sample_squitters, cfg)

        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid

    def test_av03_cpr_straddle_nl_boundary(self) -> None:
        """AV-03: Aircraft crosses latitude zone transition (~51.893 deg)."""
        cfg = CPRStraddleConfig(transition_lat_deg=51.893425, delta_lat_deg=0.005)

        # Generate Even frame at 51.888425 deg (NL=37) and Odd frame at 51.898425 deg (NL=36)
        lat_even = cfg.transition_lat_deg - cfg.delta_lat_deg
        lat_odd = cfg.transition_lat_deg + cfg.delta_lat_deg
        assert nl_lat(lat_even) == 37
        assert nl_lat(lat_odd) == 36

        raw_even = encode_1090es_airborne_position(0x4840D6, 10000, lat_even, 4.7683, 0)
        raw_odd = encode_1090es_airborne_position(0x4840D6, 10000, lat_odd, 4.7683, 1)

        events = [
            SquitterEvent(0.0, raw_even, 0x4840D6),
            SquitterEvent(0.5, raw_odd, 0x4840D6),
        ]
        faulted = apply_cpr_straddle_fault(events, cfg)

        # Stage A invariant
        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            assert decode_mode_s(ev.raw_bytes).crc_valid

        # Verify Global CPR decode detects zone mismatch and raises ValueError
        msg_even = decode_mode_s(faulted[0].raw_bytes)
        msg_odd = decode_mode_s(faulted[1].raw_bytes)
        lat_cpr0 = msg_even.cpr_lat / 131072.0
        lon_cpr0 = msg_even.cpr_lon / 131072.0
        lat_cpr1 = msg_odd.cpr_lat / 131072.0
        lon_cpr1 = msg_odd.cpr_lon / 131072.0

        with pytest.raises(ValueError, match="CPR zone boundary straddle"):
            decode_cpr_global_airborne(
                lat_cpr0, lon_cpr0, lat_cpr1, lon_cpr1, most_recent=1
            )

        # Local CPR succeeds cleanly with reference position
        local_lat, _ = decode_cpr_local(
            lat_cpr1, lon_cpr1, cpr_format=1, ref_lat=51.9, ref_lon=4.7
        )
        assert abs(local_lat - lat_odd) < 0.05

    def test_av03_cpr_straddle_arbitrary_worldwide_longitude(self) -> None:
        """AV-03: Verify CPR straddle anomaly correctly preserves non-Schiphol flight longitudes (e.g. Calgary)."""
        cfg = CPRStraddleConfig(transition_lat_deg=51.893425, delta_lat_deg=0.005)
        calgary_lon = -114.0620

        raw_even = encode_1090es_airborne_position(0x123456, 10000, 51.888425, calgary_lon, 0)
        raw_odd = encode_1090es_airborne_position(0x123456, 10000, 51.898425, calgary_lon, 1)

        events = [
            SquitterEvent(0.0, raw_even, 0x123456),
            SquitterEvent(0.5, raw_odd, 0x123456),
        ]
        faulted = apply_cpr_straddle_fault(events, cfg)

        # 1. Global CPR must fail due to zone boundary straddle
        m0 = decode_mode_s(faulted[0].raw_bytes)
        m1 = decode_mode_s(faulted[1].raw_bytes)
        assert m0.cpr_lat is not None and m0.cpr_lon is not None
        assert m1.cpr_lat is not None and m1.cpr_lon is not None
        with pytest.raises(ValueError, match="CPR zone boundary straddle"):
            decode_cpr_global_airborne(
                m0.cpr_lat / 131072.0,
                m0.cpr_lon / 131072.0,
                m1.cpr_lat / 131072.0,
                m1.cpr_lon / 131072.0,
                most_recent=1,
            )

        # 2. Local CPR with Calgary receiver reference must recover Calgary longitude, NOT Schiphol (4.7683)
        _, recovered_lon = decode_cpr_local(
            m1.cpr_lat / 131072.0,
            m1.cpr_lon / 131072.0,
            1,
            ref_lat=51.9,
            ref_lon=-114.0,
        )
        assert abs(recovered_lon - calgary_lon) < 0.01
        assert abs(recovered_lon - 4.7683) > 50.0  # Must NOT be Schiphol!

    def test_av04_gillham_stuck_wire_c1(
        self, sample_squitters: list[SquitterEvent]
    ) -> None:
        """AV-04: Wire C1 stuck at 1 forces altitude cliff or dropout."""
        cfg = GillhamGlitchConfig(stuck_wires={"C1": 1})
        faulted = apply_gillham_stuck_bit_fault(sample_squitters, cfg)

        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid
            # Since Q=0 is forced and C1 is stuck, altitude is either cliff or None
            # None indicates illegal Gray code under Annex 10
            assert decoded.altitude_ft is None or isinstance(decoded.altitude_ft, int)

    def test_av05_altitude_swap_and_qnh_bias(
        self, sample_squitters: list[SquitterEvent]
    ) -> None:
        """AV-05: QNH offset bias alters reported altitude."""
        cfg = AltitudeInversionConfig(qnh_offset_hpa=1023.25)  # 10 hPa offset
        faulted = apply_altitude_inversion_fault(sample_squitters, cfg)

        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid
            # Original altitude was 10000 ft; QNH bias changes it
            if decoded.altitude_ft is not None:
                assert decoded.altitude_ft != 10000

    def test_av06_gps_jamming_tc_drop_and_noise(
        self, sample_squitters: list[SquitterEvent]
    ) -> None:
        """AV-06: GPS Jamming demotes Type Code to 18 (NIC=0)."""
        cfg = GPSJammingConfig(
            center_lat=52.31,
            center_lon=4.76,
            radius_m=50000.0,
            target_tc=18,
        )
        rng = np.random.default_rng(42)
        faulted = apply_gps_jamming_fault(sample_squitters, cfg, rng=rng)

        for ev in faulted:
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid
            assert decoded.tc == 18  # Demoted to TC 18

    def test_av06_geographic_masking_inside_vs_outside(self) -> None:
        """AV-06: Aircraft inside jamming zone is demoted to TC 18; aircraft outside is untouched."""
        cfg = GPSJammingConfig(
            center_lat=52.31,
            center_lon=4.76,
            radius_m=20000.0,  # 20 km radius
            target_tc=18,
        )
        rng = np.random.default_rng(42)

        # Aircraft 1 inside: Schiphol (dist ~ 2.6 km)
        ev_inside = SquitterEvent(
            1.0, encode_1090es_airborne_position(0x111111, 10000, 52.33, 4.78, 0), 0x111111
        )
        # Aircraft 2 outside: Rotterdam (dist ~ 45 km > 20 km)
        ev_outside = SquitterEvent(
            1.0, encode_1090es_airborne_position(0x222222, 10000, 51.95, 4.45, 0), 0x222222
        )

        faulted = apply_gps_jamming_fault([ev_inside, ev_outside], cfg, rng=rng)

        # Inside aircraft must be jammed to TC 18
        dec_inside = decode_mode_s(faulted[0].raw_bytes)
        assert dec_inside.tc == 18
        assert dec_inside.crc_valid is True

        # Outside aircraft must be untouched (TC 11)
        dec_outside = decode_mode_s(faulted[1].raw_bytes)
        assert dec_outside.tc == 11
        assert faulted[1].raw_bytes == ev_outside.raw_bytes

    def test_av06_apply_to_states_jamming(self) -> None:
        """AV-06: apply_to_states adds Gaussian noise to aircraft states inside jamming zone."""
        cfg = GPSJammingConfig(
            center_lat=52.31,
            center_lon=4.76,
            radius_m=10000.0,
            position_noise_sigma_m=1000.0,
        )
        rng = np.random.default_rng(42)
        injector = AvionicsFaultInjector(config=AvionicsFaultConfig(gps_jamming=cfg), rng=rng)

        # State inside jamming zone
        s_inside = AircraftTruthState(
            timestamp_s=1.0,
            lat_deg=52.31,
            lon_deg=4.76,
            alt_msl_m=1000.0,
            alt_hae_m=1000.0,
            alt_baro_ft=3000.0,
            groundspeed_mps=100.0,
            tas_mps=100.0,
            ias_mps=100.0,
            mach=0.3,
            true_track_deg=0.0,
            true_heading_deg=0.0,
            vertical_rate_baro_mps=0.0,
        )
        # State outside jamming zone
        s_outside = AircraftTruthState(
            timestamp_s=1.0,
            lat_deg=51.0,
            lon_deg=4.0,
            alt_msl_m=1000.0,
            alt_hae_m=1000.0,
            alt_baro_ft=3000.0,
            groundspeed_mps=100.0,
            tas_mps=100.0,
            ias_mps=100.0,
            mach=0.3,
            true_track_deg=0.0,
            true_heading_deg=0.0,
            vertical_rate_baro_mps=0.0,
        )

        out = injector.apply_to_states([s_inside, s_outside])
        assert out[0].lat_deg != 52.31  # Noisy position
        assert out[1].lat_deg == 51.0   # Untouched position

        direct_out = apply_gps_jamming_to_states([s_inside, s_outside], cfg, rng=rng)
        assert direct_out[0].lat_deg != 52.31
        assert direct_out[1].lat_deg == 51.0

    def test_av07_duplicate_icao_conflict(
        self, sample_squitters: list[SquitterEvent]
    ) -> None:
        """AV-07: Overwrites ICAO address with conflict address."""
        conflict_icao = 0x123456
        cfg = DuplicateICAOConfig(conflict_icao24=conflict_icao)
        faulted = apply_duplicate_icao_fault(sample_squitters, cfg)

        for ev in faulted:
            assert ev.icao24 == conflict_icao
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid
            assert decoded.icao24 == conflict_icao

    def test_avionics_fault_injector_unified(
        self, sample_states: list[AircraftTruthState], sample_squitters: list[SquitterEvent]
    ) -> None:
        """Verify unified AvionicsFaultInjector class combining multiple faults."""
        config = AvionicsFaultConfig(
            stale_gps=StaleGPSConfig(start_time_s=1.0, duration_s=3.0),
            cpr_desync=CPRDesyncConfig(mode=CPRDesyncMode.STUCK_EVEN),
        )
        injector = AvionicsFaultInjector(config=config, rng=np.random.default_rng(42))

        # Apply to states
        states_out = injector.apply_to_states(sample_states)
        assert len(states_out) == len(sample_states)
        assert states_out[1].lat_deg == states_out[2].lat_deg

        # Apply to squitters
        squitters_out = injector.apply_to_squitters(sample_squitters)
        assert len(squitters_out) == len(sample_squitters)
        for ev in squitters_out:
            assert compute_syndrome(ev.raw_bytes) == 0


class TestAdversarialSpoofing:
    """Verify GhostTrackInjector, ShadowTrackHijacker, FloodDenialInjector, and ReplayInjector."""

    def test_ghost_track_injector_contracts(self) -> None:
        """Verify GhostTrackInjector matches expectations of test_e2e_closed_loop.py."""
        deterministic_rng = np.random.default_rng(12345)
        ghost_injector = GhostTrackInjector(
            target_icao=0xFA11ED,
            speed_mps=800.0,
            rng=deterministic_rng,
        )
        events = ghost_injector.generate_ghost_squitters(duration_s=10.0)
        assert len(events) > 0

        # All events must have icao24 == 0xFA11ED and valid CRC
        for ev in events:
            assert ev.icao24 == 0xFA11ED
            assert compute_syndrome(ev.raw_bytes) == 0
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid
            assert decoded.icao24 == 0xFA11ED

        # Verify time-ordering
        timestamps = [e.timestamp_s for e in events]
        assert timestamps == sorted(timestamps)

    def test_shadow_track_hijacker(self, sample_squitters: list[SquitterEvent]) -> None:
        hijacker = ShadowTrackHijacker(
            target_icao=0x4840D6,
            divergence_track_deg=15.0,
            alt_rate_fpm=2000.0,
            tx_power_dbm=57.0,
        )
        shadows = hijacker.generate_shadow_squitters(sample_squitters, divergence_start_s=2.0)
        assert len(shadows) == 8  # Events from t=2.0s to 5.5s

        # 1. Verification of RF transmission metadata
        for ev in shadows:
            assert ev.tx_power_dbm == 57.0
            assert ev.icao24 == 0x4840D6
            assert compute_syndrome(ev.raw_bytes) == 0
            assert decode_mode_s(ev.raw_bytes).crc_valid is True

        # 2. Verification that payload bytes diverge from base aircraft
        # At t=2.0s (dt=0), divergence is 0; for t > 2.0s, bytes must differ
        base_by_t = {ev.timestamp_s: ev for ev in sample_squitters}
        for sev in shadows:
            base_t = round(sev.timestamp_s - 0.001, 3)
            base_ev = base_by_t[base_t]
            if base_t > 2.0:
                assert sev.raw_bytes != base_ev.raw_bytes

        # 3. Verification of Vertical Divergence (alt_rate_fpm)
        # At t=5.5s (dt=3.5s): expected d_alt = 2000 * 3.5 / 60 = 116.7 ft
        m_base_final = decode_mode_s(base_by_t[5.5].raw_bytes)
        m_shad_final = decode_mode_s(shadows[-1].raw_bytes)
        assert m_base_final.altitude_ft is not None
        assert m_shad_final.altitude_ft is not None
        actual_dalt = m_shad_final.altitude_ft - m_base_final.altitude_ft
        # 116.7 ft quantizes to +125 ft in 25-ft Gillham resolution
        assert actual_dalt == 125

        # 4. Verification of Lateral Kinematic Divergence
        # Decode global CPR on base final pair (t=5.0 and t=5.5)
        m_base_even = decode_mode_s(base_by_t[5.0].raw_bytes)
        m_base_odd = decode_mode_s(base_by_t[5.5].raw_bytes)
        assert m_base_even.cpr_lat is not None and m_base_even.cpr_lon is not None
        assert m_base_odd.cpr_lat is not None and m_base_odd.cpr_lon is not None
        base_lat, base_lon = decode_cpr_global_airborne(
            m_base_even.cpr_lat / 131072.0,
            m_base_even.cpr_lon / 131072.0,
            m_base_odd.cpr_lat / 131072.0,
            m_base_odd.cpr_lon / 131072.0,
            most_recent=1,
        )

        # Decode global CPR on shadow final pair (t=5.001 and t=5.501)
        m_shad_even = decode_mode_s(shadows[-2].raw_bytes)
        m_shad_odd = decode_mode_s(shadows[-1].raw_bytes)
        assert m_shad_even.cpr_lat is not None and m_shad_even.cpr_lon is not None
        assert m_shad_odd.cpr_lat is not None and m_shad_odd.cpr_lon is not None
        shad_lat, shad_lon = decode_cpr_global_airborne(
            m_shad_even.cpr_lat / 131072.0,
            m_shad_even.cpr_lon / 131072.0,
            m_shad_odd.cpr_lat / 131072.0,
            m_shad_odd.cpr_lon / 131072.0,
            most_recent=1,
        )

        div_dist_m = haversine_distance(base_lat, base_lon, shad_lat, shad_lon)
        # Over 3.5s at ~264 m/s with 15 deg divergence, lateral distance is ~240m
        assert div_dist_m > 200.0

    def test_flood_denial_injector(self) -> None:
        injector = FloodDenialInjector(num_targets=20, burst_rate_hz=100.0)
        events = injector.generate_flood(duration_s=2.0)
        assert len(events) == 200
        unique_icaos = {e.icao24 for e in events}
        assert len(unique_icaos) == 20
        for ev in events:
            assert compute_syndrome(ev.raw_bytes) == 0

    def test_flood_denial_geometric_ring_positions(self) -> None:
        """Verify FloodDenialInjector position mode emits DF17 frames in a geometric ring."""
        center_lat, center_lon = 52.3105, 4.7683
        radius_m = 15000.0
        injector = FloodDenialInjector(
            num_targets=8,
            burst_rate_hz=80.0,
            center_lat=center_lat,
            center_lon=center_lon,
            radius_m=radius_m,
            emit_positions=True,
            rng=np.random.default_rng(42),
        )
        events = injector.generate_flood(duration_s=1.0)
        assert len(events) == 80

        for ev in events:
            assert len(ev.raw_bytes) == 14
            assert compute_syndrome(ev.raw_bytes) == 0
            dec = decode_mode_s(ev.raw_bytes)
            assert dec.crc_valid is True
            assert dec.df == 17
            assert dec.tc == 11
            assert dec.cpr_lat is not None and dec.cpr_lon is not None and dec.cpr_format is not None

            # Decode position locally relative to center
            dec_lat, dec_lon = decode_cpr_local(
                dec.cpr_lat / 131072.0,
                dec.cpr_lon / 131072.0,
                dec.cpr_format,
                center_lat,
                center_lon,
            )
            dist = haversine_distance(dec_lat, dec_lon, center_lat, center_lon)
            assert abs(dist - radius_m) < 15.0  # Decodes within CPR quantization of ring radius

    def test_replay_injector_temporal(self, sample_squitters: list[SquitterEvent]) -> None:
        """Verify pure temporal shift without spatial offset preserves exact bytes."""
        injector = ReplayInjector(delay_s=60.0, delta_lat_deg=0.0, delta_lon_deg=0.0)
        replayed = injector.replay(sample_squitters)
        assert len(replayed) == len(sample_squitters)
        for orig, rep in zip(sample_squitters, replayed, strict=False):
            assert rep.timestamp_s == orig.timestamp_s + 60.0
            assert rep.raw_bytes == orig.raw_bytes

    def test_replay_injector_spatial_translation(self, sample_squitters: list[SquitterEvent]) -> None:
        """Verify spatial translation properly re-encodes CPR coordinates and validates CRC."""
        injector = ReplayInjector(
            delay_s=30.0,
            delta_lat_deg=1.5,
            delta_lon_deg=2.0,
            target_icao=0x4840D6,
        )
        replayed = injector.replay(sample_squitters)
        assert len(replayed) == len(sample_squitters)

        # 1. All replayed frames have valid CRC-24 and modified bytes
        for orig, rep in zip(sample_squitters, replayed, strict=False):
            assert rep.timestamp_s == orig.timestamp_s + 30.0
            assert rep.raw_bytes != orig.raw_bytes
            assert compute_syndrome(rep.raw_bytes) == 0
            assert decode_mode_s(rep.raw_bytes).crc_valid is True

        # 2. Decode original global CPR
        m0 = decode_mode_s(sample_squitters[0].raw_bytes)
        m1 = decode_mode_s(sample_squitters[1].raw_bytes)
        assert m0.cpr_lat is not None and m0.cpr_lon is not None
        assert m1.cpr_lat is not None and m1.cpr_lon is not None
        orig_lat, orig_lon = decode_cpr_global_airborne(
            m0.cpr_lat / 131072.0,
            m0.cpr_lon / 131072.0,
            m1.cpr_lat / 131072.0,
            m1.cpr_lon / 131072.0,
            most_recent=1,
        )

        # 3. Decode replayed global CPR
        r0 = decode_mode_s(replayed[0].raw_bytes)
        r1 = decode_mode_s(replayed[1].raw_bytes)
        assert r0.cpr_lat is not None and r0.cpr_lon is not None
        assert r1.cpr_lat is not None and r1.cpr_lon is not None
        rep_lat, rep_lon = decode_cpr_global_airborne(
            r0.cpr_lat / 131072.0,
            r0.cpr_lon / 131072.0,
            r1.cpr_lat / 131072.0,
            r1.cpr_lon / 131072.0,
            most_recent=1,
        )

        # 4. Assert spatial translation accuracy
        assert pytest.approx(rep_lat - orig_lat, abs=1e-3) == 1.5
        assert pytest.approx(rep_lon - orig_lon, abs=1e-3) == 2.0

    def test_spoofing_deterministic_reproducibility(self) -> None:
        inj1 = GhostTrackInjector(target_icao=0xFA11ED, rng=np.random.default_rng(42))
        inj2 = GhostTrackInjector(target_icao=0xFA11ED, rng=np.random.default_rng(42))

        ev1 = inj1.generate_ghost_squitters(duration_s=5.0)
        ev2 = inj2.generate_ghost_squitters(duration_s=5.0)

        assert [e.timestamp_s for e in ev1] == [e.timestamp_s for e in ev2]
        assert [e.raw_bytes for e in ev1] == [e.raw_bytes for e in ev2]
