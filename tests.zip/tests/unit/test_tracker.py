"""Unit tests for Multi-Target Stateful Tracking Engine (adsb.tracker).

Covers:
- StatefulCPRResolver (Even/Odd sliding buffer, 10s timeout, zone straddle, local fallback).
- IMMEstimator (7-state local ENU Kalman filter, CV and CT model probabilities, Joseph form).
- TrackLifecycleManager (M-of-N confirmation, coasting, deletion).
- AnomalyDetector (Kinematic teleport, stale GPS, Gillham altitude cliff, RF spoofing).
- TrackingEngine (Multi-target track pipeline, association, ground distance).
"""

from __future__ import annotations

import numpy as np
import pytest

from adsb.protocol.cpr import encode_cpr_airborne
from adsb.protocol.modes import DecodedModeSMessage
from adsb.tracker import (
    AnomalyDetector,
    IMMEstimator,
    StatefulCPRResolver,
    TrackingEngine,
    TrackLifecycleManager,
    TrackState,
)


class TestStatefulCPRResolver:
    """Test suite for StatefulCPRResolver."""

    def test_global_airborne_pairing_within_10s(self) -> None:
        resolver = StatefulCPRResolver(station_ref_lat=52.0, station_ref_lon=4.0)
        # Even frame at t = 0.0s for (52.2572, 3.91937)
        lat_cpr0, lon_cpr0 = encode_cpr_airborne(52.2572, 3.91937, 0)
        pos0 = resolver.resolve_position(0x40621D, lat_cpr0, lon_cpr0, 0, 0.0)
        assert pos0 is None  # Needs paired frame

        # Odd frame at t = 1.0s
        lat_cpr1, lon_cpr1 = encode_cpr_airborne(52.2572, 3.91937, 1)
        pos1 = resolver.resolve_position(0x40621D, lat_cpr1, lon_cpr1, 1, 1.0)
        assert pos1 is not None
        assert pos1[0] == pytest.approx(52.2572, abs=1e-4)
        assert pos1[1] == pytest.approx(3.91937, abs=1e-4)
        assert resolver.has_position(0x40621D) is True

    def test_global_pairing_timeout_exceeded(self) -> None:
        resolver = StatefulCPRResolver()
        lat_cpr0, lon_cpr0 = encode_cpr_airborne(52.0, 4.0, 0)
        resolver.resolve_position(0xA1B2C3, lat_cpr0, lon_cpr0, 0, 0.0)

        # Odd frame arrives 15.0 seconds later (> 10.0s timeout)
        lat_cpr1, lon_cpr1 = encode_cpr_airborne(52.0, 4.0, 1)
        pos = resolver.resolve_position(0xA1B2C3, lat_cpr1, lon_cpr1, 1, 15.0)
        assert pos is None

    def test_zone_straddle_rejection_without_exception(self) -> None:
        resolver = StatefulCPRResolver()
        # Create straddle: Even in zone NL=2, Odd in zone NL=1 (boundary at 87.0 deg)
        lat_cpr0, lon_cpr0 = encode_cpr_airborne(86.99, 10.0, 0)
        resolver.resolve_position(0x57AD01, lat_cpr0, lon_cpr0, 0, 0.0)

        lat_cpr1, lon_cpr1 = encode_cpr_airborne(87.01, 10.0, 1)
        pos = resolver.resolve_position(0x57AD01, lat_cpr1, lon_cpr1, 1, 0.5)
        # Should cleanly return None and flag straddle
        assert pos is None
        assert resolver.get_cpr_state(0x57AD01).zone_straddle_detected is True

    def test_local_cpr_fallback_after_position_established(self) -> None:
        resolver = StatefulCPRResolver()
        # 1. Establish position with global pair
        e_lat, e_lon = encode_cpr_airborne(52.0, 4.0, 0)
        o_lat, o_lon = encode_cpr_airborne(52.0, 4.0, 1)
        resolver.resolve_position(0x10C001, e_lat, e_lon, 0, 0.0)
        resolver.resolve_position(0x10C001, o_lat, o_lon, 1, 0.5)

        # 2. Single Even frame arriving 20 seconds later at a slightly moved location
        new_e_lat, new_e_lon = encode_cpr_airborne(52.02, 4.03, 0)
        pos = resolver.resolve_position(0x10C001, new_e_lat, new_e_lon, 0, 20.5)
        assert pos is not None
        assert pos[0] == pytest.approx(52.02, abs=1e-3)
        assert pos[1] == pytest.approx(4.03, abs=1e-3)


class TestIMMEstimator:
    """Test suite for 7-state local ENU IMM Kalman filter."""

    def test_imm_initialization_and_prediction(self) -> None:
        imm = IMMEstimator(e0=100.0, n0=200.0, u0=1000.0, ve0=50.0, vn0=0.0, vu0=5.0)
        assert imm.state[0] == pytest.approx(100.0)
        assert imm.state[3] == pytest.approx(50.0)

        # Predict forward 2 seconds
        imm.predict(2.0)
        assert imm.state[0] == pytest.approx(200.0, abs=1.0)
        assert imm.state[2] == pytest.approx(1010.0, abs=1.0)
        # Covariance must remain symmetric and positive-definite
        cov = imm.covariance
        assert np.allclose(cov, cov.T)
        evals = np.linalg.eigvalsh(cov)
        assert np.all(evals > 0)

    def test_imm_position_measurement_update(self) -> None:
        imm = IMMEstimator(e0=0.0, n0=0.0, u0=0.0)
        imm.predict(1.0)
        # Update with position at (10.0, 0.0, 0.0)
        imm.update_position(e_m=10.0, n_m=0.0, u_m=0.0, sigma_h=1.0)
        assert imm.state[0] > 0.0  # Pulled towards measurement
        cov = imm.covariance
        assert np.all(np.linalg.eigvalsh(cov) > 0)

    def test_imm_mode_probability_during_straight_vs_turn(self) -> None:
        imm = IMMEstimator(e0=0.0, n0=0.0, u0=1000.0, ve0=100.0, vn0=0.0)
        # Feed 10 seconds of straight velocity updates
        for _ in range(1, 11):
            imm.predict(1.0)
            imm.update_velocity(100.0, 0.0, 0.0, sigma_v=1.0)

        # In straight flight, CV mode dominates
        assert imm.mode_probability_cv > 0.8
        assert imm.mode_probability_turn < 0.2


class TestTrackLifecycle:
    """Test suite for TrackLifecycleManager."""

    def test_promotion_to_confirmed_on_m_of_n(self) -> None:
        mgr = TrackLifecycleManager(confirmation_m=3, confirmation_window_s=5.0)
        assert mgr.state == TrackState.TENTATIVE

        # Hit 1
        mgr.register_hit(1.0, has_valid_position=False)
        assert mgr.state == TrackState.TENTATIVE

        # Hit 2
        mgr.register_hit(2.0, has_valid_position=True)
        assert mgr.state == TrackState.TENTATIVE

        # Hit 3 within 5s with valid position -> CONFIRMED
        state3 = mgr.register_hit(3.0, has_valid_position=True)
        assert state3 == TrackState.CONFIRMED
        mgr = mgr  # Reset mypy type narrowing from earlier assert
        assert mgr.state == TrackState.CONFIRMED

    def test_coasting_and_deletion_timeouts(self) -> None:
        mgr = TrackLifecycleManager(coasting_timeout_s=5.0, deletion_timeout_s=30.0)
        mgr.register_hit(0.0, has_valid_position=True)
        mgr.register_hit(1.0, has_valid_position=True)
        mgr.register_hit(2.0, has_valid_position=True)
        assert mgr.state == TrackState.CONFIRMED

        # After 6s inactivity -> COASTING
        assert mgr.evaluate_timeouts(8.0) == TrackState.COASTING

        # Re-acquisition returns to CONFIRMED
        mgr.register_hit(8.5, has_valid_position=True)
        assert mgr.state == TrackState.CONFIRMED

        # After > 30s inactivity -> DELETED
        mgr.evaluate_timeouts(14.0)  # Goes to COASTING
        assert mgr.evaluate_timeouts(40.0) == TrackState.DELETED

        # Direct jump past deletion timeout from CONFIRMED reaches DELETED in a single cycle
        mgr2 = TrackLifecycleManager(coasting_timeout_s=5.0, deletion_timeout_s=30.0)
        mgr2.register_hit(0.0, has_valid_position=True)
        mgr2.register_hit(1.0, has_valid_position=True)
        mgr2.register_hit(2.0, has_valid_position=True)
        assert mgr2.state == TrackState.CONFIRMED
        assert mgr2.evaluate_timeouts(35.0) == TrackState.DELETED


class TestAnomalyDetector:
    """Test suite for AnomalyDetector."""

    def test_stale_gps_latch_detection(self) -> None:
        det = AnomalyDetector()
        # 4 consecutive updates with identical CPR fractions while moving
        anoms: list[str] = []
        for t in range(4):
            anoms = det.check_position_anomalies(
                icao24=0x111111,
                lat_deg=52.0,
                lon_deg=4.0,
                timestamp_s=float(t),
                cpr_lat=90000,
                cpr_lon=50000,
                groundspeed_kt=200.0,
            )
        assert "STALE_GPS_LATCH" in anoms

    def test_kinematic_teleport_detection(self) -> None:
        det = AnomalyDetector()
        det.check_position_anomalies(
            icao24=0x222222,
            lat_deg=52.0,
            lon_deg=4.0,
            timestamp_s=0.0,
            cpr_lat=10000,
            cpr_lon=10000,
        )
        # Position jumps 50 km in 0.5 seconds (100,000 m/s >> 600 m/s)
        anoms = det.check_position_anomalies(
            icao24=0x222222,
            lat_deg=52.45,
            lon_deg=4.0,
            timestamp_s=0.5,
            cpr_lat=20000,
            cpr_lon=20000,
        )
        assert "KINEMATIC_TELEPORT" in anoms
        assert "RF_PHYSICAL_SPOOF" in anoms

    def test_altitude_cliff_gillham_detection(self) -> None:
        det = AnomalyDetector()
        det.check_altitude_anomalies(0x333333, 10000.0, 0.0)
        # Sudden 3000 ft jump in 0.5s without vertical rate
        anoms = det.check_altitude_anomalies(
            0x333333, 13000.0, 0.5, vertical_rate_fpm=500.0
        )
        assert "ALTITUDE_CLIFF_GILLHAM" in anoms


class TestTrackingEngine:
    """Test suite for full TrackingEngine pipeline."""

    def test_tracking_engine_creation_and_distance(self) -> None:
        engine = TrackingEngine(ref_lat=52.3105, ref_lon=4.7683)
        dist = engine.compute_ground_distance_m(52.0, 4.0, 52.0, 4.0)
        assert dist == pytest.approx(0.0)

    def test_tentative_vs_confirmed_track_filtering(self) -> None:
        engine = TrackingEngine(ref_lat=52.3105, ref_lon=4.7683)
        # Ingest single DF11 message
        df11_msg = DecodedModeSMessage(df=11, icao24=0xABCDEF, crc_valid=True)
        engine.update(rx_timestamp_s=1.0, decoded_msg=df11_msg)

        # Single DF11 hit should remain TENTATIVE
        track = engine.get_track(0xABCDEF)
        assert track is not None
        assert track.state == TrackState.TENTATIVE

        # all_tracks(include_tentative=False) should be empty
        assert len(engine.all_tracks()) == 0

        # all_tracks(include_tentative=True) should return tentative track
        assert len(engine.all_tracks(include_tentative=True)) == 1

    def test_null_island_position_establishment_and_confirmation(self) -> None:
        """Verify that an aircraft at Null Island (0.0 deg N, 0.0 deg E) establishes position and confirms."""
        engine = TrackingEngine(ref_lat=0.0, ref_lon=0.0)
        icao = 0x555555

        lat_cpr0, lon_cpr0 = encode_cpr_airborne(0.0, 0.0, 0)
        lat_cpr1, lon_cpr1 = encode_cpr_airborne(0.0, 0.0, 1)

        # Hit 1: Even CPR frame at t=1.0s (needs paired odd frame for global resolution)
        msg0 = DecodedModeSMessage(
            df=17,
            tc=11,
            icao24=icao,
            crc_valid=True,
            cpr_format=0,
            cpr_lat=lat_cpr0,
            cpr_lon=lon_cpr0,
            altitude_ft=5000,
        )
        engine.update(rx_timestamp_s=1.0, decoded_msg=msg0)
        track = engine.get_track(icao)
        assert track is not None
        assert track.state == TrackState.TENTATIVE
        assert track.has_position is False

        # Hit 2: Odd CPR frame at t=2.0s -> resolves (0.0, 0.0)
        msg1 = DecodedModeSMessage(
            df=17,
            tc=11,
            icao24=icao,
            crc_valid=True,
            cpr_format=1,
            cpr_lat=lat_cpr1,
            cpr_lon=lon_cpr1,
            altitude_ft=5000,
        )
        engine.update(rx_timestamp_s=2.0, decoded_msg=msg1)
        track = engine.get_track(icao)
        assert track is not None
        assert track.has_position is True
        assert track.lat_deg == pytest.approx(0.0, abs=1e-4)
        assert track.lon_deg == pytest.approx(0.0, abs=1e-4)
        assert track.state == TrackState.TENTATIVE

        # Hit 3: Subsequent frame at t=3.0s -> promotes to CONFIRMED
        msg2 = DecodedModeSMessage(
            df=17,
            tc=11,
            icao24=icao,
            crc_valid=True,
            cpr_format=0,
            cpr_lat=lat_cpr0,
            cpr_lon=lon_cpr0,
            altitude_ft=5000,
        )
        engine.update(rx_timestamp_s=3.0, decoded_msg=msg2)
        track = engine.get_track(icao)
        assert track is not None
        assert track.has_position is True
        assert track.state == TrackState.CONFIRMED
        assert engine.all_tracks(include_tentative=False) == [track]
