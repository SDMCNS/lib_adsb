"""Automated unit tests for Requirement R3 terminal procedures kinematics.

Asserts:
1. Departure maintains runway heading (delta heading < 0.1 deg) for 5.0 NM.
2. Arrival intercepts extended ILS at 17.0 NM (+/- 0.1 NM), altitude = 3,000 ft (+/- 25 ft),
   track aligned with runway heading (+/- 0.1 deg).
3. Level deceleration from 17 NM to ~9.43 NM glide slope intercept, followed by 3.0 deg descent.
4. Touchdown occurs at arrival runway coordinates (< 50 m error).
5. Dynamic short-haul cruise altitude capping prevents VNAV overshoot.
"""

from __future__ import annotations

import pytest

from adsb.constants import NM_TO_METERS
from adsb.core.geodesy import haversine_distance
from adsb.synthesis.airports import get_airport
from adsb.synthesis.terminal import (
    compute_capped_cruise_altitude,
    compute_departure_fix,
    compute_glide_slope_altitude_ft,
    compute_glide_slope_intercept_distance_m,
    compute_ils_intercept_fix,
)
from adsb.synthesis.trajectory import (
    FlightPhase,
    generate_terminal_routed_trajectory,
)


def test_departure_fix_projection() -> None:
    """Verify 5 NM departure fix calculation is exactly 5.0 NM from midpoint."""
    eham = get_airport("EHAM")
    rwy = eham.primary_runway  # 18R, 183.0 deg
    lat, lon = compute_departure_fix(
        rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, rwy.true_heading_deg, distance_nm=5.0
    )
    dist_m = haversine_distance(rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, lat, lon)
    assert pytest.approx(dist_m / NM_TO_METERS, rel=1e-4) == 5.0


def test_ils_intercept_fix_projection() -> None:
    """Verify 17 NM ILS intercept fix calculation is exactly 17.0 NM from midpoint."""
    egll = get_airport("EGLL")
    rwy = egll.primary_runway  # 27R, 269.8 deg
    lat, lon = compute_ils_intercept_fix(
        rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, rwy.true_heading_deg, distance_nm=17.0
    )
    dist_m = haversine_distance(rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, lat, lon)
    assert pytest.approx(dist_m / NM_TO_METERS, rel=1e-4) == 17.0


def test_glide_slope_intercept_distance() -> None:
    """Verify 3-degree glide slope intercept distance calculation."""
    # Sea-level runway: (3000 * 0.3048) / tan(3 deg) ~ 17448 m ~ 9.42 NM
    d_sea_m = compute_glide_slope_intercept_distance_m(runway_elevation_ft=0.0)
    assert pytest.approx(d_sea_m / NM_TO_METERS, rel=1e-3) == 9.421

    # EGLL runway (83 ft): delta_h = 2917 ft -> ~9.16 NM
    d_egll_m = compute_glide_slope_intercept_distance_m(runway_elevation_ft=83.0)
    assert pytest.approx(d_egll_m / NM_TO_METERS, rel=1e-3) == 9.160


def test_glide_slope_altitude_profile() -> None:
    """Verify glide slope altitude calculation along descent."""
    elev_ft = 83.0
    # At touchdown distance = 0 m -> altitude = elevation
    assert pytest.approx(compute_glide_slope_altitude_ft(0.0, elev_ft), abs=0.1) == 83.0

    # At ~9.16 NM -> altitude = 3000 ft
    d_m = compute_glide_slope_intercept_distance_m(elev_ft)
    assert pytest.approx(compute_glide_slope_altitude_ft(d_m, elev_ft), abs=1.0) == 3000.0


def test_short_haul_cruise_altitude_capping() -> None:
    """Verify cruise altitude capping prevents VNAV overshoot on short-haul routes."""
    # Short hop: EHAM -> EBBR (~85 NM) with requested FL360 capped at 12,000 ft
    capped_85 = compute_capped_cruise_altitude(85.0, requested_alt_ft=36000.0)
    assert capped_85 <= 14000.0
    assert capped_85 >= 10000.0

    # Medium hop: EHAM -> EGLL (~200 NM) with requested FL360 capped at 30,000-35,000 ft
    capped_200 = compute_capped_cruise_altitude(200.0, requested_alt_ft=36000.0)
    assert capped_200 <= 35000.0
    assert capped_200 >= 30000.0

    # Long-haul: EGLL -> KJFK (~3000 NM) allows full requested altitude
    capped_3000 = compute_capped_cruise_altitude(3000.0, requested_alt_ft=36000.0)
    assert capped_3000 == 36000.0


def test_departure_kinematics_5nm_heading_hold() -> None:
    """Assert departure maintains runway heading (delta heading < 0.1 deg) for 5.0 NM."""
    states = generate_terminal_routed_trajectory(
        origin_icao="EHAM",
        dest_icao="EGLL",
        aircraft_type="B738",
        callsign="KLM1023",
        cruise_alt_ft=33000.0,
    )
    eham = get_airport("EHAM")
    rwy = eham.primary_runway  # 18R, 183.0 deg

    dep_states = [s for s in states if s.phase in (FlightPhase.TAKEOFF_ROLL, FlightPhase.INITIAL_CLIMB)]
    assert len(dep_states) > 50

    for s in dep_states:
        dist_from_mid_nm = haversine_distance(
            rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, s.lat_deg, s.lon_deg
        ) / NM_TO_METERS
        if dist_from_mid_nm < 5.0:
            assert abs(s.true_heading_deg - rwy.true_heading_deg) < 0.1, (
                f"Heading deviation {s.true_heading_deg} vs {rwy.true_heading_deg} at {dist_from_mid_nm:.2f} NM"
            )
            assert abs(s.true_track_deg - rwy.true_heading_deg) < 0.1
            assert s.roll_angle_deg == 0.0


def test_arrival_ils_intercept_17nm_kinematics() -> None:
    """Assert arrival intercepts extended ILS at 17.0 NM (+/- 0.1 NM) at 3,000 ft (+/- 25 ft) aligned."""
    states = generate_terminal_routed_trajectory(
        origin_icao="EHAM",
        dest_icao="EGLL",
        aircraft_type="B738",
        callsign="KLM1023",
        cruise_alt_ft=33000.0,
    )
    egll = get_airport("EGLL")
    rwy = egll.primary_runway  # 27R, 269.8 deg

    approach_states = [s for s in states if s.phase == FlightPhase.APPROACH]
    assert len(approach_states) > 0

    s_int = approach_states[0]
    dist_to_mid_nm = haversine_distance(
        rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, s_int.lat_deg, s_int.lon_deg
    ) / NM_TO_METERS

    assert abs(dist_to_mid_nm - 17.0) < 0.1, f"Intercept distance {dist_to_mid_nm:.3f} NM"
    assert abs(s_int.alt_baro_ft - 3000.0) < 25.0, f"Intercept altitude {s_int.alt_baro_ft:.1f} ft"
    assert abs(s_int.true_track_deg - rwy.true_heading_deg) < 0.1, f"Track deviation {s_int.true_track_deg}"


def test_glide_slope_descent_and_touchdown() -> None:
    """Assert 3-degree glide slope descent and touchdown at runway midpoint coordinates."""
    states = generate_terminal_routed_trajectory(
        origin_icao="EHAM",
        dest_icao="EGLL",
        aircraft_type="B738",
        callsign="KLM1023",
    )
    egll = get_airport("EGLL")
    rwy = egll.primary_runway

    # Touchdown state
    rollout_states = [s for s in states if s.phase == FlightPhase.LANDING_ROLLOUT and s.on_ground]
    assert len(rollout_states) > 0
    s_td = rollout_states[0]

    miss_dist_m = haversine_distance(
        rwy.midpoint_lat_deg, rwy.midpoint_lon_deg, s_td.lat_deg, s_td.lon_deg
    )
    assert miss_dist_m < 50.0, f"Touchdown position miss distance: {miss_dist_m:.2f} m"
    assert abs(s_td.alt_baro_ft - egll.elevation_ft) < 10.0


def test_short_haul_end_to_end_eham_to_ebbr() -> None:
    """Assert complete short-haul trajectory EHAM -> EBBR executes with capped cruise altitude."""
    states = generate_terminal_routed_trajectory(
        origin_icao="EHAM",
        dest_icao="EBBR",
        aircraft_type="A320",
        callsign="BEL101",
        cruise_alt_ft=36000.0,  # Requested FL360 should cap at FL120
    )
    max_alt = max(s.alt_baro_ft for s in states)
    assert max_alt <= 14000.0
    assert max_alt >= 10000.0

    # Ensure all phases present
    phases = {s.phase for s in states}
    assert FlightPhase.TAKEOFF_ROLL in phases
    assert FlightPhase.INITIAL_CLIMB in phases
    assert FlightPhase.CRUISE in phases
    assert FlightPhase.DESCENT in phases
    assert FlightPhase.APPROACH in phases
    assert FlightPhase.LANDING_ROLLOUT in phases
