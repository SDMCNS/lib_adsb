"""Unit tests for coordinate systems, geodesy, and unit conversion primitives."""

from __future__ import annotations

import math

import numpy as np

from adsb.core.coordinates import (
    EARTH_MEAN_RADIUS_M,
    WGS84_A_M,
    WGS84_B_M,
    ecef_to_geodetic,
    enu_rotation_matrix,
    enu_to_geodetic,
    geodetic_to_ecef,
    geodetic_to_enu,
)
from adsb.core.geodesy import (
    along_track_distance,
    cross_track_distance,
    destination_point,
    haversine_distance,
    initial_bearing,
)
from adsb.core.units import (
    deg_to_rad,
    feet_to_meters,
    fpm_to_mps,
    knots_to_mps,
    meters_to_feet,
    meters_to_nm,
    mps_to_fpm,
    mps_to_knots,
    nm_to_meters,
    normalize_angle_deg,
    normalize_angle_diff_deg,
    rad_to_deg,
)


class TestUnits:
    """Test aviation unit conversions and angle normalizations."""

    def test_length_conversions(self) -> None:
        assert math.isclose(feet_to_meters(100.0), 30.48, rel_tol=1e-9)
        assert math.isclose(meters_to_feet(30.48), 100.0, rel_tol=1e-9)
        assert math.isclose(nm_to_meters(1.0), 1852.0, rel_tol=1e-9)
        assert math.isclose(meters_to_nm(1852.0), 1.0, rel_tol=1e-9)

    def test_velocity_conversions(self) -> None:
        assert math.isclose(knots_to_mps(360.0), 185.2, rel_tol=1e-9)
        assert math.isclose(mps_to_knots(185.2), 360.0, rel_tol=1e-9)
        assert math.isclose(fpm_to_mps(6000.0), 30.48, rel_tol=1e-9)
        assert math.isclose(mps_to_fpm(30.48), 6000.0, rel_tol=1e-9)

    def test_angle_conversions(self) -> None:
        assert math.isclose(deg_to_rad(180.0), math.pi, rel_tol=1e-9)
        assert math.isclose(rad_to_deg(math.pi / 2.0), 90.0, rel_tol=1e-9)
        assert math.isclose(normalize_angle_deg(370.0), 10.0, rel_tol=1e-9)
        assert math.isclose(normalize_angle_deg(-10.0), 350.0, rel_tol=1e-9)
        assert math.isclose(normalize_angle_diff_deg(350.0), -10.0, rel_tol=1e-9)
        assert math.isclose(normalize_angle_diff_deg(-350.0), 10.0, rel_tol=1e-9)


class TestCoordinates:
    """Test WGS84 Geodetic <-> ECEF and local ENU transformations."""

    def test_equator_prime_meridian(self) -> None:
        x, y, z = geodetic_to_ecef(0.0, 0.0, 0.0)
        assert math.isclose(x, WGS84_A_M, abs_tol=1e-6)
        assert math.isclose(y, 0.0, abs_tol=1e-6)
        assert math.isclose(z, 0.0, abs_tol=1e-6)

        lat, lon, alt = ecef_to_geodetic(x, y, z)
        assert math.isclose(lat, 0.0, abs_tol=1e-9)
        assert math.isclose(lon, 0.0, abs_tol=1e-9)
        assert math.isclose(alt, 0.0, abs_tol=1e-6)

    def test_north_and_south_poles(self) -> None:
        # North pole
        x, y, z = geodetic_to_ecef(90.0, 0.0, 100.0)
        assert math.isclose(x, 0.0, abs_tol=1e-6)
        assert math.isclose(y, 0.0, abs_tol=1e-6)
        assert math.isclose(z, WGS84_B_M + 100.0, abs_tol=1e-6)

        lat, _, alt = ecef_to_geodetic(x, y, z)
        assert math.isclose(lat, 90.0, abs_tol=1e-9)
        assert math.isclose(alt, 100.0, abs_tol=1e-6)

        # South pole
        x_s, y_s, z_s = geodetic_to_ecef(-90.0, 0.0, 50.0)
        lat_s, _, alt_s = ecef_to_geodetic(x_s, y_s, z_s)
        assert math.isclose(lat_s, -90.0, abs_tol=1e-9)
        assert math.isclose(alt_s, 50.0, abs_tol=1e-6)

    def test_near_polar_fallback(self) -> None:
        # Near polar point with high altitude
        lat_in, lon_in, alt_in = 89.9999, 45.0, 10_000.0
        x, y, z = geodetic_to_ecef(lat_in, lon_in, alt_in)
        lat_out, lon_out, alt_out = ecef_to_geodetic(x, y, z)

        assert math.isclose(lat_out, lat_in, abs_tol=1e-7)
        assert math.isclose(lon_out, lon_in, abs_tol=1e-7)
        assert math.isclose(alt_out, alt_in, abs_tol=1e-4)

    def test_major_airports_round_trip(self) -> None:
        airports = [
            ("JFK", 40.6413, -73.7781, 10.0),
            ("LHR", 51.4700, -0.4543, 25.0),
            ("SYD", -33.8688, 151.2093, 20.0),
            ("NRT", 35.7647, 140.3863, 43.0),
        ]
        for name, lat, lon, alt in airports:
            x, y, z = geodetic_to_ecef(lat, lon, alt)
            d_lat, d_lon, d_alt = ecef_to_geodetic(x, y, z)
            assert math.isclose(d_lat, lat, abs_tol=1e-8), f"Lat error at {name}"
            assert math.isclose(d_lon, lon, abs_tol=1e-8), f"Lon error at {name}"
            assert math.isclose(d_alt, alt, abs_tol=1e-4), f"Alt error at {name}"

    def test_enu_rotation_matrix_orthonormality(self) -> None:
        rot = enu_rotation_matrix(52.3105, 4.7683)
        assert rot.shape == (3, 3)
        identity = np.eye(3, dtype=np.float64)
        assert np.allclose(rot @ rot.T, identity, atol=1e-12)
        assert math.isclose(float(np.linalg.det(rot)), 1.0, abs_tol=1e-12)

    def test_enu_round_trip(self) -> None:
        lat0, lon0, alt0 = 52.3105, 4.7683, 10.0  # EHAM Schiphol
        # Origin point itself in ENU must be (0, 0, 0)
        e, n, u = geodetic_to_enu(lat0, lon0, alt0, lat0, lon0, alt0)
        assert math.isclose(e, 0.0, abs_tol=1e-6)
        assert math.isclose(n, 0.0, abs_tol=1e-6)
        assert math.isclose(u, 0.0, abs_tol=1e-6)

        # Displaced point (1 km East, 2 km North, 500 m Up)
        t_lat, t_lon, t_alt = enu_to_geodetic(1000.0, 2000.0, 500.0, lat0, lon0, alt0)
        e_rec, n_rec, u_rec = geodetic_to_enu(t_lat, t_lon, t_alt, lat0, lon0, alt0)
        assert math.isclose(e_rec, 1000.0, abs_tol=1e-4)
        assert math.isclose(n_rec, 2000.0, abs_tol=1e-4)
        assert math.isclose(u_rec, 500.0, abs_tol=1e-4)


class TestGeodesy:
    """Test spherical great-circle navigation formulas."""

    def test_haversine_distance_self_and_antipode(self) -> None:
        # Distance to self is 0
        d_self = haversine_distance(40.0, -74.0, 40.0, -74.0)
        assert math.isclose(d_self, 0.0, abs_tol=1e-6)

        # Distance to antipode is pi * R_E
        d_anti = haversine_distance(0.0, 0.0, 0.0, 180.0)
        expected_anti = math.pi * EARTH_MEAN_RADIUS_M
        assert math.isclose(d_anti, expected_anti, rel_tol=1e-6)

    def test_transatlantic_jfk_to_lhr(self) -> None:
        # JFK: 40.6413, -73.7781 -> LHR: 51.4700, -0.4543
        dist_m = haversine_distance(40.6413, -73.7781, 51.4700, -0.4543)
        bearing = initial_bearing(40.6413, -73.7781, 51.4700, -0.4543)

        # Standard JFK-LHR great-circle distance is ~5540 km, initial bearing ~51.35 deg
        assert math.isclose(dist_m / 1000.0, 5540.0, abs_tol=50.0)
        assert math.isclose(bearing, 51.35, abs_tol=1.0)

    def test_equatorial_bearings(self) -> None:
        # Traveling East along equator
        b_east = initial_bearing(0.0, 0.0, 0.0, 10.0)
        assert math.isclose(b_east, 90.0, abs_tol=1e-6)

        # Traveling West along equator
        b_west = initial_bearing(0.0, 10.0, 0.0, 0.0)
        assert math.isclose(b_west, 270.0, abs_tol=1e-6)

        # Traveling North along meridian
        b_north = initial_bearing(0.0, 0.0, 10.0, 0.0)
        assert math.isclose(b_north, 0.0, abs_tol=1e-6)

        # Traveling South along meridian
        b_south = initial_bearing(10.0, 0.0, 0.0, 0.0)
        assert math.isclose(b_south, 180.0, abs_tol=1e-6)

    def test_cross_and_along_track(self) -> None:
        # Path A -> B along Equator from (0, 0) to (0, 10)
        # Point P at (1.0, 5.0) is to the North (Left of Eastbound path -> negative sign)
        xt = cross_track_distance(0.0, 0.0, 0.0, 10.0, 1.0, 5.0)
        at = along_track_distance(0.0, 0.0, 0.0, 10.0, 1.0, 5.0)

        # 1 deg latitude ≈ 111,195 m North
        assert xt < 0.0  # left of track
        assert math.isclose(abs(xt) / 1000.0, 111.195, abs_tol=1.0)

        # Along-track projection at mid-point is ~5 deg longitude along equator
        expected_at = haversine_distance(0.0, 0.0, 0.0, 5.0)
        assert math.isclose(at, expected_at, abs_tol=100.0)

    def test_destination_point(self) -> None:
        lat0, lon0 = 10.0, 20.0
        dist = 500_000.0  # 500 km
        brg = 45.0

        dest_lat, dest_lon = destination_point(lat0, lon0, dist, brg)
        # Verify distance back from destination
        calc_dist = haversine_distance(lat0, lon0, dest_lat, dest_lon)
        assert math.isclose(calc_dist, dist, abs_tol=1.0)

        calc_brg = initial_bearing(lat0, lon0, dest_lat, dest_lon)
        assert math.isclose(calc_brg, brg, abs_tol=0.01)
