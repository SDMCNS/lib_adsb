"""Empirical adversarial stress tests for multi-format wire codecs (AVR, SBS-1, JSON, Beast).

Comprehensive edge case fuzzing and stress harnesses verifying:
1. Raw AVR stream parser fuzzing (noise, corrupt characters, truncated frames, lowercase hex, timestamp boundaries).
2. SBS-1 BaseStation CSV across MSG 1..8 with missing/null fields, negative altitudes, zero speed/track, extra commas, and malformed rows.
3. JSON Lines streaming parser/serializer with nested dataclasses, sets, StrEnum, bytes, and malformed non-dict JSON lines.
4. Beast binary boundary behavior, escape sequences, and streaming recovery.
"""

from __future__ import annotations

import dataclasses
import enum
import random
from typing import Any

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from adsb.wire import (
    SBSMessage,
    parse_avr_frame,
    parse_avr_stream,
    parse_beast_frame,
    parse_beast_stream,
    parse_json_line,
    parse_json_stream,
    parse_sbs_message,
    parse_sbs_stream,
    serialize_avr_frame,
    serialize_beast_frame,
    serialize_json_line,
    serialize_sbs_message,
)

# =====================================================================
# 1. Raw AVR Adversarial Suite
# =====================================================================


class TestAVRAdversarial:
    """Adversarial stress harness for Raw AVR ASCII hex format."""

    @given(
        payload=st.binary(min_size=2, max_size=14),
        ts=st.integers(min_value=0, max_value=(1 << 48) - 1),
    )
    @settings(max_examples=100)
    def test_avr_timestamped_hypothesis_roundtrip(self, payload: bytes, ts: int) -> None:
        """Property: any valid payload and 48-bit timestamp round-trips identically."""
        wire = serialize_avr_frame(payload, mlat_timestamp_12mhz=ts)
        dec_payload, dec_ts = parse_avr_frame(wire)
        assert dec_payload == payload
        assert dec_ts == ts

    @given(payload=st.binary(min_size=2, max_size=14))
    @settings(max_examples=50)
    def test_avr_unstamped_hypothesis_roundtrip(self, payload: bytes) -> None:
        """Property: any valid unstamped payload round-trips identically with ts=None."""
        wire = serialize_avr_frame(payload)
        dec_payload, dec_ts = parse_avr_frame(wire)
        assert dec_payload == payload
        assert dec_ts is None

    @pytest.mark.parametrize(
        "ts",
        [
            0,
            1,
            0x7FFFFFFFFFFF,
            0xFFFFFFFFFFFF,
            1 << 48,  # Wraps to 0 via 48-bit mask
            (1 << 48) + 12345,  # Wraps to 12345
            -1,  # In two's complement mask becomes 0xFFFFFFFFFFFF
        ],
    )
    def test_avr_timestamp_rollover_and_masking(self, ts: int) -> None:
        """Verify 48-bit rollover masking in serialize_avr_frame and parse."""
        payload = bytes.fromhex("8D4840D6202CC371C32CE0576098")
        wire = serialize_avr_frame(payload, mlat_timestamp_12mhz=ts)
        dec_payload, dec_ts = parse_avr_frame(wire)
        assert dec_payload == payload
        expected_ts = ts & 0xFFFFFFFFFFFF
        assert dec_ts == expected_ts

    def test_avr_lowercase_hex_parsing(self) -> None:
        """Verify decoder accepts lowercase hex characters in both unstamped and timestamped frames."""
        # Unstamped with lowercase
        unstamped = "*8d4840d6202cc371c32ce0576098;\r\n"
        payload, ts = parse_avr_frame(unstamped)
        assert payload == bytes.fromhex("8D4840D6202CC371C32CE0576098")
        assert ts is None

        # Timestamped with lowercase timestamp and payload
        ts_frame = "@0000001a2b3c8d4840d6202cc371c32ce0576098;\n"
        payload, ts = parse_avr_frame(ts_frame)
        assert payload == bytes.fromhex("8D4840D6202CC371C32CE0576098")
        assert ts == 0x0000001A2B3C

    def test_avr_stream_fuzzing_noise_and_truncation(self) -> None:
        """Fuzz AVR stream parser with noise, missing semicolons, and corrupt characters."""
        valid_1 = "*8D4840D6202CC371C32CE0576098;\r\n"
        valid_2 = "@0000000000055D4840D6F8740F;\n"
        valid_3 = "*02E197B867A348;\n"

        # Interleaved corrupt fragments:
        # 1. Truncated frame missing ';' directly prepending valid_1
        # 2. Corrupt non-hex characters inside frame
        # 3. Missing prefix
        # 4. Odd-length hex frame
        corrupt_stream = (
            "RANDOM_NOISE_LINE\n"
            "*8D4840D6"  # Missing semicolon, followed immediately by valid_1
            + valid_1
            + "*8D48ZZ40D6;\n"  # Non-hex characters
            + "8D4840D6202CC371C32CE0576098;\n"  # Missing prefix
            + "*123;\n"  # Odd length hex (3 digits)
            + "@0001;\n"  # Timestamp too short (< 12 hex digits)
            + valid_2
            + "@000000000001ZZ;\n"  # Corrupt hex in timestamped
            + "   \t\r\n"
            + valid_3
            + "*8D4840"  # Incomplete trailing frame
        )

        frames = parse_avr_stream(corrupt_stream)
        assert len(frames) == 3
        assert frames[0][0] == bytes.fromhex("8D4840D6202CC371C32CE0576098")
        assert frames[0][1] is None
        assert frames[1][0] == bytes.fromhex("5D4840D6F8740F")
        assert frames[1][1] == 5
        assert frames[2][0] == bytes.fromhex("02E197B867A348")
        assert frames[2][1] is None

    def test_avr_frame_syntax_error_boundaries(self) -> None:
        """Verify parse_avr_frame strictly rejects malformed syntax."""
        with pytest.raises(ValueError, match="Empty AVR frame"):
            parse_avr_frame("   \n\r  ")

        with pytest.raises(ValueError, match="missing terminating ';'"):
            parse_avr_frame("*8D4840D6")

        with pytest.raises(ValueError, match="AVR frame too short"):
            parse_avr_frame(";")

        with pytest.raises(ValueError, match="AVR frame too short"):
            parse_avr_frame("*;")

        with pytest.raises(ValueError, match="Invalid AVR frame prefix"):
            parse_avr_frame("!8D4840D6;")

        with pytest.raises(ValueError, match="requires at least 12 hex digits"):
            parse_avr_frame("@00000012345;")  # 11 hex chars

        with pytest.raises(ValueError, match="Invalid hex"):
            parse_avr_frame("*8D48G6;")

        with pytest.raises(ValueError, match="Invalid hex"):
            parse_avr_frame("*123;")  # Odd number of hex characters

        with pytest.raises(ValueError, match="Invalid timestamp hex"):
            parse_avr_frame("@00000000000Z8D48;")

        with pytest.raises(ValueError, match="Invalid payload hex"):
            parse_avr_frame("@0000000000018D48G6;")


# =====================================================================
# 2. SBS-1 BaseStation Adversarial Suite
# =====================================================================


class TestSBSAdversarial:
    """Adversarial stress harness for SBS-1 BaseStation CSV format."""

    def test_sbs_all_transmission_types_1_to_8(self) -> None:
        """Verify round-trip across all SBS-1 message transmission types (MSG 1..8)."""
        # MSG 1: Identification & Category
        m1 = SBSMessage(transmission_type=1, hex_ident="4840D6", callsign="KLM1023")
        p1 = parse_sbs_message(serialize_sbs_message(m1))
        assert p1.transmission_type == 1
        assert p1.callsign == "KLM1023"

        # MSG 2: Surface Position
        m2 = SBSMessage(
            transmission_type=2,
            hex_ident="4840D6",
            altitude=0,
            ground_speed=12.5,
            track=95.0,
            lat=52.308,
            lon=4.764,
            is_on_ground=-1,
        )
        p2 = parse_sbs_message(serialize_sbs_message(m2))
        assert p2.transmission_type == 2
        assert p2.altitude == 0
        assert p2.ground_speed == pytest.approx(12.5, abs=0.1)
        assert p2.is_on_ground == -1

        # MSG 3: Airborne Position
        m3 = SBSMessage(
            transmission_type=3,
            hex_ident="40621D",
            altitude=38000,
            lat=52.2572,
            lon=3.91937,
            alert=0,
            emergency=0,
            spi=0,
            is_on_ground=0,
        )
        p3 = parse_sbs_message(serialize_sbs_message(m3))
        assert p3.transmission_type == 3
        assert p3.altitude == 38000
        assert p3.is_on_ground == 0

        # MSG 4: Airborne Velocity
        m4 = SBSMessage(
            transmission_type=4,
            hex_ident="485020",
            ground_speed=480.0,
            track=270.5,
            vertical_rate=-1500,
        )
        p4 = parse_sbs_message(serialize_sbs_message(m4))
        assert p4.transmission_type == 4
        assert p4.ground_speed == pytest.approx(480.0, abs=0.1)
        assert p4.vertical_rate == -1500

        # MSG 5: Surveillance Altitude Reply
        m5 = SBSMessage(
            transmission_type=5,
            hex_ident="4840D6",
            altitude=15000,
            alert=1,
            spi=0,
            is_on_ground=0,
        )
        p5 = parse_sbs_message(serialize_sbs_message(m5))
        assert p5.transmission_type == 5
        assert p5.altitude == 15000
        assert p5.alert == 1

        # MSG 6: Surveillance Identity Reply
        m6 = SBSMessage(
            transmission_type=6,
            hex_ident="4840D6",
            altitude=15000,
            squawk="7700",
            alert=1,
            emergency=1,
            spi=1,
            is_on_ground=0,
        )
        p6 = parse_sbs_message(serialize_sbs_message(m6))
        assert p6.transmission_type == 6
        assert p6.squawk == "7700"
        assert p6.emergency == 1

        # MSG 7: Air-to-Air Reply
        m7 = SBSMessage(transmission_type=7, hex_ident="4840D6", altitude=24000, is_on_ground=0)
        p7 = parse_sbs_message(serialize_sbs_message(m7))
        assert p7.transmission_type == 7
        assert p7.altitude == 24000

        # MSG 8: All-Call Reply
        m8 = SBSMessage(transmission_type=8, hex_ident="4840D6", is_on_ground=0)
        p8 = parse_sbs_message(serialize_sbs_message(m8))
        assert p8.transmission_type == 8
        assert p8.is_on_ground == 0

    def test_sbs_numeric_boundary_values(self) -> None:
        """Verify boundary numeric values: negative altitudes, zero speeds/tracks, high groundspeed."""
        # 1. Zero ground speed and track: ensure formatting doesn't produce empty strings
        msg_zero = SBSMessage(ground_speed=0.0, track=0.0, altitude=0, vertical_rate=0)
        csv_zero = serialize_sbs_message(msg_zero)
        p_zero = parse_sbs_message(csv_zero)
        assert p_zero.ground_speed == 0.0
        assert p_zero.track == 0.0
        assert p_zero.altitude == 0
        assert p_zero.vertical_rate == 0

        # 2. Negative altitude (e.g. below sea level / Dead Sea -1300 ft) and descent rate
        msg_neg = SBSMessage(altitude=-1300, vertical_rate=-6000, ground_speed=150.0, track=360.0)
        csv_neg = serialize_sbs_message(msg_neg)
        assert ",-1300," in csv_neg
        assert ",-6000," in csv_neg
        p_neg = parse_sbs_message(csv_neg)
        assert p_neg.altitude == -1300
        assert p_neg.vertical_rate == -6000
        assert p_neg.track == 360.0

        # 3. High supersonic speed (1200 kt)
        msg_supersonic = SBSMessage(ground_speed=1200.4, track=180.0)
        p_supersonic = parse_sbs_message(serialize_sbs_message(msg_supersonic))
        assert p_supersonic.ground_speed == pytest.approx(1200.4, abs=0.1)

        # 4. Extreme Lat / Lon boundaries (-90, 90, -180, 180)
        msg_geo = SBSMessage(lat=-90.0, lon=-180.0)
        p_geo = parse_sbs_message(serialize_sbs_message(msg_geo))
        assert p_geo.lat == pytest.approx(-90.0, abs=1e-5)
        assert p_geo.lon == pytest.approx(-180.0, abs=1e-5)

    def test_sbs_stream_parser_malformed_and_extra_commas(self) -> None:
        """Stress stream parser with random extra commas, malformed lines, and invalid fields."""
        stream = (
            # Valid row
            "MSG,1,1,1,4840D6,1,2026/10/31,12:00:00.000,2026/10/31,12:00:00.000,KLM1023,,,,,,,,,,,\r\n"
            # Row with random extra commas (24 columns instead of 22) - should still parse first 22
            "MSG,3,1,1,40621D,1,2026/10/31,12:00:01.000,2026/10/31,12:00:01.000,,38000,,,52.2572,3.91937,,,0,0,0,0,EXTRA_COL_1,EXTRA_COL_2\n"
            # Malformed row with fewer than 22 columns
            "MSG,1,1,1,SHORT_ROW\n"
            # Malformed row with non-integer transmission type
            "MSG,NOT_INT,1,1,4840D6,1,,,,,,,,,,,,,,,,\n"
            # Malformed row with non-integer altitude
            "MSG,3,1,1,40621D,1,,,,,,,,FL380,,,52.2,4.0,,,0,0,0,0\n"
            # Empty and whitespace lines
            "   \n\r\n"
            # Another valid row
            "MSG,4,1,1,485020,1,2026/10/31,12:00:02.000,2026/10/31,12:00:02.000,,,250.0,90.0,,,-800,,,,,\n"
        )

        messages = parse_sbs_stream(stream)
        assert len(messages) == 3
        assert messages[0].transmission_type == 1
        assert messages[0].callsign == "KLM1023"
        assert messages[1].transmission_type == 3
        assert messages[1].altitude == 38000
        assert messages[2].transmission_type == 4
        assert messages[2].ground_speed == pytest.approx(250.0, abs=0.1)


# =====================================================================
# 3. JSON Lines Adversarial Suite
# =====================================================================


class ColorEnum(enum.Enum):
    RED = 1
    GREEN = 2


class AircraftCategory(enum.StrEnum):
    HEAVY = "heavy"
    MEDIUM = "medium"
    LIGHT = "light"


@dataclasses.dataclass
class NestedInner:
    raw_payload: bytes
    category: AircraftCategory
    color: ColorEnum
    tags: set[str]


@dataclasses.dataclass
class NestedOuter:
    icao_hex: str
    inner: NestedInner
    altitudes: list[int]


class TestJSONCodecAdversarial:
    """Adversarial stress harness for JSON Lines serializer and streaming parser."""

    def test_json_complex_nested_dataclass_and_enums(self) -> None:
        """Verify serialization and deserialization of complex nested dataclasses with bytes and enums."""
        obj = NestedOuter(
            icao_hex="A1B2C3",
            inner=NestedInner(
                raw_payload=b"\x8d\x48\x40\xd6",
                category=AircraftCategory.HEAVY,
                color=ColorEnum.RED,
                tags={"adsb", "mode_s"},
            ),
            altitudes=[10000, 20000, 35000],
        )

        line = serialize_json_line(obj)
        assert line.endswith("\n")
        parsed = parse_json_line(line)

        assert parsed["icao_hex"] == "A1B2C3"
        assert parsed["inner"]["raw_payload"] == "8D4840D6"
        assert parsed["inner"]["category"] == "heavy"
        assert parsed["inner"]["color"] == "RED"
        assert parsed["inner"]["tags"] == ["adsb", "mode_s"]
        assert parsed["altitudes"] == [10000, 20000, 35000]

    def test_json_raw_bytes_and_bytearray_hex_encoding(self) -> None:
        """Verify bytes and bytearray are hex-encoded in uppercase."""
        data: dict[str, Any] = {
            "bytes_field": b"\x00\x1a\xff",
            "bytearray_field": bytearray(b"\xde\xad\xbe\xef"),
        }
        line = serialize_json_line(data)
        parsed = parse_json_line(line)
        assert parsed["bytes_field"] == "001AFF"
        assert parsed["bytearray_field"] == "DEADBEEF"

    def test_json_streaming_with_malformed_and_non_dict_lines(self) -> None:
        """Verify parse_json_stream handles noise, blank lines, and non-dict records."""
        stream = (
            '{"id": 1, "status": "ok"}\n'
            "\n"
            "   \r\n"
            "[1, 2, 3]\n"  # Valid JSON, but not a dict
            '"just a string"\n'  # Valid JSON primitive, not a dict
            "true\n"
            "42\n"
            "{invalid_json\n"  # Malformed JSON
            '{"id": 2, "status": "active"}\n'
        )
        records = parse_json_stream(stream)
        assert len(records) == 2
        assert records[0]["id"] == 1
        assert records[1]["id"] == 2

    @pytest.mark.parametrize(
        "invalid_input",
        [
            "",
            "   \n",
            "{unclosed",
            "[1, 2, 3]",
            '"string"',
            "123",
            "null",
            "true",
        ],
    )
    def test_json_parse_line_errors(self, invalid_input: str) -> None:
        """Verify parse_json_line raises ValueError on malformed or non-dict inputs."""
        with pytest.raises(ValueError):
            parse_json_line(invalid_input)


# =====================================================================
# 4. Beast Binary Adversarial Suite
# =====================================================================


class TestBeastAdversarial:
    """Additional adversarial boundary stress tests for Beast binary format."""

    def test_beast_timestamp_overflow_handling(self) -> None:
        """Verify serialize_beast_frame raises OverflowError on negative or out-of-range timestamps."""
        with pytest.raises(OverflowError):
            serialize_beast_frame("3", -1, 128, b"\x00" * 14)

        with pytest.raises(OverflowError):
            serialize_beast_frame("3", 1 << 48, 128, b"\x00" * 14)

    def test_beast_odd_escape_sequences_fuzzing(self) -> None:
        """Verify odd numbers of consecutive 0x1A escape bytes are rejected."""
        # 1. Three 0x1A bytes in payload (one pair unescaped, one leftover 0x1A)
        # Header: \x1a2, ts: 6 bytes, rssi: 1 byte, payload: 7 bytes with 3 0x1A
        corrupt = (
            b"\x1a2"
            + b"\x00" * 6  # ts
            + b"\x10"  # rssi
            + b"\x1a\x1a\x1a"  # 3 0x1A bytes
            + b"\x00" * 5
        )
        with pytest.raises(ValueError, match="Invalid 0x1A escape sequence"):
            parse_beast_frame(corrupt)

    def test_beast_stream_concatenated_burst(self) -> None:
        """Stress parse_beast_stream with a burst of 500 interleaved Beast frames."""
        rng = random.Random(42)
        frames_expected: list[tuple[str, int, int, bytes]] = []
        raw_stream = bytearray()

        for _ in range(500):
            ftype = rng.choice(["1", "2", "3"])
            plen = 2 if ftype == "1" else (7 if ftype == "2" else 14)
            ts = rng.randint(0, (1 << 48) - 1)
            rssi = rng.randint(0, 255)
            payload = rng.randbytes(plen)

            frames_expected.append((ftype, ts, rssi, payload))
            raw_stream.extend(serialize_beast_frame(ftype, ts, rssi, payload))

            # Interleave occasional noise bytes between frames
            if rng.random() < 0.2:
                raw_stream.extend(b"\x00\xff\xee\xdd")

        parsed = parse_beast_stream(bytes(raw_stream))
        assert len(parsed) == 500

        for expected, actual in zip(frames_expected, parsed, strict=True):
            exp_ftype, exp_ts, exp_rssi, exp_payload = expected
            assert actual.frame_type == exp_ftype
            assert actual.mlat_timestamp == exp_ts
            assert actual.rssi_byte == exp_rssi
            assert actual.payload == exp_payload
