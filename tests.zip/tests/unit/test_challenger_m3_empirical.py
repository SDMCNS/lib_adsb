"""Empirical adversarial verification test suite for Milestone 3 RF Channel Simulation.

Author: challenger_m3_v1 (Teamwork Challenger Subagent)
Scope: Empirical verification of 5 core RF channel challenge areas:
  1. Radio Horizon & Terrain Masking (extreme altitude pairs & directional elevation profiles).
  2. Free-Space Path Loss (1090 MHz and 978 MHz across 1 m to 500 km).
  3. Pulse Garble Collision Physics (capture effect at +/-6.0 dB and destructive garble).
  4. Poisson FRUIT Generator (rate parameter lambda in [0, 2000] Hz and inter-arrival exponential distributions).
  5. Bit Error Rate (AWGN and Rayleigh fading channels at SNR from -10 dB to +30 dB).
"""

from __future__ import annotations

import math

import numpy as np
import pytest
from scipy import stats  # type: ignore[import-untyped]

from adsb.constants import (
    FEET_TO_METERS,
    FREQ_1090ES_HZ,
    FREQ_UAT_HZ,
    METERS_TO_NM,
    SPEED_OF_LIGHT_MPS,
)
from adsb.impairment.channel import (
    FadingModel,
    apply_bit_errors,
    check_terrain_mask,
    compute_fspl,
    compute_ppm_ber,
    compute_preamble_drop_prob,
    compute_radio_horizon,
)
from adsb.impairment.noise import (
    PoissonFruitGenerator,
    PulseCollisionEngine,
    ReceptionEvent,
)
from adsb.protocol.crc import compute_syndrome
from adsb.protocol.modes import (
    encode_1090es_identification,
)


class TestEmpiricalRadioHorizonAndTerrain:
    """Challenge Task 1: Radio Horizon & Terrain Masking."""

    def test_extreme_receiver_aircraft_altitudes(self) -> None:
        """Verify radio horizon at 0m receiver to 60,000 ft aircraft (~301-310 NM)."""
        h_rx_0 = 0.0
        h_tx_60k = 60_000.0 * FEET_TO_METERS  # 18,288 meters

        # Receiver at sea level (0 m MSL)
        d_horiz_0 = compute_radio_horizon(h_tx_60k, h_rx_0)
        d_horiz_0_nm = d_horiz_0 * METERS_TO_NM

        # Analytical: sqrt(2 * (4/3 * 6,371,000) * 18,288) = 557,405.9 m = 300.98 NM
        assert math.isclose(d_horiz_0, 557_405.9, rel_tol=1e-4)
        assert math.isclose(d_horiz_0_nm, 300.98, abs_tol=0.2)

        # Receiver at elevated ground station (50 ft / 15.24 m MSL): cutoff reaches ~310 NM
        h_rx_50ft = 50.0 * FEET_TO_METERS
        d_horiz_50ft = compute_radio_horizon(h_tx_60k, h_rx_50ft)
        d_horiz_50ft_nm = d_horiz_50ft * METERS_TO_NM
        assert math.isclose(d_horiz_50ft_nm, 309.66, abs_tol=0.2)

        # Test sub-surface clamp (e.g. -400 m Dead Sea depression)
        d_sub = compute_radio_horizon(-400.0, 0.0)
        assert d_sub == 0.0

    def test_mountain_elevation_masking_interpolation(self) -> None:
        """Verify directional mountain terrain profile with circular azimuth interpolation."""
        # Realistic mountain profile: peak at 45 deg (8 deg mask), ridge at 270 deg (12 deg mask)
        profile = (
            (0.0, 1.0),
            (45.0, 8.0),
            (90.0, 3.0),
            (180.0, 0.5),
            (270.0, 12.0),
            (330.0, 5.0),
        )

        # 1. At azimuth 22.5 deg (midway 0 deg @ 1.0 deg and 45 deg @ 8.0 deg -> expected 4.5 deg):
        # 4.4 deg must be occulted, 4.6 deg must be visible
        assert check_terrain_mask(22.5, 4.4, profile) is False
        assert check_terrain_mask(22.5, 4.6, profile) is True

        # 2. At azimuth 345.0 deg (wrap-around midway 330 deg @ 5.0 deg and 0 deg @ 1.0 deg -> expected 3.0 deg):
        # 2.9 deg must be occulted, 3.1 deg must be visible
        assert check_terrain_mask(345.0, 2.9, profile) is False
        assert check_terrain_mask(345.0, 3.1, profile) is True

        # 3. Peak azimuth directly at 270.0 deg:
        assert check_terrain_mask(270.0, 11.9, profile) is False
        assert check_terrain_mask(270.0, 12.1, profile) is True

        # 4. Unmaskable fallback (None profile defaults to >= 0 deg)
        assert check_terrain_mask(90.0, 0.1, None) is True
        assert check_terrain_mask(90.0, -0.1, None) is False


class TestEmpiricalFreeSpacePathLoss:
    """Challenge Task 2: Free-Space Path Loss (FSPL)."""

    @pytest.mark.parametrize(
        ("freq_name", "freq_hz"),
        [
            ("1090ES", FREQ_1090ES_HZ),
            ("UAT_978", FREQ_UAT_HZ),
        ],
    )
    def test_fspl_range_sweep_1m_to_500km(self, freq_name: str, freq_hz: float) -> None:
        """Verify FSPL against exact electrodynamics formula across 1 m to 500 km."""
        distances_m = [1.0, 10.0, 100.0, 1_000.0, 10_000.0, 100_000.0, 250_000.0, 500_000.0]

        for d in distances_m:
            calc = compute_fspl(d, freq_hz)
            exact = (
                20.0 * math.log10(d)
                + 20.0 * math.log10(freq_hz)
                + 20.0 * math.log10(4.0 * math.pi / SPEED_OF_LIGHT_MPS)
            )
            # Code implementation uses -147.5522 dB constant: error must be < 0.0001 dB
            assert math.isclose(calc, exact, abs_tol=1e-4)

    def test_fspl_zero_and_negative_distance_protection(self) -> None:
        """Verify FSPL avoids numerical singularity (log10(0)) by clamping effective distance."""
        fspl_zero = compute_fspl(0.0, FREQ_1090ES_HZ)
        fspl_neg = compute_fspl(-50.0, FREQ_1090ES_HZ)
        fspl_one = compute_fspl(1.0, FREQ_1090ES_HZ)

        assert math.isfinite(fspl_zero)
        assert fspl_zero == fspl_one
        assert fspl_neg == fspl_one


class TestEmpiricalPulseGarbleCollisionPhysics:
    """Challenge Task 3: Pulse Garble Collision Physics."""

    @pytest.mark.parametrize(
        ("delta_p_db", "expected_a_ok", "expected_b_ok"),
        [
            (+12.0, True, False),
            (+6.01, True, False),
            (+6.00, True, False),
            (+5.99, False, False),
            (+3.00, False, False),
            (+0.00, False, False),
            (-3.00, False, False),
            (-5.99, False, False),
            (-6.00, False, True),
            (-6.01, False, True),
            (-12.0, False, True),
        ],
    )
    def test_power_differential_capture_and_garble(
        self,
        delta_p_db: float,
        expected_a_ok: bool,
        expected_b_ok: bool,
    ) -> None:
        """Empirically test capture effect and destructive garble across Delta P matrix."""
        engine = PulseCollisionEngine(capture_threshold_db=6.0, rng=np.random.default_rng(42))
        raw_a = encode_1090es_identification(0x111111, "ALPHA1")
        raw_b = encode_1090es_identification(0x222222, "BRAVO2")

        rssi_a = -10.0
        rssi_b = rssi_a - delta_p_db

        ev_a = ReceptionEvent(
            rx_timestamp_ns=0,
            rx_id="RX1",
            raw_bytes=raw_a,
            rssi_dbfs=rssi_a,
            snr_db=30.0,
            is_corrupted=False,
        )
        ev_b = ReceptionEvent(
            rx_timestamp_ns=25_000,
            rx_id="RX1",
            raw_bytes=raw_b,
            rssi_dbfs=rssi_b,
            snr_db=30.0 - delta_p_db,
            is_corrupted=False,
        )

        out_a, out_b = engine.apply_collision(ev_a, ev_b)

        syn_a = compute_syndrome(out_a.raw_bytes)
        syn_b = compute_syndrome(out_b.raw_bytes)

        if expected_a_ok:
            assert out_a.is_corrupted is False
            assert syn_a == 0
            assert out_b.is_corrupted is True
            assert syn_b != 0
        elif expected_b_ok:
            assert out_a.is_corrupted is True
            assert syn_a != 0
            assert out_b.is_corrupted is False
            assert syn_b == 0
        else:  # Destructive garble: both corrupted
            assert out_a.is_corrupted is True
            assert syn_a != 0
            assert out_b.is_corrupted is True
            assert syn_b != 0

    def test_one_nanosecond_overlap_boundary(self) -> None:
        """Verify that even a 1 ns overlap triggers collision detection."""
        engine = PulseCollisionEngine(capture_threshold_db=6.0, rng=np.random.default_rng(99))
        raw_a = encode_1090es_identification(0x111111, "ALPHA1")
        raw_b = encode_1090es_identification(0x222222, "BRAVO2")

        # Long frame is 120,000 ns; Frame B arrives at 119,999 ns -> 1 ns overlap
        ev_a = ReceptionEvent(0, "RX1", raw_a, -10.0, 30.0, False)
        ev_b = ReceptionEvent(119_999, "RX1", raw_b, -10.0, 30.0, False)

        out_a, out_b = engine.apply_collision(ev_a, ev_b)
        assert out_a.is_corrupted is True
        assert out_b.is_corrupted is True
        assert compute_syndrome(out_a.raw_bytes) != 0
        assert compute_syndrome(out_b.raw_bytes) != 0


class TestEmpiricalPoissonFruitGenerator:
    """Challenge Task 4: Poisson FRUIT Generator."""

    @pytest.mark.parametrize("rate_hz", [0.0, 100.0, 500.0, 1000.0, 2000.0])
    def test_poisson_fruit_rate_sweep_and_distribution(self, rate_hz: float) -> None:
        """Verify Poisson count statistics and exponential inter-arrival distribution."""
        duration_s = 2.0
        gen = PoissonFruitGenerator(
            fruit_rate_hz=rate_hz, rx_id="FRUIT_RX", rng=np.random.default_rng(123)
        )
        events = gen.generate_fruit(duration_s=duration_s)

        if rate_hz == 0.0:
            assert len(events) == 0
            return

        expected_count = rate_hz * duration_s
        count = len(events)

        # 3.5-sigma Poisson tolerance: +/- 3.5 * sqrt(expected)
        sigma = math.sqrt(expected_count)
        assert abs(count - expected_count) <= 3.5 * sigma

        # Check strictly monotonic timestamps
        ts_s = np.array([e.rx_timestamp_ns / 1e9 for e in events])
        dts = np.diff(ts_s)
        assert np.all(dts > 0.0)

        # Verify mean inter-arrival time matches 1 / rate
        sample_mean = float(np.mean(dts))
        expected_mean = 1.0 / rate_hz
        assert math.isclose(sample_mean, expected_mean, rel_tol=0.08)

        # Kolmogorov-Smirnov test against exponential distribution
        ks_res = stats.kstest(dts, "expon", args=(0, expected_mean))
        assert ks_res.pvalue > 0.01  # Goodness-of-fit cannot be rejected


class TestEmpiricalBitErrorRate:
    """Challenge Task 5: Bit Error Rate (BER) in AWGN and Rayleigh Channels."""

    @pytest.mark.parametrize(
        ("snr_db", "expected_awgn_ber"),
        [
            (-10.0, 0.475615),
            (-5.0, 0.426876),
            (0.0, 0.303265),
            (3.0, 0.184376),
            (6.0, 0.068311),
            (10.0, 0.003369),
            (20.0, 0.0),
            (30.0, 0.0),
        ],
    )
    def test_awgn_ber_curve(self, snr_db: float, expected_awgn_ber: float) -> None:
        """Verify theoretical AWGN BER matches non-coherent 2-PPM formula."""
        calc = compute_ppm_ber(snr_db, FadingModel.AWGN)
        if expected_awgn_ber == 0.0:
            assert calc < 1e-15
        else:
            assert math.isclose(calc, expected_awgn_ber, rel_tol=1e-3)

    @pytest.mark.parametrize(
        ("snr_db", "expected_rayleigh_ber"),
        [
            (-10.0, 0.476190),
            (0.0, 0.333333),
            (10.0, 0.083333),
            (20.0, 0.009804),
            (30.0, 0.000998),
        ],
    )
    def test_rayleigh_ber_curve(self, snr_db: float, expected_rayleigh_ber: float) -> None:
        """Verify theoretical Rayleigh fading BER matches 1 / (2 + gamma)."""
        calc = compute_ppm_ber(snr_db, FadingModel.RAYLEIGH)
        assert math.isclose(calc, expected_rayleigh_ber, rel_tol=1e-3)

    def test_monte_carlo_bit_error_simulation(self) -> None:
        """Verify empirical bit flips from apply_bit_errors converge to theoretical BER."""
        rng = np.random.default_rng(2026)
        payload = bytes(14)  # 112 bits per squitter
        trials = 3_000
        total_bits = trials * 112

        for snr in [0.0, 3.0, 6.0]:
            ber = compute_ppm_ber(snr, FadingModel.AWGN)
            flips = 0
            for _ in range(trials):
                _, f = apply_bit_errors(payload, ber, rng)
                flips += f
            emp_ber = flips / total_bits
            # Law of Large Numbers convergence within 3% relative error
            assert math.isclose(emp_ber, ber, rel_tol=0.03)

    def test_preamble_detection_drop_probability(self) -> None:
        """Verify preamble drop logistic psychometric curve."""
        # Threshold is 6.0 dB: drop probability at threshold is exactly 0.50
        assert math.isclose(compute_preamble_drop_prob(6.0), 0.50, abs_tol=1e-5)
        # Deep negative SNR: drop probability approaches 1.0
        assert math.isclose(compute_preamble_drop_prob(-20.0), 1.0, abs_tol=1e-5)
        assert compute_preamble_drop_prob(-60.0) == 1.0
        # High SNR: drop probability approaches 0.0
        assert compute_preamble_drop_prob(20.0) < 1e-4
