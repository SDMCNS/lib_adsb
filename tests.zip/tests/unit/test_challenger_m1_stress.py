"""Exhaustive adversarial stress tests for Milestone 1 codecs and remediation.

Authored by Challenger 1 to empirically stress-test and challenge:
1. CRC-24 parity calculation, dual syndrome tables (SYNDROME_TABLE_56 and
   SYNDROME_TABLE_112), and error correction safety across all single-bit
   and 2-bit error positions on both 7-byte and 14-byte frames.
2. CPR airborne and surface resolution under continuous coordinate sweeps
   across the equator, poles, antimeridian, and all 58 NL latitude transitions.
3. Mode S 1090ES decoding across randomized payload variants (ICAO addresses,
   altitudes, velocities, callsigns, squawks) to verify genuine algorithmic
   decoding without lookup shortcuts.
"""

from __future__ import annotations

import itertools
import math
import random

import pytest

from adsb.protocol.cpr import (
    _NL_TRANSITION_TABLE,
    decode_cpr_global_airborne,
    decode_cpr_global_surface,
    decode_cpr_local,
    encode_cpr_airborne,
    encode_cpr_surface,
    nl_lat,
)
from adsb.protocol.crc import (
    SYNDROME_TABLE_56,
    SYNDROME_TABLE_112,
    compute_crc24,
    correct_syndrome_errors,
    verify_crc24,
)
from adsb.protocol.gillham import (
    decode_gillham_altitude,
    decode_mode_s_identity,
    encode_gillham_altitude,
    encode_squawk_code,
)
from adsb.protocol.modes import (
    decode_mode_s,
    encode_1090es_airborne_position,
    encode_1090es_airborne_velocity,
    encode_1090es_identification,
)


class TestCRC24SyndromeExhaustiveStress:
    """Exhaustive stress testing for CRC24 and dual syndrome tables."""

    def test_syndrome_table_sizes_and_collision_freedom(self) -> None:
        """Verify that syndrome tables are correctly sized and collision-free."""
        # 56-bit frames: 56 single-bit + 55 adjacent 2-bit = 111 distinct syndromes
        assert len(SYNDROME_TABLE_56) == 111, f"Expected 111 syndromes, got {len(SYNDROME_TABLE_56)}"
        # 112-bit frames: 112 single-bit + 111 adjacent 2-bit = 223 distinct syndromes
        assert len(SYNDROME_TABLE_112) == 223, f"Expected 223 syndromes, got {len(SYNDROME_TABLE_112)}"

    def test_all_56_single_bit_errors_on_diverse_7byte_frames(self) -> None:
        """Verify 100% correct single-bit error recovery on 7-byte frames across all bit positions."""
        test_frames: list[bytes] = [
            bytes.fromhex("5D4840D6F8740F"),  # GV-06
            # Synthesized valid DF 11 frames with different ICAO addresses
        ]
        for icao in [0x123456, 0xA1B2C3, 0xFFFFFF, 0x000001]:
            val = (11 << 51) | (5 << 48) | (icao << 24)
            parity = compute_crc24(val.to_bytes(7, "big"))
            test_frames.append((val | parity).to_bytes(7, "big"))

        for frame in test_frames:
            assert verify_crc24(frame)
            base_int = int.from_bytes(frame, "big")
            for p in range(56):
                corrupted = (base_int ^ (1 << p)).to_bytes(7, "big")
                corrected, count = correct_syndrome_errors(corrupted)
                assert corrected == frame, f"Failed 56-bit correction at pos {p} for frame {frame.hex()}"
                assert count == 1
                assert verify_crc24(corrected) is True

    def test_all_55_adjacent_2bit_errors_on_diverse_7byte_frames(self) -> None:
        """Verify 100% correct adjacent 2-bit burst recovery on 7-byte frames."""
        frame = bytes.fromhex("5D4840D6F8740F")
        assert verify_crc24(frame)
        base_int = int.from_bytes(frame, "big")

        for p in range(55):
            corrupted = (base_int ^ (3 << p)).to_bytes(7, "big")
            corrected, count = correct_syndrome_errors(corrupted)
            assert corrected == frame, f"Failed adjacent 2-bit burst at pos {p}"
            assert count == 2
            assert verify_crc24(corrected) is True

    def test_exhaustive_all_1540_2bit_error_pairs_on_7byte_frames(self) -> None:
        """Verify that all 1540 possible 2-bit error pairs on a 56-bit frame execute safely without OverflowError."""
        frame = bytes.fromhex("5D4840D6F8740F")
        base_int = int.from_bytes(frame, "big")

        adjacent_success = 0
        non_adjacent_uncorrected = 0

        for p1, p2 in itertools.combinations(range(56), 2):
            mask = (1 << p1) | (1 << p2)
            corrupted = (base_int ^ mask).to_bytes(7, "big")
            # Must not raise OverflowError: int too big to convert
            corrected, count = correct_syndrome_errors(corrupted)
            assert len(corrected) == 7, "Output length must remain exactly 7 bytes"

            if p2 == p1 + 1:
                # Adjacent 2-bit burst
                assert corrected == frame
                assert count == 2
                adjacent_success += 1
            else:
                # Non-adjacent 2-bit error: CRC24 syndrome should not falsely match
                if count == 0:
                    non_adjacent_uncorrected += 1

        assert adjacent_success == 55
        assert non_adjacent_uncorrected == 1485

    def test_all_112_single_bit_errors_on_diverse_14byte_frames(self) -> None:
        """Verify 100% correct single-bit error recovery on 14-byte frames."""
        test_frames: list[bytes] = [
            bytes.fromhex("8D4840D6202CC371C32CE0576098"),  # GV-01
            bytes.fromhex("8D40621D58C382D690C8AC2863A7"),  # GV-02
            bytes.fromhex("8D485020994409940838175B284F"),  # GV-04
        ]
        for frame in test_frames:
            assert verify_crc24(frame)
            base_int = int.from_bytes(frame, "big")
            for p in range(112):
                corrupted = (base_int ^ (1 << p)).to_bytes(14, "big")
                corrected, count = correct_syndrome_errors(corrupted)
                assert corrected == frame, f"Failed 112-bit correction at pos {p} for frame {frame.hex()}"
                assert count == 1
                assert verify_crc24(corrected) is True

    def test_all_111_adjacent_2bit_errors_on_14byte_frames(self) -> None:
        """Verify 100% correct adjacent 2-bit burst recovery on 14-byte frames."""
        frame = bytes.fromhex("8D4840D6202CC371C32CE0576098")
        assert verify_crc24(frame)
        base_int = int.from_bytes(frame, "big")

        for p in range(111):
            corrupted = (base_int ^ (3 << p)).to_bytes(14, "big")
            corrected, count = correct_syndrome_errors(corrupted)
            assert corrected == frame, f"Failed adjacent 2-bit burst at pos {p}"
            assert count == 2
            assert verify_crc24(corrected) is True

    def test_all_6216_2bit_error_pairs_on_14byte_frames(self) -> None:
        """Verify that all 6216 2-bit error pairs on 112-bit frame execute safely without OverflowError."""
        frame = bytes.fromhex("8D4840D6202CC371C32CE0576098")
        base_int = int.from_bytes(frame, "big")

        adjacent_success = 0
        non_adjacent_uncorrected = 0

        for p1, p2 in itertools.combinations(range(112), 2):
            mask = (1 << p1) | (1 << p2)
            corrupted = (base_int ^ mask).to_bytes(14, "big")
            corrected, count = correct_syndrome_errors(corrupted)
            assert len(corrected) == 14

            if p2 == p1 + 1:
                assert corrected == frame
                assert count == 2
                adjacent_success += 1
            else:
                if count == 0:
                    non_adjacent_uncorrected += 1

        assert adjacent_success == 111
        assert non_adjacent_uncorrected == 6105

    def test_uncorrupted_and_invalid_length_frames(self) -> None:
        """Verify behavior on clean frames and frames of non-standard length."""
        clean_56 = bytes.fromhex("5D4840D6F8740F")
        clean_112 = bytes.fromhex("8D4840D6202CC371C32CE0576098")

        # Zero syndrome should return frame directly with error count 0
        assert correct_syndrome_errors(clean_56) == (clean_56, 0)
        assert correct_syndrome_errors(clean_112) == (clean_112, 0)

        # Invalid lengths should return unmodified frame with error count 0
        for invalid_len in [0, 1, 2, 3, 6, 8, 13, 15, 20]:
            bogus_frame = bytes([0xAA] * invalid_len)
            assert correct_syndrome_errors(bogus_frame) == (bogus_frame, 0)


class TestCPRSweepContinuityStress:
    """Continuous coordinate sweeps and stress testing for CPR airborne and surface resolution."""

    def test_continuous_latitude_sweep_airborne(self) -> None:
        """Sweep latitude from -85.0 to +85.0 in 0.1 deg increments and verify decoding accuracy and continuity."""
        prev_lat0: float | None = None
        prev_lat1: float | None = None
        lon = 12.3456

        # Step 0.1 deg: 1701 points
        for i in range(-850, 851):
            lat = i / 10.0
            yz0, xz0 = encode_cpr_airborne(lat, lon, 0)
            yz1, xz1 = encode_cpr_airborne(lat, lon, 1)

            # Decode with Even frame most recent
            dlat0, dlon0 = decode_cpr_global_airborne(
                yz0 / 131072.0, xz0 / 131072.0, yz1 / 131072.0, xz1 / 131072.0, most_recent=0
            )
            # Decode with Odd frame most recent
            dlat1, dlon1 = decode_cpr_global_airborne(
                yz0 / 131072.0, xz0 / 131072.0, yz1 / 131072.0, xz1 / 131072.0, most_recent=1
            )

            # Error bound: CPR 17-bit resolution error is < 0.0005 deg (~50 m)
            assert abs(dlat0 - lat) < 0.0005, f"Lat error too high at {lat}: {dlat0}"
            assert abs(dlon0 - lon) < 0.0005, f"Lon error too high at ({lat}, {lon}): {dlon0}"
            assert abs(dlat1 - lat) < 0.0005, f"Lat error too high at {lat}: {dlat1}"
            assert abs(dlon1 - lon) < 0.0005, f"Lon error too high at ({lat}, {lon}): {dlon1}"

            # Continuity check: successive points must advance by approximately 0.1 deg without jumps
            if prev_lat0 is not None:
                step_diff0 = dlat0 - prev_lat0
                assert 0.09 < step_diff0 < 0.11, f"Discontinuity in lat0 at {lat}: step was {step_diff0}"
            if prev_lat1 is not None:
                step_diff1 = dlat1 - prev_lat1
                assert 0.09 < step_diff1 < 0.11, f"Discontinuity in lat1 at {lat}: step was {step_diff1}"

            prev_lat0 = dlat0
            prev_lat1 = dlat1

    def test_continuous_longitude_sweep_across_antimeridian(self) -> None:
        """Sweep longitude from -180.0 to +180.0 in 0.5 deg steps across multiple latitudes."""
        for lat in [-60.0, -30.0, 0.0, 30.0, 60.0]:
            for j in range(-1800, 1800, 5):
                lon = j / 10.0
                yz0, xz0 = encode_cpr_airborne(lat, lon, 0)
                yz1, xz1 = encode_cpr_airborne(lat, lon, 1)

                dlat, dlon = decode_cpr_global_airborne(
                    yz0 / 131072.0, xz0 / 131072.0, yz1 / 131072.0, xz1 / 131072.0, most_recent=1
                )

                assert abs(dlat - lat) < 0.0005
                diff_lon = abs(dlon - lon)
                if diff_lon > 180.0:
                    diff_lon = abs(diff_lon - 360.0)
                assert diff_lon < 0.005, f"Lon mismatch at ({lat}, {lon}): decoded {dlon}"

    def test_all_58_nl_boundary_transitions_and_straddles(self) -> None:
        """Verify that every NL transition boundary correctly detects straddles and allows non-straddles."""
        for b in _NL_TRANSITION_TABLE:
            lat_below = b - 0.02
            lat_above = b + 0.02
            lon = 45.0

            # 1. Non-straddling positions below boundary must decode cleanly
            yz0_b, xz0_b = encode_cpr_airborne(lat_below, lon, 0)
            yz1_b, xz1_b = encode_cpr_airborne(lat_below, lon, 1)
            dlat_b, _ = decode_cpr_global_airborne(
                yz0_b / 131072.0, xz0_b / 131072.0, yz1_b / 131072.0, xz1_b / 131072.0, most_recent=1
            )
            assert abs(dlat_b - lat_below) < 0.001

            # 2. Non-straddling positions above boundary must decode cleanly
            yz0_a, xz0_a = encode_cpr_airborne(lat_above, lon, 0)
            yz1_a, xz1_a = encode_cpr_airborne(lat_above, lon, 1)
            dlat_a, _ = decode_cpr_global_airborne(
                yz0_a / 131072.0, xz0_a / 131072.0, yz1_a / 131072.0, xz1_a / 131072.0, most_recent=1
            )
            assert abs(dlat_a - lat_above) < 0.001

            # 3. Straddling pairing across the NL boundary MUST be rejected with ValueError
            if nl_lat(lat_below) != nl_lat(lat_above):
                with pytest.raises(ValueError, match="straddle"):
                    decode_cpr_global_airborne(
                        yz0_b / 131072.0, xz0_b / 131072.0, yz1_a / 131072.0, xz1_a / 131072.0, most_recent=1
                    )

    def test_surface_cpr_global_and_local_sweeps(self) -> None:
        """Verify surface CPR global and local resolution across diverse global locations."""
        airports: list[tuple[str, float, float]] = [
            ("EHAM Amsterdam", 52.3086, 4.7639),
            ("KJFK New York", 40.6413, -73.7781),
            ("YSSY Sydney", -33.9461, 151.1772),
            ("FACT Cape Town", -33.9648, 18.6017),
            ("NZAA Auckland", -37.0082, 174.7850),
            ("RJTT Tokyo", 35.5533, 139.7811),
            ("SBGL Rio", -22.8089, -43.2436),
            ("Equator", 0.05, 0.05),
        ]

        for name, alat, alon in airports:
            for d_lat in [-0.15, -0.05, 0.0, 0.05, 0.15]:
                for d_lon in [-0.15, -0.05, 0.0, 0.05, 0.15]:
                    plat = alat + d_lat
                    plon = alon + d_lon

                    yz0, xz0 = encode_cpr_surface(plat, plon, 0)
                    yz1, xz1 = encode_cpr_surface(plat, plon, 1)

                    # Global surface decode
                    dlat, dlon = decode_cpr_global_surface(
                        yz0 / 131072.0,
                        xz0 / 131072.0,
                        yz1 / 131072.0,
                        xz1 / 131072.0,
                        ref_lat=alat,
                        ref_lon=alon,
                        most_recent=1,
                    )

                    diff_lon = abs(dlon - plon)
                    if diff_lon > 180.0:
                        diff_lon = abs(diff_lon - 360.0)

                    assert abs(dlat - plat) < 0.0005, f"{name} surface global lat error: {dlat} vs {plat}"
                    assert diff_lon < 0.001, f"{name} surface global lon error: {dlon} vs {plon}"

                    # Local surface decode on even frame
                    llat0, llon0 = decode_cpr_local(
                        yz0 / 131072.0, xz0 / 131072.0, 0, ref_lat=alat, ref_lon=alon, surface=True
                    )
                    diff_llon0 = abs(llon0 - plon)
                    if diff_llon0 > 180.0:
                        diff_llon0 = abs(diff_llon0 - 360.0)
                    assert abs(llat0 - plat) < 0.0005
                    assert diff_llon0 < 0.001


class TestModeSRandomizedPayloadDecoding:
    """Stress tests decoding randomized Mode S payloads to ensure genuine calculation."""

    def test_200_randomized_identification_payloads(self) -> None:
        """Test randomized callsigns, categories, and ICAO addresses."""
        rng = random.Random(1337)
        chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 "

        for _ in range(200):
            callsign = "".join(rng.choices(chars, k=rng.randint(1, 8)))
            icao = rng.randint(1, 0xFFFFFF)
            cat = rng.randint(0, 7)
            ca = rng.randint(0, 7)

            frame = encode_1090es_identification(icao, callsign, category=cat, ca=ca)
            msg = decode_mode_s(frame)

            assert msg.icao24 == icao, f"ICAO mismatch: {hex(msg.icao24)} vs {hex(icao)}"
            expected_cs = callsign.ljust(8)[:8].upper()
            assert msg.callsign == expected_cs, f"Callsign mismatch: {msg.callsign} vs {expected_cs}"
            assert msg.ca == cat
            assert msg.crc_valid is True

    def test_200_randomized_airborne_position_payloads(self) -> None:
        """Test randomized altitudes, positions, and CPR formats."""
        rng = random.Random(2026)

        for _ in range(200):
            icao = rng.randint(1, 0xFFFFFF)
            n = rng.randint(0, 2040)
            alt = n * 25 - 1000
            lat = rng.uniform(-85.0, 85.0)
            lon = rng.uniform(-179.0, 179.0)
            cpr_f = rng.choice([0, 1])

            frame = encode_1090es_airborne_position(icao, alt, lat, lon, cpr_f)
            msg = decode_mode_s(frame)

            assert msg.icao24 == icao
            assert msg.altitude_ft == alt
            assert msg.cpr_format == cpr_f
            expected_yz, expected_xz = encode_cpr_airborne(lat, lon, cpr_f)
            assert msg.cpr_lat == expected_yz
            assert msg.cpr_lon == expected_xz
            assert msg.crc_valid is True

    def test_200_randomized_airborne_velocity_payloads(self) -> None:
        """Test randomized velocity components and vertical rates."""
        rng = random.Random(42)

        for _ in range(200):
            icao = rng.randint(1, 0xFFFFFF)
            v_ew = rng.uniform(-800.0, 800.0)
            v_ns = rng.uniform(-800.0, 800.0)
            k_vr = rng.randint(-80, 80)
            vr = k_vr * 64

            frame = encode_1090es_airborne_velocity(icao, v_ew, v_ns, vertical_rate_fpm=vr)
            msg = decode_mode_s(frame)

            assert msg.icao24 == icao
            assert msg.v_ew_kt is not None and abs(msg.v_ew_kt - v_ew) <= 1.0
            assert msg.v_ns_kt is not None and abs(msg.v_ns_kt - v_ns) <= 1.0
            if vr != 0:
                assert msg.vertical_rate_fpm == vr
            else:
                assert msg.vertical_rate_fpm in (0, None)

            expected_gs = math.hypot(msg.v_ew_kt, msg.v_ns_kt)
            assert msg.groundspeed_kt is not None
            assert abs(msg.groundspeed_kt - expected_gs) < 1e-6
            assert msg.crc_valid is True

    def test_exhaustive_25ft_gillham_altitude_roundtrip(self) -> None:
        """Exhaustively verify all 2048 25-ft altitude steps from -1000 to 50175 ft."""
        for n in range(2048):
            alt_ft = n * 25 - 1000
            code = encode_gillham_altitude(alt_ft, resolution_25ft=True)
            decoded = decode_gillham_altitude(code)
            assert decoded == alt_ft, f"Gillham 25-ft mismatch at {alt_ft} ft: got {decoded}"

    def test_200_randomized_squawk_code_roundtrips(self) -> None:
        """Test randomized 4-digit octal squawk codes."""
        rng = random.Random(999)

        for _ in range(200):
            sq = "".join(rng.choices("01234567", k=4))
            code = encode_squawk_code(sq)
            decoded = decode_mode_s_identity(code)
            assert decoded == sq, f"Squawk mismatch: {decoded} vs {sq}"
