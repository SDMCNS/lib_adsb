"""Unit tests for the ADS-B API service, SimulationManager, and REST endpoints."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Generator

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import (
    SimulationConfig,
    SimulationManager,
    SimulationStatus,
    get_simulation_manager,
    reset_simulation_manager,
)
from adsb.core.coordinates import geodetic_to_enu
from adsb.core.units import FEET_TO_METERS
from adsb.wire.beast import serialize_beast_frame
from adsb.wire.sbs import SBSMessage, serialize_sbs_message


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Create a TestClient with a freshly reset SimulationManager."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


# ==============================================================================
# SimulationManager Unit Tests
# ==============================================================================


@pytest.mark.tier1
def test_simulation_manager_init_and_state() -> None:
    """Verify default initialization values of SimulationManager."""
    mgr = SimulationManager()
    assert mgr.status == SimulationStatus.STOPPED
    assert mgr.sim_time_s == 0.0
    assert mgr.speed_multiplier == 1.0

    state = mgr.get_state()
    assert state["status"] == "STOPPED"
    assert state["sim_time_s"] == 0.0
    assert state["speed_multiplier"] == 1.0
    assert state["scenario_name"] == "clean_tma_10_aircraft"


@pytest.mark.tier1
def test_simulation_manager_configure_valid_and_invalid() -> None:
    """Verify configuration updates and error handling."""
    mgr = SimulationManager()

    # Valid reconfigure
    new_cfg = SimulationConfig(
        scenario_name="congested_tma_25_aircraft",
        speed_multiplier=2.5,
        seed=123,
    )
    state = mgr.configure(new_cfg)
    assert state["scenario_name"] == "congested_tma_25_aircraft"
    assert state["speed_multiplier"] == 2.5
    assert mgr.status == SimulationStatus.STOPPED

    # Invalid scenario name
    with pytest.raises(ValueError, match="Unknown scenario"):
        mgr.configure({"scenario_name": "non_existent_airspace", "speed_multiplier": 1.0, "seed": 1})


@pytest.mark.tier1
def test_simulation_manager_speed_validation() -> None:
    """Verify speed multiplier validation."""
    mgr = SimulationManager()
    mgr.set_speed(3.0)
    assert mgr.speed_multiplier == 3.0

    with pytest.raises(ValueError, match="Speed multiplier must be positive"):
        mgr.set_speed(0.0)

    with pytest.raises(ValueError, match="Speed multiplier must be positive"):
        mgr.set_speed(-1.5)


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_simulation_manager_step_and_events() -> None:
    """Verify stepping advances time and updates engine tracks."""
    mgr = SimulationManager()
    assert mgr.engine is not None

    # Step forward 5.0 seconds
    state = await mgr.step(5.0)
    assert state["sim_time_s"] == 5.0
    assert len(mgr.engine.all_tracks(include_tentative=True)) > 0


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_simulation_manager_inject_avr() -> None:
    """Verify injecting AVR frame parses correctly."""
    mgr = SimulationManager()
    # KLM1023 callsign message
    res = await mgr.inject_frame("AVR", "*8D4840D6202CC371C32CE0576098;")
    assert res["icao_hex"] == "4840D6"
    assert res["df"] == 17
    assert res["callsign"].rstrip() == "KLM1023"
    assert res["crc_valid"] is True


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_simulation_manager_inject_beast() -> None:
    """Verify injecting BEAST binary and hex frames."""
    mgr = SimulationManager()
    payload = bytes.fromhex("8D4840D6202CC371C32CE0576098")
    beast_bytes = serialize_beast_frame("3", 12_000_000, 200, payload)

    # Ingest as raw bytes
    res = await mgr.inject_frame("BEAST", beast_bytes)
    assert res["icao_hex"] == "4840D6"
    assert res["df"] == 17
    assert res["callsign"].rstrip() == "KLM1023"

    # Ingest as hex string
    res_hex = await mgr.inject_frame("BEAST", beast_bytes.hex())
    assert res_hex["icao_hex"] == "4840D6"


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_simulation_manager_inject_sbs() -> None:
    """Verify injecting SBS-1 BaseStation CSV lines."""
    mgr = SimulationManager()
    sbs_line = serialize_sbs_message(
        SBSMessage(hex_ident="4840D6", altitude=10000, lat=52.31050, lon=4.76830)
    )
    res = await mgr.inject_frame("SBS", sbs_line)
    assert res["icao_hex"] == "4840D6"
    assert res["lat"] == pytest.approx(52.3105)
    assert res["lon"] == pytest.approx(4.7683)
    assert res["altitude_ft"] == 10000


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_simulation_manager_inject_invalid_payloads() -> None:
    """Verify invalid payloads raise ValueError."""
    mgr = SimulationManager()

    # Unsupported format
    with pytest.raises(ValueError, match="Unknown wire format"):
        await mgr.inject_frame("ASTERIX", "*8D4840D6;")

    # Truncated AVR
    with pytest.raises(ValueError):
        await mgr.inject_frame("AVR", "*8D48;")

    # Non-hex AVR
    with pytest.raises(ValueError):
        await mgr.inject_frame("AVR", "*ZZZZZZZZ;")

    # Corrupt Beast
    with pytest.raises(ValueError):
        await mgr.inject_frame("BEAST", b"\x1a\x33\x00")

    # Incomplete SBS
    with pytest.raises(ValueError):
        await mgr.inject_frame("SBS", "MSG,1,1")


# ==============================================================================
# REST API Endpoints Unit Tests
# ==============================================================================


@pytest.mark.tier1
def test_rest_simulation_state_and_lifecycle(client: TestClient) -> None:
    """Verify GET and POST simulation lifecycle endpoints."""
    # Initial state
    res = client.get("/api/v1/simulation/state")
    assert res.status_code == 200
    assert res.json()["status"] == "STOPPED"

    # Start
    res = client.post("/api/v1/simulation/start")
    assert res.status_code == 200
    assert res.json()["status"] == "RUNNING"

    # Pause
    res = client.post("/api/v1/simulation/pause")
    assert res.status_code == 200
    assert res.json()["status"] == "PAUSED"

    # Reset
    res = client.post("/api/v1/simulation/reset")
    assert res.status_code == 200
    assert res.json()["status"] == "STOPPED"
    assert res.json()["sim_time_s"] == 0.0


@pytest.mark.tier1
def test_rest_simulation_speed_and_step(client: TestClient) -> None:
    """Verify speed changes and manual stepping."""
    # Speed
    res = client.post("/api/v1/simulation/speed", json={"speed_multiplier": 4.0})
    assert res.status_code == 200
    assert res.json()["speed_multiplier"] == 4.0

    # Invalid speed
    res = client.post("/api/v1/simulation/speed", json={"speed_multiplier": -1.0})
    assert res.status_code == 422  # Pydantic gt=0 validation error

    # Step
    res = client.post("/api/v1/simulation/step", json={"step_s": 2.5})
    assert res.status_code == 200
    assert res.json()["sim_time_s"] == 2.5


@pytest.mark.tier1
def test_rest_tracks_endpoints(client: TestClient) -> None:
    """Verify /api/v1/tracks list and individual track lookup."""
    # Initially no tracks or minimal
    res = client.get("/api/v1/tracks")
    assert res.status_code == 200
    assert isinstance(res.json(), list)

    # Inject position frames for KLM1023
    client.post(
        "/api/v1/inject/frame",
        json={"format": "AVR", "raw_data": "*8D4840D6202CC371C32CE0576098;"},
    )
    # Even position
    client.post(
        "/api/v1/inject/frame",
        json={"format": "AVR", "raw_data": "*8D4840D658C382D690C8AC2863A7;"},
    )

    # Query all tracks
    res = client.get("/api/v1/tracks")
    assert res.status_code == 200
    tracks = res.json()
    assert len(tracks) >= 1
    klm_track = next((t for t in tracks if t["icao_hex"] == "4840D6"), None)
    assert klm_track is not None
    assert klm_track["callsign"].rstrip() == "KLM1023"

    # Query specific track by icao_hex
    res = client.get("/api/v1/tracks/4840D6")
    assert res.status_code == 200
    assert res.json()["icao_hex"] == "4840D6"

    # Query lowercase or 0x prefixed hex
    res = client.get("/api/v1/tracks/0x4840d6")
    assert res.status_code == 200
    assert res.json()["icao_hex"] == "4840D6"

    # Non-existent track -> 404
    res = client.get("/api/v1/tracks/FFFFFF")
    assert res.status_code == 404

    # Malformed ICAO hex -> 400
    res = client.get("/api/v1/tracks/NOT_HEX")
    assert res.status_code == 400


@pytest.mark.tier1
def test_rest_inject_frame_endpoints(client: TestClient) -> None:
    """Verify inject frame endpoint responses and validation errors."""
    # Valid AVR
    res = client.post(
        "/api/v1/inject/frame",
        json={"format": "AVR", "raw_data": "*8D4840D6202CC371C32CE0576098;"},
    )
    assert res.status_code == 200
    assert res.json()["icao_hex"] == "4840D6"

    # Valid SBS
    sbs = serialize_sbs_message(SBSMessage(hex_ident="4840D6", callsign="KLM1023"))
    res = client.post("/api/v1/inject/frame", json={"format": "SBS", "raw_data": sbs})
    assert res.status_code == 200
    assert res.json()["icao_hex"] == "4840D6"
    assert res.json()["callsign"] == "KLM1023"

    # Malformed payloads -> 400
    res = client.post(
        "/api/v1/inject/frame",
        json={"format": "AVR", "raw_data": "*8D48;"},
    )
    assert res.status_code == 400

    res = client.post(
        "/api/v1/inject/frame",
        json={"format": "UNKNOWN", "raw_data": "*8D48;"},
    )
    assert res.status_code == 400


def _get_sim_task(mgr: SimulationManager) -> asyncio.Task[None] | None:
    return mgr._sim_task


def _get_mgr_status(mgr: SimulationManager) -> SimulationStatus:
    return mgr.status


@pytest.mark.tier1
def test_rest_simulation_autonomous_advancement(client: TestClient) -> None:
    """Verify POST /api/v1/simulation/start spawns an active task and autonomously advances time."""
    mgr = get_simulation_manager()
    assert _get_mgr_status(mgr) == SimulationStatus.STOPPED
    assert _get_sim_task(mgr) is None

    res = client.post("/api/v1/simulation/start")
    assert res.status_code == 200
    assert res.json()["status"] == "RUNNING"

    # Verify task was created on the event loop and is active
    sim_task = _get_sim_task(mgr)
    assert sim_task is not None
    assert not sim_task.done()

    initial_time = mgr.sim_time_s
    # Wait for the background loop to advance time autonomously
    time.sleep(0.15)

    # Assert time advanced autonomously without calling /step
    assert mgr.sim_time_s > initial_time

    # Pause and verify task is cancelled
    client.post("/api/v1/simulation/pause")
    assert _get_mgr_status(mgr) == SimulationStatus.PAUSED
    assert _get_sim_task(mgr) is None


@pytest.mark.asyncio
@pytest.mark.tier1
async def test_simulation_manager_inject_sbs_enu_and_imm() -> None:
    """Verify injecting SBS frame updates IMM filter state and computes accurate ENU coordinates."""
    mgr = SimulationManager()
    assert mgr.engine is not None

    lat = 52.3105
    lon = 4.7683
    alt_ft = 10000.0

    sbs_line = serialize_sbs_message(
        SBSMessage(
            hex_ident="4840D6",
            altitude=int(alt_ft),
            lat=lat,
            lon=lon,
            ground_speed=250.0,
            track=90.0,
        )
    )
    res = await mgr.inject_frame("SBS", sbs_line)
    assert res["icao_hex"] == "4840D6"

    track = mgr.engine._tracks[0x4840D6]
    imm = mgr.engine._filters[0x4840D6]

    assert track.has_position is True
    assert imm.last_update_time_s is not None

    # Expected ENU relative to engine ref
    expected_e, expected_n, expected_u = geodetic_to_enu(
        lat,
        lon,
        alt_ft * FEET_TO_METERS,
        mgr.engine.ref_lat,
        mgr.engine.ref_lon,
        mgr.engine.ref_alt_m,
    )
    assert imm.x1[0] == pytest.approx(expected_e, abs=1e-2)
    assert imm.x1[1] == pytest.approx(expected_n, abs=1e-2)
    assert imm.x1[2] == pytest.approx(expected_u, abs=1e-2)


@pytest.mark.tier1
def test_wire_broadcast_sbs_does_not_corrupt_avr(client: TestClient) -> None:
    """Verify injecting SBS frame broadcasts to SBS clients but does not emit empty '*;\r\n' to AVR."""
    with (
        client.websocket_connect("/ws/wire?format=AVR") as ws_avr,
        client.websocket_connect("/ws/wire?format=SBS") as ws_sbs,
    ):
        sbs_line = serialize_sbs_message(
            SBSMessage(hex_ident="4840D6", altitude=10000, lat=52.3, lon=4.7)
        )
        client.post("/api/v1/inject/frame", json={"format": "SBS", "raw_data": sbs_line})

        # SBS client receives the line
        sbs_rx = ws_sbs.receive_text()
        assert "4840D6" in sbs_rx

        # Inject a valid AVR frame to check AVR client receives it without preceding empty frame
        client.post(
            "/api/v1/inject/frame",
            json={"format": "AVR", "raw_data": "*8D4840D6202CC371C32CE0576098;"},
        )
        avr_rx = ws_avr.receive_text()
        assert avr_rx != "*;\r\n"
        assert "8D4840D6202CC371C32CE0576098" in avr_rx
