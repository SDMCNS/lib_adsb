"""Empirical challenger stress-testing and adversarial harness for Milestone 2 (Synthesis).

Author: Empirical Challenger 1 (Milestone 2)
Focus:
- Dual-layer ISA atmosphere under extreme altitude and Delta-T limits
- Compressible Saint-Venant CAS <-> TAS <-> Mach roundtrip and crossover altitudes
- 3D wind triangle singularities, extreme crosswinds, and excessive headwind
- Continuous geodetic trajectory propagation across Equator and Anti-Meridian
- Squitter scheduler DO-260B jitter bounds, CPR alternation, and CRC validity
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from adsb.constants import (
    EARTH_MEAN_RADIUS_M,
    ISA_P0_PA,
    KNOTS_TO_MPS,
)
from adsb.core.geodesy import haversine_distance
from adsb.protocol.modes import decode_mode_s
from adsb.synthesis.aircraft_db import get_aircraft_profile
from adsb.synthesis.atmosphere import (
    TROPOPAUSE_ALT_M,
    cas_to_tas,
    compute_atmosphere,
    crossover_altitude_m,
    isa_pressure_pa,
    mach_to_tas,
    pressure_to_pressure_altitude_m,
    solve_wind_triangle_heading,
    solve_wind_triangle_track,
    tas_to_cas,
    tas_to_mach,
)
from adsb.synthesis.navigation import (
    TurnDirection,
    classify_holding_entry,
    compute_flyby_lead_distance,
    rhumb_distance_and_bearing,
)
from adsb.synthesis.scenario import load_scenario
from adsb.synthesis.scheduler import MultiAircraftScheduler, SquitterScheduler
from adsb.synthesis.trajectory import (
    generate_maneuvering_flight,
    generate_simple_climb_trajectory,
    generate_straight_flight,
)

# ==============================================================================
# 1. ISA Atmosphere Model Adversarial Stress
# ==============================================================================


class TestAtmosphereAdversarialStress:
    """Stress testing the dual-layer ISA model across extreme conditions."""

    @pytest.mark.parametrize("delta_isa_k", [-40.0, -20.0, 0.0, 20.0, 40.0])
    @pytest.mark.parametrize("qnh_hpa", [920.0, 980.0, 1013.25, 1040.0, 1070.0])
    def test_atmosphere_positivity_and_no_nans(
        self, delta_isa_k: float, qnh_hpa: float
    ) -> None:
        """Verify pressure, density, temperature and speed of sound are strictly positive and finite."""
        alts_m = np.linspace(0.0, 20000.0, 201)
        for h in alts_m:
            st = compute_atmosphere(float(h), delta_isa_k=delta_isa_k, qnh_hpa=qnh_hpa)

            assert not math.isnan(st.temperature_k)
            assert not math.isnan(st.pressure_pa)
            assert not math.isnan(st.density_kgpm3)
            assert not math.isnan(st.speed_of_sound_mps)

            assert st.temperature_k > 0.0
            assert st.pressure_pa > 0.0
            assert st.density_kgpm3 > 0.0
            assert st.speed_of_sound_mps > 0.0

    def test_tropopause_boundary_numerical_continuity(self) -> None:
        """Verify C0 continuity across the 11,000 m boundary to sub-microscopic tolerances."""
        epsilons = [1e-3, 1e-5, 1e-7]
        for eps in epsilons:
            st_below = compute_atmosphere(TROPOPAUSE_ALT_M - eps)
            st_above = compute_atmosphere(TROPOPAUSE_ALT_M + eps)

            dp = abs(st_above.pressure_pa - st_below.pressure_pa)
            dt = abs(st_above.temperature_k - st_below.temperature_k)
            drho = abs(st_above.density_kgpm3 - st_below.density_kgpm3)
            dsos = abs(st_above.speed_of_sound_mps - st_below.speed_of_sound_mps)

            # Jump should be bounded by hydrostatic gradient * 2 * eps
            assert dp < 10.0 * eps
            assert dt < 0.01 * eps
            assert drho < 0.01 * eps
            assert dsos < 0.01 * eps

    def test_pressure_monotonic_decrease_with_altitude(self) -> None:
        """Verify pressure strictly decreases with altitude from sea level to 20 km."""
        alts_m = np.linspace(0.0, 20000.0, 401)
        pressures = [isa_pressure_pa(float(h)) for h in alts_m]
        for i in range(len(pressures) - 1):
            assert (
                pressures[i + 1] < pressures[i]
            ), f"Pressure inversion at alt {alts_m[i]} m"

    def test_pressure_altitude_inversion_roundtrip_dense(self) -> None:
        """Verify pressure_to_pressure_altitude_m(isa_pressure_pa(h)) == h across 0..20000 m."""
        alts_m = np.linspace(0.0, 20000.0, 501)
        for h in alts_m:
            p = isa_pressure_pa(float(h))
            h_rec = pressure_to_pressure_altitude_m(p)
            assert (
                abs(h_rec - h) < 1e-3
            ), f"Pressure altitude roundtrip failed at h={h} m: got {h_rec}"

    def test_negative_altitude_handling(self) -> None:
        """Verify negative altitudes (e.g. Dead Sea -430 m) do not crash or produce NaNs."""
        st = compute_atmosphere(-430.0)
        assert not math.isnan(st.pressure_pa)
        assert st.pressure_pa >= ISA_P0_PA
        assert st.temperature_k > 0.0


# ==============================================================================
# 2. Compressible Saint-Venant Airspeed Stress
# ==============================================================================


class TestCompressibleAirspeedsStress:
    """Stress testing CAS <-> TAS <-> Mach roundtrip and crossover math."""

    @pytest.mark.parametrize(
        "alt_m", [0.0, 3000.0, 6000.0, 11000.0, 15000.0, 20000.0]
    )
    @pytest.mark.parametrize(
        "cas_kt", [30.0, 60.0, 120.0, 200.0, 300.0, 450.0, 600.0]
    )
    def test_cas_tas_invertibility_broad_envelope(
        self, alt_m: float, cas_kt: float
    ) -> None:
        """Verify roundtrip cas -> tas -> cas preserves speed within 1e-4 m/s."""
        cas_mps = cas_kt * KNOTS_TO_MPS
        tas_mps = cas_to_tas(cas_mps, alt_m)
        cas_rec = tas_to_cas(tas_mps, alt_m)
        assert (
            abs(cas_rec - cas_mps) < 1e-4
        ), f"Failed at alt={alt_m} m, cas={cas_kt} kt: got {cas_rec / KNOTS_TO_MPS} kt"

    @pytest.mark.parametrize("alt_m", [11000.0, 14000.0, 17000.0, 20000.0])
    @pytest.mark.parametrize("mach", [0.5, 0.85, 1.0, 1.4, 1.7, 2.0, 2.2])
    def test_supersonic_mach_tas_invertibility(
        self, alt_m: float, mach: float
    ) -> None:
        """Verify supersonic Mach to TAS and back to CAS preserves speeds."""
        tas_mps = mach_to_tas(mach, alt_m)
        mach_rec = tas_to_mach(tas_mps, alt_m)
        assert (
            abs(mach_rec - mach) < 1e-7
        ), f"Mach roundtrip failed at alt={alt_m}, mach={mach}"

        # Roundtrip via CAS
        cas_mps = tas_to_cas(tas_mps, alt_m)
        tas_rec = cas_to_tas(cas_mps, alt_m)
        assert (
            abs(tas_rec - tas_mps) < 1e-3
        ), f"TAS roundtrip via CAS failed at alt={alt_m}, mach={mach}"

    def test_zero_speed_boundary(self) -> None:
        """Verify zero CAS and zero TAS return 0.0 without division by zero."""
        assert cas_to_tas(0.0, 5000.0) == 0.0
        assert tas_to_cas(0.0, 5000.0) == 0.0
        assert tas_to_mach(0.0, 5000.0) == 0.0
        assert mach_to_tas(0.0, 5000.0) == 0.0

    def test_crossover_altitude_consistency(self) -> None:
        """Verify at crossover altitude, constant CAS matches target climb Mach."""
        profiles_to_test = [
            ("B738", 280.0, 0.78),
            ("A320", 290.0, 0.78),
            ("B77W", 310.0, 0.84),
            ("CONC", 400.0, 1.70),
        ]
        for name, cas_kt, mach in profiles_to_test:
            cas_mps = cas_kt * KNOTS_TO_MPS
            h_cross_m = crossover_altitude_m(cas_mps, mach)
            assert (
                h_cross_m > 0.0
            ), f"Crossover altitude must be positive for {name}"

            # At crossover altitude, CAS converted to TAS must equal Mach * SpeedOfSound
            tas_at_cross = cas_to_tas(cas_mps, h_cross_m)
            mach_at_cross = tas_to_mach(tas_at_cross, h_cross_m)
            assert (
                abs(mach_at_cross - mach) < 1e-4
            ), f"{name}: calculated Mach {mach_at_cross} != target {mach}"


# ==============================================================================
# 3. 3D Wind Triangle Adversarial Stress
# ==============================================================================


class TestWindTriangleAdversarialStress:
    """Stress testing 3D wind triangle against boundary values and singularities."""

    def test_calm_wind_identity(self) -> None:
        """With zero wind, heading == track, gs == tas, wca == 0."""
        for trk in [0.0, 90.0, 180.0, 270.0, 359.9]:
            h, gs, wca = solve_wind_triangle_heading(
                track_deg=trk, tas_mps=150.0, wind_speed_mps=0.0, wind_dir_from_deg=0.0
            )
            assert abs(h - trk) < 1e-6
            assert abs(gs - 150.0) < 1e-6
            assert abs(wca) < 1e-6

    def test_pure_headwind_and_pure_tailwind(self) -> None:
        """With along-track wind, WCA is exactly 0 and GS equals TAS +- wind."""
        tas = 200.0
        wind = 40.0
        # Headwind (track 90, wind FROM 90)
        h_hw, gs_hw, wca_hw = solve_wind_triangle_heading(
            90.0, tas, wind, 90.0
        )
        assert abs(h_hw - 90.0) < 1e-6
        assert abs(gs_hw - 160.0) < 1e-6
        assert abs(wca_hw) < 1e-6

        # Tailwind (track 90, wind FROM 270)
        h_tw, gs_tw, wca_tw = solve_wind_triangle_heading(
            90.0, tas, wind, 270.0
        )
        assert abs(h_tw - 90.0) < 1e-6
        assert abs(gs_tw - 240.0) < 1e-6
        assert abs(wca_tw) < 1e-6

    def test_excessive_headwind_clamping(self) -> None:
        """When headwind exceeds TAS, groundspeed must clamp to 0.0."""
        tas = 50.0
        excessive_wind = 80.0
        _, gs, _ = solve_wind_triangle_heading(
            0.0, tas, excessive_wind, 0.0
        )
        assert gs == 0.0

    def test_crosswind_approaching_tas_limit(self) -> None:
        """When crosswind approaches TAS (e.g. 99.9% TAS), WCA approaches +-90 deg."""
        tas = 100.0
        near_limit_wind = 99.9  # 99.9 m/s pure crosswind from left (wind FROM 0 deg, track 90 deg)
        h, gs, wca = solve_wind_triangle_heading(
            90.0, tas, near_limit_wind, 0.0
        )
        assert abs(wca) > 87.0
        assert gs > 0.0
        assert not math.isnan(h)
        assert not math.isnan(gs)

    def test_crosswind_exceeding_tas_raises_value_error(self) -> None:
        """When crosswind strictly exceeds TAS, solver must raise ValueError."""
        tas = 100.0
        with pytest.raises(ValueError, match="cannot maintain track"):
            solve_wind_triangle_heading(
                track_deg=90.0,
                tas_mps=tas,
                wind_speed_mps=100.1,
                wind_dir_from_deg=0.0,
            )

    def test_zero_tas_raises_value_error(self) -> None:
        """Zero TAS must raise ValueError."""
        with pytest.raises(ValueError, match="True Airspeed must be positive"):
            solve_wind_triangle_heading(
                track_deg=90.0,
                tas_mps=0.0,
                wind_speed_mps=10.0,
                wind_dir_from_deg=0.0,
            )

    def test_wind_triangle_mutual_inversion_grid(self) -> None:
        """Verify solve_wind_triangle_heading and solve_wind_triangle_track are mutual inverses."""
        tas = 180.0
        wind_speed = 35.0
        for trk in np.linspace(0.0, 330.0, 12):
            for wdir in [0.0, 45.0, 90.0, 135.0, 180.0, 270.0]:
                h_deg, gs_1, wca = solve_wind_triangle_heading(
                    float(trk), tas, wind_speed, wdir
                )
                trk_calc, gs_2, drift = solve_wind_triangle_track(
                    h_deg, tas, wind_speed, wdir
                )
                # Verify track matches
                diff_trk = (trk_calc - trk + 180.0) % 360.0 - 180.0
                assert abs(diff_trk) < 1e-4
                assert abs(gs_1 - gs_2) < 1e-4
                assert abs(drift - wca) < 1e-4


# ==============================================================================
# 4. Trajectory Generators Geodetic Continuity Stress
# ==============================================================================


class TestTrajectoryGeneratorsGeodeticStress:
    """Stress testing trajectory generators across Equator, Anti-Meridian, and high latitudes."""

    def test_straight_flight_equator_crossing_northbound(self) -> None:
        """Straight flight flying due North across Equator."""
        states = generate_straight_flight(
            start_lat=-0.1,
            start_lon=25.0,
            heading_deg=0.0,
            speed_kt=450.0,
            alt_ft=35000.0,
            duration_s=120.0,
            dt_s=1.0,
        )
        assert states[0].lat_deg < 0.0
        assert states[-1].lat_deg > 0.0

        # Verify step-to-step distance continuity
        for i in range(len(states) - 1):
            d = haversine_distance(
                states[i].lat_deg,
                states[i].lon_deg,
                states[i + 1].lat_deg,
                states[i + 1].lon_deg,
            )
            expected_d = states[i].groundspeed_mps * 1.0
            assert (
                abs(d - expected_d) < 1.0
            ), f"Discontinuity at step {i}: {d} vs {expected_d}"

    def test_straight_flight_equator_crossing_southbound(self) -> None:
        """Straight flight flying due South across Equator."""
        states = generate_straight_flight(
            start_lat=0.1,
            start_lon=-50.0,
            heading_deg=180.0,
            speed_kt=450.0,
            alt_ft=35000.0,
            duration_s=120.0,
            dt_s=1.0,
        )
        assert states[0].lat_deg > 0.0
        assert states[-1].lat_deg < 0.0

        for i in range(len(states) - 1):
            d = haversine_distance(
                states[i].lat_deg,
                states[i].lon_deg,
                states[i + 1].lat_deg,
                states[i + 1].lon_deg,
            )
            expected_d = states[i].groundspeed_mps * 1.0
            assert abs(d - expected_d) < 1.0

    def test_straight_flight_anti_meridian_eastbound(self) -> None:
        """Straight flight crossing Anti-Meridian from Eastern (+180) to Western (-180) hemisphere."""
        states = generate_straight_flight(
            start_lat=10.0,
            start_lon=179.9,
            heading_deg=90.0,
            speed_kt=480.0,
            alt_ft=37000.0,
            duration_s=180.0,
            dt_s=1.0,
        )
        assert states[0].lon_deg > 179.0
        assert states[-1].lon_deg < -179.0

        # Crucial: verify absence of 360-degree teleport glitches across boundary
        for i in range(len(states) - 1):
            d = haversine_distance(
                states[i].lat_deg,
                states[i].lon_deg,
                states[i + 1].lat_deg,
                states[i + 1].lon_deg,
            )
            expected_d = states[i].groundspeed_mps * 1.0
            assert (
                abs(d - expected_d) < 1.0
            ), f"Anti-Meridian teleport glitch at step {i}: distance {d} m"

    def test_straight_flight_anti_meridian_westbound(self) -> None:
        """Straight flight crossing Anti-Meridian from Western (-180) to Eastern (+180) hemisphere."""
        states = generate_straight_flight(
            start_lat=-15.0,
            start_lon=-179.9,
            heading_deg=270.0,
            speed_kt=480.0,
            alt_ft=37000.0,
            duration_s=180.0,
            dt_s=1.0,
        )
        assert states[0].lon_deg < -179.0
        assert states[-1].lon_deg > 179.0

        for i in range(len(states) - 1):
            d = haversine_distance(
                states[i].lat_deg,
                states[i].lon_deg,
                states[i + 1].lat_deg,
                states[i + 1].lon_deg,
            )
            expected_d = states[i].groundspeed_mps * 1.0
            assert abs(d - expected_d) < 1.0

    def test_simple_climb_trajectory_anti_meridian(self) -> None:
        """Climb trajectory originating right on the anti-meridian."""
        profile = get_aircraft_profile("B738")
        states = generate_simple_climb_trajectory(
            profile=profile,
            origin_lat=0.0,
            origin_lon=179.95,
            target_alt_ft=12000.0,
            duration_s=120.0,
            dt_s=1.0,
        )
        assert states[0].lon_deg > 179.9
        assert states[-1].lon_deg < -179.0
        for i in range(len(states) - 1):
            d = haversine_distance(
                states[i].lat_deg,
                states[i].lon_deg,
                states[i + 1].lat_deg,
                states[i + 1].lon_deg,
            )
            expected_d = states[i].groundspeed_mps * 1.0
            assert abs(d - expected_d) < 1.0

    def test_maneuvering_flight_anti_meridian_turn(self) -> None:
        """Maneuvering flight performing a coordinated turn across the anti-meridian."""
        states = generate_maneuvering_flight(
            start_lat=5.0,
            start_lon=179.92,
            speed_kt=300.0,
            alt_ft=25000.0,
            straight_time_1_s=20.0,
            bank_angle_deg=25.0,
            turn_duration_s=40.0,
            straight_time_2_s=20.0,
            dt_s=1.0,
        )
        assert states[0].lon_deg > 179.9
        assert states[-1].lon_deg < -179.0
        for i in range(len(states) - 1):
            d = haversine_distance(
                states[i].lat_deg,
                states[i].lon_deg,
                states[i + 1].lat_deg,
                states[i + 1].lon_deg,
            )
            expected_d = states[i].groundspeed_mps * 1.0
            assert abs(d - expected_d) < 1.0


# ==============================================================================
# 5. Squitter Scheduler DO-260B Compliance & Decodability Stress
# ==============================================================================


class TestSquitterSchedulerStress:
    """Stress testing the squitter generation timing jitter, CPR alternation, and frame decodability."""

    def test_squitter_jitter_bounds_rigorous(self) -> None:
        """Verify squitter transmission intervals strictly adhere to DO-260B uniform jitter."""
        rng = np.random.default_rng(9999)
        profile = get_aircraft_profile("B738")
        states = generate_simple_climb_trajectory(
            profile=profile,
            origin_lat=52.3,
            origin_lon=4.76,
            target_alt_ft=10000.0,
            duration_s=60.0,
            dt_s=1.0,
            rng=rng,
        )

        scheduler = SquitterScheduler(
            icao24=0x4840D6,
            callsign="KLM1023",
            rng=rng,
            profile=profile,
            include_df11=True,
        )
        events = scheduler.generate_squitters(states)
        assert len(events) > 200

        # Filter by type
        pos_events = []
        id_events = []
        df11_events = []

        for ev in events:
            msg = decode_mode_s(ev.raw_bytes)
            assert msg.crc_valid is True, f"Emitted frame CRC failed: {ev.raw_bytes.hex()}"
            if msg.df == 17 and msg.tc in range(9, 19):
                pos_events.append(ev)
            elif msg.df == 17 and msg.tc in range(1, 5):
                id_events.append(ev)
            elif msg.df == 11:
                df11_events.append(ev)

        # Check airborne position intervals: 0.40s to 0.60s
        for i in range(len(pos_events) - 1):
            dt = pos_events[i + 1].timestamp_s - pos_events[i].timestamp_s
            assert 0.399 <= dt <= 0.601, f"Position jitter out of DO-260B bounds: {dt}s"

        # Check callsign intervals: 4.80s to 5.20s
        for i in range(len(id_events) - 1):
            dt = id_events[i + 1].timestamp_s - id_events[i].timestamp_s
            assert 4.799 <= dt <= 5.201, f"Identification jitter out of DO-260B bounds: {dt}s"

        # Check DF11 intervals: 0.80s to 1.20s
        for i in range(len(df11_events) - 1):
            dt = df11_events[i + 1].timestamp_s - df11_events[i].timestamp_s
            assert 0.799 <= dt <= 1.201, f"DF11 jitter out of bounds: {dt}s"

    def test_cpr_strict_alternation_invariant(self) -> None:
        """Verify position squitter frames strictly alternate Even (0) and Odd (1)."""
        rng = np.random.default_rng(12345)
        profile = get_aircraft_profile("A320")
        states = generate_simple_climb_trajectory(
            profile=profile,
            origin_lat=40.64,
            origin_lon=-73.78,
            target_alt_ft=5000.0,
            duration_s=30.0,
            rng=rng,
        )

        scheduler = SquitterScheduler(
            icao24=0xA00001,
            callsign="JAL001",
            rng=rng,
            profile=profile,
        )
        events = scheduler.generate_squitters(states)

        cpr_formats: list[int] = []
        for ev in events:
            msg = decode_mode_s(ev.raw_bytes)
            if msg.df == 17 and msg.tc in range(9, 19):
                cpr_formats.append(msg.cpr_format)

        assert len(cpr_formats) >= 50
        for i in range(len(cpr_formats) - 1):
            assert (
                cpr_formats[i + 1] == 1 - cpr_formats[i]
            ), f"CPR alternation broken at index {i}: {cpr_formats[i]} -> {cpr_formats[i+1]}"

    def test_multi_aircraft_stream_chronological_ordering(self) -> None:
        """Verify MultiAircraftScheduler emits events strictly sorted in time."""
        rng = np.random.default_rng(42)
        scenario = load_scenario("clean_tma_10_aircraft", rng=rng)
        sched = MultiAircraftScheduler(scenario, rng=rng)
        all_events = sched.generate_all_events()

        assert len(all_events) > 1000
        for i in range(len(all_events) - 1):
            assert (
                all_events[i].timestamp_s <= all_events[i + 1].timestamp_s
            ), f"Timestamp out of order at index {i}: {all_events[i].timestamp_s} > {all_events[i+1].timestamp_s}"


# ==============================================================================
# 6. Navigation Primitives Boundary Stress
# ==============================================================================


class TestNavigationPrimitivesStress:
    """Stress testing Rhumb lines, fly-by lead solver, and holding pattern classifier."""

    def test_rhumb_line_anti_meridian_wrap(self) -> None:
        """Verify Rhumb line navigation across the anti-meridian."""
        lat1, lon1 = 0.0, 179.0
        lat2, lon2 = 0.0, -179.0
        dist_m, bearing = rhumb_distance_and_bearing(lat1, lon1, lat2, lon2)
        assert abs(bearing - 90.0) < 1e-4  # Due East
        expected_dist = EARTH_MEAN_RADIUS_M * math.radians(2.0)
        assert abs(dist_m - expected_dist) < 10.0

    def test_flyby_lead_distance_zero_turn_angle(self) -> None:
        """When course change is zero, lead distance is zero."""
        d_lead, r_turn, bank = compute_flyby_lead_distance(
            inbound_track_deg=90.0,
            outbound_track_deg=90.0,
            groundspeed_mps=200.0,
        )
        assert d_lead == 0.0
        assert r_turn == 0.0
        assert bank == 0.0

    def test_flyby_lead_distance_reversal_turn_no_divergence(self) -> None:
        """When course change is 180 degrees (reversal), lead distance does not diverge to infinity."""
        d_lead, r_turn, bank = compute_flyby_lead_distance(
            inbound_track_deg=90.0,
            outbound_track_deg=270.0,
            groundspeed_mps=200.0,
        )
        assert not math.isinf(d_lead)
        assert not math.isnan(d_lead)
        assert d_lead > 0.0
        assert r_turn > 0.0
        assert bank > 0.0

    @pytest.mark.parametrize("turn_dir", [TurnDirection.RIGHT, TurnDirection.LEFT])
    def test_holding_pattern_classifier_all_azimuths(
        self, turn_dir: TurnDirection
    ) -> None:
        """Verify holding pattern entry classifier returns valid entries across all 360 degrees."""
        for app_trk in np.linspace(0.0, 359.0, 360):
            entry = classify_holding_entry(
                approach_track_deg=float(app_trk),
                inbound_holding_track_deg=90.0,
                turn_direction=turn_dir,
            )
            assert entry in [
                "DIRECT",
                "PARALLEL",
                "TEARDROP",
            ]
