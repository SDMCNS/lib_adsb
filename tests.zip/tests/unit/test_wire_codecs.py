"""Unit tests for multi-format wire codecs (AVR, SBS-1, JSON Lines, Beast).

Covers:
- Standard unstamped and timestamped MLAT AVR ASCII codecs.
- SBS-1 BaseStation 22-column CSV codec across transmission types 1..8.
- JSON Lines streaming serializer and parser.
- Public exports from adsb.wire.
"""

from __future__ import annotations

import pytest

from adsb.wire import (
    BeastFrame,
    SBSMessage,
    parse_avr_frame,
    parse_avr_stream,
    parse_beast_frame,
    parse_json_line,
    parse_json_stream,
    parse_sbs_message,
    parse_sbs_stream,
    serialize_avr_frame,
    serialize_beast_frame,
    serialize_json_line,
    serialize_json_stream,
    serialize_sbs_message,
)


class TestAVRCodec:
    """Test suite for Raw AVR ASCII hex format."""

    def test_serialize_unstamped(self) -> None:
        raw_bytes = bytes.fromhex("8D4840D6202CC371C32CE0576098")
        out = serialize_avr_frame(raw_bytes)
        assert out == "*8D4840D6202CC371C32CE0576098;\r\n"

    def test_serialize_timestamped(self) -> None:
        raw_bytes = bytes.fromhex("8D4840D6202CC371C32CE0576098")
        ts = 0x00001A2B3C4D
        out = serialize_avr_frame(raw_bytes, mlat_timestamp_12mhz=ts)
        assert out == f"@{ts:012X}8D4840D6202CC371C32CE0576098;\r\n"

    def test_parse_unstamped(self) -> None:
        line = "*8D4840D6202CC371C32CE0576098;\r\n"
        payload, ts = parse_avr_frame(line)
        assert payload.hex().upper() == "8D4840D6202CC371C32CE0576098"
        assert ts is None

    def test_parse_timestamped(self) -> None:
        line = "@00001A2B3C4D8D4840D6202CC371C32CE0576098;\n"
        payload, ts = parse_avr_frame(line)
        assert payload.hex().upper() == "8D4840D6202CC371C32CE0576098"
        assert ts == 0x00001A2B3C4D

    def test_round_trip(self) -> None:
        raw = b"\x8d\x40\x62\x1d\x58\xc3\x82\xd6\x90\xc8\xac\x28\x63\xa7"
        ts = 987654321
        encoded = serialize_avr_frame(raw, ts)
        dec_payload, dec_ts = parse_avr_frame(encoded)
        assert dec_payload == raw
        assert dec_ts == ts

    def test_parse_stream(self) -> None:
        stream = (
            "*8D4840D6202CC371C32CE0576098;\r\n"
            "@0000000000015D4840D6F8740F;\n"
            "   GARBAGE_NOISE_HERE   \n"
            "*02E197B867A348;\n"
        )
        frames = parse_avr_stream(stream)
        assert len(frames) == 3
        assert frames[0][0].hex().upper() == "8D4840D6202CC371C32CE0576098"
        assert frames[0][1] is None
        assert frames[1][0].hex().upper() == "5D4840D6F8740F"
        assert frames[1][1] == 1
        assert frames[2][0].hex().upper() == "02E197B867A348"
        assert frames[2][1] is None

    def test_invalid_frames(self) -> None:
        with pytest.raises(ValueError):
            parse_avr_frame("")
        with pytest.raises(ValueError):
            parse_avr_frame("8D4840D6;")  # Missing * or @
        with pytest.raises(ValueError):
            parse_avr_frame("*8D4840D6")  # Missing terminating ;
        with pytest.raises(ValueError):
            parse_avr_frame("*8D48G6;")  # Non-hex characters
        with pytest.raises(ValueError):
            parse_avr_frame("@00018D48;")  # Timestamp < 12 hex digits


class TestSBSCodec:
    """Test suite for SBS-1 BaseStation 22-column CSV format."""

    def test_serialize_and_parse_msg1(self) -> None:
        msg = SBSMessage(
            message_type="MSG",
            transmission_type=1,
            hex_ident="4840D6",
            callsign="KLM1023",
            date_gen="2026/10/31",
            time_gen="12:00:00.123",
            date_log="2026/10/31",
            time_log="12:00:00.150",
        )
        csv_str = serialize_sbs_message(msg)
        assert csv_str.startswith("MSG,1,1,1,4840D6,1,2026/10/31,12:00:00.123")
        assert "KLM1023" in csv_str

        parsed = parse_sbs_message(csv_str)
        assert parsed.transmission_type == 1
        assert parsed.hex_ident == "4840D6"
        assert parsed.callsign == "KLM1023"
        assert parsed.altitude is None

    def test_serialize_and_parse_msg3(self) -> None:
        msg = SBSMessage(
            message_type="MSG",
            transmission_type=3,
            hex_ident="40621D",
            altitude=38000,
            lat=52.2572,
            lon=3.91937,
            alert=0,
            emergency=0,
            spi=0,
            is_on_ground=0,
        )
        csv_str = serialize_sbs_message(msg)
        parsed = parse_sbs_message(csv_str)
        assert parsed.transmission_type == 3
        assert parsed.hex_ident == "40621D"
        assert parsed.altitude == 38000
        assert parsed.lat == pytest.approx(52.2572, abs=1e-4)
        assert parsed.lon == pytest.approx(3.91937, abs=1e-4)
        assert parsed.is_on_ground == 0

    def test_serialize_and_parse_msg4(self) -> None:
        msg = SBSMessage(
            message_type="MSG",
            transmission_type=4,
            hex_ident="485020",
            ground_speed=159.2,
            track=182.9,
            vertical_rate=-832,
        )
        csv_str = serialize_sbs_message(msg)
        parsed = parse_sbs_message(csv_str)
        assert parsed.transmission_type == 4
        assert parsed.ground_speed == pytest.approx(159.2, abs=0.1)
        assert parsed.track == pytest.approx(182.9, abs=0.1)
        assert parsed.vertical_rate == -832

    def test_parse_sbs_stream(self) -> None:
        stream = (
            "MSG,1,1,1,4840D6,1,2026/10/31,12:00:00.000,2026/10/31,12:00:00.000,KLM1023,,,,,,,,,,,\r\n"
            "MSG,3,1,1,4840D6,1,2026/10/31,12:00:01.000,2026/10/31,12:00:01.000,,10000,,,52.31,4.76,,,0,0,0,0\n"
            "\n"
            "INVALID_SHORT_LINE\n"
        )
        msgs = parse_sbs_stream(stream)
        assert len(msgs) == 2
        assert msgs[0].callsign == "KLM1023"
        assert msgs[1].altitude == 10000

    def test_malformed_sbs(self) -> None:
        with pytest.raises(ValueError):
            parse_sbs_message("")
        with pytest.raises(ValueError):
            parse_sbs_message("MSG,1,1,1")  # < 22 fields
        with pytest.raises(ValueError):
            parse_sbs_message("MSG,NOT_AN_INT,1,1,4840D6,1,,,,,,,,,,,,,,,,")


class TestJSONCodec:
    """Test suite for JSON Lines serialization and parsing."""

    def test_json_single_line(self) -> None:
        data = {"icao": "4840D6", "alt_ft": 35000, "coords": [52.3, 4.8]}
        line = serialize_json_line(data)
        assert line.endswith("\n")
        parsed = parse_json_line(line)
        assert parsed == data

    def test_json_stream(self) -> None:
        items = [{"id": 1, "val": "A"}, {"id": 2, "val": "B"}]
        stream = serialize_json_stream(items)
        assert stream.count("\n") == 2
        parsed = parse_json_stream(stream)
        assert len(parsed) == 2
        assert parsed[0]["id"] == 1
        assert parsed[1]["val"] == "B"

    def test_json_dataclass_and_bytes(self) -> None:
        msg = SBSMessage(hex_ident="A1B2C3", altitude=12000)
        line = serialize_json_line(msg)
        parsed = parse_json_line(line)
        assert parsed["hex_ident"] == "A1B2C3"
        assert parsed["altitude"] == 12000

    def test_json_malformed(self) -> None:
        with pytest.raises(ValueError):
            parse_json_line("")
        with pytest.raises(ValueError):
            parse_json_line("{invalid json")
        with pytest.raises(ValueError):
            parse_json_line("[1, 2, 3]")  # Not a dict


class TestBeastExports:
    """Test re-exported Beast functions from adsb.wire."""

    def test_beast_reexport(self) -> None:
        enc = serialize_beast_frame("3", 1000, 200, b"\x01\x02\x03")
        parsed = parse_beast_frame(enc)
        assert isinstance(parsed, BeastFrame)
        assert parsed.frame_type == "3"
        assert parsed.payload == b"\x01\x02\x03"
