"""Empirical adversarial stress and challenge test suite for Milestone 5 API & Streaming service.

Authored by Challenger M5 to rigorously and empirically stress-test:
1. Autonomous simulation loop execution and speed multipliers (1x, 2x, 5x, 10x, dynamic adjustments, pause/step/reset).
2. Multi-client concurrent WebSocket streaming under traffic load (/ws/telemetry and /ws/wire across AVR, Beast, and SBS).
3. High-rate wire frame injection across AVR, Beast, and SBS formats into the tracker and IMM filter.
4. Robust error handling on malformed, corrupt, truncated, and unsupported wire frame injections and invalid API parameters.
5. Concurrent stress execution interleaving active autonomous simulation, multi-format wire injections, and live WebSocket broadcast drains.
6. Graceful lifespan shutdown under active WebSocket client connections.
7. Empirical verification of configuration rollback failure mode on invalid scenario injection.

Authoritative reference: PROJECT.md M5, AGENTS.md, and docs/01_ARCHITECTURE_AND_DESIGN.md.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Generator

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import (
    SimulationConfig,
    SimulationManager,
    SimulationStatus,
    get_simulation_manager,
    reset_simulation_manager,
)
from adsb.protocol.modes import (
    encode_1090es_airborne_position,
    encode_1090es_airborne_velocity,
    encode_1090es_identification,
)
from adsb.wire.avr import serialize_avr_frame
from adsb.wire.beast import serialize_beast_frame
from adsb.wire.sbs import SBSMessage, serialize_sbs_message


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Provide a TestClient with a freshly reset SimulationManager inside application lifespan."""
    mgr = get_simulation_manager()
    mgr.config = SimulationConfig()
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


def _get_sim_task(mgr: SimulationManager) -> asyncio.Task[None] | None:
    return mgr._sim_task


def _get_mgr_status(mgr: SimulationManager) -> SimulationStatus:
    return mgr.status


# ==============================================================================
# 1. Autonomous Simulation Loop Execution & Speed Multipliers Stress Tests
# ==============================================================================


@pytest.mark.tier1
def test_autonomous_simulation_speed_scaling(client: TestClient) -> None:
    """Empirically verify autonomous advancement rate scales proportionally across speed multipliers.

    Tests 1.0x, 2.0x, 5.0x, and 10.0x multipliers to ensure the 20 Hz loop advances
    simulated time according to speed_multiplier without drift, stall, or event loop starvation.
    """
    mgr = get_simulation_manager()

    speeds = [1.0, 2.0, 5.0, 10.0]
    advancements: dict[float, float] = {}

    for speed in speeds:
        client.post("/api/v1/simulation/reset")
        assert mgr.sim_time_s == 0.0
        assert _get_mgr_status(mgr) == SimulationStatus.STOPPED

        # Configure speed multiplier
        speed_res = client.post("/api/v1/simulation/speed", json={"speed_multiplier": speed})
        assert speed_res.status_code == 200
        assert speed_res.json()["speed_multiplier"] == speed
        assert mgr.speed_multiplier == speed

        # Start autonomous simulation
        start_res = client.post("/api/v1/simulation/start")
        assert start_res.status_code == 200
        assert start_res.json()["status"] == "RUNNING"
        assert _get_mgr_status(mgr) == SimulationStatus.RUNNING

        task = _get_sim_task(mgr)
        assert task is not None and not task.done()

        # Measure advancement over a controlled sleep interval (0.15s)
        t_start = mgr.sim_time_s
        time.sleep(0.15)
        adv = mgr.sim_time_s - t_start
        advancements[speed] = adv

        # Pause and verify task cancellation
        pause_res = client.post("/api/v1/simulation/pause")
        assert pause_res.status_code == 200
        assert pause_res.json()["status"] == "PAUSED"
        assert _get_sim_task(mgr) is None

    # Verify baseline advancement at 1x
    assert advancements[1.0] >= 0.08, f"1.0x speed failed to advance sufficiently: {advancements[1.0]:.3f}s"

    # Verify scaling progression: each speed level advances strictly faster than the previous
    assert (
        advancements[2.0] > advancements[1.0] * 1.2
    ), f"2.0x ({advancements[2.0]:.3f}s) should advance faster than 1.0x ({advancements[1.0]:.3f}s)"

    assert (
        advancements[5.0] > advancements[2.0] * 1.5
    ), f"5.0x ({advancements[5.0]:.3f}s) should advance faster than 2.0x ({advancements[2.0]:.3f}s)"

    assert (
        advancements[10.0] > advancements[5.0] * 1.1
    ), f"10.0x ({advancements[10.0]:.3f}s) should advance faster than 5.0x ({advancements[5.0]:.3f}s)"


@pytest.mark.tier1
def test_dynamic_in_flight_speed_multiplier_adjustment(client: TestClient) -> None:
    """Verify dynamically updating speed multiplier while simulation is actively running.

    The running task must not abort, crash, or reset sim_time_s, but must adapt its tick delta.
    """
    mgr = get_simulation_manager()
    client.post("/api/v1/simulation/reset")

    # Start at 1.0x
    client.post("/api/v1/simulation/speed", json={"speed_multiplier": 1.0})
    client.post("/api/v1/simulation/start")
    task_initial = _get_sim_task(mgr)
    assert task_initial is not None and not task_initial.done()

    time.sleep(0.10)
    t_mid1 = mgr.sim_time_s
    assert t_mid1 > 0.0

    # Dynamically increase speed to 8.0x while running
    res = client.post("/api/v1/simulation/speed", json={"speed_multiplier": 8.0})
    assert res.status_code == 200
    assert res.json()["speed_multiplier"] == 8.0
    assert mgr.speed_multiplier == 8.0

    # Background task should remain active
    task_after = _get_sim_task(mgr)
    assert task_after is not None and not task_after.done()

    time.sleep(0.12)
    adv_boosted = mgr.sim_time_s - t_mid1
    # At 8x, advancement over 0.12s should be >= 0.4s
    assert adv_boosted >= 0.40, f"Dynamic speed acceleration failed: {adv_boosted:.3f}s"

    client.post("/api/v1/simulation/pause")


@pytest.mark.tier1
def test_simulation_lifecycle_state_machine_exhaustion(client: TestClient) -> None:
    """Stress-test full state transitions, idempotence, manual stepping, and reconfigurations."""
    mgr = get_simulation_manager()

    # Initial state
    assert _get_mgr_status(mgr) == SimulationStatus.STOPPED
    assert mgr.sim_time_s == 0.0

    # 1. Multiple start calls (idempotence)
    res1 = client.post("/api/v1/simulation/start")
    assert res1.status_code == 200
    res2 = client.post("/api/v1/simulation/start")
    assert res2.status_code == 200
    assert _get_mgr_status(mgr) == SimulationStatus.RUNNING

    # 2. Pause and multiple pause calls (idempotence)
    res3 = client.post("/api/v1/simulation/pause")
    assert res3.status_code == 200
    assert _get_mgr_status(mgr) == SimulationStatus.PAUSED
    res4 = client.post("/api/v1/simulation/pause")
    assert res4.status_code == 200
    assert _get_mgr_status(mgr) == SimulationStatus.PAUSED

    # Ensure time does not advance when paused
    t_paused = mgr.sim_time_s
    time.sleep(0.10)
    assert mgr.sim_time_s == t_paused

    # 3. Step while paused
    step_res = client.post("/api/v1/simulation/step", json={"step_s": 2.5})
    assert step_res.status_code == 200
    assert mgr.sim_time_s == pytest.approx(t_paused + 2.5, abs=1e-3)
    assert _get_mgr_status(mgr) == SimulationStatus.PAUSED

    # 4. Resume running after step
    client.post("/api/v1/simulation/start")
    assert _get_mgr_status(mgr) == SimulationStatus.RUNNING
    time.sleep(0.08)
    assert mgr.sim_time_s > t_paused + 2.5

    # 5. Reset while running
    reset_res = client.post("/api/v1/simulation/reset")
    assert reset_res.status_code == 200
    assert _get_mgr_status(mgr) == SimulationStatus.STOPPED
    assert mgr.sim_time_s == 0.0
    assert _get_sim_task(mgr) is None

    # Multiple resets (idempotence)
    reset_res2 = client.post("/api/v1/simulation/reset")
    assert reset_res2.status_code == 200
    assert _get_mgr_status(mgr) == SimulationStatus.STOPPED
    assert mgr.sim_time_s == 0.0

    # 6. Step while stopped
    step_stopped = client.post("/api/v1/simulation/step", json={"step_s": 1.2})
    assert step_stopped.status_code == 200
    assert mgr.sim_time_s == pytest.approx(1.2, abs=1e-3)
    assert _get_mgr_status(mgr) == SimulationStatus.STOPPED

    # 7. Reconfigure scenario and verify state reinitialization
    new_cfg = {
        "scenario_name": "congested_tma_25_aircraft",
        "speed_multiplier": 3.0,
        "seed": 999,
    }
    cfg_res = client.post("/api/v1/simulation/config", json=new_cfg)
    assert cfg_res.status_code == 200
    assert cfg_res.json()["scenario_name"] == "congested_tma_25_aircraft"
    assert cfg_res.json()["speed_multiplier"] == 3.0
    assert _get_mgr_status(mgr) == SimulationStatus.STOPPED
    assert mgr.sim_time_s == 0.0


# ==============================================================================
# 2. Concurrent WebSocket Streaming Under Traffic Load Stress Tests
# ==============================================================================


@pytest.mark.tier1
def test_multi_client_concurrent_telemetry_streaming(client: TestClient) -> None:
    """Stress-test concurrent streaming across 4 simultaneous /ws/telemetry clients.

    Verifies broadcast fan-out, telemetry schema validity, snapshot request-response,
    and resilience against abrupt client disconnections without server degradation.
    """
    with (
        client.websocket_connect("/ws/telemetry") as ws1,
        client.websocket_connect("/ws/telemetry") as ws2,
        client.websocket_connect("/ws/telemetry") as ws3,
        client.websocket_connect("/ws/telemetry") as ws4,
    ):
        mgr = get_simulation_manager()
        assert len(mgr._telemetry_clients) == 4

        # Start autonomous simulation
        client.post("/api/v1/simulation/speed", json={"speed_multiplier": 2.0})
        client.post("/api/v1/simulation/start")

        # Let the loop advance and broadcast
        time.sleep(0.15)

        # All 4 clients should receive broadcasts
        for ws_idx, ws in enumerate([ws1, ws2, ws3, ws4], start=1):
            msg = ws.receive_json()
            assert msg["type"] == "telemetry", f"ws{ws_idx} expected type telemetry"
            assert "sim_time_s" in msg
            assert "tracks" in msg
            assert isinstance(msg["tracks"], list)
            assert msg["track_count"] == len(msg["tracks"])

            # Verify track field schema on available tracks
            for trk in msg["tracks"]:
                assert "icao_hex" in trk
                assert "state" in trk
                assert "mode_probability_turn" in trk
                assert "anomalies" in trk

        # Client 1 requests an on-demand snapshot
        ws1.send_text("snapshot")
        snap = ws1.receive_json()
        assert snap["type"] == "telemetry"
        assert "tracks" in snap
        assert snap["track_count"] == len(snap["tracks"])

    # All 4 clients exited context manager (disconnected)
    client.post("/api/v1/simulation/pause")
    assert len(mgr._telemetry_clients) == 0


@pytest.mark.tier1
def test_multi_client_concurrent_wire_streaming_mixed_formats(client: TestClient) -> None:
    """Stress-test concurrent wire streaming across AVR, Beast binary, and SBS clients.

    Verifies that each wire format subscriber receives properly formatted protocol packets:
    - AVR: ASCII hex lines (*...; or @...;)
    - Beast: Binary frames prefixed with 0x1A escape byte
    - SBS: BaseStation CSV records starting with MSG,
    """
    with (
        client.websocket_connect("/ws/wire?format=AVR") as ws_avr,
        client.websocket_connect("/ws/wire?format=BEAST") as ws_beast,
        client.websocket_connect("/ws/wire?format=SBS") as ws_sbs,
        client.websocket_connect("/ws/wire?format=avr") as ws_avr2,
    ):
        mgr = get_simulation_manager()
        assert len(mgr._wire_clients) == 4

        # Step simulation forward 2.0s to process squitter events
        client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        # AVR clients receive ASCII hex messages
        avr_line1 = ws_avr.receive_text()
        assert avr_line1.startswith(("*", "@")), f"Invalid AVR frame start: {avr_line1}"
        assert avr_line1.strip().endswith(";"), f"Invalid AVR frame end: {avr_line1}"

        avr_line2 = ws_avr2.receive_text()
        assert avr_line2.startswith(("*", "@")), f"Invalid case-insensitive AVR frame: {avr_line2}"

        # Beast client receives raw binary frames
        beast_bytes = ws_beast.receive_bytes()
        assert len(beast_bytes) >= 9, f"Beast frame too short: {len(beast_bytes)} bytes"
        assert beast_bytes[0] == 0x1A, f"Beast frame missing 0x1A escape prefix: {beast_bytes[0]:#x}"
        assert beast_bytes[1] in (0x31, 0x32, 0x33), f"Invalid Beast type byte: {beast_bytes[1]:#x}"

        # SBS client receives CSV lines
        sbs_line = ws_sbs.receive_text()
        assert sbs_line.startswith("MSG,"), f"SBS line does not start with MSG: {sbs_line}"
        fields = sbs_line.strip().split(",")
        assert len(fields) >= 11, f"SBS line has insufficient columns: {len(fields)}"


# ==============================================================================
# 3. High-Rate Wire Frame Injection Stress Tests
# ==============================================================================


@pytest.mark.tier1
def test_high_rate_burst_injection_mixed_wire_formats(client: TestClient) -> None:
    """Stress-test rapid burst injection of 55 frames across AVR, Beast, and SBS formats.

    Verifies live decoding, stateful CPR pairing, IMM filter coordination,
    and track retrieval across multiple simulated aircraft.
    """
    client.post("/api/v1/simulation/reset")

    # Aircraft 1 (AVR): 0x4840D6 (KLM1023) callsign + even/odd position at FL380
    avr_ident = serialize_avr_frame(encode_1090es_identification(0x4840D6, "KLM1023"))
    avr_pos_even = serialize_avr_frame(
        encode_1090es_airborne_position(0x4840D6, 38000, 52.257, 3.919, cpr_format=0)
    )
    avr_pos_odd = serialize_avr_frame(
        encode_1090es_airborne_position(0x4840D6, 38000, 52.265, 3.938, cpr_format=1)
    )

    # Aircraft 2 (BEAST Binary & Hex): 0x40621D (BAW456) ident + pos + vel
    beast_ident_bytes = serialize_beast_frame(
        "3",
        12_000_000,
        210,
        encode_1090es_identification(0x40621D, "BAW456"),
    )
    beast_pos_even_bytes = serialize_beast_frame(
        "3",
        12_000_000,
        210,
        encode_1090es_airborne_position(0x40621D, 38000, 52.257, 3.919, cpr_format=0),
    )
    beast_pos_odd_bytes = serialize_beast_frame(
        "3",
        12_000_000,
        210,
        encode_1090es_airborne_position(0x40621D, 38000, 52.265, 3.938, cpr_format=1),
    )
    beast_vel_bytes = serialize_beast_frame(
        "3",
        12_000_000,
        210,
        encode_1090es_airborne_velocity(0x40621D, v_ew_kt=150.0, v_ns_kt=250.0, vertical_rate_fpm=-800),
    )

    # Aircraft 3 (SBS): 0x334455 (AFR789)
    sbs_afr_callsign = serialize_sbs_message(
        SBSMessage(hex_ident="334455", callsign="AFR789")
    )
    sbs_afr_pos = serialize_sbs_message(
        SBSMessage(
            hex_ident="334455",
            altitude=32000,
            lat=52.3105,
            lon=4.7683,
            ground_speed=450.0,
            track=180.0,
            vertical_rate=-1200,
        )
    )

    # Aircraft 4 (SBS): 0xAABBCC (DLH101) climbing
    sbs_dlh_1 = serialize_sbs_message(
        SBSMessage(hex_ident="AABBCC", callsign="DLH101", altitude=5000, lat=52.1, lon=4.5)
    )
    sbs_dlh_2 = serialize_sbs_message(
        SBSMessage(hex_ident="AABBCC", altitude=8000, lat=52.15, lon=4.55, ground_speed=300.0, track=45.0)
    )

    # Perform burst injection of 55 requests in alternating format sequence
    injection_queue: list[tuple[str, str]] = [
        ("AVR", avr_ident),
        ("BEAST", beast_ident_bytes.hex()),
        ("SBS", sbs_afr_callsign),
        ("SBS", sbs_dlh_1),
        ("AVR", avr_pos_even),
        ("BEAST", beast_pos_even_bytes.hex()),
        ("SBS", sbs_afr_pos),
        ("SBS", sbs_dlh_2),
        ("AVR", avr_pos_odd),
        ("BEAST", beast_pos_odd_bytes.hex()),
        ("BEAST", beast_vel_bytes.hex()),
    ] * 5  # Total 55 injections

    for fmt, payload in injection_queue:
        res = client.post("/api/v1/inject/frame", json={"format": fmt, "raw_data": payload})
        assert res.status_code == 200, f"Injection failed for {fmt}: {res.text}"
        data = res.json()
        assert "icao_hex" in data
        assert len(data["icao_hex"]) == 6

    # Verify all tracks are present and accurately estimated
    tracks_res = client.get("/api/v1/tracks")
    assert tracks_res.status_code == 200
    tracks = tracks_res.json()
    assert len(tracks) >= 4

    track_dict = {t["icao_hex"]: t for t in tracks}
    assert "4840D6" in track_dict
    assert "40621D" in track_dict
    assert "334455" in track_dict
    assert "AABBCC" in track_dict

    # Verify Aircraft 1 (KLM1023)
    t1 = track_dict["4840D6"]
    assert t1["callsign"] == "KLM1023"
    assert t1["has_position"] is True
    assert t1["alt_baro_ft"] == 38000

    # Verify Aircraft 2 (BAW456)
    t2 = track_dict["40621D"]
    assert t2["callsign"] == "BAW456"
    assert t2["has_position"] is True
    assert t2["alt_baro_ft"] == 38000
    assert t2["groundspeed_kt"] is not None and t2["groundspeed_kt"] > 0

    # Verify Aircraft 3 (AFR789)
    t3 = track_dict["334455"]
    assert t3["callsign"] == "AFR789"
    assert t3["alt_baro_ft"] == 32000
    assert t3["lat"] == pytest.approx(52.3105, abs=1e-3)
    assert t3["lon"] == pytest.approx(4.7683, abs=1e-3)
    assert t3["groundspeed_kt"] == 450.0

    # Verify Aircraft 4 (DLH101) climbing
    t4 = track_dict["AABBCC"]
    assert t4["callsign"] == "DLH101"
    assert t4["alt_baro_ft"] == 8000

    # Verify individual track retrieval with prefix variations
    res_direct = client.get("/api/v1/tracks/40621D")
    assert res_direct.status_code == 200
    assert res_direct.json()["icao_hex"] == "40621D"

    res_lower = client.get("/api/v1/tracks/40621d")
    assert res_lower.status_code == 200
    assert res_lower.json()["icao_hex"] == "40621D"

    res_prefix = client.get("/api/v1/tracks/0x40621D")
    assert res_prefix.status_code == 200
    assert res_prefix.json()["icao_hex"] == "40621D"


@pytest.mark.tier1
def test_sbs_kinematic_updates_imm_filter_evolution(client: TestClient) -> None:
    """Empirically test SBS velocity, altitude, and turning updates on IMM filter state."""
    mgr = get_simulation_manager()
    assert mgr.engine is not None
    client.post("/api/v1/simulation/reset")

    icao_hex = "C0FFEE"
    # 1. Initial position fix
    sbs_pos = serialize_sbs_message(
        SBSMessage(
            hex_ident=icao_hex,
            altitude=15000,
            lat=52.0,
            lon=4.0,
            ground_speed=200.0,
            track=90.0,
        )
    )
    res1 = client.post("/api/v1/inject/frame", json={"format": "SBS", "raw_data": sbs_pos})
    assert res1.status_code == 200

    imm = mgr.engine._filters[0xC0FFEE]
    assert imm.last_update_time_s is not None

    # Step time forward by 5s
    client.post("/api/v1/simulation/step", json={"step_s": 5.0})

    # 2. Velocity & track turning update (turn right to track 180)
    sbs_turn = serialize_sbs_message(
        SBSMessage(
            hex_ident=icao_hex,
            ground_speed=220.0,
            track=180.0,
            vertical_rate=-1000,
        )
    )
    res2 = client.post("/api/v1/inject/frame", json={"format": "SBS", "raw_data": sbs_turn})
    assert res2.status_code == 200

    # IMM should have predicted forward and updated velocity
    assert imm.last_update_time_s == mgr.sim_time_s
    # Velocity East should be ~0, North should be negative (-220 kt)
    assert imm.x1[3] == pytest.approx(0.0, abs=10.0)  # ve
    assert imm.x1[4] < 0.0  # vn negative (heading south)

    # 3. Altitude update
    client.post("/api/v1/simulation/step", json={"step_s": 2.0})
    sbs_alt = serialize_sbs_message(
        SBSMessage(hex_ident=icao_hex, altitude=13000)
    )
    res3 = client.post("/api/v1/inject/frame", json={"format": "SBS", "raw_data": sbs_alt})
    assert res3.status_code == 200

    track = mgr.engine._tracks[0xC0FFEE]
    assert track.alt_baro_ft == 13000.0


# ==============================================================================
# 4. Malformed Frame Injection & Error Handling Stress Tests
# ==============================================================================


@pytest.mark.tier1
def test_malformed_wire_frame_injection_rejection_robustness(client: TestClient) -> None:
    """Stress-test adversarial malformed, truncated, and corrupt payloads across all wire formats.

    Verifies the server returns HTTP 400 Bad Request with descriptive details,
    never raises unhandled 500 exceptions, and remains fully functional afterwards.
    """
    adversarial_payloads: list[tuple[str, str, str]] = [
        # AVR malformations
        ("AVR", "", "empty AVR string"),
        ("AVR", "*;", "empty AVR payload delimiter only"),
        ("AVR", "*8D48;", "truncated AVR hex payload"),
        ("AVR", "*8D4840D6202CC371C32CE057609;", "odd-length AVR hex payload"),
        ("AVR", "*8D4840D6202CC371C32CE05760ZZ;", "non-hex characters in AVR"),
        ("AVR", "8D4840D6202CC371C32CE0576098;", "missing leading asterisk in AVR"),
        ("AVR", "*8D4840D6202CC371C32CE0576098", "missing trailing semicolon in AVR"),
        ("AVR", "@1234567890AB8D48;", "truncated AVR timestamped payload"),
        # Beast malformations
        ("BEAST", "", "empty Beast payload"),
        ("BEAST", "1A33", "truncated Beast header"),
        ("BEAST", "00010203040506070809", "Beast frame missing 0x1A start escape byte"),
        ("BEAST", "1A33000000000000C81A00", "invalid single 0x1A escape sequence in Beast body"),
        ("BEAST", "1A33000000000000C81122", "Beast payload invalid length (2 bytes instead of 7 or 14)"),
        ("BEAST", "1A33000000000000C8", "Beast payload empty (0 bytes instead of 7 or 14)"),
        ("BEAST", "NOT_A_HEX_STRING", "completely invalid Beast hex string"),
        # SBS malformations
        ("SBS", "", "empty SBS line"),
        ("SBS", "MSG,1", "severely incomplete SBS CSV"),
        ("SBS", "MSG,1,1,1,,1,,,,,,,,,,,,,,,,", "SBS missing hex_ident"),
        ("SBS", "MSG,1,1,1,INVALID_HEX,1,,,,,,,,,,,,,,,,", "SBS non-hex hex_ident"),
        ("SBS", "NOT_A_CSV_AT_ALL", "raw unformatted text in SBS"),
        # Unsupported / Unknown formats
        ("ASTERIX", "*8D4840D6202CC371C32CE0576098;", "unsupported ASTERIX format"),
        ("UAT", "00000000", "unsupported UAT direct format"),
        ("CUSTOM", "*8D4840D6202CC371C32CE0576098;", "custom undefined format"),
        ("", "*8D4840D6202CC371C32CE0576098;", "empty format string"),
    ]

    for fmt, payload, description in adversarial_payloads:
        res = client.post("/api/v1/inject/frame", json={"format": fmt, "raw_data": payload})
        assert (
            res.status_code == 400
        ), f"Expected HTTP 400 for {description} ({fmt}), got {res.status_code}: {res.text}"
        data = res.json()
        assert "detail" in data, f"Error response for {description} missing 'detail' field"

    # Crucial server health check: after enduring all 400 attacks, server must still accept valid frames
    valid_res = client.post(
        "/api/v1/inject/frame",
        json={"format": "AVR", "raw_data": "*8D4840D6202CC371C32CE0576098;"},
    )
    assert valid_res.status_code == 200
    assert valid_res.json()["icao_hex"] == "4840D6"


@pytest.mark.tier1
def test_rest_api_parameter_validation_and_not_found(client: TestClient) -> None:
    """Stress-test REST API parameter validation, 404 Not Found, and 422 Unprocessable Entity."""
    # 1. Invalid ICAO hex in /tracks/{icao_hex} -> 400
    res_bad_hex1 = client.get("/api/v1/tracks/NOT_HEX")
    assert res_bad_hex1.status_code == 400
    assert "Invalid ICAO hex" in res_bad_hex1.json()["detail"]

    res_bad_hex2 = client.get("/api/v1/tracks/ZZZZZZ")
    assert res_bad_hex2.status_code == 400

    # 2. Non-existent track in /tracks/{icao_hex} -> 404
    res_not_found = client.get("/api/v1/tracks/FFFFFF")
    assert res_not_found.status_code == 404
    assert "not found" in res_not_found.json()["detail"]

    # 3. Invalid speed multipliers in /simulation/speed -> 422
    res_zero_speed = client.post("/api/v1/simulation/speed", json={"speed_multiplier": 0.0})
    assert res_zero_speed.status_code == 422

    res_neg_speed = client.post("/api/v1/simulation/speed", json={"speed_multiplier": -2.5})
    assert res_neg_speed.status_code == 422

    # 4. Invalid step seconds in /simulation/step -> 422
    res_zero_step = client.post("/api/v1/simulation/step", json={"step_s": 0.0})
    assert res_zero_step.status_code == 422

    res_neg_step = client.post("/api/v1/simulation/step", json={"step_s": -1.0})
    assert res_neg_step.status_code == 422

    # 5. Invalid scenario configuration in /simulation/config -> 400
    res_bad_cfg = client.post(
        "/api/v1/simulation/config",
        json={"scenario_name": "non_existent_airspace_zone", "speed_multiplier": 1.0, "seed": 42},
    )
    assert res_bad_cfg.status_code == 400
    assert "Unknown scenario" in res_bad_cfg.json()["detail"]

    # Restore valid scenario configuration
    client.post(
        "/api/v1/simulation/config",
        json={"scenario_name": "clean_tma_10_aircraft", "speed_multiplier": 1.0, "seed": 42},
    )

    # 6. Malformed JSON schemas in /inject/frame -> 422
    res_empty_body = client.post("/api/v1/inject/frame", json={})
    assert res_empty_body.status_code == 422

    res_missing_data = client.post("/api/v1/inject/frame", json={"format": "AVR"})
    assert res_missing_data.status_code == 422


# ==============================================================================
# 5. Concurrent Autonomous Simulation, Burst Injection & Streaming Stress Test
# ==============================================================================


@pytest.mark.tier1
def test_interleaved_autonomous_sim_with_burst_injection_and_websocket_drain(
    client: TestClient,
) -> None:
    """Stress-test concurrent autonomous simulation loop ticking at 5x while processing burst injections.

    Both synthetic squitter events and live injected frames must be broadcast
    to connected telemetry and wire WebSockets without deadlock or frame corruption.
    """
    with (
        client.websocket_connect("/ws/telemetry") as ws_telemetry,
        client.websocket_connect("/ws/wire?format=AVR") as ws_avr,
    ):
        mgr = get_simulation_manager()

        # Configure and start autonomous simulation at 5x speed
        client.post("/api/v1/simulation/speed", json={"speed_multiplier": 5.0})
        client.post("/api/v1/simulation/start")
        assert _get_mgr_status(mgr) == SimulationStatus.RUNNING

        # While autonomous loop is running, inject 20 frames
        injected_icaos: list[str] = []
        for i in range(10):
            icao_int = 0x500000 + i
            icao_hex = f"{icao_int:06X}"
            injected_icaos.append(icao_hex)

            # Inject callsign
            ident_frame = serialize_avr_frame(
                encode_1090es_identification(icao_int, f"TEST{i:02d}")
            )
            res1 = client.post("/api/v1/inject/frame", json={"format": "AVR", "raw_data": ident_frame})
            assert res1.status_code == 200

            # Inject SBS position
            sbs_pos = serialize_sbs_message(
                SBSMessage(
                    hex_ident=icao_hex,
                    altitude=10000 + i * 500,
                    lat=52.0 + (i * 0.05),
                    lon=4.0 + (i * 0.05),
                    ground_speed=250.0,
                    track=120.0,
                )
            )
            res2 = client.post("/api/v1/inject/frame", json={"format": "SBS", "raw_data": sbs_pos})
            assert res2.status_code == 200

        # Drain messages from both WebSockets
        tel_msg = ws_telemetry.receive_json()
        assert tel_msg["type"] == "telemetry"
        assert len(tel_msg["tracks"]) > 0

        avr_line = ws_avr.receive_text()
        assert avr_line.startswith(("*", "@"))

        # Pause simulation
        client.post("/api/v1/simulation/pause")
        assert _get_mgr_status(mgr) == SimulationStatus.PAUSED

        # Verify all injected aircraft are tracked alongside scenario aircraft
        all_tracks = client.get("/api/v1/tracks").json()
        all_icaos = {t["icao_hex"] for t in all_tracks}
        for expected_hex in injected_icaos:
            assert expected_hex in all_icaos, f"Injected ICAO {expected_hex} missing from tracks"


# ==============================================================================
# 6. Graceful Shutdown & Cleanup Stress Tests
# ==============================================================================


@pytest.mark.tier1
@pytest.mark.asyncio
async def test_graceful_simulation_manager_shutdown() -> None:
    """Verify SimulationManager.shutdown closes WebSocket connections and halts tasks cleanly."""
    mgr = SimulationManager()
    mgr.start()
    assert _get_mgr_status(mgr) == SimulationStatus.RUNNING

    # Add mock WebSocket connections
    class MockWebSocket:
        def __init__(self) -> None:
            self.closed: bool = False
            self.close_code: int | None = None

        async def close(self, code: int = 1000, reason: str = "") -> None:
            self.closed = True
            self.close_code = code

    mock_tel = MockWebSocket()
    mock_wire = MockWebSocket()

    # Register into internal client sets (cast for duck-typing)
    mgr._telemetry_clients.add(mock_tel)  # type: ignore[arg-type]
    mgr._wire_clients[mock_wire] = "AVR"  # type: ignore[index]

    assert len(mgr._telemetry_clients) == 1
    assert len(mgr._wire_clients) == 1

    await mgr.shutdown()

    # Simulation must be paused, clients closed and collections cleared
    assert _get_mgr_status(mgr) == SimulationStatus.PAUSED
    assert mock_tel.closed is True
    assert mock_tel.close_code == 1000
    assert mock_wire.closed is True
    assert mock_wire.close_code == 1000
    assert len(mgr._telemetry_clients) == 0
    assert len(mgr._wire_clients) == 0


# ==============================================================================
# 7. Empirical Challenge Findings & Vulnerability Documentation
# ==============================================================================


@pytest.mark.tier1
def test_simulation_manager_configure_corrupts_state_on_invalid_scenario() -> None:
    """Document empirical finding: configure() mutates self.config before validating scenario.

    When an invalid scenario name is passed, ValueError is raised, but self.config remains
    mutated, preventing subsequent clean resets unless self.config is restored.
    """
    mgr = SimulationManager()
    initial_scenario = mgr.config.scenario_name

    with pytest.raises(ValueError, match="Unknown scenario"):
        mgr.configure({"scenario_name": "corrupt_scenario_name", "speed_multiplier": 1.0, "seed": 42})

    # Observe that mgr.config.scenario_name is now 'corrupt_scenario_name'
    assert mgr.config.scenario_name == "corrupt_scenario_name"

    # Subsequent reset fails due to unhandled ValueError in _init_simulation
    with pytest.raises(ValueError, match="Unknown scenario"):
        mgr.reset()

    # Recovery: setting a valid config allows reset to succeed
    mgr.config = SimulationConfig(scenario_name=initial_scenario)
    mgr.reset()
    assert _get_mgr_status(mgr) == SimulationStatus.STOPPED
