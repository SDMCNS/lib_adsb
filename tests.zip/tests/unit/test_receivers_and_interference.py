"""Unit tests for ReceiverSite, RF Interference physics, and Signal Reception Gating.

Authoritative reference: Requirements R4 & R5 and docs/04_ERROR_AND_ANOMALY_SIMULATION.md.
"""

from __future__ import annotations

import math

import pytest

from adsb.constants import FREQ_1090ES_HZ
from adsb.impairment.channel import (
    FadingModel,
    ReceiverSite,
    compute_fspl,
    compute_ppm_ber,
    compute_preamble_drop_prob,
    compute_slant_range,
)
from adsb.impairment.interference import (
    InterferenceEngine,
    InterferenceSource,
    ReceiverStatus,
    compute_aggregate_interference,
    compute_effective_noise_floor,
    compute_frame_drop_probability,
    compute_received_interference,
    compute_sinr,
    compute_spectral_overlap_factor,
)
from adsb.synthesis.scheduler import SquitterEvent


def test_receiver_site_attributes_and_serialization() -> None:
    """Verify ReceiverSite attributes, default sensitivity, and to/from_dict."""
    rx = ReceiverSite(
        lat_deg=52.3105,
        lon_deg=4.7683,
        alt_msl_m=25.0,
        rx_id="RX_TEST",
        name="Test Station",
        sensitivity_dbm=-86.0,
    )
    assert rx.sensitivity_dbm == -86.0
    assert rx.effective_alt_m == 25.0

    d = rx.to_dict()
    assert d["rx_id"] == "RX_TEST"
    assert d["sensitivity_dbm"] == -86.0
    assert d["antenna_gain_peak_dbi"] == 5.0
    assert d["lat"] == pytest.approx(52.3105)

    rx_restored = ReceiverSite.from_dict(d)
    assert rx_restored.rx_id == "RX_TEST"
    assert rx_restored.sensitivity_dbm == -86.0
    assert rx_restored.effective_alt_m == 25.0


def test_squitter_event_coordinates() -> None:
    """Verify SquitterEvent carries 3D spatial coordinates."""
    ev = SquitterEvent(
        timestamp_s=10.0,
        raw_bytes=b"\x8d\x48\x40\xd6\x20\x2c\xc3\x71\xc3\x2c\xe0\x57\x60\x98",
        icao24=0x4840D6,
        tx_lat_deg=52.3,
        tx_lon_deg=4.7,
        tx_alt_m=3000.0,
    )
    assert ev.tx_lat_deg == pytest.approx(52.3)
    assert ev.tx_lon_deg == pytest.approx(4.7)
    assert ev.tx_alt_m == pytest.approx(3000.0)
    assert ev.tx_lat == pytest.approx(52.3)
    assert ev.tx_lon == pytest.approx(4.7)


def test_fspl_and_distance_precision() -> None:
    """Verify FSPL calculations match theoretical values for 1090 MHz."""
    # 1 km FSPL: 20*log10(1000) + 20*log10(1.09e9) - 147.5522 = 60 + 180.7485 - 147.5522 = 93.1963 dB
    fspl_1km = compute_fspl(1000.0, FREQ_1090ES_HZ)
    assert fspl_1km == pytest.approx(93.1963, abs=0.05)

    # 10 km FSPL: 93.1963 + 20 dB = 113.1963 dB
    fspl_10km = compute_fspl(10000.0, FREQ_1090ES_HZ)
    assert fspl_10km == pytest.approx(113.1963, abs=0.05)

    # Distance between Amsterdam Schiphol and Rotterdam Airport (~45.1 km)
    d = compute_slant_range(52.3105, 4.7683, 0.0, 51.9569, 4.4447, 10.0)
    assert 44000.0 < d < 46000.0


def test_spectral_overlap_filtering() -> None:
    """Verify bandwidth overlap factor for matched, wideband, and out-of-band jammers."""
    # 2.0 MHz jammer at 1090 MHz on 2.0 MHz receiver -> 100% overlap
    eta_matched = compute_spectral_overlap_factor(
        f_tx_hz=FREQ_1090ES_HZ, bw_tx_mhz=2.0, f_rx_hz=FREQ_1090ES_HZ, bw_rx_mhz=2.0
    )
    assert eta_matched == pytest.approx(1.0)

    # 20.0 MHz barrage jammer at 1090 MHz on 2.0 MHz receiver -> 10% overlap (-10 dB)
    eta_wide = compute_spectral_overlap_factor(
        f_tx_hz=FREQ_1090ES_HZ, bw_tx_mhz=20.0, f_rx_hz=FREQ_1090ES_HZ, bw_rx_mhz=2.0
    )
    assert eta_wide == pytest.approx(0.10)

    # 978 MHz UAT jammer on 1090 MHz receiver -> 0% overlap
    eta_oob = compute_spectral_overlap_factor(
        f_tx_hz=978.0e6, bw_tx_mhz=2.0, f_rx_hz=FREQ_1090ES_HZ, bw_rx_mhz=2.0
    )
    assert eta_oob == pytest.approx(0.0)


def test_noise_floor_elevation_analytical() -> None:
    """Verify effective noise floor calculation when jammer power equals thermal noise."""
    n0_dbm = -90.0
    # Single jammer delivering exactly -90.0 dBm
    # N_eff = 10*log10(10^-9 + 10^-9) = -90 + 3.0103 = -86.9897 dBm
    n_eff = compute_effective_noise_floor(n0_dbm, -90.0)
    assert n_eff == pytest.approx(-86.9897, abs=0.01)
    elevation = n_eff - n0_dbm
    assert elevation == pytest.approx(3.0103, abs=0.01)


def test_multiple_jammers_noncoherent_sum() -> None:
    """Verify non-coherent power addition of multiple active jammers."""
    rx = ReceiverSite(
        lat_deg=52.3105,
        lon_deg=4.7683,
        alt_msl_m=10.0,
        noise_floor_dbm=-90.0,
        antenna_gain_peak_dbi=5.0,
    )

    # Place two active jammers calibrated to same location
    j1 = InterferenceSource(
        source_id="JAM_1",
        lat_deg=52.3200,
        lon_deg=4.7683,
        tx_power_dbm=40.0,
        is_active=True,
    )
    j2 = InterferenceSource(
        source_id="JAM_2",
        lat_deg=52.3200,
        lon_deg=4.7683,
        tx_power_dbm=40.0,
        is_active=True,
    )

    p1 = compute_received_interference(j1, rx)
    p2 = compute_received_interference(j2, rx)
    assert p1 == pytest.approx(p2, abs=0.1)

    p_agg = compute_aggregate_interference([j1, j2], rx)
    # Doubling power increases received power by 3.01 dB
    assert p_agg == pytest.approx(p1 + 3.0103, abs=0.05)

    # Inactivating one jammer returns power to single jammer
    j2_off = j2.with_active(False)
    p_agg_single = compute_aggregate_interference([j1, j2_off], rx)
    assert p_agg_single == pytest.approx(p1, abs=0.05)


def test_degraded_sinr_ber_and_drop_probability() -> None:
    """Verify SINR, 2-PPM BER, and composite packet drop probability under jamming."""
    # Strong signal under clean channel
    rx_power = -70.0  # dBm
    n0 = -90.0        # dBm
    sinr_clean = compute_sinr(rx_power, n0)
    assert sinr_clean == 20.0
    ber_clean = compute_ppm_ber(sinr_clean, FadingModel.AWGN)
    assert ber_clean < 1e-10
    drop_clean = compute_frame_drop_probability(sinr_clean)
    assert drop_clean < 0.001

    # Severe jamming: noise floor elevated to -70.0 dBm -> SINR = 0 dB
    n_jammed = -70.0
    sinr_jammed = compute_sinr(rx_power, n_jammed)
    assert sinr_jammed == 0.0
    ber_jammed = compute_ppm_ber(sinr_jammed, FadingModel.AWGN)
    assert ber_jammed == pytest.approx(0.5 * math.exp(-1.0 / 2.0), abs=0.01)  # ~0.303
    p_preamble_drop = compute_preamble_drop_prob(sinr_jammed, threshold_snr_db=6.0)
    assert p_preamble_drop > 0.98
    drop_jammed = compute_frame_drop_probability(sinr_jammed)
    assert drop_jammed == pytest.approx(1.0, abs=0.001)


def test_burnthrough_capture_effect() -> None:
    """Verify close aircraft signal burns through moderate interference."""
    # Close aircraft with -45 dBm received power in presence of -70 dBm noise floor
    rx_power = -45.0
    n_eff = -70.0
    sinr = compute_sinr(rx_power, n_eff)
    assert sinr == 25.0
    drop_prob = compute_frame_drop_probability(sinr)
    assert drop_prob < 1e-4


def test_receiver_status_metrics_accumulation() -> None:
    """Verify live metrics tracking in ReceiverStatus."""
    stat = ReceiverStatus(
        rx_id="RX_TEST",
        name="Test",
        lat_deg=52.0,
        lon_deg=4.0,
        alt_msl_m=10.0,
    )
    # 80 successful frames
    for i in range(80):
        stat.record_reception(sinr_db=20.0, ber=1e-6, is_dropped=False, timestamp_s=float(i))
    # 20 dropped frames
    for i in range(80, 100):
        stat.record_reception(sinr_db=2.0, ber=0.1, is_dropped=True, timestamp_s=float(i))

    assert stat.total_frames_received == 80
    assert stat.total_frames_dropped == 20
    assert stat.packet_loss_rate_pct == pytest.approx(20.0)
    assert stat.current_sinr_db == 2.0

    d = stat.to_dict()
    assert d["total_frames_received"] == 80
    assert d["total_frames_dropped"] == 20
    assert d["packet_loss_rate_pct"] == 20.0


def test_interference_engine_source_management() -> None:
    """Verify InterferenceEngine source CRUD and dominant jammer identification."""
    engine = InterferenceEngine()
    j1 = InterferenceSource(
        source_id="JAM_WEAK",
        lat_deg=52.35,
        lon_deg=4.76,
        tx_power_dbm=20.0,
    )
    j2 = InterferenceSource(
        source_id="JAM_STRONG",
        lat_deg=52.32,
        lon_deg=4.76,
        tx_power_dbm=50.0,
    )
    engine.add_source(j1)
    engine.add_source(j2)
    assert len(engine.list_sources()) == 2

    rx = ReceiverSite(lat_deg=52.31, lon_deg=4.76, alt_msl_m=10.0)
    dom_id, dom_pwr = engine.find_dominant_jammer(rx)
    assert dom_id == "JAM_STRONG"
    assert dom_pwr is not None and dom_pwr > -65.0

    # Toggle off strong jammer
    updated = engine.toggle_source("JAM_STRONG")
    assert updated is not None and not updated.is_active

    dom_id2, _ = engine.find_dominant_jammer(rx)
    assert dom_id2 == "JAM_WEAK"

    # Remove jammer
    assert engine.remove_source("JAM_WEAK") is True
    assert engine.get_source("JAM_WEAK") is None


def test_signal_reception_gating_logic() -> None:
    """Verify SimulationManager._check_signal_reception edge cases."""
    from adsb.api.manager import SimulationManager
    sm = SimulationManager()
    sm.reset()

    # 1. Event without coords (mock event) bypasses gating
    mock_ev = SquitterEvent(timestamp_s=1.0, raw_bytes=b"\x00" * 14, icao24=0x123456)
    assert sm._check_signal_reception(mock_ev, 1.0) is True

    # 2. Within radio horizon and sensitivity: aircraft at 10,000m, 50 km from Schiphol
    in_range_ev = SquitterEvent(
        timestamp_s=1.0,
        raw_bytes=b"\x8d\x48\x40\xd6\x20\x2c\xc3\x71\xc3\x2c\xe0\x57\x60\x98",
        icao24=0x4840D6,
        tx_lat_deg=52.4,
        tx_lon_deg=4.8,
        tx_alt_m=10000.0,
    )
    assert sm._check_signal_reception(in_range_ev, 1.0) is True

    # 3. Beyond radio horizon: aircraft at low altitude 100m, far away
    far_ev = SquitterEvent(
        timestamp_s=1.0,
        raw_bytes=b"\x8d\x48\x40\xd6\x20\x2c\xc3\x71\xc3\x2c\xe0\x57\x60\x98",
        icao24=0x4840D6,
        tx_lat_deg=46.0,
        tx_lon_deg=4.0,
        tx_alt_m=100.0,
    )
    assert sm._check_signal_reception(far_ev, 1.0) is False

    # 4. Empty receivers drops spatial signals
    sm._receivers.clear()
    assert sm._check_signal_reception(in_range_ev, 1.0) is False
    # But mock events still bypass
    assert sm._check_signal_reception(mock_ev, 1.0) is True
