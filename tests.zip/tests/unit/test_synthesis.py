"""Comprehensive unit tests for adsb.synthesis package.

Verifies:
- Aircraft performance profiles & lookup registry
- Dual-layer ISA atmosphere, altimetry, airspeed conversions, and 3D wind triangle
- Rhumb line navigation, fly-by turn lead distance, and holding pattern entries
- 4D trajectory integration, VNAV state machine, and factory flight generators
- DO-260B squitter scheduler, timing jitter, CPR alternation, and multi-aircraft scenarios
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from adsb.constants import (
    EARTH_MEAN_RADIUS_M,
    FEET_TO_METERS,
    GAMMA_AIR,
    GAS_CONSTANT_AIR,
    ISA_P0_PA,
    ISA_RHO0_KGPM3,
    ISA_T0_K,
    KNOTS_TO_MPS,
)
from adsb.protocol.modes import decode_mode_s
from adsb.synthesis import (
    P_TROPOPAUSE_PA,
    T_TROPOPAUSE_K,
    TROPOPAUSE_ALT_M,
    AircraftPerformanceProfile,
    AircraftTruthState,
    AtmosphereModel,
    AtmosphereState,
    FlightPhase,
    FlightPlan,
    GeoPoint,
    HoldingEntryType,
    HoldingPattern,
    MultiAircraftScheduler,
    SquitterScheduler,
    TurnDirection,
    WakeVortexCategory,
    Waypoint,
    altitude_to_indicated_altitude_ft,
    cas_to_tas,
    classify_holding_entry,
    compute_atmosphere,
    compute_flyby_lead_distance,
    compute_top_of_descent_distance,
    crossover_altitude_m,
    eas_to_tas,
    geo_minus_baro_ft,
    geometric_to_geopotential_m,
    geopotential_to_geometric_m,
    get_aircraft_profile,
    groundspeed_vector_3d,
    has_aircraft_profile,
    isa_density_kgpm3,
    isa_pressure_pa,
    isa_speed_of_sound_mps,
    isa_temperature_k,
    list_aircraft_profiles,
    load_scenario,
    mach_to_tas,
    pressure_to_pressure_altitude_ft,
    pressure_to_pressure_altitude_m,
    register_aircraft_profile,
    rhumb_destination_point,
    rhumb_distance_and_bearing,
    solve_wind_triangle_heading,
    solve_wind_triangle_track,
    step_kinematics,
    tas_to_cas,
    tas_to_eas,
    tas_to_mach,
    wind_components_uv,
)
from adsb.synthesis.trajectory import (
    generate_maneuvering_flight,
    generate_simple_climb_trajectory,
    generate_straight_flight,
)

# ==============================================================================
# 1. Performance Profiles & Registry Tests
# ==============================================================================


class TestPerformanceProfiles:
    """Tests for aircraft performance profiles and registry."""

    def test_builtin_reference_profiles_present(self) -> None:
        """Verify all 9 reference types plus aliases are present and valid."""
        required_types = [
            "B738",
            "A320",
            "B77W",
            "C172",
            "B350",
            "R44",
            "F16",
            "CONC",
            "GLID",
            "E75L",
            "DH8D",
            "SR22",
            "EC35",
        ]
        profiles = list_aircraft_profiles()
        for type_code in required_types:
            assert type_code in profiles
            assert has_aircraft_profile(type_code)
            profile = get_aircraft_profile(type_code)
            assert profile.type_code == type_code
            assert profile.service_ceiling_ft > 0.0
            assert profile.v_cruise_tas_kt > 0.0
            assert profile.max_bank_angle_deg > 0.0

    def test_case_insensitive_lookup_and_stripping(self) -> None:
        """Verify profile lookup handles lowercase and whitespace."""
        p1 = get_aircraft_profile("b738")
        p2 = get_aircraft_profile(" B738  ")
        assert p1.type_code == "B738"
        assert p2.type_code == "B738"

    def test_unknown_profile_raises_key_error(self) -> None:
        """Verify querying an unknown aircraft type raises KeyError."""
        with pytest.raises(KeyError, match="Unknown aircraft type 'UNKNOWN'"):
            get_aircraft_profile("UNKNOWN")

    def test_custom_profile_registration(self) -> None:
        """Verify custom aircraft profile registration and query."""
        custom = AircraftPerformanceProfile(
            type_code="TESTJET",
            category=WakeVortexCategory.LIGHT,
            v_taxi_kt=10.0,
            v_rotate_ias_kt=100.0,
            v_initial_climb_ias_kt=150.0,
            v_climb_ias_kt=200.0,
            mach_climb=0.6,
            mach_cruise=0.7,
            v_cruise_tas_kt=400.0,
            mach_descent=0.6,
            v_descent_ias_kt=200.0,
            v_approach_ias_kt=110.0,
            service_ceiling_ft=30000.0,
            initial_climb_fpm=2000.0,
            mid_climb_fpm=1500.0,
            high_climb_fpm=1000.0,
            normal_descent_fpm=-1500.0,
            approach_descent_fpm=-600.0,
            takeoff_accel_mps2=2.0,
            landing_decel_mps2=-2.0,
            enroute_accel_mps2=0.5,
            max_bank_angle_deg=25.0,
        )
        register_aircraft_profile(custom)
        assert has_aircraft_profile("TESTJET")
        retrieved = get_aircraft_profile("TESTJET")
        assert retrieved.type_code == "TESTJET"


# ==============================================================================
# 2. Dual-Layer ISA Atmosphere Tests
# ==============================================================================


class TestAtmospherePhysics:
    """Tests for standard atmosphere equations and altimetry."""

    def test_isa_sea_level_baseline(self) -> None:
        """Verify sea-level standard atmosphere constants."""
        state = compute_atmosphere(0.0)
        assert math.isclose(state.temperature_k, ISA_T0_K, rel_tol=1e-5)
        assert math.isclose(state.pressure_pa, ISA_P0_PA, rel_tol=1e-5)
        assert math.isclose(state.density_kgpm3, ISA_RHO0_KGPM3, rel_tol=1e-3)
        expected_sos = math.sqrt(GAMMA_AIR * GAS_CONSTANT_AIR * ISA_T0_K)
        assert math.isclose(state.speed_of_sound_mps, expected_sos, rel_tol=1e-5)

    def test_tropopause_boundary_continuity(self) -> None:
        """Verify smooth continuity of temperature and pressure across 11,000m."""
        eps = 1e-2
        p_below = isa_pressure_pa(TROPOPAUSE_ALT_M - eps)
        p_at = isa_pressure_pa(TROPOPAUSE_ALT_M)
        p_above = isa_pressure_pa(TROPOPAUSE_ALT_M + eps)

        assert math.isclose(p_below, p_at, rel_tol=1e-4)
        assert math.isclose(p_at, p_above, rel_tol=1e-4)
        assert math.isclose(p_at, P_TROPOPAUSE_PA, rel_tol=1e-4)

        t_at = isa_temperature_k(TROPOPAUSE_ALT_M)
        assert math.isclose(t_at, T_TROPOPAUSE_K, rel_tol=1e-5)

    def test_stratosphere_isothermal_decay(self) -> None:
        """Verify isothermal temperature and exponential pressure decay in stratosphere."""
        t_15k = isa_temperature_k(15000.0)
        t_20k = isa_temperature_k(20000.0)
        assert math.isclose(t_15k, T_TROPOPAUSE_K, rel_tol=1e-5)
        assert math.isclose(t_20k, T_TROPOPAUSE_K, rel_tol=1e-5)

        p_15k = isa_pressure_pa(15000.0)
        p_20k = isa_pressure_pa(20000.0)
        assert p_20k < p_15k < P_TROPOPAUSE_PA

    def test_non_standard_delta_isa_and_qnh(self) -> None:
        """Verify temperature delta and QNH affect ambient parameters."""
        t_hot = isa_temperature_k(1000.0, delta_isa_k=15.0)
        t_std = isa_temperature_k(1000.0, delta_isa_k=0.0)
        assert math.isclose(t_hot - t_std, 15.0, abs_tol=1e-5)

        p_high = isa_pressure_pa(0.0, qnh_hpa=1030.0)
        assert math.isclose(p_high, 103000.0, abs_tol=1e-2)

    def test_geopotential_geometric_roundtrip(self) -> None:
        """Verify geopotential and geometric altitude round-trip."""
        for h in [0.0, 1000.0, 10000.0, 20000.0]:
            h_geop = geometric_to_geopotential_m(h)
            h_recovered = geopotential_to_geometric_m(h_geop)
            assert math.isclose(h, h_recovered, abs_tol=1e-6)

    def test_pressure_to_pressure_altitude_roundtrip(self) -> None:
        """Verify pressure to pressure altitude inversion round-trip."""
        for alt_m in [0.0, 3000.0, 11000.0, 15000.0]:
            p = isa_pressure_pa(alt_m)
            recovered_alt = pressure_to_pressure_altitude_m(p)
            assert math.isclose(alt_m, recovered_alt, abs_tol=1e-2)

    def test_altitude_to_indicated_altitude_qnh(self) -> None:
        """Verify indicated altitude equals MSL altitude when QNH is set to sea-level pressure."""
        h_ind_ft = altitude_to_indicated_altitude_ft(3048.0, qnh_hpa=1013.25)
        assert math.isclose(h_ind_ft, 10000.0, abs_tol=1.0)

    def test_geo_minus_baro_difference(self) -> None:
        """Verify geo minus baro delta calculation."""
        diff = geo_minus_baro_ft(alt_hae_m=3048.0, alt_baro_ft=10000.0)
        assert math.isclose(diff, 0.0, abs_tol=1.0)

    def test_atmosphere_model_and_standalone_helpers(self) -> None:
        """Verify AtmosphereModel class and density/speed_of_sound helper functions."""
        model = AtmosphereModel(delta_isa_k=0.0, qnh_hpa=1013.25)
        state = model.evaluate(5000.0)
        assert isinstance(state, AtmosphereState)
        assert math.isclose(state.pressure_altitude_m, 5000.0, abs_tol=1e-2)
        assert math.isclose(state.pressure_altitude_ft, 5000.0 / FEET_TO_METERS, abs_tol=1.0)

        rho = isa_density_kgpm3(5000.0)
        assert math.isclose(rho, state.density_kgpm3, rel_tol=1e-5)

        sos = isa_speed_of_sound_mps(5000.0)
        assert math.isclose(sos, state.speed_of_sound_mps, rel_tol=1e-5)

        p = isa_pressure_pa(5000.0)
        alt_ft = pressure_to_pressure_altitude_ft(p)
        assert math.isclose(alt_ft, 5000.0 / FEET_TO_METERS, abs_tol=1.0)


# ==============================================================================
# 3. Airspeed Conversions & 3D Wind Triangle Tests
# ==============================================================================


class TestAirspeedAndWindTriangle:
    """Tests for CAS, TAS, Mach conversions and wind triangle equations."""

    def test_mach_tas_roundtrip(self) -> None:
        """Verify Mach and TAS round-trip conversion."""
        alt_m = 9000.0
        tas = 230.0  # m/s
        mach = tas_to_mach(tas, alt_m)
        recovered_tas = mach_to_tas(mach, alt_m)
        assert math.isclose(tas, recovered_tas, abs_tol=1e-5)

    def test_eas_tas_roundtrip(self) -> None:
        """Verify EAS and TAS round-trip conversion."""
        alt_m = 5000.0
        tas = 200.0
        eas = tas_to_eas(tas, alt_m)
        recovered_tas = eas_to_tas(eas, alt_m)
        assert math.isclose(tas, recovered_tas, abs_tol=1e-5)

    def test_compressible_cas_tas_roundtrip(self) -> None:
        """Verify Saint-Venant CAS and TAS round-trip conversion."""
        alt_m = 7000.0
        cas = 130.0  # m/s (~250 kt)
        tas = cas_to_tas(cas, alt_m)
        assert tas > cas  # TAS is higher than CAS at altitude
        recovered_cas = tas_to_cas(tas, alt_m)
        assert math.isclose(cas, recovered_cas, abs_tol=1e-2)

    def test_crossover_altitude_b738(self) -> None:
        """Verify crossover altitude for 290 kt CAS and Mach 0.78."""
        cas_mps = 290.0 * KNOTS_TO_MPS
        mach = 0.78
        cross_alt_m = crossover_altitude_m(cas_mps, mach)
        cross_alt_ft = cross_alt_m / FEET_TO_METERS
        # For B738, crossover is typically FL280 - FL310
        assert 28000.0 <= cross_alt_ft <= 31500.0

    def test_wind_components_uv(self) -> None:
        """Verify meteorological wind conversion to vector components."""
        # Wind FROM North (360 deg) at 10 m/s -> blows South (w_north = -10, w_east = 0)
        we, wn = wind_components_uv(10.0, 360.0)
        assert math.isclose(we, 0.0, abs_tol=1e-5)
        assert math.isclose(wn, -10.0, abs_tol=1e-5)

        # Wind FROM East (90 deg) at 10 m/s -> blows West (w_east = -10, w_north = 0)
        we2, wn2 = wind_components_uv(10.0, 90.0)
        assert math.isclose(we2, -10.0, abs_tol=1e-5)
        assert math.isclose(wn2, 0.0, abs_tol=1e-5)

    def test_wind_triangle_zero_wind(self) -> None:
        """Verify wind triangle with zero wind."""
        hdg, gs, wca = solve_wind_triangle_heading(track_deg=45.0, tas_mps=200.0, wind_speed_mps=0.0, wind_dir_from_deg=0.0)
        assert math.isclose(hdg, 45.0, abs_tol=1e-5)
        assert math.isclose(gs, 200.0, abs_tol=1e-5)
        assert math.isclose(wca, 0.0, abs_tol=1e-5)

    def test_wind_triangle_headwind_and_tailwind(self) -> None:
        """Verify headwind and tailwind groundspeeds."""
        # Flying North (track 0), wind FROM North (headwind 20 m/s)
        _, gs_head, _ = solve_wind_triangle_heading(0.0, 200.0, 20.0, 360.0)
        assert math.isclose(gs_head, 180.0, abs_tol=1e-4)

        # Flying North (track 0), wind FROM South (tailwind 20 m/s)
        _, gs_tail, _ = solve_wind_triangle_heading(0.0, 200.0, 20.0, 180.0)
        assert math.isclose(gs_tail, 220.0, abs_tol=1e-4)

    def test_wind_triangle_crosswind_mutual_inversion(self) -> None:
        """Verify heading solution and track solution invert each other mutually."""
        desired_track = 60.0
        tas = 220.0
        w_speed = 30.0
        w_dir = 270.0  # Westerly wind

        hdg, gs, wca = solve_wind_triangle_heading(desired_track, tas, w_speed, w_dir)
        trk_recov, gs_recov, drift = solve_wind_triangle_track(hdg, tas, w_speed, w_dir)

        assert math.isclose(trk_recov, desired_track, abs_tol=1e-4)
        assert math.isclose(gs_recov, gs, abs_tol=1e-4)
        assert math.isclose(drift, wca, abs_tol=1e-4)

    def test_excessive_crosswind_raises_value_error(self) -> None:
        """Verify crosswind exceeding TAS raises ValueError."""
        with pytest.raises(ValueError, match="cannot maintain track"):
            solve_wind_triangle_heading(track_deg=0.0, tas_mps=50.0, wind_speed_mps=60.0, wind_dir_from_deg=90.0)

    def test_groundspeed_vector_3d(self) -> None:
        """Verify 3D ground velocity vector components."""
        ve, vn, vu = groundspeed_vector_3d(heading_deg=90.0, tas_mps=100.0, vr_mps=5.0, wind_speed_mps=10.0, wind_dir_from_deg=360.0, w_up_mps=1.0)
        assert math.isclose(ve, 100.0, abs_tol=1e-4)
        assert math.isclose(vn, -10.0, abs_tol=1e-4)
        assert math.isclose(vu, 6.0, abs_tol=1e-4)


# ==============================================================================
# 4. Navigation, LNAV, and Holding Patterns
# ==============================================================================


class TestNavigationLNAV:
    """Tests for Rhumb line, fly-by turn lead, and holding pattern classifier."""

    def test_rhumb_line_eastward(self) -> None:
        """Verify Rhumb line constant bearing due East along parallel."""
        dist_m, bearing = rhumb_distance_and_bearing(lat1_deg=52.0, lon1_deg=4.0, lat2_deg=52.0, lon2_deg=5.0)
        assert math.isclose(bearing, 90.0, abs_tol=1e-4)
        # Expected distance along 52N parallel for 1 deg lon
        expected_dist = EARTH_MEAN_RADIUS_M * math.radians(1.0) * math.cos(math.radians(52.0))
        assert math.isclose(dist_m, expected_dist, rel_tol=1e-4)

    def test_rhumb_destination_point(self) -> None:
        """Verify Rhumb destination point along known course."""
        lat2, lon2 = rhumb_destination_point(52.0, 4.0, 10000.0, 90.0)
        assert math.isclose(lat2, 52.0, abs_tol=1e-4)
        assert lon2 > 4.0

    def test_compute_flyby_lead_distance_standard_turn(self) -> None:
        """Verify fly-by turn lead distance calculation."""
        # 250 kt groundspeed (~128.6 m/s) with 90-degree turn
        gs_mps = 250.0 * KNOTS_TO_MPS
        d_lead, r_turn, bank = compute_flyby_lead_distance(
            inbound_track_deg=0.0,
            outbound_track_deg=90.0,
            groundspeed_mps=gs_mps,
            max_bank_angle_deg=25.0,
            max_roll_rate_dps=5.0,
        )
        assert 3500.0 <= r_turn <= 4500.0
        assert 3500.0 <= d_lead <= 5000.0
        assert bank <= 25.0

    def test_compute_flyby_lead_distance_clamp_leg_length(self) -> None:
        """Verify lead distance is clamped to at most 50% of leg length."""
        gs_mps = 250.0 * KNOTS_TO_MPS
        d_lead, _, _ = compute_flyby_lead_distance(
            inbound_track_deg=0.0,
            outbound_track_deg=90.0,
            groundspeed_mps=gs_mps,
            leg_length_m=4000.0,
        )
        assert d_lead <= 2000.0

    def test_classify_holding_entry_standard_right(self) -> None:
        """Verify standard right-hand holding entry classification."""
        inbound = 90.0  # Inbound track to fix is 090 (reciprocal 270)
        # Approach from 200 -> relative 200 - 270 + 360 = 290 -> TEARDROP
        assert classify_holding_entry(200.0, inbound, TurnDirection.RIGHT) == HoldingEntryType.TEARDROP
        # Approach from 000 -> relative 0 - 270 + 360 = 90 -> PARALLEL
        assert classify_holding_entry(0.0, inbound, TurnDirection.RIGHT) == HoldingEntryType.PARALLEL
        # Approach from 090 -> relative 90 - 270 + 360 = 180 -> DIRECT
        assert classify_holding_entry(90.0, inbound, TurnDirection.RIGHT) == HoldingEntryType.DIRECT

    def test_classify_holding_entry_left_hand(self) -> None:
        """Verify non-standard left-hand holding entry classification."""
        inbound = 90.0
        # Approach from 090 -> DIRECT
        assert classify_holding_entry(90.0, inbound, TurnDirection.LEFT) == HoldingEntryType.DIRECT

    def test_navigation_data_models(self) -> None:
        """Verify GeoPoint, Waypoint, HoldingPattern, and FlightPlan data models."""
        pt1 = GeoPoint(lat_deg=52.3, lon_deg=4.7, alt_msl_m=10.0)
        pt2 = GeoPoint(lat_deg=51.5, lon_deg=-0.1, alt_msl_m=20.0)
        hp = HoldingPattern(
            fix_name="SPL",
            fix_lat_deg=52.3,
            fix_lon_deg=4.7,
            inbound_track_deg=90.0,
            turn_direction=TurnDirection.RIGHT,
        )
        wp = Waypoint(
            name="PAM",
            lat_deg=52.3,
            lon_deg=4.7,
            alt_target_ft=10000.0,
            holding_pattern=hp,
        )
        assert wp.get_target_alt_ft() == 10000.0

        fp = FlightPlan(
            icao_hex="4840D6",
            callsign="KLM1023",
            squawk="1200",
            aircraft_type="B738",
            origin=pt1,
            destination=pt2,
            departure_time_s=0.0,
            cruise_alt_ft=36000.0,
            waypoints=[wp],
        )
        assert fp.callsign == "KLM1023"
        assert len(fp.waypoints) == 1


# ==============================================================================
# 5. Trajectory & Kinematic Generators Tests
# ==============================================================================


class TestTrajectoryGenerators:
    """Tests for continuous trajectory generators and state vectors."""

    def test_compute_top_of_descent_distance(self) -> None:
        """Verify Top of Descent distance calculation from FL350 to sea level."""
        cruise_alt_m = 35000.0 * FEET_TO_METERS
        dest_alt_m = 0.0
        tod_m = compute_top_of_descent_distance(cruise_alt_m, dest_alt_m)
        # 32,000 ft drop at 318 ft/NM = ~100.6 NM + 10 NM decel = ~110.6 NM (~205 km)
        assert 190000.0 <= tod_m <= 220000.0

    def test_generate_simple_climb_trajectory(self, deterministic_rng: np.random.Generator) -> None:
        """Verify generate_simple_climb_trajectory produces valid climb kinematics."""
        b738 = get_aircraft_profile("B738")
        states = generate_simple_climb_trajectory(
            profile=b738,
            origin_lat=52.3105,
            origin_lon=4.7683,
            target_alt_ft=10000.0,
            duration_s=60.0,
            dt_s=1.0,
            rng=deterministic_rng,
        )
        assert len(states) >= 60
        assert states[0].timestamp_s == 0.0
        assert states[-1].timestamp_s == 60.0
        assert states[-1].alt_baro_ft > states[0].alt_baro_ft
        assert states[0].on_ground is False
        assert states[0].callsign == "KLM1023"

    def test_generate_straight_flight_equatorial_crossing(self, deterministic_rng: np.random.Generator) -> None:
        """Verify straight flight crosses the equator with correct signs."""
        states = generate_straight_flight(
            start_lat=-0.1,
            start_lon=10.0,
            heading_deg=0.0,
            speed_kt=450.0,
            alt_ft=35000.0,
            duration_s=120.0,
            dt_s=1.0,
            rng=deterministic_rng,
        )
        assert states[0].lat_deg < 0.0
        assert states[-1].lat_deg > 0.0

    def test_generate_straight_flight_anti_meridian_crossing(self, deterministic_rng: np.random.Generator) -> None:
        """Verify straight flight crosses the anti-meridian smoothly."""
        states = generate_straight_flight(
            start_lat=20.0,
            start_lon=179.95,
            heading_deg=90.0,
            speed_kt=480.0,
            alt_ft=38000.0,
            duration_s=90.0,
            dt_s=1.0,
            rng=deterministic_rng,
        )
        assert states[0].lon_deg > 179.9
        # Crosses into western hemisphere
        assert states[-1].lon_deg < 0.0

    def test_generate_maneuvering_flight_coordinated_turn(self, deterministic_rng: np.random.Generator) -> None:
        """Verify generate_maneuvering_flight executes 3-stage coordinated turn."""
        states = generate_maneuvering_flight(
            start_lat=52.0,
            start_lon=4.0,
            speed_kt=250.0,
            alt_ft=5000.0,
            straight_time_1_s=10.0,
            bank_angle_deg=25.0,
            turn_duration_s=20.0,
            straight_time_2_s=10.0,
            rng=deterministic_rng,
        )
        assert len(states) >= 40
        # Stage 1: roll angle 0
        assert math.isclose(states[5].roll_angle_deg, 0.0, abs_tol=1e-5)
        # Stage 2: roll angle 25
        assert math.isclose(states[20].roll_angle_deg, 25.0, abs_tol=1e-5)
        # Stage 3: roll angle 0
        assert math.isclose(states[35].roll_angle_deg, 0.0, abs_tol=1e-5)

    def test_step_kinematics_integration(self) -> None:
        """Verify step_kinematics single-step 4D continuous state update."""
        profile = get_aircraft_profile("B738")
        s0 = AircraftTruthState(
            timestamp_s=0.0,
            lat_deg=52.3,
            lon_deg=4.7,
            alt_msl_m=1000.0,
            alt_hae_m=1000.0,
            alt_baro_ft=3280.8,
            groundspeed_mps=120.0,
            tas_mps=120.0,
            ias_mps=115.0,
            mach=0.35,
            true_track_deg=60.0,
            true_heading_deg=60.0,
            vertical_rate_baro_mps=10.0,
            phase=FlightPhase.ENROUTE_CLIMB,
        )
        s1 = step_kinematics(
            current_state=s0,
            target_alt_m=2000.0,
            target_tas_mps=130.0,
            target_track_deg=70.0,
            dt_s=1.0,
            profile=profile,
        )
        assert s1.timestamp_s == 1.0
        assert s1.alt_msl_m > s0.alt_msl_m
        assert s1.tas_mps > s0.tas_mps
        assert s1.gs_mps == s1.groundspeed_mps
        assert s1.track_deg == s1.true_track_deg
        assert s1.vr_mps == s1.vertical_rate_baro_mps
        assert s1.alt_ft == s1.alt_baro_ft


# ==============================================================================
# 6. Squitter Scheduling & Multi-Aircraft Tests
# ==============================================================================


class TestSquitterScheduler:
    """Tests for SquitterScheduler and MultiAircraftScheduler."""

    def test_squitter_generation_and_decodability(self, deterministic_rng: np.random.Generator) -> None:
        """Verify squitter generator produces valid, decodable Mode S DF17 frames."""
        b738 = get_aircraft_profile("B738")
        states = generate_simple_climb_trajectory(
            profile=b738,
            origin_lat=52.3105,
            origin_lon=4.7683,
            target_alt_ft=10000.0,
            duration_s=30.0,
            rng=deterministic_rng,
        )
        scheduler = SquitterScheduler(icao24=0x4840D6, callsign="KLM1023", rng=deterministic_rng)
        events = scheduler.generate_squitters(states)
        assert len(events) > 20

        # Decode all frames and verify integrity
        tcs_seen: set[int] = set()
        cpr_formats: list[int] = []

        for ev in events:
            assert len(ev.raw_bytes) == 14
            decoded = decode_mode_s(ev.raw_bytes)
            assert decoded.crc_valid
            assert decoded.icao24 == 0x4840D6
            tcs_seen.add(decoded.tc)
            if decoded.tc == 11:
                cpr_formats.append(decoded.cpr_format)

        # Must have position (TC 11), velocity (TC 19), and identification (TC 4)
        assert 11 in tcs_seen
        assert 19 in tcs_seen
        assert 4 in tcs_seen

        # Verify CPR alternation: consecutive position frames alternate 0 and 1
        assert len(cpr_formats) >= 10
        for i in range(len(cpr_formats) - 1):
            assert cpr_formats[i] != cpr_formats[i + 1]

    def test_multi_aircraft_scenario_clean_10(self, deterministic_rng: np.random.Generator) -> None:
        """Verify load_scenario and MultiAircraftScheduler with 10 aircraft."""
        scenario = load_scenario("clean_tma_10_aircraft", rng=deterministic_rng)
        assert scenario.name == "clean_tma_10_aircraft"
        assert len(scenario.aircraft) == 10

        scheduler = MultiAircraftScheduler(scenario=scenario, rng=deterministic_rng)
        all_events = scheduler.generate_all_events()
        assert len(all_events) > 200

        # Verify events are strictly sorted in time
        for i in range(len(all_events) - 1):
            assert all_events[i].timestamp_s <= all_events[i + 1].timestamp_s

    def test_multi_aircraft_scenario_congested_25(self, deterministic_rng: np.random.Generator) -> None:
        """Verify load_scenario for congested 25-aircraft scenario."""
        scenario = load_scenario("congested_tma_25_aircraft", rng=deterministic_rng)
        assert len(scenario.aircraft) == 25
        scheduler = MultiAircraftScheduler(scenario=scenario, rng=deterministic_rng)
        events = scheduler.generate_all_events()
        assert len(events) > 500

    def test_unknown_scenario_raises_value_error(self, deterministic_rng: np.random.Generator) -> None:
        """Verify unknown scenario name raises ValueError."""
        with pytest.raises(ValueError, match="Unknown scenario 'nonexistent'"):
            load_scenario("nonexistent", rng=deterministic_rng)
