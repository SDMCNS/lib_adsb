"""Unit tests for Stage B physical RF channel propagation, geometry, link budget, and BER.

Authoritative reference: docs/04_ERROR_AND_ANOMALY_SIMULATION.md Sections 2.1-2.4
and docs/01_ARCHITECTURE_AND_DESIGN.md.
"""

from __future__ import annotations

import numpy as np
import pytest

from adsb.constants import FREQ_1090ES_HZ, FREQ_UAT_HZ, SPEED_OF_LIGHT_MPS
from adsb.impairment.channel import (
    AntennaPatternType,
    DropoutReason,
    FadingModel,
    ReceiverSite,
    RFPropagationChannel,
    apply_bit_errors,
    check_terrain_mask,
    compute_antenna_gain,
    compute_beast_mlat_counter,
    compute_fspl,
    compute_ppm_ber,
    compute_preamble_drop_prob,
    compute_radio_horizon,
    compute_slant_range,
)
from adsb.protocol.crc import compute_syndrome

GV01_BYTES = bytes.fromhex("8D4840D6202CC371C32CE0576098")


class TestRFGeometryAndPropagation:
    """Verify slant range, propagation delay, radio horizon, and terrain masking."""

    def test_slant_range_and_propagation_delay(self) -> None:
        # Aircraft directly overhead receiver at 10,000 m HAE
        d = compute_slant_range(
            tx_lat_deg=52.3105,
            tx_lon_deg=4.7683,
            tx_alt_m=10000.0,
            rx_lat_deg=52.3105,
            rx_lon_deg=4.7683,
            rx_alt_m=0.0,
        )
        assert abs(d - 10000.0) < 0.1

        tau = d / SPEED_OF_LIGHT_MPS
        expected_tau = 10000.0 / 299_792_458.0
        assert abs(tau - expected_tau) < 1e-12

    def test_radio_horizon_threshold(self) -> None:
        # Receiver at sea level (0 m), aircraft at 10,000 m MSL
        d_horiz = compute_radio_horizon(h_tx_m=10000.0, h_rx_m=0.0)
        # Analytical 4/3-Earth horizon: sqrt(2 * (4/3 * 6371008.8) * 10000) ~ 412,181 m
        assert abs(d_horiz - 412181.5) < 50.0

        # Receiver at 25 m, aircraft at 10,000 m
        d_horiz_25 = compute_radio_horizon(h_tx_m=10000.0, h_rx_m=25.0)
        # Adds d_rx = sqrt(2 * R_eff * 25) ~ 20,609 m -> Total ~ 432,790 m (~233.7 NM)
        assert abs(d_horiz_25 - (d_horiz + 20609.0)) < 50.0

    def test_directional_terrain_masking(self) -> None:
        # Profile: Mountain peak at azimuth 90 deg with 5.0 deg elevation mask
        profile = ((0.0, 0.0), (90.0, 5.0), (180.0, 0.0), (270.0, 0.0))

        # Target at 90 deg, 3 deg elevation -> occulted by terrain
        assert not check_terrain_mask(90.0, 3.0, profile)

        # Target at 90 deg, 7 deg elevation -> visible above peak
        assert check_terrain_mask(90.0, 7.0, profile)

        # Target at 180 deg, 1 deg elevation -> unobstructed horizon
        assert check_terrain_mask(180.0, 1.0, profile)

        # Empty profile defaults to optical horizon (>= 0.0 deg)
        assert check_terrain_mask(45.0, 0.5, None)
        assert not check_terrain_mask(45.0, -0.5, None)


class TestLinkBudgetAndAntenna:
    """Verify Free-Space Path Loss (FSPL) and antenna radiation patterns."""

    def test_fspl_numerical_reference(self) -> None:
        # FSPL(1000 m, 1090 MHz) = 20*log10(1000) + 20*log10(1.09e9) - 147.5522 = 93.1963 dB
        fspl_1km = compute_fspl(1000.0, FREQ_1090ES_HZ)
        assert abs(fspl_1km - 93.1963) < 0.05

        # FSPL(100 km, 1090 MHz) = 93.1963 + 40 dB = 133.1963 dB
        fspl_100km = compute_fspl(100_000.0, FREQ_1090ES_HZ)
        assert abs(fspl_100km - 133.1963) < 0.05

        # 978 MHz UAT FSPL(1000 m) = 20*log10(1000) + 20*log10(9.78e8) - 147.5522 = 92.2547 dB
        fspl_uat_1km = compute_fspl(1000.0, FREQ_UAT_HZ)
        assert abs(fspl_uat_1km - 92.2547) < 0.05

    def test_antenna_patterns(self) -> None:
        # Isotropic antenna is uniform 0.0 dBi across all elevations
        assert compute_antenna_gain(0.0, 5.0, AntennaPatternType.ISOTROPIC) == 0.0
        assert compute_antenna_gain(45.0, 5.0, AntennaPatternType.ISOTROPIC) == 0.0
        assert compute_antenna_gain(90.0, 5.0, AntennaPatternType.ISOTROPIC) == 0.0

        # Dipole antenna: peak gain at horizon (el = 0 deg)
        gain_horizon = compute_antenna_gain(0.0, 5.0, AntennaPatternType.DIPOLE)
        assert abs(gain_horizon - 5.0) < 0.01

        # Overhead cone of silence (el = 90 deg) -> -30.0 dBi notch
        gain_overhead = compute_antenna_gain(90.0, 5.0, AntennaPatternType.DIPOLE)
        assert gain_overhead == -30.0


class TestReceiverClocksAndDetection:
    """Verify receiver clock drift, MLAT counter, preamble drop, and BER."""

    def test_clock_drift_and_beast_counter(self) -> None:
        t_rx = 1000.0
        # 48-bit 12 MHz counter: 1000 * 12,000,000 = 12,000,000,000 ticks
        counter = compute_beast_mlat_counter(t_rx)
        assert counter == 12_000_000_000

        # Counter wrapping at 2^48
        t_wrap = (2**48) / 12_000_000
        assert compute_beast_mlat_counter(t_wrap) == 0

    def test_preamble_drop_logistic_psychometric(self) -> None:
        # Exactly at 6.0 dB SNR, drop probability is 50%
        p_drop_6db = compute_preamble_drop_prob(6.0, threshold_snr_db=6.0)
        assert abs(p_drop_6db - 0.50) < 1e-6

        # High SNR >= 20 dB has drop prob < 1e-4
        assert compute_preamble_drop_prob(20.0) < 1e-4

        # Very low SNR <= -10 dB has drop prob > 0.999
        assert compute_preamble_drop_prob(-10.0) > 0.999

    def test_ppm_ber_calculations(self) -> None:
        # AWGN at SNR = 0 dB (gamma = 1.0) -> P_b = 0.5 * exp(-0.5) ~ 0.30326
        ber_0db = compute_ppm_ber(0.0, FadingModel.AWGN)
        assert abs(ber_0db - 0.30326) < 0.001

        # Rayleigh at SNR = 0 dB (gamma = 1.0) -> P_b = 1 / (2 + 1) = 0.33333
        ber_rayleigh_0db = compute_ppm_ber(0.0, FadingModel.RAYLEIGH)
        assert abs(ber_rayleigh_0db - (1.0 / 3.0)) < 1e-5

        # Very high SNR (30 dB) in AWGN -> BER is 0.0
        assert compute_ppm_ber(30.0, FadingModel.AWGN) == 0.0

    def test_apply_bit_errors(self) -> None:
        rng = np.random.default_rng(42)
        raw = GV01_BYTES

        # BER = 0.0 -> no change
        corrupted, flips = apply_bit_errors(raw, 0.0, rng)
        assert corrupted == raw
        assert flips == 0

        # BER = 1.0 -> complete bitwise inversion
        corrupted, flips = apply_bit_errors(raw, 1.0, rng)
        assert flips == len(raw) * 8
        assert all(b1 ^ b2 == 0xFF for b1, b2 in zip(raw, corrupted, strict=False))

        # BER = 0.05 -> several bit flips corrupting CRC
        corrupted, flips = apply_bit_errors(raw, 0.05, rng)
        assert flips > 0
        assert compute_syndrome(corrupted) != 0


class TestRFPropagationChannelEngine:
    """Verify RFPropagationChannel end-to-end propagation and dropouts."""

    @pytest.fixture
    def receiver(self) -> ReceiverSite:
        return ReceiverSite(
            lat_deg=52.3105,
            lon_deg=4.7683,
            alt_hae_m=25.0,
            alt_msl_m=25.0,
            rx_id="SCHIPHOL_TOWER",
            noise_floor_dbm=-90.0,
            clock_drift_ppm=10.0,
        )

    def test_propagate_normal_clean_frame(self, receiver: ReceiverSite) -> None:
        channel = RFPropagationChannel()
        rng = np.random.default_rng(12345)

        # Aircraft 50 km away at 10,000 m HAE
        res = channel.propagate_squitter(
            raw_bytes=GV01_BYTES,
            tx_timestamp_s=10.0,
            tx_lat_deg=52.75,
            tx_lon_deg=4.7683,
            tx_alt_m=10000.0,
            receiver=receiver,
            rng=rng,
            tx_power_dbm=51.0,
        )

        assert res.received
        assert res.dropout_reason == DropoutReason.NONE
        assert res.slant_range_m > 40000.0
        assert res.snr_db > 10.0
        assert res.rx_timestamp_s > 10.0
        assert res.corrupted_bytes == GV01_BYTES
        assert res.bit_flips == 0
        assert compute_syndrome(res.corrupted_bytes) == 0

    def test_propagate_beyond_radio_horizon_dropped(self, receiver: ReceiverSite) -> None:
        channel = RFPropagationChannel()
        rng = np.random.default_rng(12345)

        # Aircraft 600 km away (approx 5.5 deg lat away) -> well beyond 432 km horizon
        res = channel.propagate_squitter(
            raw_bytes=GV01_BYTES,
            tx_timestamp_s=10.0,
            tx_lat_deg=57.8,
            tx_lon_deg=4.7683,
            tx_alt_m=10000.0,
            receiver=receiver,
            rng=rng,
        )

        assert not res.received
        assert res.dropout_reason == DropoutReason.RADIO_HORIZON

    def test_propagate_terrain_masked_dropped(self) -> None:
        # Receiver with mountain peak blocking east (azimuth 90 deg) below 10 deg elevation
        receiver = ReceiverSite(
            lat_deg=52.3105,
            lon_deg=4.7683,
            terrain_mask_profile=((90.0, 10.0),),
        )
        channel = RFPropagationChannel()
        rng = np.random.default_rng(12345)

        # Low flying aircraft to the east (approx 2 deg elevation)
        res = channel.propagate_squitter(
            raw_bytes=GV01_BYTES,
            tx_timestamp_s=10.0,
            tx_lat_deg=52.3105,
            tx_lon_deg=5.5,  # East of receiver
            tx_alt_m=500.0,  # Low altitude
            receiver=receiver,
            rng=rng,
        )

        assert not res.received
        assert res.dropout_reason == DropoutReason.TERRAIN_MASK

    def test_propagate_deterministic_reproducibility(self, receiver: ReceiverSite) -> None:
        channel = RFPropagationChannel()

        res1 = channel.propagate_squitter(
            raw_bytes=GV01_BYTES,
            tx_timestamp_s=5.0,
            tx_lat_deg=52.5,
            tx_lon_deg=4.76,
            tx_alt_m=3000.0,
            receiver=receiver,
            rng=np.random.default_rng(999),
        )
        res2 = channel.propagate_squitter(
            raw_bytes=GV01_BYTES,
            tx_timestamp_s=5.0,
            tx_lat_deg=52.5,
            tx_lon_deg=4.76,
            tx_alt_m=3000.0,
            receiver=receiver,
            rng=np.random.default_rng(999),
        )

        assert res1.slant_range_m == res2.slant_range_m
        assert res1.rx_power_dbm == res2.rx_power_dbm
        assert res1.rx_timestamp_s == res2.rx_timestamp_s
        assert res1.corrupted_bytes == res2.corrupted_bytes
