"""Unit tests for the embedded airport database (adsb.synthesis.airports)."""

from __future__ import annotations

import pytest

from adsb.core.geodesy import haversine_distance, initial_bearing
from adsb.synthesis.airports import (
    Airport,
    Runway,
    get_airport,
    has_airport,
    list_aircraft_types,
    list_airports,
    search_airports,
)


class TestAirportDatabase:
    """Test suite verifying the 31-hub embedded airport database."""

    def test_airport_count_and_types(self) -> None:
        """Verify exactly 31 global hubs are present (20 European, 11 International)."""
        airports = list_airports()
        assert len(airports) == 31
        assert all(isinstance(a, Airport) for a in airports)
        assert sorted(airports, key=lambda a: a.icao) == airports

    def test_all_expected_icaos_present(self) -> None:
        """Verify all 20 European and 11 International ICAO codes exist."""
        european_icaos = {
            "EGLL", "LFPG", "EHAM", "EDDF", "LEMD", "LIRF", "LOWW", "EKCH",
            "LSZH", "EDDM", "EBBR", "EIDW", "LEBL", "LPPT", "ENGM", "ESSA",
            "EFHK", "EPWA", "LGAV", "LTFM",
        }
        international_icaos = {
            "KJFK", "KLAX", "KORD", "KATL", "OMDB", "OTHH", "RJTT", "RJAA",
            "VHHH", "WSSS", "YSSY",
        }
        all_expected = european_icaos | international_icaos
        assert len(all_expected) == 31

        for icao in all_expected:
            assert has_airport(icao), f"Missing expected airport: {icao}"
            apt = get_airport(icao)
            assert apt.icao == icao
            assert isinstance(apt.iata, str) and len(apt.iata) == 3

    def test_iata_lookup(self) -> None:
        """Verify lookup works using 3-letter IATA codes."""
        test_cases = [
            ("LHR", "EGLL"),
            ("AMS", "EHAM"),
            ("CDG", "LFPG"),
            ("JFK", "KJFK"),
            ("DXB", "OMDB"),
            ("SYD", "YSSY"),
        ]
        for iata, expected_icao in test_cases:
            assert has_airport(iata)
            apt = get_airport(iata)
            assert apt.icao == expected_icao
            assert apt.iata == iata

    def test_case_insensitivity(self) -> None:
        """Verify lookups are case-insensitive with whitespace trimming."""
        assert get_airport("eham").icao == "EHAM"
        assert get_airport(" Eham ").icao == "EHAM"
        assert get_airport("lhr").icao == "EGLL"
        assert get_airport(" ams ").icao == "EHAM"

    def test_invalid_airport_codes_rejection(self) -> None:
        """Verify non-existent codes raise KeyError with informative message."""
        with pytest.raises(KeyError, match="ZZZZ"):
            get_airport("ZZZZ")

        with pytest.raises(KeyError, match="XYZ"):
            get_airport("XYZ")

        assert not has_airport("ZZZZ")
        assert not has_airport("1234")
        assert not has_airport("")

    def test_invalid_types_and_empty_codes_rejection(self) -> None:
        """Verify empty string or whitespace raises ValueError."""
        with pytest.raises(ValueError, match="non-empty string"):
            get_airport("")

        with pytest.raises(ValueError, match="non-empty string"):
            get_airport("   ")

        with pytest.raises(ValueError):
            get_airport(None)  # type: ignore[arg-type]

    def test_airport_and_runway_data_integrity(self) -> None:
        """Verify geodetic coordinates, elevations, and runway geometry bounds."""
        for apt in list_airports():
            # Check aerodrome coordinates
            assert -90.0 <= apt.lat_deg <= 90.0
            assert -180.0 <= apt.lon_deg <= 180.0
            assert len(apt.runways) >= 1
            assert apt.primary_runway_id
            assert apt.primary_runway is not None
            assert apt.primary_runway.designation == apt.primary_runway_id

            # Elevation properties
            assert apt.elevation_m == apt.elev_m
            assert abs(apt.elevation_ft - (apt.elev_m / 0.3048)) < 1e-4
            assert apt.elev_ft == apt.elevation_ft

            # Primary runway lookup helper
            rwy = apt.get_runway(apt.primary_runway_id)
            assert rwy == apt.primary_runway

            # Verify every runway at airport
            for r in apt.runways:
                assert isinstance(r, Runway)
                assert 0.0 <= r.true_heading_deg < 360.0
                assert r.length_m > 1000.0  # All major hubs have > 1000m runways
                assert r.width_m >= 30.0
                assert -90.0 <= r.threshold_lat <= 90.0
                assert -180.0 <= r.threshold_lon <= 180.0
                assert -90.0 <= r.midpoint_lat <= 90.0
                assert -180.0 <= r.midpoint_lon <= 180.0

                # Runway coordinate property aliases
                assert r.midpoint_lat_deg == r.midpoint_lat
                assert r.midpoint_lon_deg == r.midpoint_lon
                assert r.threshold_lat_deg == r.threshold_lat
                assert r.threshold_lon_deg == r.threshold_lon
                assert abs(r.length_ft - (r.length_m / 0.3048)) < 1e-4
                assert abs(r.width_ft - (r.width_m / 0.3048)) < 1e-4
                assert r.elevation_m == r.threshold_elev_m
                assert abs(r.elevation_ft - (r.threshold_elev_m / 0.3048)) < 1e-4
                assert r.threshold_elev_ft == r.elevation_ft

                # Geodetic validation: distance from threshold to midpoint must be length / 2
                dist_to_mid = haversine_distance(
                    r.threshold_lat, r.threshold_lon, r.midpoint_lat, r.midpoint_lon
                )
                assert abs(dist_to_mid - (r.length_m / 2.0)) < 1.0

                # Bearing from threshold to midpoint must equal true_heading_deg
                bearing_to_mid = initial_bearing(
                    r.threshold_lat, r.threshold_lon, r.midpoint_lat, r.midpoint_lon
                )
                assert abs((bearing_to_mid - r.true_heading_deg + 180.0) % 360.0 - 180.0) < 0.2

    def test_get_runway_invalid_rejection(self) -> None:
        """Verify invalid runway designation raises KeyError."""
        apt = get_airport("EHAM")
        with pytest.raises(KeyError, match="Runway '99Z' not found"):
            apt.get_runway("99Z")

    def test_search_airports(self) -> None:
        """Verify search_airports matches ICAO, IATA, name, and city."""
        # By city
        results = search_airports("London")
        assert any(a.icao == "EGLL" for a in results)

        # By airport name
        results = search_airports("Schiphol")
        assert len(results) == 1
        assert results[0].icao == "EHAM"

        # By IATA
        results = search_airports("JFK")
        assert any(a.icao == "KJFK" for a in results)

        # By country
        results = search_airports("Japan")
        assert {a.icao for a in results} == {"RJTT", "RJAA"}

        # Empty / whitespace query returns all
        assert len(search_airports("")) == 31
        assert len(search_airports("   ")) == 31

    def test_list_aircraft_types(self) -> None:
        """Verify list_aircraft_types returns known aircraft type codes."""
        types = list_aircraft_types()
        assert isinstance(types, list)
        assert len(types) >= 10
        assert "B738" in types
        assert "A320" in types
        assert "B77W" in types
        assert "C172" in types
        assert sorted(types) == types
