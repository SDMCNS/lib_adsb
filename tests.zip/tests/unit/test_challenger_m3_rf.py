"""Adversarial stress-testing suite for Milestone 3 RF Channel Physics & Noise Models.

Author: challenger_m3_1 (Teamwork Challenger Subagent)
Scope: Empirical verification of singularities, radio horizon boundary precision,
capture effect thresholds, high-rate FRUIT saturation, and bit-flipping/CRC integrity.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np
import pytest
from scipy import stats  # type: ignore[import-untyped]
from scipy.optimize import brentq  # type: ignore[import-untyped]

from adsb.impairment.channel import (
    AntennaPatternType,
    ChannelConfig,
    DropoutReason,
    FadingModel,
    ReceiverSite,
    RFChannelModel,
    RFPropagationChannel,
    apply_bit_errors,
    compute_antenna_gain,
    compute_fspl,
    compute_ppm_ber,
    compute_radio_horizon,
    compute_slant_range,
)
from adsb.impairment.noise import (
    PoissonFruitGenerator,
    PulseCollisionEngine,
    ReceptionEvent,
)
from adsb.protocol.crc import compute_syndrome
from adsb.protocol.modes import (
    encode_1090es_df11,
    encode_1090es_identification,
)
from adsb.synthesis.scheduler import SquitterEvent

if TYPE_CHECKING:
    pass


class TestAdversarialSingularities:
    """Stress-test numerical singularities and boundary conditions in RF propagation."""

    def test_aircraft_at_receiver_zero_distance(self) -> None:
        """Verify propagation physics when aircraft is collocated with receiver (d = 0)."""
        lat, lon, alt = 52.3105, 4.7683, 50.0
        rx = ReceiverSite(lat_deg=lat, lon_deg=lon, alt_hae_m=alt, alt_msl_m=alt)

        # 1. 3D Slant range must be 0.0
        d_slant = compute_slant_range(lat, lon, alt, rx.lat_deg, rx.lon_deg, rx.effective_alt_m)
        assert d_slant == 0.0

        # 2. FSPL handles d=0 via d_eff = max(1.0, d) without log(0) error
        fspl = compute_fspl(0.0)
        assert math.isfinite(fspl)
        assert fspl > 0.0

        # 3. Antenna gain at 90.0 deg elevation returns cone of silence notch (-30 dBi)
        g_90 = compute_antenna_gain(90.0, pattern_type=AntennaPatternType.DIPOLE)
        assert g_90 == -30.0
        g_neg90 = compute_antenna_gain(-90.0, pattern_type=AntennaPatternType.DIPOLE)
        assert g_neg90 == -30.0

        # 4. RFPropagationChannel executes cleanly without ZeroDivisionError
        channel = RFPropagationChannel()
        raw = encode_1090es_df11(0x123456)
        rng = np.random.default_rng(42)

        res = channel.propagate_squitter(
            raw_bytes=raw,
            tx_timestamp_s=1.0,
            tx_lat_deg=lat,
            tx_lon_deg=lon,
            tx_alt_m=alt,
            receiver=rx,
            rng=rng,
        )

        assert res.received is True
        assert res.dropout_reason == DropoutReason.NONE
        assert res.slant_range_m == 0.0
        assert res.azimuth_deg == 0.0
        assert res.elevation_deg == 90.0
        assert math.isfinite(res.rx_power_dbm)
        assert math.isfinite(res.snr_db)
        assert res.snr_db > 50.0  # High SNR at zero distance

    def test_extreme_altitude_karman_line(self) -> None:
        """Verify propagation physics at edge of space (100 km / Karman line)."""
        rx = ReceiverSite(lat_deg=52.0, lon_deg=4.0, alt_hae_m=50.0, alt_msl_m=50.0)
        h_tx = 100_000.0  # 100 km

        d_horizon = compute_radio_horizon(h_tx, rx.effective_alt_m)
        assert math.isfinite(d_horizon)
        assert d_horizon > 1_000_000.0  # Over 1,000 km horizon

        channel = RFPropagationChannel()
        raw = encode_1090es_df11(0xABCDEF)
        rng = np.random.default_rng(42)

        res = channel.propagate_squitter(
            raw_bytes=raw,
            tx_timestamp_s=1.0,
            tx_lat_deg=52.0,
            tx_lon_deg=4.0,
            tx_alt_m=h_tx,
            receiver=rx,
            rng=rng,
        )

        assert math.isclose(res.slant_range_m, 99950.0, rel_tol=1e-3)
        assert math.isclose(res.elevation_deg, 90.0, abs_tol=1e-5)
        assert math.isfinite(res.rx_power_dbm)
        assert math.isfinite(res.snr_db)

    def test_extreme_altitude_sub_surface(self) -> None:
        """Verify propagation physics at negative altitude (-500 m, e.g. Dead Sea depression)."""
        rx = ReceiverSite(lat_deg=31.5, lon_deg=35.5, alt_hae_m=50.0, alt_msl_m=50.0)
        h_tx = -500.0

        # Horizon calculation clamps negative altitude to 0.0 via max(0.0, h_tx)
        d_horizon = compute_radio_horizon(h_tx, rx.effective_alt_m)
        assert math.isfinite(d_horizon)
        assert d_horizon > 0.0

        # With terrain masking disabled, frame propagates without domain error
        channel_no_mask = RFPropagationChannel(
            config=ChannelConfig(enable_terrain_masking=False, enable_preamble_dropout=False)
        )
        raw = encode_1090es_df11(0x123456)
        rng = np.random.default_rng(42)

        res = channel_no_mask.propagate_squitter(
            raw_bytes=raw,
            tx_timestamp_s=1.0,
            tx_lat_deg=31.5,
            tx_lon_deg=35.5,
            tx_alt_m=h_tx,
            receiver=rx,
            rng=rng,
        )
        assert res.received is True
        assert res.dropout_reason == DropoutReason.NONE
        assert math.isclose(res.elevation_deg, -90.0, abs_tol=1e-5)

    def test_polar_coordinates_propagation(self) -> None:
        """Verify propagation at geographic poles (North and South Poles)."""
        rx = ReceiverSite(lat_deg=90.0, lon_deg=0.0, alt_hae_m=10.0, alt_msl_m=10.0)
        channel = RFPropagationChannel()
        raw = encode_1090es_df11(0x123456)
        rng = np.random.default_rng(42)

        res = channel.propagate_squitter(
            raw_bytes=raw,
            tx_timestamp_s=1.0,
            tx_lat_deg=90.0,
            tx_lon_deg=0.0,
            tx_alt_m=1000.0,
            receiver=rx,
            rng=rng,
        )
        assert math.isfinite(res.slant_range_m)
        assert math.isfinite(res.elevation_deg)
        assert res.elevation_deg == 90.0

    def test_extreme_snr_limits_in_ber(self) -> None:
        """Verify non-coherent 2-PPM BER at extreme SNR inputs."""
        # Ultra high SNR -> BER is 0.0
        assert compute_ppm_ber(100.0, FadingModel.AWGN) == 0.0
        assert compute_ppm_ber(300.0, FadingModel.AWGN) == 0.0

        # Deep negative SNR -> BER converges to 0.5 (pure noise)
        ber_neg = compute_ppm_ber(-100.0, FadingModel.AWGN)
        assert math.isclose(ber_neg, 0.5, rel_tol=1e-5)

        # Rayleigh fading under deep negative SNR converges to 0.5
        ber_rayleigh_neg = compute_ppm_ber(-100.0, FadingModel.RAYLEIGH)
        assert math.isclose(ber_rayleigh_neg, 0.5, rel_tol=1e-5)


class TestAdversarialRadioHorizonBoundary:
    """Stress-test radio horizon boundary with exact +/-1 meter precision."""

    def test_radio_horizon_boundary_cutoff_precision(self) -> None:
        """Empirically test transmission at d_horizon - 1 m (admitted) vs d_horizon + 1 m (dropped)."""
        rx = ReceiverSite(lat_deg=0.0, lon_deg=0.0, alt_hae_m=100.0, alt_msl_m=100.0)
        tx_alt = 10_000.0  # 10,000 m flight level

        d_horizon = compute_radio_horizon(tx_alt, rx.effective_alt_m)

        def slant_error(lat_deg: float, target_dist: float) -> float:
            return (
                compute_slant_range(
                    lat_deg, 0.0, tx_alt, rx.lat_deg, rx.lon_deg, rx.effective_alt_m
                )
                - target_dist
            )

        # Numerically solve for latitude achieving target slant distance along meridian
        lat_inside = float(brentq(slant_error, 0.0, 10.0, args=(d_horizon - 1.0,)))
        lat_outside = float(brentq(slant_error, 0.0, 10.0, args=(d_horizon + 1.0,)))

        d_in = compute_slant_range(
            lat_inside, 0.0, tx_alt, rx.lat_deg, rx.lon_deg, rx.effective_alt_m
        )
        d_out = compute_slant_range(
            lat_outside, 0.0, tx_alt, rx.lat_deg, rx.lon_deg, rx.effective_alt_m
        )

        assert math.isclose(d_in, d_horizon - 1.0, abs_tol=1e-3)
        assert math.isclose(d_out, d_horizon + 1.0, abs_tol=1e-3)

        # Propagate through channel with terrain masking and preamble drop disabled
        # to isolate the horizon decision boundary
        channel = RFPropagationChannel(
            config=ChannelConfig(
                enable_horizon_check=True,
                enable_terrain_masking=False,
                enable_preamble_dropout=False,
            )
        )
        raw = encode_1090es_df11(0x123456)
        rng = np.random.default_rng(123)

        # 1. At d_horizon - 1.0 m: MUST be admitted
        res_inside = channel.propagate_squitter(raw, 0.0, lat_inside, 0.0, tx_alt, rx, rng)
        assert res_inside.received is True
        assert res_inside.dropout_reason == DropoutReason.NONE

        # 2. At d_horizon + 1.0 m: MUST be dropped due to RADIO_HORIZON
        res_outside = channel.propagate_squitter(raw, 0.0, lat_outside, 0.0, tx_alt, rx, rng)
        assert res_outside.received is False
        assert res_outside.dropout_reason == DropoutReason.RADIO_HORIZON
        assert res_outside.rx_power_dbm == -150.0

    def test_radio_horizon_disabled_bypass(self) -> None:
        """Verify that when enable_horizon_check=False, transmissions beyond horizon are admitted."""
        rx = ReceiverSite(lat_deg=0.0, lon_deg=0.0, alt_hae_m=100.0, alt_msl_m=100.0)
        tx_alt = 10_000.0
        d_horizon = compute_radio_horizon(tx_alt, rx.effective_alt_m)

        def slant_error(lat_deg: float, target_dist: float) -> float:
            return (
                compute_slant_range(
                    lat_deg, 0.0, tx_alt, rx.lat_deg, rx.lon_deg, rx.effective_alt_m
                )
                - target_dist
            )

        lat_outside = float(brentq(slant_error, 0.0, 10.0, args=(d_horizon + 50_000.0,)))

        channel = RFPropagationChannel(
            config=ChannelConfig(
                enable_horizon_check=False,
                enable_terrain_masking=False,
                enable_preamble_dropout=False,
            )
        )
        raw = encode_1090es_df11(0x123456)
        rng = np.random.default_rng(123)

        res = channel.propagate_squitter(raw, 0.0, lat_outside, 0.0, tx_alt, rx, rng)
        assert res.received is True
        assert res.dropout_reason == DropoutReason.NONE


class TestAdversarialCaptureEffect:
    """Stress-test exact capture effect boundaries (+6.01, +5.99, -5.99, -6.01 dB) and CRC."""

    @pytest.mark.parametrize(
        ("delta_rssi", "expected_a_captures", "expected_b_captures", "expected_garble"),
        [
            (6.01, True, False, False),
            (6.00, True, False, False),
            (5.99, False, False, True),
            (0.00, False, False, True),
            (-5.99, False, False, True),
            (-6.00, False, True, False),
            (-6.01, False, True, False),
        ],
    )
    def test_capture_threshold_boundary_matrix(
        self,
        delta_rssi: float,
        expected_a_captures: bool,
        expected_b_captures: bool,
        expected_garble: bool,
    ) -> None:
        """Verify exact capture threshold behavior at +/-6.01 dB, +/-6.00 dB, and +/-5.99 dB."""
        engine = PulseCollisionEngine(capture_threshold_db=6.0, rng=np.random.default_rng(42))
        raw_a = encode_1090es_identification(0x111111, "ALPHA1")
        raw_b = encode_1090es_identification(0x222222, "BRAVO2")

        assert compute_syndrome(raw_a) == 0
        assert compute_syndrome(raw_b) == 0

        rssi_a = -10.0
        rssi_b = rssi_a - delta_rssi

        ev_a = ReceptionEvent(
            rx_timestamp_ns=0,
            rx_id="RX",
            raw_bytes=raw_a,
            rssi_dbfs=rssi_a,
            snr_db=35.0,
            is_corrupted=False,
        )
        ev_b = ReceptionEvent(
            rx_timestamp_ns=20_000,
            rx_id="RX",
            raw_bytes=raw_b,
            rssi_dbfs=rssi_b,
            snr_db=35.0 - delta_rssi,
            is_corrupted=False,
        )

        out_a, out_b = engine.apply_collision(ev_a, ev_b)

        syn_a = compute_syndrome(out_a.raw_bytes)
        syn_b = compute_syndrome(out_b.raw_bytes)

        if expected_a_captures:
            assert out_a.is_corrupted is False
            assert syn_a == 0
            assert out_a.raw_bytes == raw_a
            assert out_b.is_corrupted is True
            assert syn_b != 0
        elif expected_b_captures:
            assert out_a.is_corrupted is True
            assert syn_a != 0
            assert out_b.is_corrupted is False
            assert syn_b == 0
            assert out_b.raw_bytes == raw_b
        elif expected_garble:
            assert out_a.is_corrupted is True
            assert syn_a != 0
            assert out_b.is_corrupted is True
            assert syn_b != 0

    @pytest.mark.parametrize(
        "dt_offset_ns",
        [
            0,  # Exact simultaneous arrival
            4_000,  # Within preamble (0..8 us)
            8_000,  # Exactly at preamble end / data start
            30_000,  # Mid-frame overlap
            60_000,  # Late-frame overlap
            110_000,  # Parity field overlap
        ],
    )
    def test_destructive_garble_across_all_overlap_offsets(self, dt_offset_ns: int) -> None:
        """Verify that destructive garble (equal RSSI) invalidates CRC across all offset intervals."""
        engine = PulseCollisionEngine(capture_threshold_db=6.0, rng=np.random.default_rng(777))
        raw_a = encode_1090es_identification(0x333333, "CHARL1")
        raw_b = encode_1090es_identification(0x444444, "DELTA2")

        ev_a = ReceptionEvent(
            rx_timestamp_ns=0,
            rx_id="RX",
            raw_bytes=raw_a,
            rssi_dbfs=-15.0,
            snr_db=30.0,
            is_corrupted=False,
        )
        ev_b = ReceptionEvent(
            rx_timestamp_ns=dt_offset_ns,
            rx_id="RX",
            raw_bytes=raw_b,
            rssi_dbfs=-15.0,
            snr_db=30.0,
            is_corrupted=False,
        )

        out_a, out_b = engine.apply_collision(ev_a, ev_b)

        assert out_a.is_corrupted is True
        assert compute_syndrome(out_a.raw_bytes) != 0
        assert out_b.is_corrupted is True
        assert compute_syndrome(out_b.raw_bytes) != 0

    def test_multi_frame_cluster_garble_cascade(self) -> None:
        """Verify collision resolution when 3 overlapping frames arrive in tight succession."""
        engine = PulseCollisionEngine(rng=np.random.default_rng(100))
        f1 = encode_1090es_identification(0x111111, "PLANE1")
        f2 = encode_1090es_identification(0x222222, "PLANE2")
        f3 = encode_1090es_identification(0x333333, "PLANE3")

        ev1 = ReceptionEvent(0, "RX", f1, -10.0, 35.0, False)
        ev2 = ReceptionEvent(40_000, "RX", f2, -10.0, 35.0, False)
        ev3 = ReceptionEvent(80_000, "RX", f3, -10.0, 35.0, False)

        res = engine.resolve_collisions([ev1, ev2, ev3])
        assert len(res) == 3
        for ev in res:
            assert ev.is_corrupted is True
            assert compute_syndrome(ev.raw_bytes) != 0

    def test_dominant_frame_survives_multi_frame_cluster(self) -> None:
        """Verify that a single high-power frame captures over multiple weaker interferers."""
        engine = PulseCollisionEngine(capture_threshold_db=6.0, rng=np.random.default_rng(100))
        f1 = encode_1090es_identification(0x111111, "STRONG")
        f2 = encode_1090es_identification(0x222222, "WEAK01")
        f3 = encode_1090es_identification(0x333333, "WEAK02")

        # f1 is at -5 dBFS; f2 is at -15 dBFS (delta = +10 dB); f3 is at -18 dBFS (delta = +13 dB)
        ev1 = ReceptionEvent(0, "RX", f1, -5.0, 40.0, False)
        ev2 = ReceptionEvent(30_000, "RX", f2, -15.0, 30.0, False)
        ev3 = ReceptionEvent(70_000, "RX", f3, -18.0, 27.0, False)

        res = engine.resolve_collisions([ev1, ev2, ev3])
        # f1 captures cleanly!
        assert res[0].is_corrupted is False
        assert compute_syndrome(res[0].raw_bytes) == 0
        assert res[0].raw_bytes == f1

        # f2 and f3 are suppressed/corrupted
        assert res[1].is_corrupted is True
        assert compute_syndrome(res[1].raw_bytes) != 0
        assert res[2].is_corrupted is True
        assert compute_syndrome(res[2].raw_bytes) != 0


class TestAdversarialFruitSaturation:
    """Stress-test Poisson background FRUIT generator at maximum rate (2000 Hz)."""

    def test_poisson_fruit_rate_2000hz_exponential_statistics(self) -> None:
        """Verify Poisson inter-arrival exponential statistics at maximum rate (2000 Hz)."""
        rate_hz = 2000.0
        duration_s = 5.0
        gen = PoissonFruitGenerator(
            fruit_rate_hz=rate_hz, rx_id="TEST_RX", rng=np.random.default_rng(42)
        )

        events = gen.generate_fruit(duration_s=duration_s, start_timestamp_ns=1_000_000)

        # Expected events N ~ Poisson(2000 * 5) = 10,000. 3-sigma bound: 10,000 +/- 300
        assert 9_500 <= len(events) <= 10_500

        timestamps_s = np.array([e.rx_timestamp_ns / 1e9 for e in events])
        # Check strictly monotonic arrival timestamps
        deltas_s = np.diff(timestamps_s)
        assert np.all(deltas_s > 0.0)

        # Theoretical exponential distribution parameters: mean = 1/lambda, std = 1/lambda
        expected_mean = 1.0 / rate_hz  # 0.0005 s
        sample_mean = float(np.mean(deltas_s))
        sample_std = float(np.std(deltas_s))

        assert math.isclose(sample_mean, expected_mean, rel_tol=0.05)
        assert math.isclose(sample_std, expected_mean, rel_tol=0.05)

        # Kolmogorov-Smirnov test against theoretical Exponential(scale = 1/2000)
        ks_res = stats.kstest(deltas_s, "expon", args=(0, expected_mean))
        assert ks_res.pvalue > 0.01  # Cannot reject the hypothesis of exponential distribution

    def test_poisson_fruit_packet_distribution(self) -> None:
        """Verify format distribution (50% DF11, 30% DF17, 20% Mode A/C) over 10,000 events."""
        gen = PoissonFruitGenerator(fruit_rate_hz=2000.0, rng=np.random.default_rng(99))
        events = gen.generate_fruit(duration_s=5.0)

        total = len(events)
        df11_count = sum(1 for e in events if len(e.raw_bytes) == 7)
        df17_count = sum(1 for e in events if len(e.raw_bytes) == 14)
        mode_ac_count = sum(1 for e in events if len(e.raw_bytes) == 2)

        p_df11 = df11_count / total
        p_df17 = df17_count / total
        p_mode_ac = mode_ac_count / total

        # Check proportions within +/-3% tolerance
        assert math.isclose(p_df11, 0.50, abs_tol=0.03)
        assert math.isclose(p_df17, 0.30, abs_tol=0.03)
        assert math.isclose(p_mode_ac, 0.20, abs_tol=0.03)

    def test_poisson_fruit_amplitude_distribution_and_crc(self) -> None:
        """Verify RSSI amplitude bounds and valid CRC on uncorrupted FRUIT squitters."""
        gen = PoissonFruitGenerator(fruit_rate_hz=1000.0, rng=np.random.default_rng(2026))
        events = gen.generate_fruit(duration_s=2.0)

        rssis = [e.rssi_dbfs for e in events]
        assert all(-40.0 <= r <= -5.0 for r in rssis)
        mean_rssi = float(np.mean(rssis))
        assert math.isclose(mean_rssi, -22.0, abs_tol=0.6)

        # Every uncorrupted DF11 and DF17 generated by FRUIT MUST have valid Mode S CRC
        for e in events:
            if len(e.raw_bytes) in (7, 14):
                assert compute_syndrome(e.raw_bytes) == 0


class TestAdversarialBitFlippingAndCRCIntegrity:
    """Stress-test CRC integrity under bit errors and garble pulse flips."""

    def test_exhaustive_1bit_flip_parity_invalidation_df17(self) -> None:
        """Exhaustively verify that every single bit flip in DF17 (112 bits) invalidates CRC."""
        golden_df17 = encode_1090es_identification(0x4840D6, "KLM1023")
        assert compute_syndrome(golden_df17) == 0

        for bit_idx in range(112):
            b_arr = bytearray(golden_df17)
            byte_pos = bit_idx // 8
            bit_in_byte = 7 - (bit_idx % 8)
            b_arr[byte_pos] ^= 1 << bit_in_byte
            corrupted = bytes(b_arr)

            # CRC syndrome MUST be non-zero for any 1-bit error!
            syndrome = compute_syndrome(corrupted)
            assert syndrome != 0, f"Undetected 1-bit flip at bit index {bit_idx} in DF17!"

    def test_exhaustive_1bit_flip_parity_invalidation_df11(self) -> None:
        """Exhaustively verify that every single bit flip in DF11 (56 bits) invalidates CRC."""
        golden_df11 = encode_1090es_df11(0x4840D6)
        assert compute_syndrome(golden_df11) == 0

        for bit_idx in range(56):
            b_arr = bytearray(golden_df11)
            byte_pos = bit_idx // 8
            bit_in_byte = 7 - (bit_idx % 8)
            b_arr[byte_pos] ^= 1 << bit_in_byte
            corrupted = bytes(b_arr)

            # CRC syndrome MUST be non-zero for any 1-bit error!
            syndrome = compute_syndrome(corrupted)
            assert syndrome != 0, f"Undetected 1-bit flip at bit index {bit_idx} in DF11!"

    def test_exhaustive_2bit_flip_parity_invalidation_df17(self) -> None:
        """Exhaustively verify all 6,216 pairwise bit flips in DF17 invalidate CRC."""
        golden_df17 = encode_1090es_identification(0x4840D6, "KLM1023")
        assert compute_syndrome(golden_df17) == 0

        for i in range(112):
            for j in range(i + 1, 112):
                b_arr = bytearray(golden_df17)
                b_arr[i // 8] ^= 1 << (7 - (i % 8))
                b_arr[j // 8] ^= 1 << (7 - (j % 8))
                corrupted = bytes(b_arr)

                syndrome = compute_syndrome(corrupted)
                assert syndrome != 0, f"Undetected 2-bit flip at indices ({i}, {j}) in DF17!"

    def test_apply_bit_errors_stochastic_crc_invalidation(self) -> None:
        """Verify that apply_bit_errors invalidates CRC whenever bit_flips > 0 across 1000 trials."""
        raw = encode_1090es_identification(0xA12345, "SPEED01")
        assert compute_syndrome(raw) == 0

        rng = np.random.default_rng(8888)
        for _ in range(1000):
            ber = float(rng.uniform(0.01, 0.20))
            corrupted, flips = apply_bit_errors(raw, ber, rng)
            if flips > 0:
                assert compute_syndrome(corrupted) != 0

    def test_apply_garble_preserves_df_field_and_invalidates_crc(self) -> None:
        """Verify apply_garble protects bits 0..4 (DF field) and produces invalid CRC."""
        engine = PulseCollisionEngine(rng=np.random.default_rng(555))
        raw = encode_1090es_identification(0xBEEF01, "CARRIER")
        assert compute_syndrome(raw) == 0

        original_df = raw[0] >> 3

        # Test garble affecting the preamble and first few bits
        for start in range(0, 50, 5):
            affected = list(range(start, start + 10))
            garbled = engine.apply_garble(raw, affected)

            # DF field (first 5 bits) must be preserved
            garbled_df = garbled[0] >> 3
            assert garbled_df == original_df, "Garble corrupted the Downlink Format bits!"

            # Parity must be invalid
            assert compute_syndrome(garbled) != 0


class TestAdversarialEndToEndChannelIntegration:
    """Stress-test RFChannelModel end-to-end integration under heavy load."""

    def test_rf_channel_model_saturation_and_ordering(self) -> None:
        """Verify RFChannelModel handles 2000 Hz FRUIT + real flights with chronological ordering."""
        model = RFChannelModel(
            fruit_rate_hz=2000.0,
            garble_enabled=True,
            capture_threshold_db=6.0,
            rng=np.random.default_rng(42),
        )

        raw1 = encode_1090es_identification(0x111111, "FLIGHT1")
        raw2 = encode_1090es_identification(0x222222, "FLIGHT2")

        transmissions = [
            SquitterEvent(timestamp_s=1.0, raw_bytes=raw1, icao24=0x111111, tx_power_dbm=51.0),
            SquitterEvent(timestamp_s=1.00005, raw_bytes=raw2, icao24=0x222222, tx_power_dbm=40.0),
        ]

        receptions = model.process_transmissions(transmissions)
        assert len(receptions) > 1000

        # Verify strict non-decreasing order of timestamps
        ts = [r.rx_timestamp_ns for r in receptions]
        assert ts == sorted(ts)
