"""Unit tests for noise models, pulse collisions, capture effect, and background FRUIT generator.

Authoritative reference: docs/04_ERROR_AND_ANOMALY_SIMULATION.md Section 2.4.
"""

from __future__ import annotations

from dataclasses import FrozenInstanceError

import numpy as np
import pytest

from adsb.impairment.channel import RFChannelModel
from adsb.impairment.noise import (
    MODE_AC_FRAME_DURATION_NS,
    MODE_S_BIT_DURATION_NS,
    MODE_S_LONG_FRAME_DURATION_NS,
    MODE_S_PREAMBLE_DURATION_NS,
    MODE_S_SHORT_FRAME_DURATION_NS,
    PoissonFruitGenerator,
    PulseCollisionEngine,
    ReceptionEvent,
)
from adsb.protocol.crc import compute_syndrome
from adsb.protocol.modes import (
    decode_mode_s,
)
from adsb.synthesis.scheduler import SquitterEvent

# Golden Vector Frames from docs/02_PROTOCOL_SPECIFICATION.md
GV01_BYTES = bytes.fromhex("8D4840D6202CC371C32CE0576098")
GV02_BYTES = bytes.fromhex("8D40621D58C382D690C8AC2863A7")


class TestReceptionEventContract:
    """Verify ReceptionEvent contract and immutability."""

    def test_reception_event_frozen_dataclass(self) -> None:
        ev = ReceptionEvent(
            rx_timestamp_ns=1_000_000_000,
            rx_id="SITE_ALPHA",
            raw_bytes=GV01_BYTES,
            rssi_dbfs=-15.0,
            snr_db=30.0,
            is_corrupted=False,
        )
        assert ev.rx_timestamp_ns == 1_000_000_000
        assert ev.rx_id == "SITE_ALPHA"
        assert ev.raw_bytes == GV01_BYTES
        assert ev.rssi_dbfs == -15.0
        assert ev.snr_db == 30.0
        assert not ev.is_corrupted
        assert ev.rx_timestamp_s == 1.0

        with pytest.raises(FrozenInstanceError):
            ev.is_corrupted = True  # type: ignore[misc]

    def test_reception_event_timestamp_conversion(self) -> None:
        ev = ReceptionEvent(
            rx_timestamp_ns=123_456_789,
            rx_id="SITE_BETA",
            raw_bytes=b"\x00" * 7,
            rssi_dbfs=-20.0,
            snr_db=25.0,
            is_corrupted=False,
        )
        assert abs(ev.rx_timestamp_s - 0.123456789) < 1e-12


class TestPulseCollisionEngine:
    """Verify pulse duration, collision detection, capture effect, and garble."""

    @pytest.fixture
    def engine(self) -> PulseCollisionEngine:
        return PulseCollisionEngine(
            capture_threshold_db=6.0,
            garble_bit_flip_prob=0.35,
            rng=np.random.default_rng(42),
        )

    def test_frame_durations(self, engine: PulseCollisionEngine) -> None:
        assert engine.get_frame_duration_ns(14) == MODE_S_LONG_FRAME_DURATION_NS  # 120 us
        assert engine.get_frame_duration_ns(7) == MODE_S_SHORT_FRAME_DURATION_NS  # 64 us
        assert engine.get_frame_duration_ns(2) == MODE_AC_FRAME_DURATION_NS  # 20.3 us
        assert engine.get_frame_duration_ns(10) == MODE_S_PREAMBLE_DURATION_NS + (10 * 8 * MODE_S_BIT_DURATION_NS)

    def test_overlap_detection_intervals(self, engine: PulseCollisionEngine) -> None:
        dur = 120_000
        # Exact tangent touch (no overlap)
        is_ov, _, _ = engine.check_overlap(1_000_000, dur, 1_120_000, dur)
        assert not is_ov

        # 1 ns overlap
        is_ov, t_start, t_end = engine.check_overlap(1_000_000, dur, 1_119_999, dur)
        assert is_ov
        assert t_start == 1_119_999
        assert t_end == 1_120_000

        # Complete internal overlap
        is_ov, t_start, t_end = engine.check_overlap(1_000_000, dur, 1_020_000, 50_000)
        assert is_ov
        assert t_start == 1_020_000
        assert t_end == 1_070_000

    def test_overlapping_bit_indices(self, engine: PulseCollisionEngine) -> None:
        # Frame starts at 1,000,000 ns. Preamble is 1,000,000..1,008,000 ns.
        # Data bit 0 is 1,008,000..1,009,000 ns. Data bit 1 is 1,009,000..1,010,000 ns.
        # Overlap in preamble only
        bits = engine.get_overlapping_bit_indices(1_000_000, 112, 1_000_000, 1_005_000)
        assert bits == []

        # Overlap covering bit 0 and bit 1
        bits = engine.get_overlapping_bit_indices(1_000_000, 112, 1_008_500, 1_009_500)
        assert bits == [0, 1]

    def test_giv01_clean_capture_effect(self, engine: PulseCollisionEngine) -> None:
        """GIV-01: Delta RSSI >= 6.0 dB -> Frame A cleanly captures, Frame B garbled."""
        frame_a = ReceptionEvent(
            rx_timestamp_ns=10_000_000,
            rx_id="SITE_1",
            raw_bytes=GV01_BYTES,
            rssi_dbfs=-10.0,
            snr_db=35.0,
            is_corrupted=False,
        )
        frame_b = ReceptionEvent(
            rx_timestamp_ns=10_050_000,  # 50 us later, inside Frame A
            rx_id="SITE_1",
            raw_bytes=GV02_BYTES,
            rssi_dbfs=-18.0,  # Delta RSSI = +8.0 dB >= 6.0 dB
            snr_db=27.0,
            is_corrupted=False,
        )

        out_a, out_b = engine.apply_collision(frame_a, frame_b)

        # Frame A captures cleanly
        assert not out_a.is_corrupted
        assert out_a.raw_bytes == GV01_BYTES
        assert compute_syndrome(out_a.raw_bytes) == 0

        # Frame B is suppressed and corrupted
        assert out_b.is_corrupted
        assert out_b.raw_bytes != GV02_BYTES
        assert compute_syndrome(out_b.raw_bytes) != 0

    def test_giv02_destructive_garble(self, engine: PulseCollisionEngine) -> None:
        """GIV-02: |Delta RSSI| < 6.0 dB -> Both frames destroyed."""
        frame_a = ReceptionEvent(
            rx_timestamp_ns=20_000_000,
            rx_id="SITE_1",
            raw_bytes=GV01_BYTES,
            rssi_dbfs=-14.0,
            snr_db=31.0,
            is_corrupted=False,
        )
        frame_b = ReceptionEvent(
            rx_timestamp_ns=20_040_000,
            rx_id="SITE_1",
            raw_bytes=GV02_BYTES,
            rssi_dbfs=-15.5,  # Delta RSSI = +1.5 dB < 6.0 dB
            snr_db=29.5,
            is_corrupted=False,
        )

        out_a, out_b = engine.apply_collision(frame_a, frame_b)

        assert out_a.is_corrupted
        assert out_a.raw_bytes != GV01_BYTES
        assert compute_syndrome(out_a.raw_bytes) != 0

        assert out_b.is_corrupted
        assert out_b.raw_bytes != GV02_BYTES
        assert compute_syndrome(out_b.raw_bytes) != 0

    def test_stronger_interferer_capture(self, engine: PulseCollisionEngine) -> None:
        """Delta RSSI <= -6.0 dB -> Frame B captures cleanly, Frame A garbled."""
        frame_a = ReceptionEvent(
            rx_timestamp_ns=30_000_000,
            rx_id="SITE_1",
            raw_bytes=GV01_BYTES,
            rssi_dbfs=-20.0,
            snr_db=25.0,
            is_corrupted=False,
        )
        frame_b = ReceptionEvent(
            rx_timestamp_ns=30_030_000,
            rx_id="SITE_1",
            raw_bytes=GV02_BYTES,
            rssi_dbfs=-12.0,  # Delta RSSI = -8.0 dB <= -6.0 dB
            snr_db=33.0,
            is_corrupted=False,
        )

        out_a, out_b = engine.apply_collision(frame_a, frame_b)

        # Frame A corrupted
        assert out_a.is_corrupted
        assert out_a.raw_bytes != GV01_BYTES
        assert compute_syndrome(out_a.raw_bytes) != 0

        # Frame B captures cleanly
        assert not out_b.is_corrupted
        assert out_b.raw_bytes == GV02_BYTES
        assert compute_syndrome(out_b.raw_bytes) == 0

    def test_giv03_non_overlapping_succession(self, engine: PulseCollisionEngine) -> None:
        """GIV-03: Separation > 120 us -> No collision."""
        frame_a = ReceptionEvent(
            rx_timestamp_ns=40_000_000,
            rx_id="SITE_1",
            raw_bytes=GV01_BYTES,
            rssi_dbfs=-12.0,
            snr_db=33.0,
            is_corrupted=False,
        )
        frame_b = ReceptionEvent(
            rx_timestamp_ns=40_125_000,  # 125 us later > 120 us
            rx_id="SITE_1",
            raw_bytes=GV02_BYTES,
            rssi_dbfs=-12.0,
            snr_db=33.0,
            is_corrupted=False,
        )

        out_a, out_b = engine.apply_collision(frame_a, frame_b)

        assert not out_a.is_corrupted
        assert out_a.raw_bytes == GV01_BYTES
        assert not out_b.is_corrupted
        assert out_b.raw_bytes == GV02_BYTES

    def test_resolve_collisions_multi_frame(self, engine: PulseCollisionEngine) -> None:
        events = [
            ReceptionEvent(10_000_000, "S1", GV01_BYTES, -10.0, 35.0, False),
            ReceptionEvent(10_050_000, "S1", GV02_BYTES, -11.0, 34.0, False),  # Collides with #0, |Δ|<6 dB
            ReceptionEvent(20_000_000, "S1", GV01_BYTES, -10.0, 35.0, False),  # Independent
        ]
        resolved = engine.resolve_collisions(events)
        assert len(resolved) == 3
        assert resolved[0].is_corrupted
        assert resolved[1].is_corrupted
        assert not resolved[2].is_corrupted


class TestPoissonFruitGenerator:
    """Verify Poisson FRUIT arrival statistics, valid CRC framing, and RSSI distributions."""

    def test_fruit_rate_zero(self) -> None:
        gen = PoissonFruitGenerator(fruit_rate_hz=0.0)
        events = gen.generate_fruit(duration_s=5.0)
        assert events == []

    def test_fruit_rate_and_poisson_statistics(self) -> None:
        rng = np.random.default_rng(12345)
        gen = PoissonFruitGenerator(fruit_rate_hz=500.0, rng=rng)
        duration_s = 2.0
        events = gen.generate_fruit(duration_s=duration_s)

        # Expected 1000 events; assert within 3 sigma (~ 3 * sqrt(1000) ~ 95)
        assert 800 <= len(events) <= 1200

        # Verify time monotonicity
        timestamps = [e.rx_timestamp_ns for e in events]
        assert timestamps == sorted(timestamps)
        assert timestamps[-1] < int(duration_s * 1e9)

    def test_fruit_payload_valid_crc(self) -> None:
        rng = np.random.default_rng(999)
        gen = PoissonFruitGenerator(fruit_rate_hz=100.0, rng=rng)
        events = gen.generate_fruit(duration_s=1.0)

        for ev in events:
            # Check RSSI and SNR bounds
            assert -40.0 <= ev.rssi_dbfs <= -5.0
            assert ev.snr_db >= 0.0
            assert not ev.is_corrupted

            # If 7 or 14 bytes (Mode S), clean FRUIT must have valid CRC syndrome!
            if len(ev.raw_bytes) in (7, 14):
                assert compute_syndrome(ev.raw_bytes) == 0
                decoded = decode_mode_s(ev.raw_bytes)
                assert decoded.crc_valid


class TestRFChannelModelPipeline:
    """Verify RFChannelModel end-to-end integration and deterministic reproducibility."""

    def test_process_transmissions_clean(self) -> None:
        rng = np.random.default_rng(42)
        channel = RFChannelModel(fruit_rate_hz=0.0, garble_enabled=False, rng=rng)

        sq_events = [
            SquitterEvent(timestamp_s=1.0, raw_bytes=GV01_BYTES, icao24=0x4840D6),
            SquitterEvent(timestamp_s=2.0, raw_bytes=GV02_BYTES, icao24=0x40621D),
        ]
        rx_events = channel.process_transmissions(sq_events)
        assert len(rx_events) == 2
        assert not rx_events[0].is_corrupted
        assert rx_events[0].raw_bytes == GV01_BYTES
        assert not rx_events[1].is_corrupted
        assert rx_events[1].raw_bytes == GV02_BYTES

    def test_process_transmissions_with_fruit_and_garble(self) -> None:
        rng = np.random.default_rng(42)
        channel = RFChannelModel(fruit_rate_hz=500.0, garble_enabled=True, rng=rng)

        # 2 legitimate squitters spaced by 10 ms (10,000,000 ns)
        sq_events = [
            SquitterEvent(timestamp_s=0.1, raw_bytes=GV01_BYTES, icao24=0x4840D6),
            SquitterEvent(timestamp_s=0.2, raw_bytes=GV02_BYTES, icao24=0x40621D),
        ]
        rx_events = channel.process_transmissions(sq_events)

        # Check that output includes transmissions and FRUIT
        assert len(rx_events) > 2
        timestamps = [e.rx_timestamp_ns for e in rx_events]
        assert timestamps == sorted(timestamps)

        # Verify decoding rejects corrupted garbled frames
        clean_count = 0
        corrupted_count = 0
        for ev in rx_events:
            if ev.is_corrupted:
                corrupted_count += 1
                if len(ev.raw_bytes) in (7, 14):
                    decoded = decode_mode_s(ev.raw_bytes)
                    assert not decoded.crc_valid
            else:
                clean_count += 1

        assert clean_count > 0

    def test_deterministic_reproducibility(self) -> None:
        sq_events = [
            SquitterEvent(timestamp_s=0.5, raw_bytes=GV01_BYTES, icao24=0x4840D6),
            SquitterEvent(timestamp_s=0.50005, raw_bytes=GV02_BYTES, icao24=0x40621D),  # Overlapping
        ]

        chan1 = RFChannelModel(fruit_rate_hz=200.0, garble_enabled=True, rng=np.random.default_rng(777))
        chan2 = RFChannelModel(fruit_rate_hz=200.0, garble_enabled=True, rng=np.random.default_rng(777))

        res1 = chan1.process_transmissions(sq_events)
        res2 = chan2.process_transmissions(sq_events)

        assert len(res1) == len(res2)
        assert [e.rx_timestamp_ns for e in res1] == [e.rx_timestamp_ns for e in res2]
        assert [e.raw_bytes for e in res1] == [e.raw_bytes for e in res2]
        assert [e.is_corrupted for e in res1] == [e.is_corrupted for e in res2]
