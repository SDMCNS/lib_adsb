"""Empirical Adversarial Challenge Test Harness for Milestone 1.

Executed by: challenger_enh_m1_1
Target:
- R1: Basemap Default and Cleanup (CARTO elimination & ESRI Dark default)
- R2: Simulation Engine Stability beyond 70s to 150s across all pre-existing scenarios,
      verifying continuous track motion, timestamp advancement, WebSocket wire streaming,
      and autonomous background loop resilience.
"""

from __future__ import annotations

import asyncio
import re
from collections.abc import Generator
from pathlib import Path

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import (
    SimulationConfig,
    SimulationManager,
    SimulationStatus,
    reset_simulation_manager,
)
from adsb.protocol.modes import decode_mode_s

STATIC_DIR = Path(__file__).resolve().parent.parent.parent / "src" / "adsb" / "api" / "static"


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Clean TestClient fixture."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


# ==============================================================================
# 1. R1: Adversarial Basemap Asset Audit & HTTP Delivery
# ==============================================================================


@pytest.mark.tier1
def test_adversarial_scrape_static_assets_zero_carto() -> None:
    """Scrape and parse all files in src/adsb/api/static/ for any CARTO reference or endpoint."""
    assert STATIC_DIR.is_dir(), f"Static directory not found: {STATIC_DIR}"

    all_files = [p for p in STATIC_DIR.rglob("*") if p.is_file()]
    assert len(all_files) >= 5, f"Expected static files, found {len(all_files)}"

    forbidden_patterns = [
        re.compile(r"carto", re.IGNORECASE),
        re.compile(r"cartocdn", re.IGNORECASE),
        re.compile(r"carto_key", re.IGNORECASE),
        re.compile(r"carto_api_key", re.IGNORECASE),
        re.compile(r"basemaps\.cartocdn\.com", re.IGNORECASE),
    ]

    violations: list[str] = []
    for file_path in all_files:
        try:
            content = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue

        for pat in forbidden_patterns:
            matches = pat.findall(content)
            if matches:
                violations.append(
                    f"{file_path.relative_to(STATIC_DIR)} matched pattern '{pat.pattern}': {matches}"
                )

    assert not violations, "CARTO references found in static assets:\n" + "\n".join(violations)


@pytest.mark.tier1
def test_adversarial_leaflet_map_http_delivery_and_esri_default(client: TestClient) -> None:
    """Test frontend delivery via TestClient and verify ESRI World Dark Canvas is default."""
    res = client.get("/js/leaflet_map.js")
    assert res.status_code == 200, f"Expected 200, got {res.status_code}"
    assert "application/javascript" in res.headers.get("content-type", "")

    js_text = res.text

    # Assert strict presence of default layer attachment
    assert "esriDarkLayer.addTo(this.map)" in js_text, (
        "esriDarkLayer.addTo(this.map) MUST be strictly present in leaflet_map.js"
    )

    # Assert ESRI Dark Gray Base URL
    esri_url_frag = "server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile"
    assert esri_url_frag in js_text, f"ESRI tile URL fragment '{esri_url_frag}' missing from JS"

    # Assert zero carto references in response text
    assert "carto" not in js_text.lower(), "CARTO reference found in delivered leaflet_map.js"


# ==============================================================================
# 2. R2: Empirical Simulation to 150s Across All Pre-Existing Scenarios
# ==============================================================================


@pytest.mark.asyncio
@pytest.mark.tier1
@pytest.mark.parametrize(
    "scenario_name, expected_min_tracks",
    [
        ("clean_tma_10_aircraft", 10),
        ("congested_tma_25_aircraft", 25),
        ("fault_and_spoofing_test", 3),
    ],
)
async def test_adversarial_simulation_run_to_150s(
    scenario_name: str, expected_min_tracks: int
) -> None:
    """Run autonomous simulations to 150s across all 3 scenarios and assert kinematic continuity."""
    mgr = SimulationManager(SimulationConfig(scenario_name=scenario_name, seed=42))
    assert mgr.engine is not None

    # Step to 60.0s (baseline before historical 70s stall point)
    await mgr.step(60.0)
    assert mgr.sim_time_s == 60.0

    tracks_60 = {
        t.icao24: (t.lat_deg, t.lon_deg, t.last_seen_s)
        for t in mgr.engine.all_tracks()
        if t.has_position
    }
    assert len(tracks_60) >= expected_min_tracks, (
        f"At t=60s, expected at least {expected_min_tracks} tracks with position, got {len(tracks_60)}"
    )

    # Step to 120.0s (past 70s and 100s mark)
    await mgr.step(60.0)
    assert mgr.sim_time_s == 120.0
    assert mgr.sim_time_s >= 120.0

    tracks_120 = {
        t.icao24: (t.lat_deg, t.lon_deg, t.last_seen_s)
        for t in mgr.engine.all_tracks()
        if t.has_position
    }
    assert len(tracks_120) >= expected_min_tracks, (
        f"At t=120s, expected at least {expected_min_tracks} tracks with position, got {len(tracks_120)}"
    )

    # Assert geodetic coordinates continue changing ([x, y]_120 != [x, y]_60)
    # and last_seen_s advances
    movement_verified = 0
    for icao24, (lat60, lon60, seen60) in tracks_60.items():
        if icao24 in tracks_120:
            lat120, lon120, seen120 = tracks_120[icao24]
            assert seen120 > 60.0, f"Track {icao24:06X} last_seen_s did not advance past 60s"
            assert seen120 > seen60, f"Track {icao24:06X} timestamp did not increase"

            # Check coordinate displacement: aircraft at ~250kt moves >4 NM in 60s (~0.06 deg)
            delta_coord = abs(lat120 - lat60) + abs(lon120 - lon60)
            assert delta_coord > 0.005, (
                f"Track {icao24:06X} coordinates frozen between 60s and 120s: "
                f"lat={lat60}->{lat120}, lon={lon60}->{lon120}"
            )
            movement_verified += 1

    assert movement_verified >= expected_min_tracks

    # Step further to 150.0s (full 150s challenge)
    await mgr.step(30.0)
    assert mgr.sim_time_s == 150.0

    tracks_150 = {
        t.icao24: (t.lat_deg, t.lon_deg, t.last_seen_s)
        for t in mgr.engine.all_tracks()
        if t.has_position
    }
    assert len(tracks_150) >= expected_min_tracks

    for icao24, (lat120, lon120, seen120) in tracks_120.items():
        if icao24 in tracks_150:
            lat150, lon150, seen150 = tracks_150[icao24]
            assert seen150 >= 140.0, (
                f"Track {icao24:06X} last_seen_s {seen150} not close to current sim time 150s"
            )
            assert seen150 > seen120
            delta_coord_150 = abs(lat150 - lat120) + abs(lon150 - lon120)
            assert delta_coord_150 > 0.002, (
                f"Track {icao24:06X} coordinates stalled between 120s and 150s: "
                f"lat={lat120}->{lat150}, lon={lon120}->{lon150}"
            )


# ==============================================================================
# 3. R2: Autonomous Background Loop Resilience (_run_loop())
# ==============================================================================


@pytest.mark.asyncio
@pytest.mark.tier2
async def test_adversarial_autonomous_run_loop_stability() -> None:
    """Verify SimulationManager._run_loop runs autonomously across 70s without unhandled exceptions."""
    mgr = SimulationManager(
        SimulationConfig(
            scenario_name="clean_tma_10_aircraft",
            speed_multiplier=100.0,  # 100x acceleration
            seed=42,
        )
    )

    # Pre-advance to 65s
    await mgr.step(65.0)
    assert mgr.sim_time_s == 65.0

    # Start autonomous background task
    mgr.start()
    assert mgr.status == SimulationStatus.RUNNING
    assert mgr._sim_task is not None

    # Run for 0.7s wall-clock time -> advances ~70s sim time (from 65s to ~135s)
    await asyncio.sleep(0.7)

    # Verify task did not terminate with an unhandled exception
    sim_task = mgr._sim_task
    assert sim_task is not None
    assert not sim_task.done(), (
        f"_sim_task terminated unexpectedly! Exception: {sim_task.exception() if sim_task.done() else None}"
    )

    # Check sim_time_s advanced well past 70s and beyond 120s
    assert mgr.sim_time_s >= 120.0, (
        f"Expected sim_time_s >= 120.0, got {mgr.sim_time_s}"
    )

    # Verify tracks actively exist and have recent timestamps
    assert mgr.engine is not None
    active_tracks = mgr.engine.all_tracks()
    assert len(active_tracks) >= 10
    recent_tracks = [t for t in active_tracks if t.last_seen_s >= 110.0]
    assert len(recent_tracks) >= 10

    # Stop simulation gracefully
    pause_res = mgr.pause()
    assert pause_res["status"] == "PAUSED"


# ==============================================================================
# 4. R2: WebSocket Wire Frame and Telemetry Streaming Beyond 70s to 150s
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier3
def test_adversarial_websocket_wire_broadcasting_beyond_70s(client: TestClient) -> None:
    """Verify WebSocket /ws/wire continues broadcasting valid Mode S frames past 70s up to 150s."""
    # Fast forward simulation to 75.0s
    client.post("/api/v1/simulation/step", json={"step_s": 75.0})

    with client.websocket_connect("/ws/wire?format=AVR") as ws:
        # Step forward 5.0s at t=75s -> receives frames at t in [75, 80]
        client.post("/api/v1/simulation/step", json={"step_s": 5.0})
        frame_80 = ws.receive_text()
        assert frame_80.startswith("*") and frame_80.endswith(";\r\n")

        # Extract hex payload and verify Mode S CRC
        hex_data_80 = frame_80.strip()[1:-1]
        decoded_80 = decode_mode_s(bytes.fromhex(hex_data_80))
        assert decoded_80.crc_valid is True

        # Fast forward to 120s
        client.post("/api/v1/simulation/step", json={"step_s": 40.0})
        # Step forward 2.0s at t=120s
        client.post("/api/v1/simulation/step", json={"step_s": 2.0})
        frame_122 = ws.receive_text()
        assert frame_122.startswith("*") and frame_122.endswith(";\r\n")
        hex_data_122 = frame_122.strip()[1:-1]
        decoded_122 = decode_mode_s(bytes.fromhex(hex_data_122))
        assert decoded_122.crc_valid is True

        # Fast forward to 150s
        client.post("/api/v1/simulation/step", json={"step_s": 28.0})
        # Step forward 2.0s at t=150s
        client.post("/api/v1/simulation/step", json={"step_s": 2.0})
        frame_152 = ws.receive_text()
        assert frame_152.startswith("*") and frame_152.endswith(";\r\n")
        hex_data_152 = frame_152.strip()[1:-1]
        decoded_152 = decode_mode_s(bytes.fromhex(hex_data_152))
        assert decoded_152.crc_valid is True


@pytest.mark.integration
@pytest.mark.tier3
def test_adversarial_websocket_telemetry_streaming_to_150s(client: TestClient) -> None:
    """Verify WebSocket /ws/telemetry delivers moving track states up to 150s."""
    with client.websocket_connect("/ws/telemetry") as ws:
        # Step to 120s
        res = client.post("/api/v1/simulation/step", json={"step_s": 120.0})
        assert res.status_code == 200
        msg_120 = ws.receive_json()
        assert msg_120["type"] == "telemetry"
        assert msg_120["sim_time_s"] >= 120.0
        tracks_120 = msg_120["tracks"]
        assert len(tracks_120) >= 10
        recent_120 = [t for t in tracks_120 if t["last_seen_s"] >= 115.0]
        assert len(recent_120) >= 10

        # Step to 150s
        res = client.post("/api/v1/simulation/step", json={"step_s": 30.0})
        assert res.status_code == 200
        msg_150 = ws.receive_json()
        assert msg_150["type"] == "telemetry"
        assert msg_150["sim_time_s"] >= 150.0
        tracks_150 = msg_150["tracks"]
        assert len(tracks_150) >= 10
        recent_150 = [t for t in tracks_150 if t["last_seen_s"] >= 145.0]
        assert len(recent_150) >= 10
