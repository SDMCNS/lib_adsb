"""Adversarial and stress test harness for UAT Reed-Solomon FEC and Geodesy.

Targeting:
1. Reed-Solomon RS(30,18) error correction limits (1..6 errors) and uncorrectable detection (>=7 errors).
2. Reed-Solomon RS(48,34) error correction limits (1..7 errors) and uncorrectable detection (>=8 errors).
3. Bowring ECEF <-> Geodetic geodesy at poles (+/-90 deg, cardinal longitudes), high altitudes (100 km), and deep subsurface (-1000 m).
4. Local ENU coordinate rotation matrix orthonormality and multi-scale roundtrip conversions.
"""

from __future__ import annotations

import math
import random

import numpy as np
import pytest

from adsb.core.coordinates import (
    WGS84_B_M,
    ecef_to_geodetic,
    enu_rotation_matrix,
    enu_to_geodetic,
    geodetic_to_ecef,
    geodetic_to_enu,
)
from adsb.protocol.uat import (
    UAT_BASIC_RS,
    UAT_LONG_RS,
    ReedSolomonCodec,
    UATReedSolomonError,
)


class TestUATReedSolomonStress:
    """Stress tests and boundary condition verification for UAT Reed-Solomon FEC."""

    @pytest.mark.parametrize(
        "msg_pattern",
        [
            b"123456789012345678",  # Standard alphanumeric
            b"\x00" * 18,  # All zeros
            b"\xff" * 18,  # All ones
            b"\xaa\x55" * 9,  # Alternating bit patterns
            bytes(range(18)),  # Ascending sequence
        ],
    )
    def test_rs30_18_exact_error_correction_limits(self, msg_pattern: bytes) -> None:
        """Assert RS(30,18) perfectly corrects all error counts from 1 to 6."""
        codec = UAT_BASIC_RS
        codeword = bytearray(msg_pattern + codec.encode(msg_pattern))
        assert len(codeword) == 30

        for n_err in range(1, 7):
            rng = random.Random(42 + n_err * 31 + hash(msg_pattern) % 1000)
            for _ in range(25):
                corrupted = bytearray(codeword)
                error_indices = rng.sample(range(30), n_err)
                for idx in error_indices:
                    # Ensure the byte is modified by at least 1 bit
                    corrupted[idx] ^= rng.randint(1, 255)

                decoded, err_count = codec.decode(bytes(corrupted))
                assert decoded == msg_pattern, f"Failed correcting {n_err} errors in {msg_pattern!r}"
                assert err_count == n_err, f"Reported {err_count} errors, expected {n_err}"

    def test_rs30_18_uncorrectable_detection(self) -> None:
        """Assert RS(30,18) detects uncorrectable errors (7..14 errors) without crashing."""
        codec = UAT_BASIC_RS
        msg = b"UAT BASIC TEST MSG"[:18]
        codeword = bytearray(msg + codec.encode(msg))

        for n_err in range(7, 15):
            rng = random.Random(1000 + n_err)
            for _ in range(50):
                corrupted = bytearray(codeword)
                error_indices = rng.sample(range(30), n_err)
                for idx in error_indices:
                    corrupted[idx] ^= rng.randint(1, 255)

                with pytest.raises(UATReedSolomonError):
                    codec.decode(bytes(corrupted))

    @pytest.mark.parametrize(
        "msg_pattern",
        [
            b"UAT LONG PAYLOAD TEST 34 BYTES!!--",  # Exactly 34 bytes
            b"\x00" * 34,
            b"\xff" * 34,
            b"\x5a\xa5" * 17,
            bytes(range(34)),
        ],
    )
    def test_rs48_34_exact_error_correction_limits(self, msg_pattern: bytes) -> None:
        """Assert RS(48,34) perfectly corrects all error counts from 1 to 7."""
        assert len(msg_pattern) == 34
        codec = UAT_LONG_RS
        codeword = bytearray(msg_pattern + codec.encode(msg_pattern))
        assert len(codeword) == 48

        for n_err in range(1, 8):
            rng = random.Random(123 + n_err * 17 + hash(msg_pattern) % 1000)
            for _ in range(25):
                corrupted = bytearray(codeword)
                error_indices = rng.sample(range(48), n_err)
                for idx in error_indices:
                    corrupted[idx] ^= rng.randint(1, 255)

                decoded, err_count = codec.decode(bytes(corrupted))
                assert decoded == msg_pattern, f"Failed correcting {n_err} errors in {msg_pattern!r}"
                assert err_count == n_err, f"Reported {err_count} errors, expected {n_err}"

    def test_rs48_34_uncorrectable_detection(self) -> None:
        """Assert RS(48,34) detects uncorrectable errors (8..16 errors) without crashing."""
        codec = UAT_LONG_RS
        msg = b"0123456789012345678901234567890123"  # Exactly 34 bytes
        assert len(msg) == 34
        codeword = bytearray(msg + codec.encode(msg))
        assert len(codeword) == 48

        for n_err in range(8, 17):
            rng = random.Random(2000 + n_err)
            for _ in range(50):
                corrupted = bytearray(codeword)
                error_indices = rng.sample(range(48), n_err)
                for idx in error_indices:
                    corrupted[idx] ^= rng.randint(1, 255)

                with pytest.raises(UATReedSolomonError):
                    codec.decode(bytes(corrupted))

    def test_rs_burst_errors_and_partitions(self) -> None:
        """Test burst corruptions (contiguous slices) and partition-specific corruptions."""
        codec = UAT_BASIC_RS
        msg = b"BURST_TEST_PAYLOAD"
        parity = codec.encode(msg)
        codeword = bytearray(msg + parity)

        # 1. Contiguous 6-byte burst in data
        c1 = bytearray(codeword)
        for i in range(6):
            c1[i] ^= 0xAA
        dec1, cnt1 = codec.decode(bytes(c1))
        assert dec1 == msg and cnt1 == 6

        # 2. Contiguous 6-byte burst straddling data and parity (bytes 15..20)
        c2 = bytearray(codeword)
        for i in range(15, 21):
            c2[i] ^= 0x55
        dec2, cnt2 = codec.decode(bytes(c2))
        assert dec2 == msg and cnt2 == 6

        # 3. Contiguous 6-byte burst purely in parity (bytes 24..29)
        c3 = bytearray(codeword)
        for i in range(24, 30):
            c3[i] ^= 0xFF
        dec3, cnt3 = codec.decode(bytes(c3))
        assert dec3 == msg and cnt3 == 6

        # 4. Exceeding burst of 7 bytes straddling data and parity (must fail)
        c4 = bytearray(codeword)
        for i in range(15, 22):
            c4[i] ^= 0x55
        with pytest.raises(UATReedSolomonError):
            codec.decode(bytes(c4))

    def test_rs_codec_malformed_inputs(self) -> None:
        """Verify handling of invalid or undersized codewords."""
        codec = ReedSolomonCodec(nsym=12, fcr=120)

        # Zero-length codeword
        with pytest.raises(ValueError, match="Codeword too short"):
            codec.decode(b"")

        # Codeword length exactly equal to nsym (k == 0)
        with pytest.raises(ValueError, match="Codeword too short"):
            codec.decode(bytes(12))

        # Codeword length strictly less than nsym (k < 0)
        with pytest.raises(ValueError, match="Codeword too short"):
            codec.decode(bytes(6))

        # Arbitrary corrupted shortened frame with uncorrectable syndromes
        with pytest.raises(UATReedSolomonError):
            codec.decode(b"too_short_bytes")


class TestGeodesyBowringStress:
    """Stress tests for Bowring Geodetic <-> ECEF transformations at extreme boundaries."""

    @pytest.mark.parametrize("lat", [90.0, -90.0])
    @pytest.mark.parametrize("lon", [0.0, 90.0, 180.0, -180.0])
    @pytest.mark.parametrize("alt", [-1000.0, 0.0, 1000.0, 100_000.0])
    def test_poles_cardinal_longitudes_and_altitudes(
        self, lat: float, lon: float, alt: float
    ) -> None:
        """Assert exact polar coordinates roundtrip with sub-nanometer 3D position error."""
        x, y, z = geodetic_to_ecef(lat, lon, alt)
        r_lat, _r_lon, r_alt = ecef_to_geodetic(x, y, z)

        # Latitude and altitude must match exactly
        assert math.isclose(r_lat, lat, abs_tol=1e-8)
        assert math.isclose(r_alt, alt, abs_tol=1e-4)

        # 3D Cartesian position must match within 1 micron
        rx, ry, rz = geodetic_to_ecef(r_lat, 0.0, r_alt)
        err_3d = math.sqrt((rx - x) ** 2 + (ry - y) ** 2 + (rz - z) ** 2)
        assert err_3d < 1e-6

    def test_near_polar_sub_micron_transition(self) -> None:
        """Verify numerical stability across the p = 1e-6 polar singularity threshold."""
        for sign in (1.0, -1.0):
            z = sign * (WGS84_B_M + 500.0)
            # Test distances from 1e-8 meters up to 10 meters from polar axis
            for p_val in (1e-8, 5e-7, 9.99e-7, 1e-6, 1.01e-6, 1e-5, 1e-3, 1.0, 10.0):
                angle = math.radians(37.5)
                x = p_val * math.cos(angle)
                y = p_val * math.sin(angle)

                lat, lon, alt = ecef_to_geodetic(x, y, z)
                assert not math.isnan(lat) and not math.isnan(lon) and not math.isnan(alt)
                assert math.isclose(alt, 500.0, abs_tol=1e-3)

                rx, ry, rz = geodetic_to_ecef(lat, lon, alt)
                err_3d = math.sqrt((rx - x) ** 2 + (ry - y) ** 2 + (rz - z) ** 2)
                assert err_3d < 1e-5

    @pytest.mark.parametrize(
        ("lat", "lon", "alt"),
        [
            (0.0, 0.0, 100_000.0),  # Equator 100 km (Karman line)
            (45.0, -75.0, 100_000.0),  # Mid-lat 100 km
            (89.99, 45.0, 100_000.0),  # Sub-polar 100 km
            (0.0, 0.0, 500_000.0),  # LEO 500 km
            (45.0, 90.0, 1_000_000.0),  # LEO 1,000 km
        ],
    )
    def test_high_altitudes_troposphere_to_space(
        self, lat: float, lon: float, alt: float
    ) -> None:
        """Assert Bowring transformation retains millimeter accuracy up to space altitudes."""
        x, y, z = geodetic_to_ecef(lat, lon, alt)
        r_lat, r_lon, r_alt = ecef_to_geodetic(x, y, z)

        assert math.isclose(r_lat, lat, abs_tol=1e-7)
        assert math.isclose(r_lon, lon, abs_tol=1e-7)
        assert math.isclose(r_alt, alt, abs_tol=1e-3)

        rx, ry, rz = geodetic_to_ecef(r_lat, r_lon, r_alt)
        err_3d = math.sqrt((rx - x) ** 2 + (ry - y) ** 2 + (rz - z) ** 2)
        assert err_3d < 1e-4

    @pytest.mark.parametrize(
        ("lat", "lon", "alt"),
        [
            (0.0, 0.0, -1000.0),  # Equator -1000 m subsurface
            (45.0, 45.0, -1000.0),  # Mid-lat -1000 m subsurface
            (90.0, 0.0, -1000.0),  # North Pole -1000 m subsurface
            (-90.0, 0.0, -1000.0),  # South Pole -1000 m subsurface
            (11.35, 142.2, -11_000.0),  # Mariana Trench Challenger Deep (-11 km)
        ],
    )
    def test_deep_subsurface_altitudes(self, lat: float, lon: float, alt: float) -> None:
        """Assert Bowring transformation handles subterranean and oceanic trench depths."""
        x, y, z = geodetic_to_ecef(lat, lon, alt)
        r_lat, r_lon, r_alt = ecef_to_geodetic(x, y, z)

        assert math.isclose(r_lat, lat, abs_tol=1e-7)
        if abs(lat) < 90.0:
            assert math.isclose(r_lon, lon, abs_tol=1e-7)
        assert math.isclose(r_alt, alt, abs_tol=1e-3)

        rx, ry, rz = geodetic_to_ecef(r_lat, r_lon, r_alt)
        err_3d = math.sqrt((rx - x) ** 2 + (ry - y) ** 2 + (rz - z) ** 2)
        assert err_3d < 1e-4


class TestLocalENUStress:
    """Stress tests for Local ENU rotation matrix orthonormality and roundtrip conversions."""

    def test_enu_rotation_matrix_orthonormality_global(self) -> None:
        """Assert R_ECEF->ENU is orthonormal (R * R^T = I) and det(R) = +1.0 globally."""
        lats = [-90.0, -89.99, -60.0, -45.0, -15.0, 0.0, 15.0, 45.0, 60.0, 89.99, 90.0]
        lons = [-180.0, -135.0, -90.0, -45.0, 0.0, 45.0, 90.0, 135.0, 180.0]

        identity = np.eye(3, dtype=np.float64)

        for lat in lats:
            for lon in lons:
                r = enu_rotation_matrix(lat, lon)
                assert r.shape == (3, 3)

                # Orthonormality R @ R.T == I
                ortho_err = float(np.max(np.abs(r @ r.T - identity)))
                assert ortho_err < 1e-12, f"Orthonormality failed at lat={lat}, lon={lon}: {ortho_err}"

                # Determinant == +1.0 (Right-handed frame)
                det_val = float(np.linalg.det(r))
                assert math.isclose(det_val, 1.0, abs_tol=1e-12), f"Det != 1.0 at lat={lat}, lon={lon}: {det_val}"

    @pytest.mark.parametrize(
        ("origin_name", "lat0", "lon0", "alt0"),
        [
            ("Equator Prime Meridian", 0.0, 0.0, 0.0),
            ("North Pole", 90.0, 0.0, 0.0),
            ("South Pole", -90.0, 0.0, 0.0),
            ("Antimeridian Equator", 0.0, 180.0, 0.0),
            ("JFK Airport", 40.6413, -73.7781, 10.0),
            ("Himalayan High Altitude", 27.9881, 86.9250, 8848.0),
        ],
    )
    def test_enu_roundtrip_multi_scale_displacements(
        self, origin_name: str, lat0: float, lon0: float, alt0: float
    ) -> None:
        """Assert ENU roundtrip conversions preserve coordinates across multi-scale displacements."""
        displacements = [
            (0.0, 0.0, 0.0),  # Origin
            (0.5, -0.5, 0.2),  # Sub-meter
            (1500.0, -2500.0, 450.0),  # Terminal area
            (50_000.0, 120_000.0, 10_000.0),  # En-route sector
            (-250_000.0, 350_000.0, 100_000.0),  # Regional 100 km space
            (1000.0, 1000.0, -1000.0),  # Deep subsurface displacement
        ]

        for de, dn, du in displacements:
            t_lat, t_lon, t_alt = enu_to_geodetic(de, dn, du, lat0, lon0, alt0)
            re, rn, ru = geodetic_to_enu(t_lat, t_lon, t_alt, lat0, lon0, alt0)

            err = math.sqrt((re - de) ** 2 + (rn - dn) ** 2 + (ru - du) ** 2)
            assert err < 1e-4, f"ENU roundtrip error {err:.2e} m at {origin_name} with ({de}, {dn}, {du})"


class TestGreatCircleExtremaStress:
    """Stress tests for great circle navigation primitives across extreme boundaries."""

    def test_antipodal_haversine_limits(self) -> None:
        """Assert haversine distance handles exact antipodal points without domain errors or NaN."""
        from adsb.core.coordinates import EARTH_MEAN_RADIUS_M
        from adsb.core.geodesy import haversine_distance

        expected_pi_r = math.pi * EARTH_MEAN_RADIUS_M

        # Equator antipodes (0, 0) and (0, 180)
        d1 = haversine_distance(0.0, 0.0, 0.0, 180.0)
        assert math.isclose(d1, expected_pi_r, rel_tol=1e-7)

        # Poles antipodes (+90, 0) and (-90, 0)
        d2 = haversine_distance(90.0, 0.0, -90.0, 0.0)
        assert math.isclose(d2, expected_pi_r, rel_tol=1e-7)

        # Arbitrary antipodal pair: (lat, lon) and (-lat, lon + 180)
        d3 = haversine_distance(37.6188, -122.3750, -37.6188, 57.6250)
        assert math.isclose(d3, expected_pi_r, rel_tol=1e-7)

    def test_dateline_bearing_and_destination_continuity(self) -> None:
        """Assert bearing and destination point calculations smoothly cross the 180th meridian."""
        from adsb.core.geodesy import destination_point, initial_bearing

        # Heading due East crossing 180 meridian (179 -> -179)
        brg_east = initial_bearing(0.0, 179.0, 0.0, -179.0)
        assert math.isclose(brg_east, 90.0, abs_tol=1e-5)

        # Heading due West crossing -180 meridian (-179 -> 179)
        brg_west = initial_bearing(0.0, -179.0, 0.0, 179.0)
        assert math.isclose(brg_west, 270.0, abs_tol=1e-5)

        # Destination point 2 degrees East of 179E should land at -179W
        dest_lat, dest_lon = destination_point(0.0, 179.0, 222_389.85, 90.0)
        assert math.isclose(dest_lat, 0.0, abs_tol=1e-4)
        assert math.isclose(dest_lon, -179.0, abs_tol=1e-4)

    def test_cross_and_along_track_extrema(self) -> None:
        """Assert cross-track and along-track formulas maintain exact sign conventions at boundaries."""
        from adsb.core.geodesy import along_track_distance, cross_track_distance

        # Equator path A->B from (0, 0) to (0, 90)
        # Point North at (10, 45) is Left of track -> negative cross-track
        xt_north = cross_track_distance(0.0, 0.0, 0.0, 90.0, 10.0, 45.0)
        assert xt_north < 0.0

        # Point South at (-10, 45) is Right of track -> positive cross-track
        xt_south = cross_track_distance(0.0, 0.0, 0.0, 90.0, -10.0, 45.0)
        assert xt_south > 0.0

        # Along-track projection for point at 45 deg longitude
        at_mid = along_track_distance(0.0, 0.0, 0.0, 90.0, 10.0, 45.0)
        assert at_mid > 0.0

