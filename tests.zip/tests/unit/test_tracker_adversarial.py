"""Adversarial stress-test suite for Multi-Target Stateful Tracking Engine (adsb.tracker).

Empirical verification covers:
1. 7-State Local ENU IMM Kalman Filter under extreme kinematics:
   - 60-degree banked turn, S-turns, sudden stop / extreme acceleration.
   - Mode probability dynamics: mu_CT > 0.55 during turn, mu_CV > 0.70 during straight flight.
   - Covariance positive semi-definiteness (eigenvalues >= 0) via Joseph-form update.
2. Stateful CPR Resolution edge cases:
   - Out-of-order squitters, prolonged dropouts (> 10s), rapid surface <-> airborne transitions.
   - Exact latitude zone straddle across 51.893425 deg (safe suppression, no coordinate spikes).
   - Equatorial (0 deg) and Anti-Meridian (180 deg) crossings.
3. Track Lifecycle & Anomaly Detection:
   - 500 fake single-squitter background flood (0 CONFIRMED tracks).
   - Complete lifecycle state machine transitions (TENTATIVE -> CONFIRMED -> COASTING -> DELETED).
   - Anomaly triggers: KINEMATIC_TELEPORT, STALE_GPS_LATCH, ALTITUDE_CLIFF_GILLHAM, RF_PHYSICAL_SPOOF.
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from adsb.protocol.cpr import (
    encode_cpr_airborne,
    encode_cpr_surface,
    nl_lat,
)
from adsb.protocol.modes import DecodedModeSMessage
from adsb.tracker import (
    AnomalyDetector,
    IMMEstimator,
    StatefulCPRResolver,
    TrackingEngine,
    TrackLifecycleManager,
    TrackState,
)

# ==============================================================================
# Task 1: 7-State Local ENU IMM Kalman Filter Stress Tests
# ==============================================================================


class TestIMMFilterAdversarial:
    """Adversarial kinematics and numerical stability tests for IMMEstimator."""

    def test_high_g_banked_turn_60_degree(self) -> None:
        """Stress-test high-g maneuvering: 60-degree banked turn at 200 m/s (~390 kt).

        Kinematics:
            tan(phi) = (v * omega) / g -> omega = (g * tan(60 deg)) / v ~ 0.0849 rad/s (~4.87 deg/s).
            Load factor n = 1 / cos(60 deg) = 2.0g.
            Centripetal acceleration a_c = v * omega ~ 17.0 m/s^2 (~1.73g).
        """
        imm = IMMEstimator(e0=0.0, n0=0.0, u0=1000.0, ve0=200.0, vn0=0.0, vu0=0.0)
        dt = 1.0

        # Phase 1: 20 seconds of straight flight at 200 m/s
        for _ in range(20):
            imm.predict(dt)
            imm.update_velocity(200.0, 0.0, 0.0, sigma_v=1.0)

        # Straight flight must be heavily dominated by Constant Velocity model
        assert imm.mode_probability_cv > 0.70, (
            f"Expected mu_CV > 0.70 during straight flight, got {imm.mode_probability_cv:.3f}"
        )
        assert imm.mode_probability_turn < 0.30

        # Phase 2: 30 seconds of 60-degree banked turn (omega = 0.0849 rad/s)
        heading_rad = 0.0
        omega = 0.0849
        turn_mu_ct: list[float] = []

        for _ in range(30):
            heading_rad += omega * dt
            ve = 200.0 * math.cos(heading_rad)
            vn = 200.0 * math.sin(heading_rad)
            imm.predict(dt)
            imm.update_velocity(ve, vn, 0.0, sigma_v=1.0)
            turn_mu_ct.append(imm.mode_probability_turn)

        # Turn mode probability must peak and maintain high confidence
        max_mu_ct = max(turn_mu_ct)
        mean_mu_ct = float(np.mean(turn_mu_ct[5:]))  # After filter locks onto turn
        assert max_mu_ct > 0.55, f"Expected peak mu_CT > 0.55, got {max_mu_ct:.3f}"
        assert mean_mu_ct > 0.55, f"Expected sustained mean mu_CT > 0.55, got {mean_mu_ct:.3f}"

        # Phase 3: 20 seconds of straight recovery along current tangent heading
        for _ in range(20):
            ve = 200.0 * math.cos(heading_rad)
            vn = 200.0 * math.sin(heading_rad)
            imm.predict(dt)
            imm.update_velocity(ve, vn, 0.0, sigma_v=1.0)

        # Mode probability must recover back to CV (> 0.70)
        assert imm.mode_probability_cv > 0.70, (
            f"Expected mu_CV to recover > 0.70 after turn, got {imm.mode_probability_cv:.3f}"
        )

    def test_rapid_s_turns(self) -> None:
        """Stress-test alternating S-turns (+0.10 rad/s then -0.10 rad/s)."""
        imm = IMMEstimator(e0=0.0, n0=0.0, u0=2000.0, ve0=150.0, vn0=0.0, vu0=0.0)
        dt = 1.0
        heading = 0.0

        # 10s left turn (+0.10 rad/s)
        for _ in range(10):
            heading += 0.10 * dt
            ve = 150.0 * math.cos(heading)
            vn = 150.0 * math.sin(heading)
            imm.predict(dt)
            imm.update_velocity(ve, vn, 0.0, sigma_v=1.0)

        assert imm.mode_probability_turn > 0.55

        # 10s right turn (-0.10 rad/s reversal)
        for _ in range(10):
            heading -= 0.10 * dt
            ve = 150.0 * math.cos(heading)
            vn = 150.0 * math.sin(heading)
            imm.predict(dt)
            imm.update_velocity(ve, vn, 0.0, sigma_v=1.0)

        # Filter must remain stable and responsive
        assert not np.any(np.isnan(imm.state))
        assert not np.any(np.isnan(imm.covariance))
        assert np.all(np.linalg.eigvalsh(imm.covariance) > 0)

    def test_sudden_extreme_acceleration_and_deceleration(self) -> None:
        """Stress-test sudden stop (-50 m/s^2) and sudden acceleration (+40 m/s^2)."""
        imm = IMMEstimator(e0=0.0, n0=0.0, u0=500.0, ve0=250.0, vn0=0.0, vu0=0.0)

        # Extreme deceleration: 250 m/s -> 0 m/s in 5s
        for step in range(5):
            ve = 250.0 - 50.0 * (step + 1)
            imm.predict(1.0)
            imm.update_velocity(ve, 0.0, 0.0, sigma_v=2.0)
            assert not np.any(np.isnan(imm.state))
            assert not np.any(np.isinf(imm.state))

        # Extreme acceleration: 0 m/s -> 200 m/s in 5s
        for step in range(5):
            ve = 40.0 * (step + 1)
            imm.predict(1.0)
            imm.update_velocity(ve, 0.0, 0.0, sigma_v=2.0)
            assert not np.any(np.isnan(imm.state))
            assert not np.any(np.isinf(imm.state))

        evals = np.linalg.eigvalsh(imm.covariance)
        assert np.all(evals > 0)

    def test_covariance_positive_semidefinite_joseph_form(self) -> None:
        """Verify Joseph-form covariance update maintains positive semi-definiteness under extreme noise."""
        rng = np.random.default_rng(1337)
        imm = IMMEstimator(e0=0.0, n0=0.0, u0=1000.0, ve0=100.0, vn0=50.0, vu0=0.0)

        for _ in range(100):
            dt = float(rng.uniform(0.1, 5.0))
            imm.predict(dt)

            # High noise scaling: up to 10,000 meters for position, 1,000 m/s for velocity
            sigma_h = float(10.0 ** rng.uniform(0.0, 4.0))
            sigma_v = float(10.0 ** rng.uniform(0.0, 3.0))

            noise_pos = rng.normal(0.0, sigma_h, 3)
            imm.update_position(float(noise_pos[0]), float(noise_pos[1]), 1000.0 + float(noise_pos[2]), sigma_h=sigma_h)

            noise_vel = rng.normal(0.0, sigma_v, 3)
            imm.update_velocity(100.0 + float(noise_vel[0]), 50.0 + float(noise_vel[1]), float(noise_vel[2]), sigma_v=sigma_v)

            cov = imm.covariance
            evals = np.linalg.eigvalsh(cov)
            # Eigenvalues must be non-negative (within float64 precision of max eigenvalue)
            assert np.all(evals >= -1e-12 * np.max(evals)), f"Negative eigenvalue detected: {np.min(evals)}"
            assert not np.any(np.isnan(cov))


# ==============================================================================
# Task 2: Stateful CPR Resolution Stress Tests
# ==============================================================================


class TestStatefulCPRAdversarial:
    """Adversarial boundary and temporal desynchronization tests for StatefulCPRResolver."""

    def test_out_of_order_and_delayed_cpr_squitters(self) -> None:
        """Test out-of-order arrival and prolonged dropouts (> 10s airborne window)."""
        resolver = StatefulCPRResolver()
        e_cpr = encode_cpr_airborne(52.0, 4.0, 0)
        o_cpr = encode_cpr_airborne(52.0, 4.0, 1)

        # 1. Prolonged dropout (> 10.0s) on initial resolution
        resolver.resolve_position(0x100001, e_cpr[0], e_cpr[1], 0, 0.0)
        # Arrives at t = 12.0s (> 10s maximum airborne window)
        pos_late = resolver.resolve_position(0x100001, o_cpr[0], o_cpr[1], 1, 12.0)
        assert pos_late is None, "Should drop pairing when dt > 10.0s"

        # 2. Reverse order: Odd frame received first, then Even frame
        resolver.resolve_position(0x100002, o_cpr[0], o_cpr[1], 1, 20.0)
        pos_rev = resolver.resolve_position(0x100002, e_cpr[0], e_cpr[1], 0, 20.8)
        assert pos_rev is not None, "Odd frame followed by Even frame should resolve correctly"
        assert pos_rev[0] == pytest.approx(52.0, abs=1e-3)
        assert pos_rev[1] == pytest.approx(4.0, abs=1e-3)

        # 3. Out-of-order timestamp where second frame has older timestamp with dt > 10s
        resolver.resolve_position(0x100003, e_cpr[0], e_cpr[1], 0, 30.0)
        pos_ooo = resolver.resolve_position(0x100003, o_cpr[0], o_cpr[1], 1, 15.0)
        assert pos_ooo is None, "Out-of-order frame with dt > 10s must be dropped"

    def test_rapid_surface_airborne_transitions(self) -> None:
        """Verify rapid touch-and-go surface <-> airborne frames do not corrupt CPR pairing."""
        resolver = StatefulCPRResolver(station_ref_lat=52.0, station_ref_lon=4.0)

        # Surface Even frame at t = 0.0s
        surf_e = encode_cpr_surface(52.001, 4.001, 0)
        pos_s = resolver.resolve_position(0x200001, surf_e[0], surf_e[1], 0, 0.0, on_ground=True)
        assert pos_s is None

        # Airborne Odd frame arrives 0.2s later
        air_o = encode_cpr_airborne(52.002, 4.002, 1)
        pos_mix = resolver.resolve_position(0x200001, air_o[0], air_o[1], 1, 0.2, on_ground=False)
        assert pos_mix is None, "Must NEVER pair a surface frame with an airborne frame"

        # Subsequent Airborne Even frame arrives 0.5s later
        air_e = encode_cpr_airborne(52.002, 4.002, 0)
        pos_air = resolver.resolve_position(0x200001, air_e[0], air_e[1], 0, 0.7, on_ground=False)
        assert pos_air is not None
        assert pos_air[0] == pytest.approx(52.002, abs=1e-3)
        assert pos_air[1] == pytest.approx(4.002, abs=1e-3)

    def test_latitude_zone_straddle_at_51_893425_deg(self) -> None:
        """Verify latitude zone straddle across 51.893425 deg transition boundary is safely handled."""
        # 51.89342469... deg is exact DO-260B boundary where NL changes between 37 and 36
        lat_south = 51.8933247  # NL = 37
        lat_north = 51.8935247  # NL = 36
        lon = 4.0

        assert nl_lat(lat_south) == 37
        assert nl_lat(lat_north) == 36

        e_cpr = encode_cpr_airborne(lat_south, lon, 0)
        o_cpr = encode_cpr_airborne(lat_north, lon, 1)

        # Case A: Uninitialized track straddling boundary -> Must suppress false coordinate spike
        resolver = StatefulCPRResolver()
        resolver.resolve_position(0x300001, e_cpr[0], e_cpr[1], 0, 0.0)
        pos_uninit = resolver.resolve_position(0x300001, o_cpr[0], o_cpr[1], 1, 1.0)
        assert pos_uninit is None, "Uninitialized global straddle must return None"
        assert resolver.get_cpr_state(0x300001).zone_straddle_detected is True

        # Case B: Established track straddling boundary -> Must fall back cleanly to local CPR
        resolver2 = StatefulCPRResolver()
        init_e = encode_cpr_airborne(51.890, lon, 0)
        init_o = encode_cpr_airborne(51.890, lon, 1)
        resolver2.resolve_position(0x300002, init_e[0], init_e[1], 0, 0.0)
        resolver2.resolve_position(0x300002, init_o[0], init_o[1], 1, 0.5)
        assert resolver2.has_position(0x300002) is True

        # Now send straddling pair
        resolver2.resolve_position(0x300002, e_cpr[0], e_cpr[1], 0, 2.0)
        pos_est = resolver2.resolve_position(0x300002, o_cpr[0], o_cpr[1], 1, 2.5)
        assert pos_est is not None, "Established track must resolve via local CPR fallback"
        assert resolver2.get_cpr_state(0x300002).zone_straddle_detected is True
        # Resolved position must be within ~10 meters of true position without coordinate spike
        assert pos_est[0] == pytest.approx(lat_north, abs=1e-3)
        assert pos_est[1] == pytest.approx(lon, abs=1e-3)

    def test_equatorial_crossing(self) -> None:
        """Verify seamless airborne CPR resolution when crossing equator (-0.05 deg -> +0.05 deg)."""
        resolver = StatefulCPRResolver()
        lat_south, lon = -0.05, 10.0
        e_s = encode_cpr_airborne(lat_south, lon, 0)
        o_s = encode_cpr_airborne(lat_south, lon, 1)

        resolver.resolve_position(0x400001, e_s[0], e_s[1], 0, 0.0)
        pos_s = resolver.resolve_position(0x400001, o_s[0], o_s[1], 1, 0.5)
        assert pos_s is not None
        assert pos_s[0] == pytest.approx(-0.05, abs=1e-3)

        # Cross into Northern hemisphere
        lat_north = 0.05
        e_n = encode_cpr_airborne(lat_north, lon, 0)
        o_n = encode_cpr_airborne(lat_north, lon, 1)

        pos_n1 = resolver.resolve_position(0x400001, e_n[0], e_n[1], 0, 1.0)
        pos_n2 = resolver.resolve_position(0x400001, o_n[0], o_n[1], 1, 1.5)
        assert pos_n1 is not None and pos_n1[0] == pytest.approx(0.05, abs=1e-3)
        assert pos_n2 is not None and pos_n2[0] == pytest.approx(0.05, abs=1e-3)

    def test_anti_meridian_crossing(self) -> None:
        """Verify CPR resolution across 180-degree anti-meridian (+179.95 deg -> -179.95 deg)."""
        resolver = StatefulCPRResolver()
        lat, lon_w = 20.0, 179.95
        e_w = encode_cpr_airborne(lat, lon_w, 0)
        o_w = encode_cpr_airborne(lat, lon_w, 1)

        resolver.resolve_position(0x500001, e_w[0], e_w[1], 0, 0.0)
        pos_w = resolver.resolve_position(0x500001, o_w[0], o_w[1], 1, 0.5)
        assert pos_w is not None
        assert pos_w[1] == pytest.approx(179.95, abs=1e-3)

        # Cross 180 meridian into Western hemisphere coordinates (-179.95 deg)
        lon_e = -179.95
        e_e = encode_cpr_airborne(lat, lon_e, 0)
        o_e = encode_cpr_airborne(lat, lon_e, 1)

        pos_e1 = resolver.resolve_position(0x500001, e_e[0], e_e[1], 0, 1.0)
        pos_e2 = resolver.resolve_position(0x500001, o_e[0], o_e[1], 1, 1.5)
        assert pos_e1 is not None and pos_e1[1] == pytest.approx(-179.95, abs=1e-3)
        assert pos_e2 is not None and pos_e2[1] == pytest.approx(-179.95, abs=1e-3)


# ==============================================================================
# Task 3: Track Lifecycle & Anomaly Detection Stress Tests
# ==============================================================================


class TestLifecycleAndAnomalyAdversarial:
    """Adversarial stress-testing for track management, flood resistance, and anomalies."""

    def test_flood_500_single_squitter_hits(self) -> None:
        """Flood tracker with 500 fake single-squitter hits: verify 0 CONFIRMED tracks are created."""
        engine = TrackingEngine(ref_lat=52.0, ref_lon=4.0)

        # Inject 500 single-hit Mode S messages from unique ICAOs
        for i, icao in enumerate(range(0x700000, 0x700000 + 500)):
            msg = DecodedModeSMessage(df=11, icao24=icao, crc_valid=True)
            engine.update(rx_timestamp_s=float(i) * 0.01, decoded_msg=msg)

        # Active tracks (confirmed + coasting) must be strictly 0
        confirmed_tracks = engine.all_tracks(include_tentative=False)
        assert len(confirmed_tracks) == 0, f"Expected 0 confirmed tracks, found {len(confirmed_tracks)}"

        # All 500 tracks must remain quarantined in TENTATIVE state
        all_tracks = engine.all_tracks(include_tentative=True)
        assert len(all_tracks) == 500
        assert all(t.state == TrackState.TENTATIVE for t in all_tracks)

    def test_lifecycle_state_machine_transitions(self) -> None:
        """Verify lifecycle state transitions: TENTATIVE -> CONFIRMED -> COASTING -> DELETED."""
        mgr = TrackLifecycleManager(
            confirmation_m=3,
            confirmation_window_s=5.0,
            coasting_timeout_s=5.0,
            deletion_timeout_s=30.0,
        )

        # Hit 1 at t = 0s -> TENTATIVE
        assert mgr.register_hit(0.0, has_valid_position=True) == TrackState.TENTATIVE

        # Hit 2 at t = 1s -> TENTATIVE
        assert mgr.register_hit(1.0, has_valid_position=True) == TrackState.TENTATIVE

        # Hit 3 at t = 2s (3 hits in 5s with valid position) -> CONFIRMED
        assert mgr.register_hit(2.0, has_valid_position=True) == TrackState.CONFIRMED

        # Inactivity for 5.1s -> transitions to COASTING
        assert mgr.evaluate_timeouts(7.1) == TrackState.COASTING

        # Re-acquisition within timeout -> restores CONFIRMED
        assert mgr.register_hit(7.5, has_valid_position=True) == TrackState.CONFIRMED

        # Inactivity past coasting timeout -> COASTING
        assert mgr.evaluate_timeouts(13.0) == TrackState.COASTING

        # Inactivity past deletion timeout (> 30s) -> DELETED
        assert mgr.evaluate_timeouts(38.0) == TrackState.DELETED

    def test_kinematic_teleport_anomaly(self) -> None:
        """Test KINEMATIC_TELEPORT and RF_PHYSICAL_SPOOF anomaly triggers on non-physical speed."""
        det = AnomalyDetector()
        det.check_position_anomalies(
            icao24=0x800001,
            lat_deg=52.0,
            lon_deg=4.0,
            timestamp_s=0.0,
            cpr_lat=10000,
            cpr_lon=10000,
        )

        # Position jumps 80 km in 1.0s (80,000 m/s >> 600 m/s threshold)
        anoms = det.check_position_anomalies(
            icao24=0x800001,
            lat_deg=52.72,
            lon_deg=4.0,
            timestamp_s=1.0,
            cpr_lat=20000,
            cpr_lon=20000,
        )
        assert "KINEMATIC_TELEPORT" in anoms
        assert "RF_PHYSICAL_SPOOF" in anoms

    def test_stale_gps_latch_anomaly(self) -> None:
        """Test STALE_GPS_LATCH trigger when CPR fraction freezes while groundspeed > 30 kt."""
        det = AnomalyDetector()

        for t in range(4):
            anoms = det.check_position_anomalies(
                icao24=0x800002,
                lat_deg=52.0,
                lon_deg=4.0,
                timestamp_s=float(t),
                cpr_lat=54321,
                cpr_lon=12345,
                groundspeed_kt=280.0,
            )

        assert "STALE_GPS_LATCH" in anoms

    def test_altitude_cliff_gillham_anomaly(self) -> None:
        """Test ALTITUDE_CLIFF_GILLHAM anomaly triggers on > 2000 ft step jump."""
        det = AnomalyDetector()
        det.check_altitude_anomalies(icao24=0x800003, alt_ft=15000.0, timestamp_s=0.0)

        # 3000 ft jump in 0.5s while vertical rate is only 200 fpm
        anoms = det.check_altitude_anomalies(
            icao24=0x800003,
            alt_ft=18000.0,
            timestamp_s=0.5,
            vertical_rate_fpm=200.0,
        )
        assert "ALTITUDE_CLIFF_GILLHAM" in anoms

    def test_rf_physical_spoof_speed_and_acceleration(self) -> None:
        """Test RF_PHYSICAL_SPOOF triggers on Mach 2+ velocity (> 600 m/s) and > 6g acceleration."""
        det = AnomalyDetector()

        # Non-physical speed: 700 m/s (~1360 kt)
        anoms_spd = det.check_velocity_anomalies(icao24=0x800004, speed_mps=700.0, timestamp_s=0.0)
        assert "RF_PHYSICAL_SPOOF" in anoms_spd

        # Normal speed (200 m/s), then extreme acceleration (jump to 350 m/s in 1.0s = 150 m/s^2 > 60 m/s^2)
        det.check_velocity_anomalies(icao24=0x800005, speed_mps=200.0, timestamp_s=0.0)
        anoms_acc = det.check_velocity_anomalies(icao24=0x800005, speed_mps=350.0, timestamp_s=1.0)
        assert "RF_PHYSICAL_SPOOF" in anoms_acc
