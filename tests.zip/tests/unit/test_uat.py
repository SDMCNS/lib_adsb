"""Unit tests for 978 MHz UAT Frame Codecs and Reed-Solomon Forward Error Correction."""

from __future__ import annotations

import math
import random

import pytest

from adsb.protocol.uat import (
    AltitudeSource,
    ReedSolomonCodec,
    UATAuxStateVector,
    UATHeader,
    UATModeStatus,
    UATReedSolomonError,
    UATStateVector,
    decode_uat,
    decode_uat_auxsv,
    decode_uat_header,
    decode_uat_ms,
    decode_uat_sv,
    encode_uat_auxsv,
    encode_uat_basic,
    encode_uat_header,
    encode_uat_long,
    encode_uat_ms,
    encode_uat_sv,
)


class TestReedSolomonFEC:
    """Test pure-Python GF(2^8) Reed-Solomon encoding and error correction."""

    def test_rs30_18_clean_codeword_zero_syndromes(self) -> None:
        codec = ReedSolomonCodec(nsym=12, fcr=120)
        msg = b"123456789012345678"  # 18 bytes
        parity = codec.encode(msg)
        assert len(parity) == 12
        codeword = msg + parity
        assert len(codeword) == 30

        syndromes = codec.calc_syndromes(codeword)
        assert all(s == 0 for s in syndromes)

        decoded_msg, err_count = codec.decode(codeword)
        assert err_count == 0
        assert decoded_msg == msg

    def test_rs30_18_correct_up_to_6_byte_errors(self) -> None:
        codec = ReedSolomonCodec(nsym=12, fcr=120)
        msg = b"UAT ADS-B BASIC MSG"[:18]
        parity = codec.encode(msg)
        codeword = bytearray(msg + parity)

        rng = random.Random(42)
        for n_err in range(1, 7):
            corrupted = bytearray(codeword)
            err_indices = rng.sample(range(30), n_err)
            for idx in err_indices:
                corrupted[idx] ^= rng.randint(1, 255)

            decoded_msg, count = codec.decode(bytes(corrupted))
            assert count == n_err
            assert decoded_msg == msg

    def test_rs48_34_correct_up_to_7_byte_errors(self) -> None:
        codec = ReedSolomonCodec(nsym=14, fcr=120)
        msg = (b"UAT LONG ADS-B PAYLOAD 34 BYTES!!" * 2)[:34]
        parity = codec.encode(msg)
        codeword = bytearray(msg + parity)
        assert len(codeword) == 48

        rng = random.Random(123)
        for n_err in range(1, 8):
            corrupted = bytearray(codeword)
            err_indices = rng.sample(range(48), n_err)
            for idx in err_indices:
                corrupted[idx] ^= rng.randint(1, 255)

            decoded_msg, count = codec.decode(bytes(corrupted))
            assert count == n_err
            assert decoded_msg == msg

    def test_rs_uncorrectable_errors_raise_exception(self) -> None:
        codec = ReedSolomonCodec(nsym=12, fcr=120)
        msg = b"123456789012345678"
        codeword = bytearray(msg + codec.encode(msg))

        # Inject 7 byte errors (exceeds t=6 capacity)
        for i in range(7):
            codeword[i] ^= 0x55

        with pytest.raises(UATReedSolomonError):
            codec.decode(bytes(codeword))


class TestUATMessageCodec:
    """Test bit-level encoding and decoding of UAT headers, state vectors, and mode status."""

    def test_header_round_trip(self) -> None:
        hdr = UATHeader(hdr_type=1, addr_qual=0, address=0xA1B2C3, icao_hex="A1B2C3")
        encoded = encode_uat_header(hdr)
        assert len(encoded) == 4
        decoded = decode_uat_header(encoded)
        assert decoded.hdr_type == 1
        assert decoded.addr_qual == 0
        assert decoded.address == 0xA1B2C3
        assert decoded.icao_hex == "A1B2C3"

    def test_state_vector_airborne_round_trip(self) -> None:
        sv = UATStateVector(
            lat_deg=37.6188,
            lon_deg=-122.3750,
            altitude_ft=12500,
            altitude_source=AltitudeSource.BAROMETRIC,
            nic=8,
            airground_state=0,  # Airborne subsonic
            v_ns_kt=180.0,
            v_ew_kt=-90.0,
            vertical_rate_fpm=1280,
            vertical_rate_source=AltitudeSource.BAROMETRIC,
        )
        encoded = encode_uat_sv(sv)
        assert len(encoded) == 13
        # Prefix with 4 dummy header bytes to simulate full payload
        decoded = decode_uat_sv(b"\x00\x00\x00\x00" + encoded)

        assert math.isclose(decoded.lat_deg, sv.lat_deg, abs_tol=2.5e-5)
        assert math.isclose(decoded.lon_deg, sv.lon_deg, abs_tol=2.5e-5)
        assert decoded.altitude_ft == 12500
        assert decoded.altitude_source == AltitudeSource.BAROMETRIC
        assert decoded.nic == 8
        assert decoded.airground_state == 0
        assert math.isclose(decoded.v_ns_kt or 0.0, 180.0, abs_tol=1.0)
        assert math.isclose(decoded.v_ew_kt or 0.0, -90.0, abs_tol=1.0)
        assert decoded.vertical_rate_fpm == 1280

    def test_mode_status_base40_callsign_round_trip(self) -> None:
        ms = UATModeStatus(
            emitter_category=1,  # Light
            callsign="N12345  ",
            emergency_status=0,
            uat_version=2,
            sil=3,
            nac_p=9,
            nac_v=2,
        )
        encoded = encode_uat_ms(ms)
        assert len(encoded) == 12
        # Prefix with 17 bytes to simulate full payload offset
        decoded = decode_uat_ms(b"\x00" * 17 + encoded)

        assert decoded.callsign == "N12345"
        assert decoded.emitter_category == 1
        assert decoded.sil == 3
        assert decoded.nac_p == 9

    def test_aux_state_vector_round_trip(self) -> None:
        aux = UATAuxStateVector(
            sec_altitude_ft=14000,
            sec_altitude_source=AltitudeSource.GNSS_HAE,
        )
        encoded = encode_uat_auxsv(aux)
        assert len(encoded) == 2
        decoded = decode_uat_auxsv(b"\x00" * 29 + encoded, AltitudeSource.BAROMETRIC)
        assert decoded.sec_altitude_ft == 14000
        assert decoded.sec_altitude_source == AltitudeSource.GNSS_HAE

    def test_full_uat_basic_with_fec(self) -> None:
        raw_frame = encode_uat_basic(
            icao24=0x40621D,
            lat_deg=52.3105,
            lon_deg=4.7683,
            altitude_ft=35000,
            nic=9,
            v_ns_kt=250.0,
            v_ew_kt=100.0,
            include_fec=True,
        )
        assert len(raw_frame) == 30  # 18B payload + 12B FEC

        # Decode clean frame
        msg = decode_uat(raw_frame)
        assert msg.icao24 == 0x40621D
        assert msg.icao_hex == "40621D"
        assert math.isclose(msg.lat_deg or 0.0, 52.3105, abs_tol=2.5e-5)
        assert math.isclose(msg.lon_deg or 0.0, 4.7683, abs_tol=2.5e-5)
        assert msg.altitude_ft == 35000
        assert msg.errors_corrected == 0

        # Inject 3 byte errors
        corrupted = bytearray(raw_frame)
        corrupted[2] ^= 0xAA
        corrupted[10] ^= 0x55
        corrupted[25] ^= 0x33
        msg_corr = decode_uat(bytes(corrupted))
        assert msg_corr.errors_corrected == 3
        assert msg_corr.icao24 == 0x40621D
        assert msg_corr.altitude_ft == 35000

    def test_full_uat_long_with_fec(self) -> None:
        raw_frame = encode_uat_long(
            icao24=0xA1B2C3,
            lat_deg=40.6413,
            lon_deg=-73.7781,
            callsign="DAL456  ",
            altitude_ft=24000,
            include_fec=True,
        )
        assert len(raw_frame) == 48  # 34B payload + 14B FEC

        msg = decode_uat(raw_frame)
        assert msg.icao24 == 0xA1B2C3
        assert msg.callsign == "DAL456"
        assert msg.altitude_ft == 24000
        assert math.isclose(msg.lat_deg or 0.0, 40.6413, abs_tol=2.5e-5)
