"""Empirical adversarial stress test suite for physical RF interference, jammer summation, and gating.

Authoritative reference: Milestone 3 Requirements R4 & R5, RTCA DO-260B,
docs/04_ERROR_AND_ANOMALY_SIMULATION.md, and challenger_enh_m3_1 DISPATCH.
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from adsb.constants import (
    EARTH_MEAN_RADIUS_M,
    EFFECTIVE_EARTH_RADIUS_FACTOR,
    FREQ_1090ES_HZ,
)
from adsb.impairment.channel import (
    ChannelConfig,
    DropoutReason,
    FadingModel,
    ReceiverSite,
    RFPropagationChannel,
    compute_fspl,
    compute_ppm_ber,
    compute_preamble_drop_prob,
    compute_radio_horizon,
    compute_slant_range,
)
from adsb.impairment.interference import (
    InterferenceEngine,
    InterferenceSource,
    JammingModulation,
    compute_aggregate_interference,
    compute_effective_noise_floor,
    compute_frame_drop_probability,
    compute_received_interference,
    compute_sinr,
    compute_spectral_overlap_factor,
)
from adsb.synthesis.scheduler import SquitterEvent


class TestExtremeJammerPower:
    """Stress tests for extreme jammer power levels up to 80 dBm (100 kW EIRP)."""

    def test_extreme_power_80dbm_noise_elevation_and_packet_drop(self) -> None:
        """Verify 80 dBm (100 kW) jammer causes massive noise floor elevation and near 100% drops."""
        rx = ReceiverSite(
            lat_deg=52.3105,
            lon_deg=4.7683,
            alt_msl_m=25.0,
            noise_floor_dbm=-90.0,
            antenna_gain_peak_dbi=5.0,
            sensitivity_dbm=-84.0,
            rx_id="RX_SCHIPHOL",
        )

        # Place 80 dBm jammer 5.0 km north of receiver
        # 80 dBm = 100 kW EIRP
        # Approximate 5 km distance: ~0.045 deg latitude offset
        jammer = InterferenceSource(
            source_id="SUPER_JAMMER_80DBM",
            name="100kW Tactical Jammer",
            lat_deg=52.3555,
            lon_deg=4.7683,
            alt_msl_m=10.0,
            tx_power_dbm=80.0,
            frequency_hz=FREQ_1090ES_HZ,
            bandwidth_mhz=2.0,
            modulation=JammingModulation.NOISE,
            is_active=True,
        )

        assert jammer.tx_power_w == pytest.approx(100_000.0, rel=1e-3)
        assert jammer.effective_range_km > 1000.0

        # Calculate received interference power
        d_slant = compute_slant_range(
            jammer.lat_deg, jammer.lon_deg, jammer.alt_msl_m,
            rx.lat_deg, rx.lon_deg, rx.effective_alt_m,
        )
        assert 4900.0 < d_slant < 5100.0

        p_interf = compute_received_interference(jammer, rx, cable_loss_db=2.0)
        # At ~5 km, FSPL is ~107.2 dB. P_rx = 80 + 5 - 107.2 - 2.0 = -24.2 dBm
        assert -26.0 < p_interf < -22.0

        # Effective noise floor elevation
        n_eff = compute_effective_noise_floor(rx.noise_floor_dbm, p_interf)
        noise_elevation = n_eff - rx.noise_floor_dbm
        assert noise_elevation > 60.0  # Elevated from -90 dBm to ~ -24 dBm (>60 dB rise!)

        # Aircraft squitter received at typical strong level: -60.0 dBm
        p_aircraft_rx = -60.0
        sinr = compute_sinr(p_aircraft_rx, n_eff)
        assert sinr < -30.0  # Catastrophic negative SINR

        # BER and drop probabilities
        ber = compute_ppm_ber(sinr, FadingModel.AWGN)
        p_preamble_drop = compute_preamble_drop_prob(sinr)
        p_frame_drop = compute_frame_drop_probability(sinr)

        assert ber > 0.45  # Near random guessing (0.50)
        assert p_preamble_drop == pytest.approx(1.0, abs=1e-6)
        assert p_frame_drop == pytest.approx(1.0, abs=1e-6)

    def test_simulation_manager_extreme_jamming_complete_denial(self) -> None:
        """Verify SimulationManager._check_signal_reception drops all frames under 80 dBm jamming."""
        from adsb.api.manager import SimulationManager
        sm = SimulationManager()
        sm.reset()

        # Add 80 dBm jammer directly over Amsterdam Schiphol
        sm.add_interference_source({
            "source_id": "JAMMER_SATURATION",
            "name": "Saturation Jammer",
            "lat_deg": 52.3105,
            "lon_deg": 4.7683,
            "alt_msl_m": 50.0,
            "tx_power_dbm": 80.0,
            "is_active": True,
        })

        # Generate 50 squitter events from aircraft 5 km away on low approach at 50m MSL
        # At 50m MSL, remote stations (Rotterdam 45km, Brussels 158km) are beyond radio horizon
        # (horizon for 50m + 10m is 42.1 km). Only RX_EHAM can see this aircraft.
        raw_msg = b"\x8d\x48\x40\xd6\x20\x2c\xc3\x71\xc3\x2c\xe0\x57\x60\x98"
        events = [
            SquitterEvent(
                timestamp_s=float(t),
                raw_bytes=raw_msg,
                icao24=0x4840D6,
                tx_lat_deg=52.3450,
                tx_lon_deg=4.7900,
                tx_alt_m=50.0,
            )
            for t in range(50)
        ]

        received_count = sum(1 for ev in events if sm._check_signal_reception(ev, ev.timestamp_s))
        assert received_count == 0, f"Expected 0% reception under 80 dBm jammer, got {received_count}/50"

        # Check receiver status for Amsterdam Schiphol
        rx_stat = sm.get_receiver_status("RX_EHAM")
        assert rx_stat is not None
        assert rx_stat["status"] == "JAMMED"
        assert rx_stat["dominant_jammer_id"] == "JAMMER_SATURATION"
        assert rx_stat["metrics"]["dropped_frames_count"] == 50
        assert rx_stat["metrics"]["packet_loss_rate"] == 1.0

    def test_power_upper_boundary_validation(self) -> None:
        """Verify API rejects transmit powers outside [0.0, 80.0] dBm."""
        from adsb.api.manager import SimulationManager
        sm = SimulationManager()
        sm.reset()

        # Exactly 80.0 dBm must be accepted
        res_80 = sm.add_interference_source({
            "source_id": "VALID_80",
            "tx_power_dbm": 80.0,
        })
        assert res_80["tx_power_dbm"] == 80.0

        # 80.001 dBm must raise ValueError
        with pytest.raises(ValueError, match=r"between 0\.0 and 80\.0 dBm"):
            sm.add_interference_source({
                "source_id": "INVALID_OVERPOWER",
                "tx_power_dbm": 80.001,
            })

        # Negative power must raise ValueError
        with pytest.raises(ValueError, match=r"between 0\.0 and 80\.0 dBm"):
            sm.add_interference_source({
                "source_id": "INVALID_NEGATIVE",
                "tx_power_dbm": -5.0,
            })


class TestSubNoiseAndLongDistanceAttenuation:
    """Stress tests for zero/sub-noise jammers and long-distance attenuation (1000 km)."""

    def test_sub_noise_jammer_zero_measurable_degradation(self) -> None:
        """Verify 0 dBm (1 mW) jammer 50 km away produces negligible noise floor elevation."""
        rx = ReceiverSite(
            lat_deg=52.3105,
            lon_deg=4.7683,
            alt_msl_m=10.0,
            noise_floor_dbm=-90.0,
        )

        # 0 dBm jammer 50 km away
        jammer = InterferenceSource(
            source_id="TINY_JAMMER",
            lat_deg=51.9569,  # Rotterdam area (~45 km away)
            lon_deg=4.4447,
            alt_msl_m=10.0,
            tx_power_dbm=0.0,  # 1 mW EIRP
            is_active=True,
        )

        p_interf = compute_received_interference(jammer, rx)
        # Expected FSPL is ~127 dB. Received power is ~ -124 dBm
        assert p_interf < -120.0

        n_eff = compute_effective_noise_floor(rx.noise_floor_dbm, p_interf)
        elevation = n_eff - rx.noise_floor_dbm
        # Noise floor elevation must be less than 0.005 dB (unmeasurable)
        assert elevation < 0.005
        assert n_eff == pytest.approx(-90.0, abs=0.005)

    def test_long_distance_1000km_complete_attenuation_and_horizon_cutoff(self) -> None:
        """Verify 1000 km distance produces 0 measurable degradation due to radio horizon and FSPL."""
        rx = ReceiverSite(
            lat_deg=52.3105,
            lon_deg=4.7683,
            alt_msl_m=25.0,
            noise_floor_dbm=-90.0,
        )

        # Jammer placed ~1000 km away (e.g. Madrid: ~40.4 deg N, -3.7 deg W)
        jammer = InterferenceSource(
            source_id="MADRID_JAMMER",
            lat_deg=40.4168,
            lon_deg=-3.7038,
            alt_msl_m=50.0,
            tx_power_dbm=70.0,  # Even with 10 kW EIRP
            is_active=True,
        )

        # 1. With radio horizon check enabled
        p_interf_horizon = compute_received_interference(jammer, rx, check_horizon=True)
        assert p_interf_horizon == -150.0  # Cut off by 4/3-Earth curvature

        n_eff_horizon = compute_effective_noise_floor(rx.noise_floor_dbm, p_interf_horizon)
        assert n_eff_horizon == rx.noise_floor_dbm  # Identically -90.0 dBm

        # 2. Even in deep line of sight without horizon masking
        p_interf_los = compute_received_interference(jammer, rx, check_horizon=False)
        # FSPL at ~1400 km is ~156 dB. P_rx = 70 + 5 - 156 - 2 = -83 dBm
        assert p_interf_los < -80.0
        d_slant_m = compute_slant_range(
            jammer.lat_deg, jammer.lon_deg, jammer.alt_msl_m,
            rx.lat_deg, rx.lon_deg, rx.effective_alt_m,
        )
        assert d_slant_m > 1_000_000.0  # > 1000 km

    def test_inactive_jammer_strict_zero_power_leakage(self) -> None:
        """Verify inactive jammer contributes identically zero power regardless of power or proximity."""
        rx = ReceiverSite(lat_deg=52.3105, lon_deg=4.7683, alt_msl_m=10.0)

        # Inactive 80 dBm jammer located 50 meters away
        jammer = InterferenceSource(
            source_id="STANDBY_MEGA_JAMMER",
            lat_deg=52.3109,
            lon_deg=4.7683,
            alt_msl_m=10.0,
            tx_power_dbm=80.0,
            is_active=False,
        )

        p = compute_received_interference(jammer, rx)
        assert p == -150.0

        p_agg = compute_aggregate_interference([jammer], rx)
        assert p_agg == -150.0

        n_eff = compute_effective_noise_floor(rx.noise_floor_dbm, p_agg)
        assert n_eff == rx.noise_floor_dbm


class TestNonCoherentJammerSummation:
    """Stress tests for non-coherent power summation of 10+ concurrent jammers against the analytical formula."""

    def test_ten_plus_identical_concurrent_jammers_analytical_equivalence(self) -> None:
        """Verify N identical jammers produce exactly +10*log10(N) dB aggregate power."""
        rx = ReceiverSite(
            lat_deg=52.3105,
            lon_deg=4.7683,
            alt_msl_m=10.0,
            noise_floor_dbm=-90.0,
            antenna_gain_peak_dbi=5.0,
        )

        # Place 12 identical active jammers in a ring 2.0 km around the receiver
        num_jammers = 12
        radius_m = 2000.0
        jammers: list[InterferenceSource] = []

        for i in range(num_jammers):
            angle_rad = (2.0 * math.pi * i) / num_jammers
            # Approx 1 deg lat ~ 111,139 m
            d_lat = (radius_m * math.cos(angle_rad)) / 111_139.0
            d_lon = (radius_m * math.sin(angle_rad)) / (111_139.0 * math.cos(math.radians(52.3105)))
            jammers.append(
                InterferenceSource(
                    source_id=f"RING_JAMMER_{i+1:02d}",
                    lat_deg=52.3105 + d_lat,
                    lon_deg=4.7683 + d_lon,
                    alt_msl_m=10.0,
                    tx_power_dbm=30.0,
                    is_active=True,
                )
            )

        # Verify individual received power is uniform
        powers = [compute_received_interference(j, rx) for j in jammers]
        p_single = powers[0]
        for p in powers:
            assert p == pytest.approx(p_single, abs=0.05)

        # Aggregate received power
        p_agg = compute_aggregate_interference(jammers, rx)
        # Exact linear sum of individual received powers
        p_lin_sum = sum(10.0 ** (p / 10.0) for p in powers)
        expected_exact_agg = 10.0 * math.log10(p_lin_sum)
        assert p_agg == pytest.approx(expected_exact_agg, rel=1e-9)

        # Theoretical N*I_0 formula within geodetic circle variance (abs=0.03 dB)
        expected_nominal_agg = p_single + 10.0 * math.log10(num_jammers)
        assert p_agg == pytest.approx(expected_nominal_agg, abs=0.03)

        # Effective noise floor comparison
        n_eff = compute_effective_noise_floor(rx.noise_floor_dbm, p_agg)
        expected_n_eff = 10.0 * math.log10(
            10.0 ** (rx.noise_floor_dbm / 10.0) + p_lin_sum
        )
        assert n_eff == pytest.approx(expected_n_eff, rel=1e-9)

    def test_heterogeneous_multi_jammer_power_summation_arbitrary(self) -> None:
        """Verify 15 heterogeneous jammers strictly satisfy N_eff = 10*log10(10^(N0/10) + sum(10^(Ij/10)))."""
        rng = np.random.default_rng(seed=42)
        rx = ReceiverSite(
            lat_deg=52.3105,
            lon_deg=4.7683,
            alt_msl_m=15.0,
            noise_floor_dbm=-92.0,
        )

        sources: list[InterferenceSource] = []
        for i in range(15):
            dist_km = float(rng.uniform(1.0, 8.0))
            angle_rad = float(rng.uniform(0.0, 2.0 * math.pi))
            d_lat = (dist_km * 1000.0 * math.cos(angle_rad)) / 111_139.0
            d_lon = (dist_km * 1000.0 * math.sin(angle_rad)) / (111_139.0 * math.cos(math.radians(52.3105)))
            pwr = float(rng.uniform(20.0, 55.0))
            sources.append(
                InterferenceSource(
                    source_id=f"HETERO_JAM_{i:02d}",
                    lat_deg=52.3105 + d_lat,
                    lon_deg=4.7683 + d_lon,
                    alt_msl_m=float(rng.uniform(5.0, 30.0)),
                    tx_power_dbm=pwr,
                    is_active=bool(rng.random() > 0.15),  # Random active state
                )
            )

        # Calculate received powers individually
        individual_powers = [
            compute_received_interference(s, rx)
            for s in sources
            if s.is_active
        ]
        # Analytical linear sum
        p_lin_sum = sum(10.0 ** (p / 10.0) for p in individual_powers if p > -140.0)
        expected_agg_dbm = 10.0 * math.log10(p_lin_sum)
        expected_n_eff_dbm = 10.0 * math.log10(10.0 ** (rx.noise_floor_dbm / 10.0) + p_lin_sum)

        actual_agg = compute_aggregate_interference(sources, rx)
        actual_n_eff = compute_effective_noise_floor(rx.noise_floor_dbm, actual_agg)

        assert actual_agg == pytest.approx(expected_agg_dbm, rel=1e-6)
        assert actual_n_eff == pytest.approx(expected_n_eff_dbm, rel=1e-6)

    def test_dynamic_jammer_power_subtraction_on_disable(self) -> None:
        """Verify disabling individual jammers sequentially reduces aggregate linear power exactly."""
        rx = ReceiverSite(lat_deg=52.3105, lon_deg=4.7683, alt_msl_m=10.0)
        engine = InterferenceEngine()

        for i in range(10):
            engine.add_source(
                InterferenceSource(
                    source_id=f"JAM_SEQ_{i}",
                    lat_deg=52.3200 + i * 0.005,
                    lon_deg=4.7683,
                    tx_power_dbm=35.0,
                    is_active=True,
                )
            )

        # Baseline with 10 jammers
        n_eff_10, elev_10, agg_10 = engine.evaluate_receiver_noise(rx)

        # Disable half the jammers
        for i in range(5):
            engine.toggle_source(f"JAM_SEQ_{i}")

        n_eff_5, elev_5, agg_5 = engine.evaluate_receiver_noise(rx)
        assert agg_5 < agg_10
        assert n_eff_5 < n_eff_10
        assert elev_5 < elev_10

        # Disable remaining jammers
        for i in range(5, 10):
            engine.toggle_source(f"JAM_SEQ_{i}")

        n_eff_0, elev_0, agg_0 = engine.evaluate_receiver_noise(rx)
        assert agg_0 <= -140.0
        assert n_eff_0 == pytest.approx(rx.noise_floor_dbm, abs=0.001)
        assert elev_0 == pytest.approx(0.0, abs=0.001)


class TestBurnThroughCaptureEffect:
    """Stress tests for burn-through capture effect (close aircraft penetrating jamming)."""

    def test_close_aircraft_burns_through_moderate_jamming(self) -> None:
        """Verify close aircraft at 2 km penetrates jamming field where distant aircraft fails."""
        rx = ReceiverSite(
            lat_deg=52.3105,
            lon_deg=4.7683,
            alt_msl_m=10.0,
            noise_floor_dbm=-90.0,
            antenna_gain_peak_dbi=5.0,
        )

        # Jammer creates elevated noise floor of -70.0 dBm (20 dB elevation over rx.noise_floor_dbm!)
        n_eff = -70.0
        assert n_eff > rx.noise_floor_dbm

        # 1. Distant aircraft: 60 km away at 3000m altitude
        # P_rx ~ 51 (tx) + 2 (tx_gain) + G_rx - 128.8 (FSPL) - 2.5 (loss) = -73.3 dBm
        d_dist = 60_000.0
        fspl_dist = compute_fspl(d_dist, FREQ_1090ES_HZ)
        p_rx_dist = 51.0 + 2.0 + rx.antenna_gain_peak_dbi - fspl_dist - 2.5
        sinr_dist = compute_sinr(p_rx_dist, n_eff)

        assert sinr_dist < 0.0  # -3.3 dB
        drop_dist = compute_frame_drop_probability(sinr_dist)
        assert drop_dist > 0.999  # > 99.9% drop probability

        # 2. Close aircraft on final approach: 2.0 km away at 200m altitude
        # P_rx ~ 51 + 2 + G_rx - 99.2 (FSPL) - 2.5 = -43.7 dBm
        d_close = 2000.0
        fspl_close = compute_fspl(d_close, FREQ_1090ES_HZ)
        p_rx_close = 51.0 + 2.0 + rx.antenna_gain_peak_dbi - fspl_close - 2.5
        sinr_close = compute_sinr(p_rx_close, n_eff)

        assert sinr_close > 25.0  # +26.3 dB
        drop_close = compute_frame_drop_probability(sinr_close)
        assert drop_close < 1e-5  # Clean burn-through!

    def test_burn_through_distance_sweep_transition(self) -> None:
        """Verify monotonically increasing drop probability as distance increases under jamming."""
        n_eff = -68.0  # Elevated noise floor from 45 dBm jammer nearby
        distances_km = [1.0, 3.0, 10.0, 30.0, 70.0]
        drop_rates: list[float] = []

        for d_km in distances_km:
            fspl = compute_fspl(d_km * 1000.0, FREQ_1090ES_HZ)
            p_rx = 51.0 + 2.0 + 5.0 - fspl - 2.5
            sinr = compute_sinr(p_rx, n_eff)
            drop_rates.append(compute_frame_drop_probability(sinr))

        # Drop rates must increase monotonically with distance
        for i in range(len(drop_rates) - 1):
            assert drop_rates[i] <= drop_rates[i + 1]

        # 1 km must be < 1% drops; 70 km must be > 99% drops
        assert drop_rates[0] < 0.01
        assert drop_rates[-1] > 0.99


class TestRadioHorizonCurvatureLimits:
    """Stress tests for 4/3-Earth curvature radio horizon and sharp geometric cutoff."""

    def test_radio_horizon_exact_formula_and_symmetry(self) -> None:
        """Verify compute_radio_horizon matches d = sqrt(2*R_eff*h_tx) + sqrt(2*R_eff*h_rx)."""
        r_eff = EFFECTIVE_EARTH_RADIUS_FACTOR * EARTH_MEAN_RADIUS_M
        assert r_eff == pytest.approx(8_494_678.4, abs=1.0)

        h_tx = 10_000.0  # 10 km cruise altitude
        h_rx = 25.0      # 25 m tower mast

        d_calc = compute_radio_horizon(h_tx, h_rx)
        d_tx = math.sqrt(2.0 * r_eff * h_tx)
        d_rx = math.sqrt(2.0 * r_eff * h_rx)
        expected = d_tx + d_rx

        assert d_calc == pytest.approx(expected, rel=1e-9)
        assert 430_000.0 < d_calc < 435_000.0  # ~432.8 km

        # Symmetry property
        assert compute_radio_horizon(h_tx, h_rx) == compute_radio_horizon(h_rx, h_tx)

        # Clamping property for negative heights (sub-sea level)
        assert compute_radio_horizon(-10.0, h_rx) == compute_radio_horizon(0.0, h_rx)

    def test_sharp_geometric_cutoff_in_received_interference(self) -> None:
        """Verify compute_received_interference exhibits sharp step function at the radio horizon."""
        rx = ReceiverSite(
            lat_deg=0.0,
            lon_deg=0.0,
            alt_msl_m=20.0,
        )

        h_tx = 50.0
        h_rx = rx.effective_alt_m
        d_horizon = compute_radio_horizon(h_tx, h_rx)
        # d_horizon = sqrt(2 * 8.495e6 * 50) + sqrt(2 * 8.495e6 * 20) ~ 29.14 km + 18.43 km = 47.58 km

        # Place jammer along equator: 1 deg lon at equator ~ 111,319.5 m
        # Case A: Inside horizon (d_horizon - 200 m)
        d_inside = d_horizon - 200.0
        lon_inside = d_inside / 111_319.5
        j_inside = InterferenceSource(
            source_id="JAM_INSIDE",
            lat_deg=0.0,
            lon_deg=lon_inside,
            alt_msl_m=h_tx,
            tx_power_dbm=50.0,
            is_active=True,
        )
        p_inside = compute_received_interference(j_inside, rx, check_horizon=True)
        assert p_inside > -120.0  # Readily detectable line-of-sight signal

        # Case B: Beyond horizon (d_horizon + 200 m)
        d_outside = d_horizon + 200.0
        lon_outside = d_outside / 111_319.5
        j_outside = InterferenceSource(
            source_id="JAM_OUTSIDE",
            lat_deg=0.0,
            lon_deg=lon_outside,
            alt_msl_m=h_tx,
            tx_power_dbm=50.0,
            is_active=True,
        )
        p_outside = compute_received_interference(j_outside, rx, check_horizon=True)
        assert p_outside == -150.0  # Hard geometric cutoff!

    def test_propagation_channel_dropout_reason_horizon(self) -> None:
        """Verify RFPropagationChannel tags horizon dropouts with DropoutReason.RADIO_HORIZON."""
        channel = RFPropagationChannel(ChannelConfig(enable_horizon_check=True))
        rx = ReceiverSite(lat_deg=52.3105, lon_deg=4.7683, alt_msl_m=10.0)
        rng = np.random.default_rng(123)

        # Aircraft at 100m MSL, 200 km away (far beyond horizon of ~54 km)
        raw_msg = b"\x8d\x48\x40\xd6\x20\x2c\xc3\x71\xc3\x2c\xe0\x57\x60\x98"
        res = channel.propagate_squitter(
            raw_bytes=raw_msg,
            tx_timestamp_s=10.0,
            tx_lat_deg=50.5000,
            tx_lon_deg=4.7683,
            tx_alt_m=100.0,
            receiver=rx,
            rng=rng,
        )

        assert res.received is False
        assert res.dropout_reason == DropoutReason.RADIO_HORIZON
        assert res.snr_db == -60.0
        assert res.rx_power_dbm == -150.0


class TestModulationTypesAndSpectralOverlapMath:
    """Stress tests for modulation types and spectral overlap factors."""

    def test_spectral_overlap_profiles_and_math(self) -> None:
        """Verify spectral overlap factor math for CW, Gaussian, Chirp, Sweep, and Pulse."""
        f_rx = FREQ_1090ES_HZ
        bw_rx = 2.0  # 2.0 MHz IF filter

        # 1. CW Tone: extremely narrow bandwidth centered at 1090 MHz
        # 100% of power falls in 2 MHz IF bandwidth
        eta_cw = compute_spectral_overlap_factor(
            f_tx_hz=f_rx, bw_tx_mhz=0.05, f_rx_hz=f_rx, bw_rx_mhz=bw_rx
        )
        assert eta_cw == pytest.approx(1.0)

        # 2. Gaussian barrage noise: 20.0 MHz bandwidth centered at 1090 MHz
        # 2.0 MHz / 20.0 MHz = 10% overlap
        eta_gauss = compute_spectral_overlap_factor(
            f_tx_hz=f_rx, bw_tx_mhz=20.0, f_rx_hz=f_rx, bw_rx_mhz=bw_rx
        )
        assert eta_gauss == pytest.approx(0.10)

        # 3. Chirp (linear FM): 10.0 MHz chirp sweep width
        # 2.0 MHz / 10.0 MHz = 20% overlap
        eta_chirp = compute_spectral_overlap_factor(
            f_tx_hz=f_rx, bw_tx_mhz=10.0, f_rx_hz=f_rx, bw_rx_mhz=bw_rx
        )
        assert eta_chirp == pytest.approx(0.20)

        # 4. Sweep: 40.0 MHz wide sweep
        # 2.0 MHz / 40.0 MHz = 5% overlap
        eta_sweep = compute_spectral_overlap_factor(
            f_tx_hz=f_rx, bw_tx_mhz=40.0, f_rx_hz=f_rx, bw_rx_mhz=bw_rx
        )
        assert eta_sweep == pytest.approx(0.05)

        # 5. Pulse (matched 2.0 MHz RF bandwidth)
        eta_pulse = compute_spectral_overlap_factor(
            f_tx_hz=f_rx, bw_tx_mhz=2.0, f_rx_hz=f_rx, bw_rx_mhz=bw_rx
        )
        assert eta_pulse == pytest.approx(1.0)

    def test_frequency_offset_overlap_decay(self) -> None:
        """Verify linear decrease of overlap factor as transmitter center frequency drifts."""
        f_rx = 1090.0e6
        bw = 2.0  # Both tx and rx 2 MHz

        # Offsets from 0.0 MHz to 2.5 MHz
        # At 0.0 MHz offset: overlap = 2.0 / 2.0 = 1.0
        # At 0.5 MHz offset: overlap = 1.5 / 2.0 = 0.75
        # At 1.0 MHz offset: overlap = 1.0 / 2.0 = 0.50
        # At 1.5 MHz offset: overlap = 0.5 / 2.0 = 0.25
        # At 2.0 MHz offset: overlap = 0.0 / 2.0 = 0.00
        # At 2.5 MHz offset: overlap = 0.0
        offsets_mhz = [0.0, 0.5, 1.0, 1.5, 2.0, 2.5]
        expected_etas = [1.0, 0.75, 0.50, 0.25, 0.0, 0.0]

        for offset, expected in zip(offsets_mhz, expected_etas, strict=True):
            f_tx = f_rx + offset * 1e6
            eta = compute_spectral_overlap_factor(f_tx, bw, f_rx, bw)
            assert eta == pytest.approx(expected, abs=1e-6)

    def test_spectral_overlap_zero_bandwidth_edge_case(self) -> None:
        """Verify edge case: zero or negative bandwidth returns 0.0 without division by zero."""
        assert compute_spectral_overlap_factor(1090e6, 0.0, 1090e6, 2.0) == 0.0
        assert compute_spectral_overlap_factor(1090e6, -2.0, 1090e6, 2.0) == 0.0
        assert compute_spectral_overlap_factor(1090e6, 2.0, 1090e6, 0.0) == 0.0

    def test_jamming_modulation_enum_and_source_representation(self) -> None:
        """Verify JammingModulation enum members and dictionary serialization."""
        # Check standard members
        assert JammingModulation.CW == "CW"
        assert JammingModulation.NOISE == "NOISE"
        assert JammingModulation.PULSE == "PULSE"

        # Verify from_dict parsing of standard and alternative strings
        src_cw = InterferenceSource.from_dict({"source_id": "J_CW", "modulation": "CW"})
        assert src_cw.modulation == JammingModulation.CW

        src_noise = InterferenceSource.from_dict({"source_id": "J_NOISE", "modulation": "NOISE"})
        assert src_noise.modulation == JammingModulation.NOISE

        src_pulse = InterferenceSource.from_dict({"source_id": "J_PULSE", "modulation": "PULSE"})
        assert src_pulse.modulation == JammingModulation.PULSE

        # Unrecognized strings (e.g. CHIRP, SWEEP) fallback safely to NOISE
        src_fallback = InterferenceSource.from_dict({"source_id": "J_FALLBACK", "modulation": "CHIRP"})
        assert src_fallback.modulation == JammingModulation.NOISE

        d = src_cw.to_dict()
        assert d["modulation"] == "CW"
