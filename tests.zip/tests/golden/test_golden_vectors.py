"""Golden Vector Verification Suite (GV-01 through GV-06 and Adversarial Vectors).

Authoritative reference: docs/02_PROTOCOL_SPECIFICATION.md Section 10 & PROJECT.md
"""

from __future__ import annotations

import importlib.util
import math

import pytest


def _is_available(module_name: str) -> bool:
    try:
        return importlib.util.find_spec(module_name) is not None
    except (ModuleNotFoundError, ValueError):
        return False


HAS_ADSB_PROTOCOL = _is_available("adsb.protocol")

pytestmark = pytest.mark.skipif(
    not HAS_ADSB_PROTOCOL, reason="adsb.protocol not yet implemented (pending Milestone 1)"
)


@pytest.mark.golden
@pytest.mark.tier1
def test_gv01_callsign_klm1023() -> None:
    """GV-01: Verify KLM1023 callsign decoding from DF17 TC4 extended squitter.

    Raw Hex: 8D4840D6202CC371C32CE0576098
    Expected: ICAO=4840D6, Callsign='KLM1023 ', CRC valid=True, CA=0.
    """
    raw_bytes = bytes.fromhex("8D4840D6202CC371C32CE0576098")
    assert len(raw_bytes) == 14

    from adsb.protocol.crc import compute_syndrome, verify_crc24
    from adsb.protocol.modes import decode_mode_s

    assert verify_crc24(raw_bytes) is True
    assert compute_syndrome(raw_bytes) == 0

    msg = decode_mode_s(raw_bytes)
    assert msg.df == 17
    assert msg.tc == 4
    assert f"{msg.icao24:06X}" == "4840D6"
    assert msg.callsign.rstrip() == "KLM1023"
    assert getattr(msg, "ca", 0) == 0


@pytest.mark.golden
@pytest.mark.tier1
def test_gv02_airborne_pos_even() -> None:
    """GV-02: Verify Even airborne position message decoding (TC11, FL380).

    Raw Hex: 8D40621D58C382D690C8AC2863A7
    Expected: ICAO=40621D, altitude=38000 ft, Q-bit=1, CPR Even (F=0),
              CPR Lat=93000, CPR Lon=51372, CRC valid=True.
    """
    raw_bytes = bytes.fromhex("8D40621D58C382D690C8AC2863A7")
    assert len(raw_bytes) == 14

    from adsb.protocol.crc import compute_syndrome, verify_crc24
    from adsb.protocol.modes import decode_mode_s

    assert verify_crc24(raw_bytes) is True
    assert compute_syndrome(raw_bytes) == 0

    msg = decode_mode_s(raw_bytes)
    assert msg.df == 17
    assert msg.tc == 11
    assert f"{msg.icao24:06X}" == "40621D"
    assert msg.altitude_ft == 38000
    assert msg.cpr_format == 0  # EVEN
    assert msg.cpr_lat == 93000
    assert msg.cpr_lon == 51372


@pytest.mark.golden
@pytest.mark.tier1
def test_gv03_airborne_pos_odd() -> None:
    """GV-03: Verify Odd airborne position message decoding (TC11, FL380).

    Raw Hex: 8D40621D58C386435CC412692AD6
    Expected: ICAO=40621D, altitude=38000 ft, Q-bit=1, CPR Odd (F=1),
              CPR Lat=74158, CPR Lon=50194, CRC valid=True.
    """
    raw_bytes = bytes.fromhex("8D40621D58C386435CC412692AD6")
    assert len(raw_bytes) == 14

    from adsb.protocol.crc import compute_syndrome, verify_crc24
    from adsb.protocol.modes import decode_mode_s

    assert verify_crc24(raw_bytes) is True
    assert compute_syndrome(raw_bytes) == 0

    msg = decode_mode_s(raw_bytes)
    assert msg.df == 17
    assert msg.tc == 11
    assert f"{msg.icao24:06X}" == "40621D"
    assert msg.altitude_ft == 38000
    assert msg.cpr_format == 1  # ODD
    assert msg.cpr_lat == 74158
    assert msg.cpr_lon == 50194


@pytest.mark.golden
@pytest.mark.tier1
def test_gv02_gv03_global_cpr_pairing() -> None:
    """GV-02 + GV-03: Global CPR resolution pairing Even (GV-02) and Odd (GV-03).

    Expected position: Lat = 52.25720 deg, Lon = 3.91937 deg (most_recent=0)
                       Lat = 52.26578 deg, Lon = 3.93891 deg (most_recent=1)
    """
    from adsb.protocol.cpr import decode_cpr_global_airborne

    even_cpr_lat = 93000 / 131072.0
    even_cpr_lon = 51372 / 131072.0
    odd_cpr_lat = 74158 / 131072.0
    odd_cpr_lon = 50194 / 131072.0

    # Test with Even most recent (t_even >= t_odd)
    lat_deg0, lon_deg0 = decode_cpr_global_airborne(
        even_cpr_lat, even_cpr_lon, odd_cpr_lat, odd_cpr_lon, most_recent=0
    )
    assert math.isclose(lat_deg0, 52.25720, abs_tol=1e-4), f"Resolved lat {lat_deg0} != 52.25720"
    assert math.isclose(lon_deg0, 3.91937, abs_tol=1e-4), f"Resolved lon {lon_deg0} != 3.91937"

    # Test with Odd most recent (t_odd > t_even)
    lat_deg1, lon_deg1 = decode_cpr_global_airborne(
        even_cpr_lat, even_cpr_lon, odd_cpr_lat, odd_cpr_lon, most_recent=1
    )
    assert math.isclose(lat_deg1, 52.26578, abs_tol=1e-4), f"Resolved lat {lat_deg1} != 52.26578"
    assert math.isclose(lon_deg1, 3.93891, abs_tol=1e-4), f"Resolved lon {lon_deg1} != 3.93891"


@pytest.mark.golden
@pytest.mark.tier1
def test_gv04_airborne_velocity_subtype1() -> None:
    """GV-04: Airborne Velocity Subtype 1 (Subsonic, Groundspeed vector).

    Raw Hex: 8D485020994409940838175B284F
    Expected: ICAO=485020, v_ew=-8.0 kt, v_ns=-159.0 kt, groundspeed=159.20 kt,
              ground_track=182.88 deg, vertical_rate=-832 fpm, CRC valid=True.
    """
    raw_bytes = bytes.fromhex("8D485020994409940838175B284F")
    assert len(raw_bytes) == 14

    from adsb.protocol.crc import compute_syndrome, verify_crc24
    from adsb.protocol.modes import decode_mode_s

    assert verify_crc24(raw_bytes) is True
    assert compute_syndrome(raw_bytes) == 0

    msg = decode_mode_s(raw_bytes)
    assert msg.df == 17
    assert msg.tc == 19
    assert msg.subtype == 1
    assert f"{msg.icao24:06X}" == "485020"
    assert msg.v_ew_kt == -8.0
    assert msg.v_ns_kt == -159.0
    assert msg.groundspeed_kt is not None
    assert math.isclose(msg.groundspeed_kt, 159.20, abs_tol=0.2)
    assert msg.ground_track_deg is not None
    assert math.isclose(msg.ground_track_deg, 182.88, abs_tol=0.2)
    assert msg.vertical_rate_fpm == -832


@pytest.mark.golden
@pytest.mark.tier1
def test_gv05_airborne_velocity_subtype3() -> None:
    """GV-05: Airborne Velocity Subtype 3 (Subsonic, Heading & Airspeed).

    Raw Hex: 8DA05F219B06B6AF189400CBC33F
    Expected: ICAO=A05F21, magnetic_heading=243.98 deg, airspeed=375 kt (TAS),
              vertical_rate=-2304 fpm, CRC valid=True.
    """
    raw_bytes = bytes.fromhex("8DA05F219B06B6AF189400CBC33F")
    assert len(raw_bytes) == 14

    from adsb.protocol.crc import compute_syndrome, verify_crc24
    from adsb.protocol.modes import decode_mode_s

    assert verify_crc24(raw_bytes) is True
    assert compute_syndrome(raw_bytes) == 0

    msg = decode_mode_s(raw_bytes)
    assert msg.df == 17
    assert msg.tc == 19
    assert msg.subtype == 3
    assert f"{msg.icao24:06X}" == "A05F21"
    assert msg.magnetic_heading_deg is not None
    assert math.isclose(msg.magnetic_heading_deg, 243.98, abs_tol=0.5)
    assert msg.airspeed_kt == 375
    assert msg.airspeed_is_tas is True
    assert msg.vertical_rate_fpm == -2304


@pytest.mark.golden
@pytest.mark.tier1
def test_gv06_df11_all_call_reply() -> None:
    """GV-06: DF 11 All-Call Reply.

    Raw Hex: 5D4840D6F8740F
    Expected: DF=11, ICAO=4840D6, CA=5, syndrome=0 (Interrogator Identifier II=0).
    """
    raw_bytes = bytes.fromhex("5D4840D6F8740F")
    assert len(raw_bytes) == 7

    from adsb.protocol.crc import compute_syndrome, verify_crc24
    from adsb.protocol.modes import decode_mode_s

    # In DF11, syndrome is II (Interrogator Identifier). For II=0, syndrome == 0.
    assert verify_crc24(raw_bytes) is True
    syndrome = compute_syndrome(raw_bytes)
    assert syndrome == 0

    msg = decode_mode_s(raw_bytes)
    assert msg.df == 11
    assert f"{msg.icao24:06X}" == "4840D6"
    assert getattr(msg, "ca", 0) == 5


# ==============================================================================
# Adversarial & Boundary Golden Vectors (Tier 2 & Adversarial Verification)
# ==============================================================================


@pytest.mark.golden
@pytest.mark.tier2
def test_gv_adv01_single_bit_flip_detection_across_all_112_bits() -> None:
    """Adversarial GV-ADV-01: Single-bit flip across every bit in GV-01.

    Asserts that:
    1. Every single-bit corruption produces compute_syndrome(corrupted) != 0.
    2. The 24-bit CRC syndrome uniquely detects every 1-bit error.
    3. Syndrome-based single-bit error correction restores the exact original frame.
    """
    from adsb.protocol.crc import compute_syndrome, correct_syndrome_errors

    base_frame = bytes.fromhex("8D4840D6202CC371C32CE0576098")
    base_int = int.from_bytes(base_frame, "big")

    for bit_pos in range(112):
        corrupted_int = base_int ^ (1 << bit_pos)
        corrupted_frame = corrupted_int.to_bytes(14, "big")

        syndrome = compute_syndrome(corrupted_frame)
        assert syndrome != 0, f"Undetected 1-bit error at bit position {bit_pos}"

        # If syndrome error correction is implemented, verify correction restores base_frame
        corrected_frame, err_count = correct_syndrome_errors(corrupted_frame)
        assert err_count == 1, f"Expected 1 corrected error for bit {bit_pos}, got {err_count}"
        assert corrected_frame == base_frame, f"Syndrome correction failed at bit {bit_pos}"


@pytest.mark.golden
@pytest.mark.tier2
def test_gv_adv02_adjacent_2bit_burst_error_detection() -> None:
    """Adversarial GV-ADV-02: Adjacent 2-bit burst error detection across GV-01.

    Asserts that all 111 adjacent 2-bit burst errors are detected and corrected.
    """
    from adsb.protocol.crc import compute_syndrome, correct_syndrome_errors

    base_frame = bytes.fromhex("8D4840D6202CC371C32CE0576098")
    base_int = int.from_bytes(base_frame, "big")

    for bit_pos in range(111):
        # Flip bit_pos and bit_pos + 1
        mask = 3 << bit_pos
        corrupted_int = base_int ^ mask
        corrupted_frame = corrupted_int.to_bytes(14, "big")

        syndrome = compute_syndrome(corrupted_frame)
        assert syndrome != 0, f"Undetected 2-bit burst error at bits {bit_pos},{bit_pos + 1}"

        corrected_frame, err_count = correct_syndrome_errors(corrupted_frame)
        assert err_count == 2
        assert corrected_frame == base_frame


@pytest.mark.golden
@pytest.mark.tier2
def test_gv_adv03_address_parity_df4_whitelist_validation() -> None:
    """Adversarial GV-ADV-03: Address/Parity (AP) field in DF 4/5/20/21.

    DF 4 Parity = CRC(data) ^ ICAO.
    Asserts:
    1. Syndrome equals 24-bit ICAO address.
    2. Decoder accepts frame if ICAO is in active whitelist.
    3. Decoder rejects frame if ICAO is absent from whitelist (preventing RF noise phantoms).
    """
    from adsb.protocol.crc import compute_crc24, compute_syndrome
    from adsb.protocol.modes import decode_mode_s

    icao = 0x4840D6
    # Construct synthetic DF4 frame: DF=4 (00100), FS=0 (000), DR=0 (00000), UM=0, AC=altitude FL350
    # Data is 32 bits (4 bytes), AP is 24 bits (3 bytes)
    data_bits = (4 << 27) | (0 << 24) | (0 << 19) | (0 << 13) | (0x0C8A)  # FL350 in AC
    data_bytes = data_bits.to_bytes(4, "big") + b"\x00\x00\x00"
    crc = compute_crc24(data_bytes)
    ap = crc ^ icao
    full_frame = data_bits.to_bytes(4, "big") + ap.to_bytes(3, "big")

    # Verify syndrome recovers ICAO directly
    syndrome = compute_syndrome(full_frame)
    assert syndrome == icao

    # With whitelist containing icao:
    whitelist = {icao}
    msg = decode_mode_s(full_frame, active_whitelist=whitelist)
    assert msg.df == 4
    assert msg.icao24 == icao

    # With empty whitelist: should raise or return unverified
    msg_unverified = decode_mode_s(full_frame, active_whitelist=set())
    assert getattr(msg_unverified, "is_verified", False) is False or msg_unverified is None


@pytest.mark.golden
@pytest.mark.tier2
def test_gv_adv04_gillham_gray_code_invalid_pulses_rejection() -> None:
    """Adversarial GV-ADV-04: Gillham 100-ft Gray code pulse validation.

    Pulses C1, C2, C4 map to Gray word G_100.
    G_100 in {0, 5, 7} are invalid Gillham states and must return None.
    """
    from adsb.protocol.gillham import decode_gillham_altitude

    # Valid altitude: FL350 in Q=0 Gillham representation
    # Construct invalid raw 12-bit AC codes where Q=0 and C1,C2,C4 correspond to 0, 5, 7
    # For example, all zero pulses C1=C2=C4=0 -> G_100=0
    invalid_ac_code_0 = 0x000  # Q=0, all bits 0 -> G_100 = 0 -> Invalid
    res_0 = decode_gillham_altitude(invalid_ac_code_0)
    assert res_0 is None, f"Expected None for invalid Gillham code 0, got {res_0}"


@pytest.mark.golden
@pytest.mark.tier2
def test_gv_adv05_cpr_zone_boundary_straddle_rejection() -> None:
    """Adversarial GV-ADV-05: Mandatory CPR latitude boundary straddle rejection.

    If an Even frame and Odd frame straddle different NL(lat) transition boundaries
    (i.e., NL(Rlat_0) != NL(Rlat_1)), Global CPR decoding must reject the decode.
    """
    from adsb.protocol.cpr import decode_cpr_global_airborne, encode_cpr_airborne, nl_lat

    # Latitude near 87 degrees where NL transitions from 2 to 1
    # NL(86.99) == 2, NL(87.01) == 1
    assert nl_lat(86.99) == 2
    assert nl_lat(87.01) == 1

    yz0, xz0 = encode_cpr_airborne(86.99, 10.0, 0)
    yz1, xz1 = encode_cpr_airborne(87.01, 10.0, 1)

    with pytest.raises(ValueError, match="CPR zone boundary straddle detected"):
        decode_cpr_global_airborne(
            lat_cpr0=yz0 / 131072.0,
            lon_cpr0=xz0 / 131072.0,
            lat_cpr1=yz1 / 131072.0,
            lon_cpr1=xz1 / 131072.0,
            most_recent=1,
        )


@pytest.mark.golden
@pytest.mark.tier2
def test_gv_adv06_mode_s_beast_binary_escaping() -> None:
    """Adversarial GV-ADV-06: Beast binary framing with 0x1A escape stuffing.

    Any 0x1A inside the timestamp, RSSI, or payload must be escaped as 0x1A 0x1A.
    """
    from adsb.wire.beast import parse_beast_frame, serialize_beast_frame

    # Construct payload with multiple 0x1A bytes
    mlat_ts = 0x001A2233441A  # contains two 0x1A bytes
    rssi_byte = 0x1A  # 0x1A RSSI byte
    payload = b"\x8d\x1a\x40\xd6\x1a\x2c\xc3\x71\xc3\x2c\xe0\x57\x60\x98"

    encoded = serialize_beast_frame(
        frame_type="3", mlat_timestamp=mlat_ts, rssi_byte=rssi_byte, payload=payload
    )

    # Encoded frame must start with 0x1A 0x33 ('3')
    assert encoded.startswith(b"\x1a3")

    # Decoding must recover exact timestamp, rssi, and payload
    decoded = parse_beast_frame(encoded)
    assert decoded.mlat_timestamp == mlat_ts
    assert decoded.rssi_byte == rssi_byte
    assert decoded.payload == payload
