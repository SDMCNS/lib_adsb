"""Adversarial stress-testing suite for Milestone 3 (R4 & R5: Ground Receivers and RF Interference REST API).

Authored by Empirical Challenger (challenger_enh_m3_2) to empirically challenge:
1. High-concurrency CRUD requests across 20+ threads creating, updating, toggling,
   and deleting ground receiver stations and RF interference sources simultaneously.
2. Duplicate ID handling (place-and-configure upsert) and malformed coordinates/RF parameters
   (HTTP 422 / 400 validation boundaries).
3. Rapid toggle and power updates (50+ calls) verifying atomic state consistency in
   InterferenceEngine and ReceiverStatus.
4. Simulation state transitions and reset (sm.reset()) verifying clean memory, purge of
   custom jammers/stations, and exact restoration of the 20 default European airport hubs.
5. Real-time telemetry snapshot extraction under concurrent mutations, verifying
   JSON serialization resilience and zero race-condition corruptions.
"""

from __future__ import annotations

import concurrent.futures
import json
from collections.abc import Generator
from typing import Any, cast

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import (
    SimulationManager,
    SimulationStatus,
    reset_simulation_manager,
)


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Provide a fresh FastAPI TestClient instance with reset SimulationManager singleton."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


# ==============================================================================
# 1. High-Concurrency CRUD Operations (20+ Threads)
# ==============================================================================


class TestConcurrentReceiverAndJammerCRUD:
    """Stress tests challenging thread-safety, race conditions, and concurrency during CRUD."""

    @pytest.mark.integration
    def test_concurrent_receiver_crud_threadpool(self, client: TestClient) -> None:
        """Challenge: 20 concurrent threads performing CRUD on /api/v1/receivers simultaneously.

        Verifies that simultaneous creations, lookups, and deletions do not crash
        with unhandled 500 errors, dictionary mutation exceptions, or corrupted station state.
        """
        num_workers = 20

        def receiver_worker(idx: int) -> dict[str, Any]:
            rx_id = f"RX_CONC_{idx:02d}"
            lat = 48.0 + (idx % 10) * 0.5
            lon = 2.0 + (idx % 10) * 0.5

            # 1. Create receiver
            res_create = client.post(
                "/api/v1/receivers",
                json={
                    "rx_id": rx_id,
                    "name": f"Concurrent Tower {idx:02d}",
                    "lat_deg": lat,
                    "lon_deg": lon,
                    "alt_msl_m": 30.0,
                    "antenna_gain_peak_dbi": 6.0,
                    "sensitivity_dbm": -88.0,
                },
            )
            assert res_create.status_code == 201, f"Failed create {rx_id}: {res_create.text}"

            # 2. Get specific receiver
            res_get = client.get(f"/api/v1/receivers/{rx_id}")
            assert res_get.status_code == 200, f"Failed get {rx_id}: {res_get.text}"
            data_get = res_get.json()
            assert data_get["rx_id"] == rx_id

            # 3. Get status
            res_stat = client.get(f"/api/v1/receivers/{rx_id}/status")
            assert res_stat.status_code == 200, f"Failed status {rx_id}: {res_stat.text}"

            # 4. List receivers
            res_list = client.get("/api/v1/receivers")
            assert res_list.status_code == 200

            # 5. Delete receiver
            res_del = client.delete(f"/api/v1/receivers/{rx_id}")
            assert res_del.status_code == 200, f"Failed delete {rx_id}: {res_del.text}"

            return cast(dict[str, Any], data_get)

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            results = list(pool.map(receiver_worker, range(num_workers)))

        assert len(results) == num_workers
        # Verify clean cleanup after deletions: all 20 temp stations deleted, only default 20 remain
        final_list = client.get("/api/v1/receivers").json()
        final_ids = {r["rx_id"] for r in final_list}
        for idx in range(num_workers):
            assert f"RX_CONC_{idx:02d}" not in final_ids

    @pytest.mark.integration
    def test_concurrent_interference_crud_threadpool(self, client: TestClient) -> None:
        """Challenge: 20 concurrent threads deploying, patching, toggling, and deleting jammers."""
        num_workers = 20

        def jammer_worker(idx: int) -> dict[str, Any]:
            source_id = f"JAM_CONC_{idx:02d}"
            lat = 49.0 + (idx % 10) * 0.4
            lon = 3.0 + (idx % 10) * 0.4

            # 1. Create jammer
            res_create = client.post(
                "/api/v1/interference",
                json={
                    "source_id": source_id,
                    "name": f"Concurrent Jammer {idx:02d}",
                    "lat_deg": lat,
                    "lon_deg": lon,
                    "tx_power_dbm": 42.0,
                    "is_active": True,
                },
            )
            assert res_create.status_code == 201, f"Create failed {source_id}: {res_create.text}"

            # 2. Patch jammer power
            res_patch = client.patch(
                f"/api/v1/interference/{source_id}",
                json={"tx_power_dbm": 48.0},
            )
            assert res_patch.status_code == 200, f"Patch failed {source_id}: {res_patch.text}"
            assert res_patch.json()["tx_power_dbm"] == 48.0

            # 3. Toggle jammer
            res_toggle = client.post(f"/api/v1/interference/{source_id}/toggle")
            assert res_toggle.status_code == 200, f"Toggle failed {source_id}: {res_toggle.text}"
            assert res_toggle.json()["is_active"] is False

            # 4. Get jammer
            res_get = client.get(f"/api/v1/interference/{source_id}")
            assert res_get.status_code == 200, f"Get failed {source_id}: {res_get.text}"

            # 5. Delete jammer
            res_del = client.delete(f"/api/v1/interference/{source_id}")
            assert res_del.status_code == 200, f"Delete failed {source_id}: {res_del.text}"

            return cast(dict[str, Any], res_get.json())

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            results = list(pool.map(jammer_worker, range(num_workers)))

        assert len(results) == num_workers
        final_list = client.get("/api/v1/interference").json()
        assert len(final_list) == 0

    @pytest.mark.integration
    def test_concurrent_mutations_during_active_simulation_stepping(self, client: TestClient) -> None:
        """Challenge: Mutate receiver network and jammers while stepping simulation and processing squitters."""
        # 1. Deploy baseline receiver at Amsterdam and start stepping
        step_res = client.post("/api/v1/simulation/step", json={"step_s": 1.0})
        assert step_res.status_code == 200

        def mutate_step_worker(idx: int) -> bool:
            # Create a receiver
            rx_id = f"RX_STEP_{idx}"
            client.post(
                "/api/v1/receivers",
                json={"rx_id": rx_id, "lat_deg": 52.0 + idx * 0.05, "lon_deg": 4.5},
            )
            # Create a jammer
            jam_id = f"JAM_STEP_{idx}"
            client.post(
                "/api/v1/interference",
                json={"source_id": jam_id, "lat_deg": 52.1 + idx * 0.05, "lon_deg": 4.6, "tx_power_dbm": 45.0},
            )
            # Step simulation simultaneously
            res_s = client.post("/api/v1/simulation/step", json={"step_s": 0.5})
            assert res_s.status_code == 200

            # Toggle jammer
            client.post(f"/api/v1/interference/{jam_id}/toggle")

            # Clean up
            client.delete(f"/api/v1/receivers/{rx_id}")
            client.delete(f"/api/v1/interference/{jam_id}")
            return True

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            outcomes = list(pool.map(mutate_step_worker, range(8)))

        assert all(outcomes)


# ==============================================================================
# 2. Duplicate ID Handling & Input Validation (Adversarial Boundaries)
# ==============================================================================


class TestDuplicateIDAndInputValidationAdversarial:
    """Stress tests challenging duplicate ID handling and input validation boundaries."""

    @pytest.mark.integration
    def test_duplicate_receiver_id_idempotent_place_and_configure(self, client: TestClient) -> None:
        """Verify duplicate station ID performs place-and-configure without registry pollution.

        Under Requirement R4, POST /api/v1/receivers provides map-based 'place and configure'.
        Posting an existing station ID (e.g. 'RX_EHAM' or a user station) updates that station
        in-place and does NOT create duplicate registry entries.
        """
        # Baseline check on RX_EHAM
        res0 = client.get("/api/v1/receivers/RX_EHAM")
        assert res0.status_code == 200
        orig_sens = res0.json()["sensitivity_dbm"]
        assert orig_sens != -95.0

        # Re-post RX_EHAM with updated sensitivity -95.0 dBm
        update_payload = {
            "rx_id": "RX_EHAM",
            "name": "Updated Schiphol Tower",
            "lat_deg": 52.3105,
            "lon_deg": 4.7683,
            "sensitivity_dbm": -95.0,
        }
        res_post = client.post("/api/v1/receivers", json=update_payload)
        assert res_post.status_code == 201
        updated = res_post.json()
        assert updated["rx_id"] == "RX_EHAM"
        assert updated["name"] == "Updated Schiphol Tower"
        assert updated["sensitivity_dbm"] == -95.0

        # Verify exactly 1 instance of RX_EHAM exists in list
        list_res = client.get("/api/v1/receivers")
        assert list_res.status_code == 200
        eham_matches = [rx for rx in list_res.json() if rx["rx_id"] == "RX_EHAM"]
        assert len(eham_matches) == 1, f"Registry duplicate detected: {eham_matches}"

        # Re-post custom station twice
        custom_payload = {
            "rx_id": "RX_CUSTOM_DUP",
            "lat_deg": 50.1234,
            "lon_deg": 8.5678,
            "antenna_gain_peak_dbi": 7.0,
        }
        r1 = client.post("/api/v1/receivers", json=custom_payload)
        assert r1.status_code == 201
        r2 = client.post("/api/v1/receivers", json={**custom_payload, "antenna_gain_peak_dbi": 9.5})
        assert r2.status_code == 201
        assert r2.json()["antenna_gain_peak_dbi"] == 9.5

        dup_matches = [rx for rx in client.get("/api/v1/receivers").json() if rx["rx_id"] == "RX_CUSTOM_DUP"]
        assert len(dup_matches) == 1
        client.delete("/api/v1/receivers/RX_CUSTOM_DUP")

    @pytest.mark.integration
    def test_duplicate_jammer_id_idempotent_place(self, client: TestClient) -> None:
        """Verify duplicate jammer ID performs in-place redeployment without duplicate leaks."""
        payload = {
            "source_id": "JAM_IDEM_01",
            "lat_deg": 52.5,
            "lon_deg": 5.0,
            "tx_power_dbm": 35.0,
        }
        r1 = client.post("/api/v1/interference", json=payload)
        assert r1.status_code == 201

        # Re-post same ID with 55.0 dBm power
        r2 = client.post("/api/v1/interference", json={**payload, "tx_power_dbm": 55.0})
        assert r2.status_code == 201
        assert r2.json()["tx_power_dbm"] == 55.0

        jam_list = client.get("/api/v1/interference").json()
        matches = [j for j in jam_list if j["source_id"] == "JAM_IDEM_01"]
        assert len(matches) == 1
        client.delete("/api/v1/interference/JAM_IDEM_01")

    @pytest.mark.integration
    @pytest.mark.parametrize(
        ("lat", "lon"),
        [
            (90.001, 0.0),
            (-90.001, 0.0),
            (0.0, 180.001),
            (0.0, -180.001),
            (150.0, 50.0),
            (-200.0, 0.0),
        ],
    )
    def test_malformed_coordinates_rejection(self, client: TestClient, lat: float, lon: float) -> None:
        """Adversarial boundary test: verify coordinates beyond WGS84 limits return 422."""
        # Receivers
        res_rx = client.post(
            "/api/v1/receivers",
            json={"lat_deg": lat, "lon_deg": lon},
        )
        assert res_rx.status_code in (422, 400), f"Accepted invalid lat/lon ({lat}, {lon}) on receivers"

        # Interference
        res_jam = client.post(
            "/api/v1/interference",
            json={"lat_deg": lat, "lon_deg": lon},
        )
        assert res_jam.status_code in (422, 400), f"Accepted invalid lat/lon ({lat}, {lon}) on interference"

    @pytest.mark.integration
    @pytest.mark.parametrize(
        ("field", "bad_value"),
        [
            ("sensitivity_dbm", -125.0),
            ("sensitivity_dbm", -35.0),
            ("antenna_gain_peak_dbi", -15.0),
            ("antenna_gain_peak_dbi", 35.0),
            ("alt_msl_m", -600.0),
            ("alt_msl_m", 15000.0),
            ("noise_floor_dbm", -140.0),
            ("noise_floor_dbm", -40.0),
        ],
    )
    def test_malformed_receiver_rf_parameters(self, client: TestClient, field: str, bad_value: float) -> None:
        """Verify out-of-range RF link budget parameters are rejected with 422."""
        payload: dict[str, Any] = {
            "lat_deg": 52.0,
            "lon_deg": 4.0,
            field: bad_value,
        }
        res = client.post("/api/v1/receivers", json=payload)
        assert res.status_code in (422, 400), f"Accepted out-of-bounds {field}={bad_value}"

    @pytest.mark.integration
    @pytest.mark.parametrize(
        ("field", "bad_value"),
        [
            ("tx_power_dbm", -1.0),
            ("tx_power_dbm", 85.0),
            ("frequency_hz", 800e6),
            ("frequency_hz", 1300e6),
            ("bandwidth_mhz", 0.05),
            ("bandwidth_mhz", 150.0),
        ],
    )
    def test_malformed_jammer_rf_parameters(self, client: TestClient, field: str, bad_value: float) -> None:
        """Verify out-of-range jammer RF parameters are rejected with 422."""
        payload: dict[str, Any] = {
            "lat_deg": 52.0,
            "lon_deg": 4.0,
            field: bad_value,
        }
        res = client.post("/api/v1/interference", json=payload)
        assert res.status_code in (422, 400), f"Accepted out-of-bounds {field}={bad_value}"

    @pytest.mark.integration
    def test_malformed_payload_body_types(self, client: TestClient) -> None:
        """Verify non-JSON, missing mandatory fields, and incorrect types return 422/400."""
        # 1. Missing mandatory fields
        r1 = client.post("/api/v1/receivers", json={})
        assert r1.status_code == 422

        r2 = client.post("/api/v1/interference", json={})
        assert r2.status_code == 422

        # 2. String for numeric coordinates
        r3 = client.post("/api/v1/receivers", json={"lat_deg": "NORTH", "lon_deg": "EAST"})
        assert r3.status_code == 422

        # 3. Non-JSON string body
        r4 = client.post(
            "/api/v1/receivers",
            content="NOT_A_JSON_STRING",
            headers={"Content-Type": "application/json"},
        )
        assert r4.status_code in (422, 400)

    @pytest.mark.integration
    def test_nonexistent_entity_404_handling(self, client: TestClient) -> None:
        """Verify operations on non-existent stations and jammers reliably return 404."""
        assert client.get("/api/v1/receivers/NONEXISTENT_RX").status_code == 404
        assert client.get("/api/v1/receivers/NONEXISTENT_RX/status").status_code == 404
        assert client.delete("/api/v1/receivers/NONEXISTENT_RX").status_code == 404

        assert client.get("/api/v1/interference/NONEXISTENT_JAM").status_code == 404
        assert client.patch("/api/v1/interference/NONEXISTENT_JAM", json={"tx_power_dbm": 30.0}).status_code == 404
        assert client.post("/api/v1/interference/NONEXISTENT_JAM/toggle").status_code == 404
        assert client.delete("/api/v1/interference/NONEXISTENT_JAM").status_code == 404


# ==============================================================================
# 3. Rapid Toggle & Power Updates (Atomic Consistency)
# ==============================================================================


class TestRapidToggleAndPowerUpdates:
    """Stress tests challenging rapid toggle and power updates for atomic consistency."""

    @pytest.mark.integration
    def test_rapid_toggle_50_sequential_calls(self, client: TestClient) -> None:
        """Verify 50 rapid sequential toggle calls alternate state with strict parity."""
        # Deploy jammer initially active
        create_res = client.post(
            "/api/v1/interference",
            json={
                "source_id": "JAM_TOGGLE_50",
                "lat_deg": 52.3,
                "lon_deg": 4.8,
                "tx_power_dbm": 50.0,
                "is_active": True,
            },
        )
        assert create_res.status_code == 201
        assert create_res.json()["is_active"] is True

        for i in range(50):
            toggle_res = client.post("/api/v1/interference/JAM_TOGGLE_50/toggle")
            assert toggle_res.status_code == 200
            expected_active = (i % 2 != 0)  # i=0 -> False, i=1 -> True, ..., i=49 -> True
            assert toggle_res.json()["is_active"] == expected_active, f"Parity mismatch at cycle {i}"

        # After 50 toggles (even number), state should return to True
        final_get = client.get("/api/v1/interference/JAM_TOGGLE_50")
        assert final_get.status_code == 200
        assert final_get.json()["is_active"] is True

        client.delete("/api/v1/interference/JAM_TOGGLE_50")

    @pytest.mark.integration
    def test_rapid_power_updates_receiver_impact(self, client: TestClient) -> None:
        """Verify 50 rapid power updates dynamically scale receiver noise floor and status."""
        # Place receiver and jammer 5 km apart
        client.post(
            "/api/v1/receivers",
            json={"rx_id": "RX_IMPACT_TEST", "lat_deg": 52.3000, "lon_deg": 4.7000, "alt_msl_m": 20.0},
        )
        client.post(
            "/api/v1/interference",
            json={"source_id": "JAM_POWER_SWEEP", "lat_deg": 52.3400, "lon_deg": 4.7000, "tx_power_dbm": 10.0},
        )

        prev_noise = -100.0
        # Sweep power up across 50 increments from 20 to 69 dBm
        for p in range(20, 70):
            patch_res = client.patch(
                "/api/v1/interference/JAM_POWER_SWEEP",
                json={"tx_power_dbm": float(p), "is_active": True},
            )
            assert patch_res.status_code == 200
            assert patch_res.json()["tx_power_dbm"] == float(p)

            # Check receiver status
            stat = client.get("/api/v1/receivers/RX_IMPACT_TEST/status").json()
            curr_noise = stat["metrics"]["noise_floor_eff_dbm"]
            assert curr_noise >= prev_noise - 0.01, f"Noise floor decreased during power increase: {curr_noise} < {prev_noise}"
            prev_noise = curr_noise

        # At 69 dBm, receiver must be JAMMED
        final_stat = client.get("/api/v1/receivers/RX_IMPACT_TEST/status").json()
        assert final_stat["status"] == "JAMMED"
        assert final_stat["dominant_jammer_id"] == "JAM_POWER_SWEEP"

        client.delete("/api/v1/receivers/RX_IMPACT_TEST")
        client.delete("/api/v1/interference/JAM_POWER_SWEEP")

    @pytest.mark.integration
    def test_concurrent_toggle_thread_safety(self, client: TestClient) -> None:
        """Verify 20 concurrent threads toggling the same jammer do not deadlock or crash."""
        client.post(
            "/api/v1/interference",
            json={"source_id": "JAM_CONC_TOG", "lat_deg": 52.0, "lon_deg": 4.0, "is_active": True},
        )

        def toggle_worker(_: int) -> bool:
            res = client.post("/api/v1/interference/JAM_CONC_TOG/toggle")
            assert res.status_code == 200
            return bool(res.json()["is_active"])

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            results = list(pool.map(toggle_worker, range(20)))

        assert len(results) == 20
        # Final state check
        final_get = client.get("/api/v1/interference/JAM_CONC_TOG")
        assert final_get.status_code == 200
        assert isinstance(final_get.json()["is_active"], bool)
        client.delete("/api/v1/interference/JAM_CONC_TOG")


# ==============================================================================
# 4. Simulation Reset (sm.reset()) & Memory Restoration
# ==============================================================================


class TestSimulationResetRestorationAndMemory:
    """Stress tests challenging simulation reset, factory restoration, and memory leaks."""

    @pytest.mark.integration
    def test_reset_restores_default_20_european_stations(self) -> None:
        """Verify sm.reset() restores exactly the 20 authentic European airport hub receivers."""
        sm = SimulationManager()

        # Add rogue user stations
        sm.add_receiver({"rx_id": "RX_USER_1", "lat_deg": 40.0, "lon_deg": 10.0})
        sm.add_receiver({"rx_id": "RX_USER_2", "lat_deg": 41.0, "lon_deg": 11.0})
        # Add rogue user jammers
        sm.add_interference_source({"source_id": "JAM_USER_1", "lat_deg": 52.0, "lon_deg": 4.0, "tx_power_dbm": 60.0})
        sm.add_interference_source({"source_id": "JAM_USER_2", "lat_deg": 48.0, "lon_deg": 2.0, "tx_power_dbm": 65.0})

        assert len(sm.get_receivers()) == 22
        assert len(sm.get_interference_sources()) == 2

        # Perform Reset
        state = sm.reset()
        assert state["status"] == SimulationStatus.STOPPED.value
        assert state["sim_time_s"] == 0.0

        # Verify restoration of exactly 20 default European stations
        receivers = sm.get_receivers()
        assert len(receivers) == 20
        rx_ids = {r["rx_id"] for r in receivers}

        expected_20_hubs = {
            "RX_EHAM", "RX_EGLL", "RX_LFPG", "RX_EDDF", "RX_EDDM",
            "RX_LSZH", "RX_LEMD", "RX_LIRF", "RX_LOWW", "RX_EKCH",
            "RX_EBBR", "RX_EIDW", "RX_LEBL", "RX_LPPT", "RX_ENGM",
            "RX_ESSA", "RX_EFHK", "RX_EPWA", "RX_LGAV", "RX_LTFM",
        }
        assert rx_ids == expected_20_hubs, f"Mismatch in restored hubs: {rx_ids ^ expected_20_hubs}"

        # Verify user stations and user jammers completely purged
        assert "RX_USER_1" not in rx_ids
        assert "RX_USER_2" not in rx_ids
        assert len(sm.get_interference_sources()) == 0

    @pytest.mark.integration
    def test_reset_zeroes_all_metrics(self) -> None:
        """Verify simulation reset wipes cumulative packet counts, drop rates, and BER."""
        sm = SimulationManager()
        # Simulate severe jamming and frame drops on RX_EHAM
        rx_status = sm._receiver_status["RX_EHAM"]
        rx_status.record_reception(sinr_db=-5.0, ber=0.5, is_dropped=True, timestamp_s=10.0)
        rx_status.record_reception(sinr_db=-2.0, ber=0.45, is_dropped=True, timestamp_s=11.0)
        assert rx_status.total_frames_dropped == 2
        assert rx_status.packet_loss_rate_pct == 100.0

        sm.reset()

        reset_status = sm.get_receiver_status("RX_EHAM")
        assert reset_status is not None
        metrics = reset_status["metrics"]
        assert metrics["total_frames_detected"] == 0
        assert metrics["dropped_frames_count"] == 0
        assert metrics["packet_loss_rate"] == 0.0
        assert metrics["active_jammers_in_range"] == 0
        assert reset_status["status"] == "NORMAL"

    @pytest.mark.integration
    def test_repeated_resets_idempotent(self) -> None:
        """Verify 10 consecutive resets do not leak memory, duplicate stations, or corrupt RNG."""
        sm = SimulationManager()
        for i in range(10):
            sm.add_interference_source({"source_id": f"JAM_LEAK_{i}", "lat_deg": 50.0, "lon_deg": 4.0})
            sm.reset()
            assert len(sm._receivers) == 20
            assert len(sm._interference_engine.list_sources()) == 0


# ==============================================================================
# 5. Telemetry Snapshot Concurrency & Serialization Resilience
# ==============================================================================


class TestTelemetrySnapshotConcurrentResilience:
    """Stress tests challenging get_telemetry_snapshot() serialization under active mutations."""

    @pytest.mark.integration
    def test_telemetry_snapshot_schema_and_completeness(self) -> None:
        """Verify complete schema of get_telemetry_snapshot() including receivers & jammers."""
        sm = SimulationManager()
        sm.add_interference_source({"source_id": "JAM_SNAP_01", "lat_deg": 52.3, "lon_deg": 4.7, "tx_power_dbm": 45.0})

        snapshot = sm.get_telemetry_snapshot()
        assert snapshot["type"] == "telemetry"
        assert "sim_time_s" in snapshot
        assert "tracks" in snapshot
        assert "track_count" in snapshot
        assert "receivers" in snapshot
        assert "interference_sources" in snapshot

        assert len(snapshot["receivers"]) == 20
        first_rx = snapshot["receivers"][0]
        assert "rx_id" in first_rx
        assert "status" in first_rx
        assert "metrics" in first_rx
        assert "coverage_radius_km" in first_rx

        assert len(snapshot["interference_sources"]) == 1
        first_jam = snapshot["interference_sources"][0]
        assert first_jam["source_id"] == "JAM_SNAP_01"
        assert first_jam["tx_power_w"] > 0
        assert first_jam["effective_range_km"] > 0

    @pytest.mark.integration
    def test_telemetry_snapshot_under_concurrent_crud(self) -> None:
        """Verify get_telemetry_snapshot() can be serialized to JSON while concurrent mutations occur."""
        sm = SimulationManager()

        def snapshot_caller(_: int) -> int:
            snap = sm.get_telemetry_snapshot()
            raw = json.dumps(snap)
            return len(raw)

        def mutator_caller(i: int) -> None:
            if i % 2 == 0:
                sm.add_interference_source({"source_id": f"JAM_MUT_{i}", "lat_deg": 50.0 + (i % 10) * 0.1, "lon_deg": 4.0})
            else:
                sm.remove_interference_source(f"JAM_MUT_{i - 1}")

        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures: list[concurrent.futures.Future[Any]] = []
            for i in range(30):
                futures.append(pool.submit(mutator_caller, i))
                futures.append(pool.submit(snapshot_caller, i))

            serialized_lengths: list[int] = []
            for f in concurrent.futures.as_completed(futures):
                res = f.result()
                if isinstance(res, int):
                    serialized_lengths.append(res)

        assert len(serialized_lengths) == 30
        assert all(length > 100 for length in serialized_lengths)
