"""Integration tests for Milestone 1 public API and unified frame dispatcher."""

from __future__ import annotations

import math

import pytest

import adsb
from adsb import (
    decode_frame,
)
from adsb.protocol.uat import encode_uat_basic, encode_uat_long


class TestMilestone1Integration:
    """Test unified frame dispatcher and top-level package namespace."""

    def test_version_present(self) -> None:
        assert hasattr(adsb, "__version__")
        assert adsb.__version__ == "0.1.0"

    def test_decode_frame_mode_s_df17(self) -> None:
        # GV-01 14-byte frame
        raw_bytes = bytes.fromhex("8D4840D6202CC371C32CE0576098")
        msg = decode_frame(raw_bytes)
        assert msg.df == 17
        assert msg.tc == 4
        assert msg.icao24 == 0x4840D6
        assert msg.callsign.rstrip() == "KLM1023"

    def test_decode_frame_mode_s_df11(self) -> None:
        # GV-06 7-byte frame
        raw_bytes = bytes.fromhex("5D4840D6F8740F")
        msg = decode_frame(raw_bytes)
        assert msg.df == 11
        assert msg.icao24 == 0x4840D6

    def test_decode_frame_uat_basic(self) -> None:
        raw_uat_30 = encode_uat_basic(
            icao24=0x40621D,
            lat_deg=52.3105,
            lon_deg=4.7683,
            altitude_ft=35000,
            include_fec=True,
        )
        assert len(raw_uat_30) == 30
        msg = decode_frame(raw_uat_30)
        assert msg.icao24 == 0x40621D
        assert msg.altitude_ft == 35000
        assert math.isclose(msg.lat_deg or 0.0, 52.3105, abs_tol=2.5e-5)

    def test_decode_frame_uat_long(self) -> None:
        raw_uat_48 = encode_uat_long(
            icao24=0xA1B2C3,
            lat_deg=40.6413,
            lon_deg=-73.7781,
            callsign="SWA123  ",
            altitude_ft=18000,
            include_fec=True,
        )
        assert len(raw_uat_48) == 48
        msg = decode_frame(raw_uat_48)
        assert msg.icao24 == 0xA1B2C3
        assert msg.callsign == "SWA123"
        assert msg.altitude_ft == 18000

    def test_decode_frame_invalid_length_raises(self) -> None:
        with pytest.raises(ValueError, match="Unrecognized frame length"):
            decode_frame(b"\x00\x01\x02")  # 3 bytes
