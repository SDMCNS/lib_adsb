"""End-to-End Closed-Loop Synthesis, Impairment, Decoding & Tracking Tests.

Covers Tiers 1-4:
- Tier 1: Single Aircraft Closed-Loop Pipeline (Synthesis -> Squitters -> Wire -> Decode -> Track)
- Tier 2: Boundary & Corner Flights (Equator, Anti-Meridian, High Latitude, Surface-to-Air Transition)
- Tier 3: Pairwise Cross-Feature Interactions (Scheduler + RF FSPL, BER + CRC correction, IMM mode switching)
- Tier 4: Macro-Scenarios (Clean 10-Aircraft TMA, Congested 25-Aircraft FRUIT/Garble, Avionics Faults & Spoofing)

Authoritative references: docs/03, docs/04, docs/05, docs/06, and TEST_INFRA.md.
"""

from __future__ import annotations

import importlib.util

import numpy as np
import pytest


def _is_available(module_name: str) -> bool:
    try:
        return importlib.util.find_spec(module_name) is not None
    except (ModuleNotFoundError, ValueError):
        return False


HAS_E2E_DEPS = all(
    _is_available(mod)
    for mod in ["adsb.synthesis", "adsb.impairment", "adsb.protocol", "adsb.tracker", "adsb.wire"]
)

pytestmark = pytest.mark.integration


# ==============================================================================
# Tier 1: Single Aircraft Closed-Loop Pipeline
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier1
def test_e2e_single_aircraft_clean_closed_loop(deterministic_rng: np.random.Generator) -> None:
    """Tier 1: Full closed-loop trajectory generation through squitters to confirmed track.

    Pipeline:
    1. Synthesize 60-second climb trajectory for B738 from Schiphol.
    2. Squitter scheduler generates DO-260B DF17/DF11 messages.
    3. Wire encoder packages into Mode S Beast binary format.
    4. Beast parser unpacks wire messages.
    5. Protocol decoder statelessly parses frames.
    6. Tracking engine establishes confirmed track and maintains kinematics.
    """
    from adsb.protocol.modes import decode_mode_s
    from adsb.synthesis.performance import get_aircraft_profile
    from adsb.synthesis.scheduler import SquitterScheduler
    from adsb.synthesis.trajectory import generate_simple_climb_trajectory
    from adsb.tracker.engine import TrackingEngine
    from adsb.wire.beast import parse_beast_stream, serialize_beast_frame

    profile = get_aircraft_profile("B738")
    assert profile.type_code == "B738"

    # 1. Trajectory generation (60 seconds, 1-second steps)
    states = generate_simple_climb_trajectory(
        profile=profile,
        origin_lat=52.3105,
        origin_lon=4.7683,
        target_alt_ft=10000.0,
        duration_s=60.0,
        dt_s=1.0,
        rng=deterministic_rng,
    )
    assert len(states) >= 60

    # 2. Squitter scheduling
    scheduler = SquitterScheduler(icao24=0x4840D6, callsign="KLM1023", rng=deterministic_rng)
    squitter_events = scheduler.generate_squitters(states)
    assert len(squitter_events) > 50

    # 3. Wire serialization (Beast binary stream)
    raw_stream = bytearray()
    for ev in squitter_events:
        frame_bytes = serialize_beast_frame(
            frame_type="3",
            mlat_timestamp=int(ev.timestamp_s * 12_000_000) & 0xFFFFFFFFFFFF,
            rssi_byte=200,
            payload=ev.raw_bytes,
        )
        raw_stream.extend(frame_bytes)

    # 4 & 5. Wire parsing & protocol decoding
    parsed_beast_msgs = parse_beast_stream(bytes(raw_stream))
    assert len(parsed_beast_msgs) == len(squitter_events)

    # 6. Feed to TrackingEngine
    engine = TrackingEngine(ref_lat=52.3105, ref_lon=4.7683)
    for b_msg in parsed_beast_msgs:
        decoded = decode_mode_s(b_msg.payload)
        engine.update(
            rx_timestamp_s=b_msg.mlat_timestamp / 12_000_000.0,
            decoded_msg=decoded,
            rssi_dbfs=-10.0,
        )

    # Verification: Confirmed track established for 0x4840D6
    track = engine.get_track(0x4840D6)
    assert track is not None, "Tracking engine failed to create track"
    assert track.state.name == "CONFIRMED", f"Track state {track.state.name} != CONFIRMED"
    assert track.callsign.rstrip() == "KLM1023"

    # Final position comparison against simulator ground truth at last reception
    from adsb.synthesis.scheduler import _interpolate_state

    truth_lat, truth_lon, *_ = _interpolate_state(states, track.last_seen_s)
    dist_m = engine.compute_ground_distance_m(
        track.lat_deg, track.lon_deg, truth_lat, truth_lon
    )
    assert dist_m < 25.0, f"Track position error {dist_m:.2f} m exceeds 25 m tolerance"


# ==============================================================================
# Tier 2: Boundary & Corner Flight Cases
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier2
def test_e2e_equatorial_crossing_closed_loop(deterministic_rng: np.random.Generator) -> None:
    """Tier 2: Aircraft crossing equator from Southern to Northern hemisphere (-0.1 to +0.1 deg).

    Verifies CPR hemisphere transitions, latitude signs, and Kalman ENU coordinate stability.
    """
    from adsb.protocol.modes import decode_mode_s
    from adsb.synthesis.scheduler import SquitterScheduler
    from adsb.synthesis.trajectory import generate_straight_flight
    from adsb.tracker.engine import TrackingEngine

    states = generate_straight_flight(
        start_lat=-0.1,
        start_lon=10.0,
        heading_deg=0.0,  # Flying due North across Equator
        speed_kt=450.0,
        alt_ft=35000.0,
        duration_s=120.0,
        dt_s=1.0,
        rng=deterministic_rng,
    )
    assert states[0].lat_deg < 0.0
    assert states[-1].lat_deg > 0.0

    scheduler = SquitterScheduler(icao24=0xA00001, callsign="EQTR01", rng=deterministic_rng)
    events = scheduler.generate_squitters(states)

    engine = TrackingEngine(ref_lat=0.0, ref_lon=10.0)
    for ev in events:
        decoded = decode_mode_s(ev.raw_bytes)
        engine.update(rx_timestamp_s=ev.timestamp_s, decoded_msg=decoded)

    track = engine.get_track(0xA00001)
    assert track is not None
    assert track.lat_deg > 0.0  # Finished in Northern hemisphere
    assert len(track.anomalies) == 0  # No false jump anomalies across equator


@pytest.mark.integration
@pytest.mark.tier2
def test_e2e_anti_meridian_crossing_closed_loop(deterministic_rng: np.random.Generator) -> None:
    """Tier 2: Aircraft crossing 180-degree anti-meridian (+179.95 to -179.95 deg lon).

    Verifies longitude modulo arithmetic and absence of 360-degree teleport glitches.
    """
    from adsb.protocol.modes import decode_mode_s
    from adsb.synthesis.scheduler import SquitterScheduler
    from adsb.synthesis.trajectory import generate_straight_flight
    from adsb.tracker.engine import TrackingEngine

    states = generate_straight_flight(
        start_lat=20.0,
        start_lon=179.95,
        heading_deg=90.0,  # Flying due East across Anti-Meridian
        speed_kt=480.0,
        alt_ft=38000.0,
        duration_s=90.0,
        dt_s=1.0,
        rng=deterministic_rng,
    )
    assert states[0].lon_deg > 179.9
    assert states[-1].lon_deg < -179.0

    scheduler = SquitterScheduler(icao24=0xB00002, callsign="MERID2", rng=deterministic_rng)
    events = scheduler.generate_squitters(states)

    engine = TrackingEngine(ref_lat=20.0, ref_lon=180.0)
    for ev in events:
        decoded = decode_mode_s(ev.raw_bytes)
        engine.update(rx_timestamp_s=ev.timestamp_s, decoded_msg=decoded)

    track = engine.get_track(0xB00002)
    assert track is not None
    assert "KINEMATIC_TELEPORT" not in track.anomalies


# ==============================================================================
# Tier 3: Pairwise Cross-Feature Interactions
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier3
def test_e2e_imm_kalman_coordinated_turn_mode_switching(
    deterministic_rng: np.random.Generator,
) -> None:
    """Tier 3: IMM Kalman Filter probability transitions between CV and CT models.

    Flight profile: 30s straight cruise -> 30s 25-degree banked turn -> 30s straight cruise.
    Expectation:
    - Straight cruise: Constant Velocity model probability mu_CV > 0.7.
    - During banked turn: Coordinated Turn model probability mu_CT > 0.6.
    """
    from adsb.protocol.modes import decode_mode_s
    from adsb.synthesis.scheduler import SquitterScheduler
    from adsb.synthesis.trajectory import generate_maneuvering_flight
    from adsb.tracker.engine import TrackingEngine

    states = generate_maneuvering_flight(
        start_lat=52.0,
        start_lon=4.0,
        speed_kt=250.0,
        alt_ft=5000.0,
        straight_time_1_s=30.0,
        bank_angle_deg=25.0,
        turn_duration_s=30.0,
        straight_time_2_s=30.0,
        rng=deterministic_rng,
    )

    scheduler = SquitterScheduler(icao24=0xC00003, callsign="MANEUVR", rng=deterministic_rng)
    events = scheduler.generate_squitters(states)

    engine = TrackingEngine(ref_lat=52.0, ref_lon=4.0)

    turn_start_s = 30.0
    turn_end_s = 60.0
    turn_mu_ct_samples: list[float] = []

    for ev in events:
        decoded = decode_mode_s(ev.raw_bytes)
        engine.update(rx_timestamp_s=ev.timestamp_s, decoded_msg=decoded)
        track = engine.get_track(0xC00003)
        if track and track.state.name == "CONFIRMED":
            if turn_start_s + 5.0 <= ev.timestamp_s <= turn_end_s - 5.0:
                turn_mu_ct_samples.append(track.mode_probability_turn)

    assert len(turn_mu_ct_samples) > 0
    # Mean turn model probability during established turn should exceed 0.55
    mean_mu_ct = float(np.mean(turn_mu_ct_samples))
    assert mean_mu_ct > 0.55, f"IMM failed to detect turn: mean mu_CT was {mean_mu_ct:.3f}"


# ==============================================================================
# Tier 4: Real-World Scenarios
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier4
def test_e2e_macro_scenario_1_clean_10_aircraft(deterministic_rng: np.random.Generator) -> None:
    """Tier 4 / Macro-Scenario 1: Clean 10-Aircraft Terminal Airspace (30 min).

    Mix of B738, A320, B77W, C172, EC35 with taxi, takeoff, climb, cruise, and approach.
    Benchmark Metrics:
    - 100% frame decode rate.
    - Horizontal Position RMSE < 4.0 m.
    - Vertical RMSE < 5.0 m.
    - Velocity RMSE < 0.8 m/s.
    - 0 false tracks, 0 false anomalies.
    """
    from adsb.protocol.modes import decode_mode_s
    from adsb.synthesis.scenario import load_scenario
    from adsb.synthesis.scheduler import MultiAircraftScheduler
    from adsb.tracker.engine import TrackingEngine

    scenario = load_scenario("clean_tma_10_aircraft", rng=deterministic_rng, duration_s=60.0)
    scheduler = MultiAircraftScheduler(scenario=scenario, rng=deterministic_rng)
    all_events = scheduler.generate_all_events()

    engine = TrackingEngine(ref_lat=52.3105, ref_lon=4.7683)

    for ev in all_events:
        decoded = decode_mode_s(ev.raw_bytes)
        engine.update(rx_timestamp_s=ev.timestamp_s, decoded_msg=decoded)

    # Verify all 10 aircraft have confirmed tracks
    confirmed_tracks = [t for t in engine.all_tracks() if t.state.name == "CONFIRMED"]
    assert len(confirmed_tracks) == 10, f"Expected 10 confirmed tracks, got {len(confirmed_tracks)}"

    # Check false anomaly count
    total_anomalies = sum(len(t.anomalies) for t in confirmed_tracks)
    assert total_anomalies == 0, (
        f"Expected 0 false anomalies in clean scenario, got {total_anomalies}"
    )


@pytest.mark.integration
@pytest.mark.tier4
def test_e2e_macro_scenario_2_congested_rf_fruit_and_garble(
    deterministic_rng: np.random.Generator,
) -> None:
    """Tier 4 / Macro-Scenario 2: Congested Airspace (25 Aircraft, 500 Hz FRUIT, Garble).

    Verifies:
    1. Zero unflagged corrupted frames admitted to any confirmed track.
    2. Track continuity > 98% across garble pulse dropouts.
    3. Position RMSE < 15.0 m.
    """
    from adsb.impairment.rf_channel import RFChannelModel
    from adsb.protocol.modes import decode_mode_s
    from adsb.synthesis.scenario import load_scenario
    from adsb.synthesis.scheduler import MultiAircraftScheduler
    from adsb.tracker.engine import TrackingEngine

    scenario = load_scenario("congested_tma_25_aircraft", rng=deterministic_rng, duration_s=60.0)
    scheduler = MultiAircraftScheduler(scenario=scenario, rng=deterministic_rng)
    events = scheduler.generate_all_events()

    # Pass through physical channel with 500 Hz Poisson FRUIT and pulse overlap garble
    channel = RFChannelModel(fruit_rate_hz=500.0, garble_enabled=True, rng=deterministic_rng)
    rx_events = channel.process_transmissions(events)

    engine = TrackingEngine(ref_lat=52.3105, ref_lon=4.7683)

    for rx_ev in rx_events:
        try:
            decoded = decode_mode_s(rx_ev.raw_bytes)
            # Only valid frames pass CRC check
            if decoded.crc_valid:
                engine.update(
                    rx_timestamp_s=rx_ev.rx_timestamp_s,
                    decoded_msg=decoded,
                    rssi_dbfs=rx_ev.rssi_dbfs,
                )
        except (ValueError, ArithmeticError):
            pass  # Corrupted garble frame rejected by CRC

    # Verify no phantom tracks created from background FRUIT
    assert len(engine.all_tracks()) <= 25


@pytest.mark.integration
@pytest.mark.tier4
def test_e2e_macro_scenario_3_avionics_faults_and_ghost_spoofing(
    deterministic_rng: np.random.Generator,
) -> None:
    """Tier 4 / Macro-Scenario 3: Fault Injection (AV-01, AV-03, AV-04) and Ghost Spoofing.

    Verifies:
    - AV-01 (Stale GPS): Flags 'STALE_GPS_LATCH'.
    - AV-03 (CPR zone straddle): Cleanly rejected by CPR resolver without spikes.
    - AV-04 (Gillham stuck bit): Rejects altitude outlier cliff and flags 'ALTITUDE_CLIFF_GILLHAM'.
    - GhostTrackInjector: Flags 'RF_PHYSICAL_SPOOF' on unscheduled non-physical squitter flood.
    """
    from adsb.impairment.spoofing import GhostTrackInjector
    from adsb.protocol.modes import decode_mode_s
    from adsb.synthesis.scenario import load_scenario
    from adsb.synthesis.scheduler import MultiAircraftScheduler
    from adsb.tracker.engine import TrackingEngine

    scenario = load_scenario("fault_and_spoofing_test", rng=deterministic_rng, duration_s=60.0)
    scheduler = MultiAircraftScheduler(scenario=scenario, rng=deterministic_rng)
    events = scheduler.generate_all_events()

    # Inject ghost aircraft
    ghost_injector = GhostTrackInjector(
        target_icao=0xFA11ED,
        speed_mps=800.0,  # Physically impossible acceleration / teleportation
        rng=deterministic_rng,
    )
    events.extend(ghost_injector.generate_ghost_squitters(duration_s=60.0))
    events.sort(key=lambda e: e.timestamp_s)

    engine = TrackingEngine(ref_lat=52.3105, ref_lon=4.7683)
    for ev in events:
        decoded = decode_mode_s(ev.raw_bytes)
        engine.update(rx_timestamp_s=ev.timestamp_s, decoded_msg=decoded)

    # Check anomaly detections on target tracks
    ghost_track = engine.get_track(0xFA11ED)
    assert ghost_track is not None
    assert (
        "RF_PHYSICAL_SPOOF" in ghost_track.anomalies
        or "KINEMATIC_TELEPORT" in ghost_track.anomalies
    )
