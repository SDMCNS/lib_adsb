"""End-to-End API Service & Tactical Map Streaming Tests (R2 & R3).

Covers:
- REST Simulation Lifecycle: /config, /start, /pause, /step, /speed, /reset, /state
- Live Wire Frame Injection: /api/v1/inject/frame (AVR, Beast binary, SBS-1)
- WebSocket Streaming: /ws/telemetry (JSON track vectors) and /ws/wire (raw wire packets)
- Tactical Map Frontend Asset Delivery: index.html, radar.css, canvas_radar.js, leaflet_map.js
- Concurrency & Error Handling: Multi-client broadcast, invalid injection payloads

Authoritative reference: PROJECT.md M5 & M6 and docs/01.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Generator

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import SimulationManager, get_simulation_manager, reset_simulation_manager


def _get_sim_task(mgr: SimulationManager) -> asyncio.Task[None] | None:
    return mgr._sim_task


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Create FastAPI TestClient for adsb.api.app."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


# ==============================================================================
# 1. REST Simulation Lifecycle Endpoints
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier1
def test_simulation_lifecycle_rest_api(client: TestClient) -> None:
    """Test full simulation control lifecycle via REST API."""
    # 1. Initial State
    res = client.get("/api/v1/simulation/state")
    assert res.status_code == 200
    state_data = res.json()
    assert "status" in state_data
    assert "sim_time_s" in state_data

    # 2. Configure Simulation
    config_payload = {
        "scenario_name": "clean_tma_10_aircraft",
        "speed_multiplier": 2.0,
        "seed": 42,
    }
    res = client.post("/api/v1/simulation/config", json=config_payload)
    assert res.status_code in (200, 201)

    # 3. Start Simulation
    res = client.post("/api/v1/simulation/start")
    assert res.status_code == 200
    assert res.json()["status"] == "RUNNING"

    mgr = get_simulation_manager()
    sim_task = _get_sim_task(mgr)
    assert sim_task is not None
    assert not sim_task.done()

    initial_time = mgr.sim_time_s
    time.sleep(0.15)
    assert mgr.sim_time_s > initial_time

    # 4. Set Speed Multiplier
    res = client.post("/api/v1/simulation/speed", json={"speed_multiplier": 5.0})
    assert res.status_code == 200
    assert res.json()["speed_multiplier"] == 5.0

    # 5. Step Simulation
    res = client.post("/api/v1/simulation/step", json={"step_s": 1.0})
    assert res.status_code == 200

    # 6. Pause Simulation
    res = client.post("/api/v1/simulation/pause")
    assert res.status_code == 200
    assert res.json()["status"] == "PAUSED"
    assert _get_sim_task(mgr) is None

    # 7. Reset Simulation
    res = client.post("/api/v1/simulation/reset")
    assert res.status_code == 200
    assert res.json()["status"] == "STOPPED"
    assert res.json()["sim_time_s"] == 0.0


@pytest.mark.integration
@pytest.mark.tier1
def test_autonomous_simulation_advancement_and_streaming(client: TestClient) -> None:
    """Verify simulation autonomously advances time and streams telemetry over WebSocket."""
    with client.websocket_connect("/ws/telemetry") as ws:
        res = client.post("/api/v1/simulation/start")
        assert res.status_code == 200
        assert res.json()["status"] == "RUNNING"

        mgr = get_simulation_manager()
        sim_task = _get_sim_task(mgr)
        assert sim_task is not None
        assert not sim_task.done()

        # Let background simulation run autonomously
        initial_time = mgr.sim_time_s
        time.sleep(0.2)
        assert mgr.sim_time_s > initial_time

        # Receive streamed telemetry message
        msg = ws.receive_json()
        assert msg["type"] == "telemetry"
        assert "tracks" in msg

        client.post("/api/v1/simulation/pause")
        assert _get_sim_task(mgr) is None


# ==============================================================================
# 2. Live Wire Frame Injection Endpoint
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier1
def test_inject_frame_avr_hex(client: TestClient) -> None:
    """Test injecting raw AVR hex string (*8D...;) and receiving decoded telemetry."""
    # GV-01 KLM1023 callsign message
    payload = {
        "format": "AVR",
        "raw_data": "*8D4840D6202CC371C32CE0576098;",
    }
    res = client.post("/api/v1/inject/frame", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert data["icao_hex"] == "4840D6"
    assert data["df"] == 17
    assert data["callsign"].rstrip() == "KLM1023"
    assert data["crc_valid"] is True


@pytest.mark.integration
@pytest.mark.tier2
def test_inject_malformed_frame_error_handling(client: TestClient) -> None:
    """Test injecting invalid/corrupted wire payloads returns appropriate error."""
    # Truncated hex
    res = client.post("/api/v1/inject/frame", json={"format": "AVR", "raw_data": "*8D48;"})
    assert res.status_code in (400, 422)

    # Unknown format
    res = client.post("/api/v1/inject/frame", json={"format": "UNKNOWN_FORMAT", "raw_data": "1234"})
    assert res.status_code in (400, 422)


# ==============================================================================
# 3. WebSocket Streaming Endpoints
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier3
def test_telemetry_websocket_streaming(client: TestClient) -> None:
    """Test WebSocket /ws/telemetry receives JSON track state vectors upon injection."""
    with client.websocket_connect("/ws/telemetry") as ws:
        # Inject Even + Odd position frames for 40621D (GV-02 + GV-03)
        client.post(
            "/api/v1/inject/frame",
            json={"format": "AVR", "raw_data": "*8D40621D58C382D690C8AC2863A7;"},
        )
        client.post(
            "/api/v1/inject/frame",
            json={"format": "AVR", "raw_data": "*8D40621D58C386435CC412692AD6;"},
        )

        # Receive streamed telemetry message
        data = ws.receive_json()
        assert "tracks" in data or "icao24" in data


@pytest.mark.integration
@pytest.mark.tier3
def test_wire_websocket_streaming(client: TestClient) -> None:
    """Test WebSocket /ws/wire broadcasts raw wire strings or bytes."""
    with client.websocket_connect("/ws/wire?format=AVR") as ws:
        client.post(
            "/api/v1/inject/frame",
            json={"format": "AVR", "raw_data": "*8D4840D6202CC371C32CE0576098;"},
        )
        msg = ws.receive_text()
        assert "8D4840D6202CC371C32CE0576098" in msg


# ==============================================================================
# 4. Tactical Map Frontend Asset Delivery
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier4
@pytest.mark.parametrize(
    "asset_path, expected_content_type",
    [
        ("/", "text/html"),
        ("/index.html", "text/html"),
        ("/css/radar.css", "text/css"),
        ("/js/app.js", "application/javascript"),
        ("/js/canvas_radar.js", "application/javascript"),
        ("/js/leaflet_map.js", "application/javascript"),
        ("/js/websocket_client.js", "application/javascript"),
        ("/js/telemetry_panel.js", "application/javascript"),
    ],
)
def test_tactical_map_static_assets(
    client: TestClient, asset_path: str, expected_content_type: str
) -> None:
    """Verify all tactical radar map frontend static assets are served with HTTP 200."""
    res = client.get(asset_path)
    assert res.status_code == 200, f"Asset {asset_path} returned {res.status_code}"
    content_type = res.headers.get("content-type", "")
    assert expected_content_type in content_type, (
        f"Asset {asset_path} content-type '{content_type}' does not match expected '{expected_content_type}'"
    )
    assert len(res.content) > 0, f"Asset {asset_path} is empty"


# ==============================================================================
# 5. Milestone 1: Continuous Streaming Beyond 70 Seconds
# ==============================================================================


@pytest.mark.integration
@pytest.mark.tier1
def test_leaflet_map_basemap_esri_default_no_carto(client: TestClient) -> None:
    """Verify Leaflet map static asset defaults to ESRI Dark Canvas and contains 0 CARTO references."""
    res = client.get("/js/leaflet_map.js")
    assert res.status_code == 200
    text = res.text
    assert (
        "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}"
        in text
    )
    assert "esriDarkLayer.addTo(this.map)" in text
    assert "carto" not in text.lower()


@pytest.mark.integration
@pytest.mark.tier3
def test_websocket_telemetry_streaming_past_70s(client: TestClient) -> None:
    """Verify WebSocket /ws/telemetry continuously streams active tracks beyond 70s."""
    with client.websocket_connect("/ws/telemetry") as ws:
        # Step simulation from 0s to 75.0s
        res = client.post("/api/v1/simulation/step", json={"step_s": 75.0})
        assert res.status_code == 200
        assert res.json()["sim_time_s"] == 75.0

        # Receive streamed telemetry snapshot
        msg = ws.receive_json()
        assert msg["type"] == "telemetry"
        assert msg["sim_time_s"] >= 70.0
        assert "tracks" in msg
        assert len(msg["tracks"]) >= 10

        # Assert tracks are actively updated past 70s
        tracks_past_70 = [t for t in msg["tracks"] if t["last_seen_s"] >= 70.0]
        assert len(tracks_past_70) == len(msg["tracks"]), (
            f"Expected all tracks updated past 70s, got {len(tracks_past_70)}/{len(msg['tracks'])}"
        )


@pytest.mark.integration
@pytest.mark.tier3
def test_websocket_wire_streaming_past_70s(client: TestClient) -> None:
    """Verify WebSocket /ws/wire broadcasts raw wire packets beyond 70 seconds."""
    # Fast forward simulation to 70.0s
    client.post("/api/v1/simulation/step", json={"step_s": 70.0})

    with client.websocket_connect("/ws/wire?format=AVR") as ws:
        # Step forward 2 seconds past 70s
        client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        # Receive broadcast AVR frame
        msg = ws.receive_text()
        assert msg.startswith("*")
        assert msg.endswith(";\r\n")
        assert len(msg.strip()) in (16, 30)  # 7-byte (*14 hex;) or 14-byte (*28 hex;)


@pytest.mark.integration
@pytest.mark.tier4
def test_autonomous_background_loop_streaming_cross_70s(client: TestClient) -> None:
    """Verify autonomous background loop streams telemetry smoothly across the 70s mark."""
    # Pre-advance to 68.0s
    client.post("/api/v1/simulation/step", json={"step_s": 68.0})

    # Set speed multiplier to 50x so 0.3s wall clock advances 15s sim time
    client.post("/api/v1/simulation/speed", json={"speed_multiplier": 50.0})

    with client.websocket_connect("/ws/telemetry") as ws:
        # Start background simulation
        res = client.post("/api/v1/simulation/start")
        assert res.status_code == 200

        # Run autonomously for 0.3s wall-clock time
        time.sleep(0.3)

        # Receive latest telemetry
        msg = ws.receive_json()
        assert msg["type"] == "telemetry"
        assert msg["sim_time_s"] >= 70.0
        assert len(msg["tracks"]) > 0

        # Clean up
        client.post("/api/v1/simulation/pause")
