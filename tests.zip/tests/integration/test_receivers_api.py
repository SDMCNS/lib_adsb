"""Automated integration tests for R4 Interactive Receiver Placement REST API."""

from __future__ import annotations

from collections.abc import Generator

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import reset_simulation_manager


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Test client with clean singleton SimulationManager per test."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


@pytest.mark.integration
def test_get_receivers_initial_station(client: TestClient) -> None:
    """Verify GET /api/v1/receivers initially lists the default European receiver network."""
    res = client.get("/api/v1/receivers")
    assert res.status_code == 200
    data = res.json()
    assert isinstance(data, list)
    assert len(data) >= 1
    assert data[0]["status"] == "NORMAL"
    assert "metrics" in data[0]
    assert data[0]["metrics"]["sinr_db"] > 10.0


@pytest.mark.integration
def test_create_receiver_success(client: TestClient) -> None:
    """Verify POST /api/v1/receivers adds a receiver and returns 201 Created."""
    payload = {
        "rx_id": "RX_LONDON_01",
        "name": "London Heathrow Radar Tower",
        "lat_deg": 51.4700,
        "lon_deg": -0.4543,
        "alt_msl_m": 25.0,
        "antenna_gain_peak_dbi": 6.0,
        "sensitivity_dbm": -86.0,
    }
    res = client.post("/api/v1/receivers", json=payload)
    assert res.status_code == 201
    rx = res.json()
    assert rx["rx_id"] == "RX_LONDON_01"
    assert rx["name"] == "London Heathrow Radar Tower"
    assert rx["lat_deg"] == pytest.approx(51.4700, abs=1e-4)
    assert rx["lon_deg"] == pytest.approx(-0.4543, abs=1e-4)
    assert rx["status"] == "NORMAL"
    assert rx["coverage_radius_km"] > 50.0

    # Verify presence in list
    list_res = client.get("/api/v1/receivers")
    ids = [r["rx_id"] for r in list_res.json()]
    assert "RX_LONDON_01" in ids


@pytest.mark.integration
def test_create_receiver_validation_errors(client: TestClient) -> None:
    """Verify boundary validation rejections."""
    # Invalid latitude > 90
    res = client.post("/api/v1/receivers", json={"lat_deg": 95.0, "lon_deg": 4.0})
    assert res.status_code in (422, 400)

    # Invalid sensitivity
    res2 = client.post(
        "/api/v1/receivers",
        json={"lat_deg": 50.0, "lon_deg": 4.0, "sensitivity_dbm": 10.0},
    )
    assert res2.status_code in (422, 400)


@pytest.mark.integration
def test_get_receiver_by_id_and_status(client: TestClient) -> None:
    """Verify individual station lookup and detailed health diagnostics."""
    client.post(
        "/api/v1/receivers",
        json={
            "rx_id": "RX_PARIS",
            "name": "Paris CDG",
            "lat_deg": 49.0097,
            "lon_deg": 2.5479,
        },
    )

    res = client.get("/api/v1/receivers/RX_PARIS")
    assert res.status_code == 200
    assert res.json()["name"] == "Paris CDG"

    res_stat = client.get("/api/v1/receivers/RX_PARIS/status")
    assert res_stat.status_code == 200
    stat = res_stat.json()
    assert stat["rx_id"] == "RX_PARIS"
    assert stat["status"] in ("NORMAL", "DEGRADED", "JAMMED")
    assert "sinr_db" in stat["metrics"]


@pytest.mark.integration
def test_delete_receiver(client: TestClient) -> None:
    """Verify DELETE /api/v1/receivers/{rx_id} removes station."""
    client.post(
        "/api/v1/receivers",
        json={"rx_id": "RX_TEMP", "lat_deg": 52.0, "lon_deg": 4.0},
    )
    del_res = client.delete("/api/v1/receivers/RX_TEMP")
    assert del_res.status_code == 200
    assert del_res.json()["status"] == "DELETED"

    # Subsequent GET returns 404
    get_res = client.get("/api/v1/receivers/RX_TEMP")
    assert get_res.status_code == 404
