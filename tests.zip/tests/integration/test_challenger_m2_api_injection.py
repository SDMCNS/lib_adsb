"""Adversarial stress-testing suite for Milestone 2 (R3: Dynamic Flight Injection, API & WebSocket Streaming).

Authored by Empirical Challenger (challenger_enh_m2_2) to empirically challenge:
1. Concurrency and thread-safety: concurrent flight injections, race conditions in ICAO allocation,
   and event list synchronization (detecting lost updates and address collisions).
2. End-to-end squitter synthesis, CPR position resolution, and tracking verification in /api/v1/tracks.
3. Real-time WebSocket telemetry and raw wire streaming resilience across multiple clients.
4. Dynamic flight injection during active simulation execution and after cycle wrap-around (_cycle_offset_s > 0).
5. Comprehensive input sanitization, malformed payload attacks, and boundary condition handling.
"""

from __future__ import annotations

import concurrent.futures
from collections.abc import Generator
from typing import Any, cast

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import (
    get_simulation_manager,
    reset_simulation_manager,
)


@pytest.fixture
def test_client() -> Generator[TestClient, None, None]:
    """Provide a fresh FastAPI TestClient instance with reset simulation state."""
    reset_simulation_manager()
    with TestClient(app) as client:
        yield client


# ==============================================================================
# 1. Concurrency & Thread-Safety Stress Tests (CRITICAL CHALLENGE)
# ==============================================================================


class TestConcurrentInjectionAdversarial:
    """Stress tests challenging thread-safety and concurrency during dynamic flight creation."""

    @pytest.mark.integration
    def test_concurrent_flight_injection_address_uniqueness(self, test_client: TestClient) -> None:
        """Challenge: 10 concurrent flight creation requests without explicit icao_hex.

        Vulnerability Under Test:
        In SimulationManager.add_flight(), candidate 0x484100 is selected based on
        self.scenario.aircraft. Because trajectory calculation takes 20-50ms and requests
        run in parallel worker threads, concurrent calls see the same empty scenario
        state and allocate identical ICAO addresses to different flights.
        """
        num_requests = 10

        def create_flight(idx: int) -> dict[str, Any]:
            res = test_client.post(
                "/api/v1/flights",
                json={
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "callsign": f"CONC{idx:02d}",
                },
            )
            assert res.status_code == 201, f"Request {idx} failed: {res.text}"
            return cast(dict[str, Any], res.json())

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            responses = list(pool.map(create_flight, range(num_requests)))

        allocated_hexes = [r["icao_hex"] for r in responses]
        unique_hexes = set(allocated_hexes)

        # Adversarial assertion: Every created flight MUST receive a unique 24-bit ICAO address
        assert len(unique_hexes) == num_requests, (
            f"Race condition detected: {num_requests} concurrent flights received only "
            f"{len(unique_hexes)} unique ICAO addresses! Duplicates: {allocated_hexes}"
        )

    @pytest.mark.integration
    def test_concurrent_flight_injection_no_lost_events(self, test_client: TestClient) -> None:
        """Challenge: 10 concurrent injections with explicit unique ICAO addresses.

        Vulnerability Under Test:
        In SimulationManager.add_flight():
            past_events = self._events[: self._event_idx]
            future_events = self._events[self._event_idx :] + new_events
            self._events = past_events + future_events
        When concurrent threads execute this unsynchronized slice-and-reassign,
        one thread's new_events overwrite another's, causing permanent event loss.
        """
        num_requests = 10

        def create_flight_with_hex(idx: int) -> dict[str, Any]:
            res = test_client.post(
                "/api/v1/flights",
                json={
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "callsign": f"HEX{idx:02d}",
                    "icao_hex": f"B{idx:05X}",
                },
            )
            assert res.status_code == 201, f"Request {idx} failed: {res.text}"
            return cast(dict[str, Any], res.json())

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            responses = list(pool.map(create_flight_with_hex, range(num_requests)))

        injected_hexes = {r["icao_hex"] for r in responses}

        # Step simulation to advance clock and process initial squitters
        for _ in range(5):
            test_client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        # Verify all injected flights appear in active tracks
        tracks_res = test_client.get("/api/v1/tracks")
        assert tracks_res.status_code == 200
        tracked_hexes = {t["icao_hex"] for t in tracks_res.json()}

        missing_from_tracks = injected_hexes - tracked_hexes
        assert not missing_from_tracks, (
            f"Lost update race condition: Injected flights {missing_from_tracks} were dropped "
            f"from the simulation event queue and never appeared in tracks!"
        )

    @pytest.mark.integration
    def test_flight_injection_during_active_simulation_stepping(
        self, test_client: TestClient
    ) -> None:
        """Challenge: Dynamic flight injection while simulation step loop is actively running."""
        manager = get_simulation_manager()
        assert manager.scenario is not None
        initial_aircraft_count = len(manager.scenario.aircraft)

        # Step simulation in intervals
        for step_i in range(5):
            test_client.post("/api/v1/simulation/step", json={"step_s": 1.0})

            # Inject a flight midway through stepping
            if step_i == 2:
                res = test_client.post(
                    "/api/v1/flights",
                    json={
                        "origin_icao": "LFPG",
                        "destination_icao": "EDDF",
                        "aircraft_type": "A320",
                        "callsign": "MIDSTEP1",
                        "icao_hex": "C00001",
                    },
                )
                assert res.status_code == 201

        # Advance further so squitters are decoded
        for _ in range(5):
            test_client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        track_res = test_client.get("/api/v1/tracks/C00001")
        assert track_res.status_code == 200
        data = track_res.json()
        assert data["callsign"] == "MIDSTEP1"
        assert len(manager.scenario.aircraft) == initial_aircraft_count + 1


# ==============================================================================
# 2. Cycle Wrap-around & Long-Running Simulation Injection
# ==============================================================================


class TestSimulationLifecycleInjection:
    """Stress tests dynamic flight injection across cycle boundaries and time offsets."""

    @pytest.mark.integration
    def test_injection_after_cycle_wraparound(self, test_client: TestClient) -> None:
        """Verify dynamic injection works correctly when _cycle_offset_s > 0."""
        manager = get_simulation_manager()
        assert manager.scenario is not None

        # Advance past initial scenario duration to trigger wrap-around
        duration = manager.scenario.duration_s
        # Advance in 60s steps
        steps = int(duration // 60.0) + 1
        for _ in range(steps):
            test_client.post("/api/v1/simulation/step", json={"step_s": 60.0})

        assert manager._cycle_offset_s > 0.0, (
            f"Expected cycle offset > 0 after stepping {steps * 60}s, got {manager._cycle_offset_s}"
        )

        # Inject flight after wrap-around
        res = test_client.post(
            "/api/v1/flights",
            json={
                "origin_icao": "EHAM",
                "destination_icao": "EGLL",
                "aircraft_type": "B738",
                "callsign": "WRAP01",
                "icao_hex": "D00001",
            },
        )
        assert res.status_code == 201

        # Step 16 seconds to allow position & velocity squitters to register
        for _ in range(8):
            test_client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        track_res = test_client.get("/api/v1/tracks/D00001")
        assert track_res.status_code == 200, "Flight injected after wrap-around was not tracked"
        track_data = track_res.json()
        assert track_data["callsign"] == "WRAP01"
        assert track_data["has_position"] is True
        assert track_data["lat"] is not None
        assert track_data["lon"] is not None


# ==============================================================================
# 3. Tracking Engine State & Telemetry Accuracy
# ==============================================================================


class TestInjectedFlightTrackingEngine:
    """Empirical verification of tracker position, kinematics, and lifecycle for injected flights."""

    @pytest.mark.integration
    def test_injected_flight_cpr_resolution_and_kinematics(
        self, test_client: TestClient
    ) -> None:
        """Verify that an injected flight resolves CPR position during ground roll and kinematics when airborne."""
        res = test_client.post(
            "/api/v1/flights",
            json={
                "origin_icao": "EGLL",
                "destination_icao": "LFPG",
                "aircraft_type": "A320",
                "callsign": "BAW123",
                "squawk": "7700",
                "icao_hex": "E00001",
            },
        )
        assert res.status_code == 201

        # 1. Step 20s (ground roll phase): verify surface CPR position resolves
        for _ in range(10):
            test_client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        track_res = test_client.get("/api/v1/tracks/E00001")
        assert track_res.status_code == 200
        track = track_res.json()
        assert track["callsign"] == "BAW123"
        assert track["squawk"] == "7700"
        assert track["has_position"] is True
        # Heathrow 27R midpoint is around lat 51.47, lon -0.46
        assert track["lat"] == pytest.approx(51.47, abs=0.2)
        assert track["lon"] == pytest.approx(-0.46, abs=0.2)

        # 2. Step another 25s (total 45s, beyond rotation t=32s into airborne initial climb)
        for _ in range(13):
            test_client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        airborne_res = test_client.get("/api/v1/tracks/E00001")
        assert airborne_res.status_code == 200
        airborne_track = airborne_res.json()
        assert airborne_track["groundspeed_kt"] is not None
        assert airborne_track["groundspeed_kt"] > 100.0
        assert airborne_track["track_deg"] is not None
        # Heading hold along 27R (269.8 deg)
        assert airborne_track["track_deg"] == pytest.approx(270.0, abs=15.0)

    @pytest.mark.integration
    def test_multiple_diverse_injected_flights_tracking(self, test_client: TestClient) -> None:
        """Inject 5 diverse flights across different hubs and aircraft categories simultaneously."""
        flights_spec = [
            ("LFPG", "EDDF", "A320", "AFR01", "E00011"),
            ("LEMD", "LIRF", "B738", "IBE02", "E00012"),
            ("LOWW", "EKCH", "B77W", "AUA03", "E00013"),
            ("LSZH", "EDDM", "C172", "SWR04", "E00014"),
            ("EBBR", "EIDW", "B738", "BEL05", "E00015"),
        ]

        for orig, dest, ac, cs, hex_code in flights_spec:
            res = test_client.post(
                "/api/v1/flights",
                json={
                    "origin_icao": orig,
                    "destination_icao": dest,
                    "aircraft_type": ac,
                    "callsign": cs,
                    "icao_hex": hex_code,
                },
            )
            assert res.status_code == 201

        # Step 16 seconds
        for _ in range(8):
            test_client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        tracks_res = test_client.get("/api/v1/tracks")
        assert tracks_res.status_code == 200
        active_hexes = {t["icao_hex"] for t in tracks_res.json()}

        for _, _, _, cs, hex_code in flights_spec:
            assert hex_code in active_hexes, f"Flight {cs} ({hex_code}) missing from active tracks"


# ==============================================================================
# 4. WebSocket Telemetry & Wire Streaming Resilience
# ==============================================================================


class TestWebSocketStreamingAdversarial:
    """Stress tests WebSocket telemetry broadcast, command handling, and multi-client durability."""

    @pytest.mark.integration
    def test_websocket_telemetry_broadcast_on_injection(self, test_client: TestClient) -> None:
        """Verify injected flights appear in WebSocket telemetry broadcasts."""
        with test_client.websocket_connect("/ws/telemetry") as ws:
            # Inject flight
            res = test_client.post(
                "/api/v1/flights",
                json={
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "callsign": "WSTEL1",
                    "icao_hex": "F00001",
                },
            )
            assert res.status_code == 201

            # Step simulation to trigger broadcast
            test_client.post("/api/v1/simulation/step", json={"step_s": 2.0})

            # Receive broadcast frame
            msg = ws.receive_json()
            assert msg["type"] == "telemetry"
            assert "tracks" in msg
            tracked_icaos = [t["icao_hex"] for t in msg["tracks"]]
            assert "F00001" in tracked_icaos

    @pytest.mark.integration
    def test_websocket_telemetry_snapshot_command(self, test_client: TestClient) -> None:
        """Verify WebSocket responds immediately to interactive 'snapshot' command."""
        with test_client.websocket_connect("/ws/telemetry") as ws:
            ws.send_text("snapshot")
            snapshot = ws.receive_json()
            assert snapshot["type"] == "telemetry"
            assert "tracks" in snapshot
            assert "track_count" in snapshot

    @pytest.mark.integration
    def test_websocket_multi_client_resilience(self, test_client: TestClient) -> None:
        """Verify multiple WebSocket clients stream correctly, even when one disconnects abruptly."""
        with test_client.websocket_connect("/ws/telemetry") as ws1:
            with test_client.websocket_connect("/ws/telemetry") as ws2:
                # Step simulation; both should receive
                test_client.post("/api/v1/simulation/step", json={"step_s": 1.0})
                msg1 = ws1.receive_json()
                msg2 = ws2.receive_json()
                assert msg1["type"] == "telemetry"
                assert msg2["type"] == "telemetry"

            # ws2 is now closed abruptly; ws1 should continue to receive broadcasts
            test_client.post("/api/v1/simulation/step", json={"step_s": 1.0})
            msg1_next = ws1.receive_json()
            assert msg1_next["type"] == "telemetry"

    @pytest.mark.integration
    def test_websocket_wire_streaming_avr_and_beast(self, test_client: TestClient) -> None:
        """Verify /ws/wire streams raw wire encoded messages in AVR format."""
        with test_client.websocket_connect("/ws/wire?format=AVR") as ws_avr:
            # Step simulation to produce squitters
            test_client.post("/api/v1/simulation/step", json={"step_s": 1.0})
            avr_text = ws_avr.receive_text()
            assert avr_text.startswith(("*", "@"))
            assert avr_text.strip().endswith(";")


# ==============================================================================
# 5. Malformed Input, Boundary Attacks, and Negative Testing
# ==============================================================================


class TestMalformedPayloadAttacks:
    """Negative testing: API robustness against malformed, adversarial, and boundary payloads."""

    @pytest.mark.integration
    @pytest.mark.parametrize(
        ("payload", "expected_status", "description"),
        [
            ({}, 422, "Empty body"),
            ({"origin_icao": "EHAM"}, 422, "Missing destination and aircraft type"),
            (
                {"origin_icao": "", "destination_icao": "EGLL", "aircraft_type": "B738"},
                400,
                "Empty origin code",
            ),
            (
                {"origin_icao": "   ", "destination_icao": "EGLL", "aircraft_type": "B738"},
                400,
                "Whitespace origin code",
            ),
            (
                {"origin_icao": "ZZZZ", "destination_icao": "EGLL", "aircraft_type": "B738"},
                400,
                "Non-existent origin airport",
            ),
            (
                {"origin_icao": "EHAM", "destination_icao": "ZZZZ", "aircraft_type": "B738"},
                400,
                "Non-existent destination airport",
            ),
            (
                {"origin_icao": "EHAM", "destination_icao": "EHAM", "aircraft_type": "B738"},
                400,
                "Same origin and destination",
            ),
            (
                {"origin": "eham", "destination": "EHAM", "aircraft_type": "B738"},
                400,
                "Case-insensitive same origin and destination",
            ),
            (
                {"origin_icao": "EHAM", "destination_icao": "EGLL", "aircraft_type": "SPACESHIP"},
                400,
                "Invalid aircraft type",
            ),
            (
                {
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "cruise_alt_ft": -5000.0,
                },
                422,
                "Negative cruise altitude",
            ),
            (
                {
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "cruise_alt_ft": 0.0,
                },
                422,
                "Zero cruise altitude",
            ),
            (
                {
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "squawk": "9999",
                },
                400,
                "Non-octal squawk code",
            ),
            (
                {
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "squawk": "12",
                },
                400,
                "Truncated squawk code",
            ),
            (
                {
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "squawk": "ABCD",
                },
                400,
                "Alphabetic squawk code",
            ),
            (
                {
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "icao_hex": "GGGGGG",
                },
                400,
                "Non-hex ICAO string",
            ),
            (
                {
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "icao_hex": "12345",
                },
                400,
                "5-character ICAO string",
            ),
            (
                {
                    "origin_icao": "EHAM",
                    "destination_icao": "EGLL",
                    "aircraft_type": "B738",
                    "icao_hex": "1234567",
                },
                400,
                "7-character ICAO string",
            ),
        ],
    )
    def test_malformed_flight_create_payloads(
        self,
        test_client: TestClient,
        payload: dict[str, Any],
        expected_status: int,
        description: str,
    ) -> None:
        """Verify API returns 400 or 422 with clean error detail for invalid payloads."""
        res = test_client.post("/api/v1/flights", json=payload)
        assert res.status_code == expected_status, (
            f"Failed on {description}: expected {expected_status}, got {res.status_code}: {res.text}"
        )
        assert "detail" in res.json()

    @pytest.mark.integration
    def test_non_json_body_rejection(self, test_client: TestClient) -> None:
        """Verify sending malformed raw bytes returns 422 Unprocessable Entity."""
        res = test_client.post(
            "/api/v1/flights",
            content=b"MALFORMED_NON_JSON_DATA",
            headers={"content-type": "application/json"},
        )
        assert res.status_code == 422

    @pytest.mark.integration
    def test_altitude_response_discrepancy(self, test_client: TestClient) -> None:
        """Challenge: API returns unchecked raw requested cruise_alt_ft in response.

        When a flight is created with an extreme cruise altitude (e.g. 99,999 ft, far above
        the B738 service ceiling of 41,000 ft), the internal trajectory solver caps the
        altitude to 41,000 ft, and the API response must return the effective capped altitude.
        """
        res_high = test_client.post(
            "/api/v1/flights",
            json={
                "origin_icao": "EHAM",
                "destination_icao": "EGLL",
                "aircraft_type": "B738",
                "cruise_alt_ft": 99999.0,
            },
        )
        assert res_high.status_code == 201
        response_alt = res_high.json()["cruise_alt_ft"]
        manager = get_simulation_manager()
        assert manager.scenario is not None
        last_ac = manager.scenario.aircraft[-1]
        max_truth_alt = max(s.alt_baro_ft for s in last_ac.states)
        # Verify the trajectory capped it to <= 41000 ft
        assert max_truth_alt <= 41000.0, f"Trajectory failed to cap altitude: {max_truth_alt}"
        # Verify the API response returns the effective capped cruise altitude matching trajectory
        assert response_alt <= 41000.0, f"API returned uncapped cruise altitude: {response_alt}"
        assert response_alt == last_ac.states[0].alt_mcp_selected_ft, "API response altitude does not match trajectory"
        assert abs(response_alt - max_truth_alt) <= 100.0, "API response altitude does not match truth altitude reached"

    @pytest.mark.integration
    def test_tracks_endpoint_adversarial_queries(self, test_client: TestClient) -> None:
        """Verify GET /api/v1/tracks/{icao_hex} error paths."""
        # Non-hex string -> 400
        res = test_client.get("/api/v1/tracks/NOTHEX")
        assert res.status_code == 400
        assert "Invalid ICAO hex string" in res.json()["detail"]

        # Non-existent track -> 404
        res = test_client.get("/api/v1/tracks/FFFFFF")
        assert res.status_code == 404
        assert "not found" in res.json()["detail"]
