"""Automated integration tests for R5 RF Interference & Jammer REST API."""

from __future__ import annotations

from collections.abc import Generator

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import reset_simulation_manager


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Test client with clean singleton SimulationManager per test."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


@pytest.mark.integration
def test_create_interference_source(client: TestClient) -> None:
    """Verify POST /api/v1/interference creates and deploys jammer."""
    payload = {
        "source_id": "JAMMER_ALPHA",
        "name": "Tactical EW Jammer Alpha",
        "lat_deg": 52.2500,
        "lon_deg": 4.6500,
        "tx_power_dbm": 45.0,
        "frequency_hz": 1090000000.0,
        "bandwidth_mhz": 2.0,
        "is_active": True,
    }
    res = client.post("/api/v1/interference", json=payload)
    assert res.status_code == 201
    source = res.json()
    assert source["source_id"] == "JAMMER_ALPHA"
    assert source["tx_power_dbm"] == 45.0
    assert source["tx_power_w"] > 30.0  # 45 dBm ~ 31.6 W
    assert source["effective_range_km"] > 30.0
    assert source["is_active"] is True


@pytest.mark.integration
def test_get_interference_sources(client: TestClient) -> None:
    """Verify GET /api/v1/interference lists deployed jammers."""
    client.post(
        "/api/v1/interference",
        json={"source_id": "JAM_LIST_1", "lat_deg": 52.1, "lon_deg": 4.1},
    )
    res = client.get("/api/v1/interference")
    assert res.status_code == 200
    data = res.json()
    assert isinstance(data, list)
    assert any(j["source_id"] == "JAM_LIST_1" for j in data)


@pytest.mark.integration
def test_interference_impact_on_receiver(client: TestClient) -> None:
    """Verify nearby jammer degrades receiver SINR and elevates status to JAMMED."""
    # Place receiver at Amsterdam Schiphol
    client.post(
        "/api/v1/receivers",
        json={
            "rx_id": "RX_TARGET",
            "name": "Target Receiver",
            "lat_deg": 52.3105,
            "lon_deg": 4.7683,
            "alt_msl_m": 15.0,
        },
    )

    # Initial status: NORMAL
    stat0 = client.get("/api/v1/receivers/RX_TARGET/status").json()
    assert stat0["status"] == "NORMAL"
    baseline_sinr = stat0["metrics"]["sinr_db"]

    # Deploy powerful 50 dBm jammer 4 km away
    client.post(
        "/api/v1/interference",
        json={
            "source_id": "JAMMER_NEAR",
            "lat_deg": 52.3500,
            "lon_deg": 4.7683,
            "tx_power_dbm": 50.0,
            "is_active": True,
        },
    )

    # Step simulation
    client.post("/api/v1/simulation/step", json={"step_s": 1.0})

    # Receiver status must now be degraded or jammed
    stat1 = client.get("/api/v1/receivers/RX_TARGET/status").json()
    assert stat1["status"] in ("DEGRADED", "JAMMED")
    assert stat1["metrics"]["sinr_db"] < baseline_sinr
    assert stat1["dominant_jammer_id"] == "JAMMER_NEAR"

    # Mute jammer via toggle
    toggle_res = client.post("/api/v1/interference/JAMMER_NEAR/toggle")
    assert toggle_res.status_code == 200
    assert toggle_res.json()["is_active"] is False

    # Step simulation again
    client.post("/api/v1/simulation/step", json={"step_s": 1.0})

    # Status recovers to NORMAL
    stat2 = client.get("/api/v1/receivers/RX_TARGET/status").json()
    assert stat2["status"] == "NORMAL"


@pytest.mark.integration
def test_patch_interference_source(client: TestClient) -> None:
    """Verify PATCH /api/v1/interference/{source_id} updates source properties."""
    client.post(
        "/api/v1/interference",
        json={"source_id": "JAM_PATCH", "lat_deg": 52.0, "lon_deg": 4.0, "tx_power_dbm": 30.0},
    )

    patch_res = client.patch(
        "/api/v1/interference/JAM_PATCH",
        json={"tx_power_dbm": 55.0, "is_active": False},
    )
    assert patch_res.status_code == 200
    updated = patch_res.json()
    assert updated["tx_power_dbm"] == 55.0
    assert updated["is_active"] is False


@pytest.mark.integration
def test_delete_interference_source(client: TestClient) -> None:
    """Verify DELETE /api/v1/interference/{source_id} removes jammer."""
    client.post(
        "/api/v1/interference",
        json={"source_id": "JAM_DEL", "lat_deg": 52.0, "lon_deg": 4.0},
    )
    del_res = client.delete("/api/v1/interference/JAM_DEL")
    assert del_res.status_code == 200
    assert del_res.json()["status"] == "DELETED"

    # Subsequent GET returns 404
    get_res = client.get("/api/v1/interference/JAM_DEL")
    assert get_res.status_code == 404
