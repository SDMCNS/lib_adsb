"""Automated integration tests for R3 Flight Creation REST API & Web UI Endpoints."""

from __future__ import annotations

from collections.abc import Generator

import pytest
from starlette.testclient import TestClient

from adsb.api.app import app
from adsb.api.manager import reset_simulation_manager


@pytest.fixture
def client() -> Generator[TestClient, None, None]:
    """Create FastAPI TestClient with fresh simulation state."""
    reset_simulation_manager()
    with TestClient(app) as test_client:
        yield test_client


@pytest.mark.integration
def test_get_airports_endpoint(client: TestClient) -> None:
    """Verify GET /api/v1/airports returns catalog of 31 embedded hubs."""
    res = client.get("/api/v1/airports")
    assert res.status_code == 200
    airports = res.json()
    assert isinstance(airports, list)
    assert len(airports) == 31

    # Verify key European and International hubs
    icaos = {apt["icao"] for apt in airports}
    expected_sample = {
        "EHAM", "EGLL", "LFPG", "EDDF", "LEMD", "LIRF", "LOWW", "EKCH",
        "LSZH", "EDDM", "KJFK", "KLAX", "KORD", "OMDB", "RJTT", "YSSY",
    }
    assert expected_sample.issubset(icaos)

    # Verify schema fields on EHAM
    eham = next(apt for apt in airports if apt["icao"] == "EHAM")
    assert eham["iata"] == "AMS"
    assert "Amsterdam" in eham["name"] or "Schiphol" in eham["name"]
    assert "primary_runway" in eham
    assert eham["primary_runway"]["designation"] == "18R"
    assert eham["primary_runway"]["true_heading_deg"] == pytest.approx(183.0, abs=1.0)


@pytest.mark.integration
def test_get_airports_search_query(client: TestClient) -> None:
    """Verify search filter on GET /api/v1/airports?query=..."""
    res = client.get("/api/v1/airports?query=Heathrow")
    assert res.status_code == 200
    airports = res.json()
    assert len(airports) == 1
    assert airports[0]["icao"] == "EGLL"


@pytest.mark.integration
def test_get_aircraft_types_endpoint(client: TestClient) -> None:
    """Verify GET /api/v1/aircraft-types returns registered performance profiles."""
    res = client.get("/api/v1/aircraft-types")
    assert res.status_code == 200
    types = res.json()
    assert isinstance(types, list)
    assert len(types) >= 13
    assert "B738" in types
    assert "A320" in types
    assert "B77W" in types
    assert "C172" in types


@pytest.mark.integration
def test_post_flight_creation_success(client: TestClient) -> None:
    """Verify valid flight creation returns 201 and appears in tracks and stream."""
    payload = {
        "origin_icao": "EHAM",
        "destination_icao": "EGLL",
        "aircraft_type": "B738",
        "callsign": "KLM1023",
        "cruise_alt_ft": 36000.0,
        "squawk": "1200",
    }
    res = client.post("/api/v1/flights", json=payload)
    assert res.status_code == 201
    data = res.json()
    assert data["status"] == "CREATED"
    assert data["icao_hex"]
    assert data["callsign"] == "KLM1023"
    assert data["origin"] == "EHAM"
    assert data["destination"] == "EGLL"
    assert data["distance_nm"] > 150.0
    assert data["dep_rwy"] == "18R"
    assert data["arr_rwy"] == "27R"

    icao_hex = data["icao_hex"]

    # Step simulation to advance clock and process initial squitters
    step_res = client.post("/api/v1/simulation/step", json={"step_s": 2.0})
    assert step_res.status_code == 200

    # Verify newly created flight appears in active tracks
    tracks_res = client.get("/api/v1/tracks")
    assert tracks_res.status_code == 200
    track_icaos = [t["icao_hex"] for t in tracks_res.json()]
    assert icao_hex in track_icaos

    # Query specific track endpoint
    track_detail = client.get(f"/api/v1/tracks/{icao_hex}")
    assert track_detail.status_code == 200
    detail_data = track_detail.json()
    assert detail_data["callsign"] == "KLM1023"
    assert detail_data["squawk"] == "1200"


@pytest.mark.integration
def test_post_flight_creation_aliases(client: TestClient) -> None:
    """Verify flight creation accepts 'origin' and 'destination' alias keys."""
    payload = {
        "origin": "LFPG",
        "destination": "EDDF",
        "aircraft_type": "A320",
    }
    res = client.post("/api/v1/flights", json=payload)
    assert res.status_code == 201
    data = res.json()
    assert data["origin"] == "LFPG"
    assert data["destination"] == "EDDF"
    assert data["aircraft_type"] == "A320"


@pytest.mark.integration
def test_post_flight_creation_validation_errors(client: TestClient) -> None:
    """Verify validation error rejection for unknown airports and types."""
    # Unknown origin
    res = client.post("/api/v1/flights", json={
        "origin_icao": "ZZZZ",
        "destination_icao": "EGLL",
        "aircraft_type": "B738",
    })
    assert res.status_code == 400

    # Unknown destination
    res = client.post("/api/v1/flights", json={
        "origin_icao": "EHAM",
        "destination_icao": "ZZZZ",
        "aircraft_type": "B738",
    })
    assert res.status_code == 400

    # Same origin and destination
    res = client.post("/api/v1/flights", json={
        "origin_icao": "EHAM",
        "destination_icao": "EHAM",
        "aircraft_type": "B738",
    })
    assert res.status_code == 400

    # Unknown aircraft type
    res = client.post("/api/v1/flights", json={
        "origin_icao": "EHAM",
        "destination_icao": "EGLL",
        "aircraft_type": "SPACESHIP",
    })
    assert res.status_code == 400

    # Invalid squawk (non-octal)
    res = client.post("/api/v1/flights", json={
        "origin_icao": "EHAM",
        "destination_icao": "EGLL",
        "aircraft_type": "B738",
        "squawk": "9999",
    })
    assert res.status_code == 400


@pytest.mark.integration
def test_flight_creation_websocket_streaming(client: TestClient) -> None:
    """Verify newly created flight streams state vectors over /ws/telemetry."""
    with client.websocket_connect("/ws/telemetry") as ws:
        res = client.post("/api/v1/flights", json={
            "origin_icao": "EHAM",
            "destination_icao": "LFPG",
            "aircraft_type": "A320",
            "callsign": "AFR105",
        })
        assert res.status_code == 201
        icao_hex = res.json()["icao_hex"]

        # Step simulation to trigger broadcast
        client.post("/api/v1/simulation/step", json={"step_s": 2.0})

        # Receive streamed frame
        msg = ws.receive_json()
        assert msg["type"] == "telemetry"
        assert "tracks" in msg
        streamed_icaos = [t["icao_hex"] for t in msg["tracks"]]
        assert icao_hex in streamed_icaos
