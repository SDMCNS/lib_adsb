"""Global pytest fixtures and configuration for ADS-B verification suite."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import numpy as np
import pytest

# Ensure src/ is importable from tests without an editable install
ROOT_DIR = Path(__file__).resolve().parent.parent
SRC_DIR = ROOT_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))


def pytest_configure(config: pytest.Config) -> None:
    """Register custom markers for tier and test category filtering."""
    config.addinivalue_line(
        "markers", "golden: Golden Vector verification tests (GV-01..06 and adversarial)"
    )
    config.addinivalue_line("markers", "property: Hypothesis property-based tests")
    config.addinivalue_line("markers", "integration: End-to-end integration tests")
    config.addinivalue_line(
        "markers", "tier1: Tier 1 Feature Coverage tests (>=5 test cases per feature)"
    )
    config.addinivalue_line("markers", "tier2: Tier 2 Boundary & Corner Case tests")
    config.addinivalue_line("markers", "tier3: Tier 3 Cross-Feature Combination tests")
    config.addinivalue_line("markers", "tier4: Tier 4 Macro-Scenario Closed-Loop tests")


@pytest.fixture
def deterministic_rng() -> np.random.Generator:
    """Provide a deterministic NumPy random generator seeded with 42."""
    return np.random.default_rng(seed=42)


@pytest.fixture
def schiphol_coords() -> dict[str, float]:
    """Provide reference geodetic coordinates for Amsterdam Airport Schiphol (EHAM)."""
    return {
        "lat_deg": 52.3105,
        "lon_deg": 4.7683,
        "alt_msl_m": -3.0,
    }


@pytest.fixture
def golden_vectors_data() -> dict[str, dict[str, Any]]:
    """Authoritative golden vectors from docs/02_PROTOCOL_SPECIFICATION.md Section 10."""
    return {
        "GV-01": {
            "hex": "8D4840D6202CC371C32CE0576098",
            "df": 17,
            "tc": 4,
            "icao_hex": "4840D6",
            "icao_int": 0x4840D6,
            "callsign": "KLM1023 ",
            "ca": 0,
            "crc_valid": True,
        },
        "GV-02": {
            "hex": "8D40621D58C382D690C8AC2863A7",
            "df": 17,
            "tc": 11,
            "icao_hex": "40621D",
            "icao_int": 0x40621D,
            "altitude_ft": 38000,
            "q_bit": True,
            "cpr_format": 0,  # EVEN
            "cpr_lat": 93000,
            "cpr_lon": 51372,
            "crc_valid": True,
        },
        "GV-03": {
            "hex": "8D40621D58C386435CC412692AD6",
            "df": 17,
            "tc": 11,
            "icao_hex": "40621D",
            "icao_int": 0x40621D,
            "altitude_ft": 38000,
            "q_bit": True,
            "cpr_format": 1,  # ODD
            "cpr_lat": 74158,
            "cpr_lon": 50194,
            "crc_valid": True,
        },
        "GV-02_03_PAIR": {
            "lat_deg": 52.25720,
            "lon_deg": 3.91937,
            "tolerance_deg": 0.0001,
        },
        "GV-04": {
            "hex": "8D485020994409940838175B284F",
            "df": 17,
            "tc": 19,
            "subtype": 1,
            "icao_hex": "485020",
            "icao_int": 0x485020,
            "v_ew_kt": -8.0,
            "v_ns_kt": -159.0,
            "groundspeed_kt": 159.20,
            "ground_track_deg": 182.88,
            "vertical_rate_fpm": -832,
            "crc_valid": True,
        },
        "GV-05": {
            "hex": "8DA05F219B06B6AF189400CBC33F",
            "df": 17,
            "tc": 19,
            "subtype": 3,
            "icao_hex": "A05F21",
            "icao_int": 0xA05F21,
            "magnetic_heading_deg": 243.98,
            "airspeed_kt": 375,
            "airspeed_is_tas": True,
            "vertical_rate_fpm": -2304,
            "crc_valid": True,
        },
        "GV-06": {
            "hex": "5D4840D6F8740F",
            "df": 11,
            "icao_hex": "4840D6",
            "icao_int": 0x4840D6,
            "ca": 5,
            "syndrome": 0,
        },
    }
