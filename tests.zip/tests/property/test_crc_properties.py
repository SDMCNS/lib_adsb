"""Hypothesis Property-Based Tests for Mode S 24-Bit CRC Linearity & Error Detection.

Authoritative reference: docs/02_PROTOCOL_SPECIFICATION.md Section 2 &
docs/06_IMPLEMENTATION_ROADMAP_AND_TESTING.md Section 2.
"""

from __future__ import annotations

import importlib.util

import hypothesis.strategies as st
import pytest
from hypothesis import given, settings


def _is_available(module_name: str) -> bool:
    try:
        return importlib.util.find_spec(module_name) is not None
    except (ModuleNotFoundError, ValueError):
        return False


HAS_ADSB_CRC = _is_available("adsb.protocol.crc")

pytestmark = pytest.mark.skipif(
    not HAS_ADSB_CRC, reason="adsb.protocol.crc not yet implemented (pending Milestone 1)"
)


@pytest.mark.property
@pytest.mark.tier1
@settings(max_examples=500)
@given(
    data=st.binary(min_size=4, max_size=11),  # Data bytes (excluding 3 parity bytes)
)
def test_crc24_parity_consistency(data: bytes) -> None:
    """Property: Appending compute_crc24 to data bytes always yields syndrome == 0."""
    from adsb.protocol.crc import compute_crc24, compute_syndrome

    # Frame is data + 3 zero bytes
    raw_frame = data + b"\x00\x00\x00"
    parity = compute_crc24(raw_frame)
    assert 0 <= parity <= 0xFFFFFF

    # Complete frame with computed parity
    full_frame = data + parity.to_bytes(3, "big")
    syndrome = compute_syndrome(full_frame)
    assert syndrome == 0, f"Syndrome must be 0 for valid frame, got 0x{syndrome:06X}"


@pytest.mark.property
@pytest.mark.tier2
@settings(max_examples=500)
@given(
    data=st.binary(min_size=11, max_size=11),  # 88 data bits for long 112-bit Mode S frame
    bit_pos=st.integers(min_value=0, max_value=111),
)
def test_crc24_single_bit_error_detection_100_percent(data: bytes, bit_pos: int) -> None:
    """Property: Inversion of any single bit in a 112-bit frame is 100% detected."""
    from adsb.protocol.crc import compute_crc24, compute_syndrome

    parity = compute_crc24(data + b"\x00\x00\x00")
    full_frame = data + parity.to_bytes(3, "big")
    frame_int = int.from_bytes(full_frame, "big")

    # Invert bit_pos
    corrupted_int = frame_int ^ (1 << bit_pos)
    corrupted_frame = corrupted_int.to_bytes(14, "big")

    syndrome = compute_syndrome(corrupted_frame)
    assert syndrome != 0, (
        f"1-bit error at bit position {bit_pos} failed to produce non-zero syndrome"
    )


@pytest.mark.property
@pytest.mark.tier2
@settings(max_examples=500)
@given(
    data=st.binary(min_size=11, max_size=11),
    start_bit=st.integers(min_value=0, max_value=111 - 24),
    burst_len=st.integers(min_value=1, max_value=24),
    pattern=st.integers(min_value=1, max_value=(1 << 24) - 1),
)
def test_crc24_burst_error_detection_up_to_24_bits(
    data: bytes, start_bit: int, burst_len: int, pattern: int
) -> None:
    """Property: 100% detection of all burst errors of length <= 24 bits.

    Mathematical Invariant: Any error polynomial E(x) with deg(E) < 24 is not divisible by G(x).
    """
    from adsb.protocol.crc import compute_crc24, compute_syndrome

    parity = compute_crc24(data + b"\x00\x00\x00")
    full_frame = data + parity.to_bytes(3, "big")
    frame_int = int.from_bytes(full_frame, "big")

    # Mask pattern to burst length with MSB and LSB both set to 1
    burst_mask = (1 << (burst_len - 1)) | (pattern & ((1 << burst_len) - 1)) | 1
    corrupted_int = frame_int ^ (burst_mask << start_bit)
    corrupted_frame = corrupted_int.to_bytes(14, "big")

    syndrome = compute_syndrome(corrupted_frame)
    assert syndrome != 0, f"Burst error of length {burst_len} at bit {start_bit} went undetected"


@pytest.mark.property
@pytest.mark.tier3
@settings(max_examples=300)
@given(
    a=st.binary(min_size=11, max_size=11),
    b=st.binary(min_size=11, max_size=11),
)
def test_crc24_gf2_linearity(a: bytes, b: bytes) -> None:
    """Property: CRC-24 is linear over GF(2): CRC(A ^ B) == CRC(A) ^ CRC(B)."""
    from adsb.protocol.crc import compute_crc24

    a_frame = a + b"\x00\x00\x00"
    b_frame = b + b"\x00\x00\x00"
    xor_frame = bytes(x ^ y for x, y in zip(a_frame, b_frame))

    crc_a = compute_crc24(a_frame)
    crc_b = compute_crc24(b_frame)
    crc_xor = compute_crc24(xor_frame)

    assert crc_xor == (crc_a ^ crc_b), (
        "Linearity over GF(2) violated: CRC(A ^ B) != CRC(A) ^ CRC(B)"
    )
