"""Hypothesis Property-Based Tests for CPR Quantization, NL Symmetry & Global Resolution.

Authoritative reference: docs/02_PROTOCOL_SPECIFICATION.md Section 5 &
docs/06_IMPLEMENTATION_ROADMAP_AND_TESTING.md Section 2.
"""

from __future__ import annotations

import importlib.util

import hypothesis.strategies as st
import pytest
from hypothesis import given, settings


def _is_available(module_name: str) -> bool:
    try:
        return importlib.util.find_spec(module_name) is not None
    except (ModuleNotFoundError, ValueError):
        return False


HAS_ADSB_CPR = _is_available("adsb.protocol.cpr")

pytestmark = pytest.mark.skipif(
    not HAS_ADSB_CPR, reason="adsb.protocol.cpr not yet implemented (pending Milestone 1)"
)


@pytest.mark.property
@pytest.mark.tier1
@settings(max_examples=500)
@given(
    lat_deg=st.floats(min_value=-89.9, max_value=89.9),
)
def test_cpr_nl_symmetry_and_bounds(lat_deg: float) -> None:
    """Property: NL(lat) is symmetric NL(lat) == NL(-lat) and bounded in [1, 59]."""
    from adsb.protocol.cpr import nl_lat

    nl_pos = nl_lat(abs(lat_deg))
    nl_neg = nl_lat(-abs(lat_deg))

    assert nl_pos == nl_neg, f"NL must be symmetric: NL({abs(lat_deg)}) != NL({-abs(lat_deg)})"
    assert 1 <= nl_pos <= 59, f"NL must be bounded in [1, 59], got {nl_pos}"


@pytest.mark.property
@pytest.mark.tier2
@settings(max_examples=300)
@given(
    lat1=st.floats(min_value=0.0, max_value=85.0),
    lat2=st.floats(min_value=0.0, max_value=85.0),
)
def test_cpr_nl_monotonic_decrease(lat1: float, lat2: float) -> None:
    """Property: NL(lat) is monotonically non-increasing from equator to pole."""
    from adsb.protocol.cpr import nl_lat

    lower = min(lat1, lat2)
    higher = max(lat1, lat2)

    assert nl_lat(lower) >= nl_lat(higher), (
        f"NL must be non-increasing: NL({lower})={nl_lat(lower)} < NL({higher})={nl_lat(higher)}"
    )


@pytest.mark.property
@pytest.mark.tier1
@settings(max_examples=500)
@given(
    lat_deg=st.floats(min_value=-85.0, max_value=85.0),
    lon_deg=st.floats(min_value=-179.99, max_value=179.99),
    cpr_format=st.integers(min_value=0, max_value=1),
)
def test_cpr_local_airborne_bounded_quantization(
    lat_deg: float, lon_deg: float, cpr_format: int
) -> None:
    """Property: Local CPR round-trip error is strictly within 17-bit quantization bound.

    Maximum latitude quantization step: 360 / 60 / 131072 deg ≈ 4.58e-5 deg ≈ 5.1 m.
    Local CPR error must not exceed 2.6 m in latitude and delta_lon / 2^18 in longitude.
    """
    from adsb.protocol.cpr import decode_cpr_local, encode_cpr_airborne

    cpr_lat, cpr_lon = encode_cpr_airborne(lat_deg, lon_deg, cpr_format)
    assert 0 <= cpr_lat < 131072
    assert 0 <= cpr_lon < 131072

    lat_frac = cpr_lat / 131072.0
    lon_frac = cpr_lon / 131072.0

    dec_lat, dec_lon = decode_cpr_local(
        lat_frac, lon_frac, cpr_format, ref_lat=lat_deg, ref_lon=lon_deg, surface=False
    )

    # 1 deg latitude ≈ 111,139 m. 5.1 m ≈ 4.6e-5 deg
    lat_err_deg = abs(dec_lat - lat_deg)
    assert lat_err_deg < 5e-5, f"Lat error {lat_err_deg} exceeds 17-bit bound for lat={lat_deg}"

    # Check longitude error (accounting for anti-meridian wraparound)
    lon_diff = abs(dec_lon - lon_deg)
    if lon_diff > 180.0:
        lon_diff = 360.0 - lon_diff
    # Longitude zone width increases with latitude; bound by 360 / 131072
    assert lon_diff < 0.005, f"Lon error {lon_diff} exceeds bound for ({lat_deg}, {lon_deg})"


@pytest.mark.property
@pytest.mark.tier2
@settings(max_examples=300)
@given(
    lat_deg=st.floats(min_value=-80.0, max_value=80.0),
    lon_deg=st.floats(min_value=-179.0, max_value=179.0),
)
def test_cpr_global_airborne_round_trip(lat_deg: float, lon_deg: float) -> None:
    """Property: Global CPR decode Even + Odd recovers coordinates within 5.1 m."""
    from adsb.protocol.cpr import (
        decode_cpr_global_airborne,
        encode_cpr_airborne,
    )

    # Encode Even (0) and Odd (1)
    even_lat, even_lon = encode_cpr_airborne(lat_deg, lon_deg, 0)
    odd_lat, odd_lon = encode_cpr_airborne(lat_deg, lon_deg, 1)

    even_lat_frac = even_lat / 131072.0
    even_lon_frac = even_lon / 131072.0
    odd_lat_frac = odd_lat / 131072.0
    odd_lon_frac = odd_lon / 131072.0

    dec_lat, dec_lon = decode_cpr_global_airborne(
        even_lat_frac, even_lon_frac, odd_lat_frac, odd_lon_frac, most_recent=1
    )

    lat_err = abs(dec_lat - lat_deg)
    assert lat_err < 1e-4, f"Global CPR lat error {lat_err} for ({lat_deg}, {lon_deg})"

    lon_diff = abs(dec_lon - lon_deg)
    if lon_diff > 180.0:
        lon_diff = 360.0 - lon_diff
    assert lon_diff < 2e-4, f"Global CPR lon error {lon_diff} for ({lat_deg}, {lon_deg})"
