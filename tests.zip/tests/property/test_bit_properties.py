"""Hypothesis Property-Based Tests for Bit Manipulation Primitives (1-Based MSB-First).

Authoritative reference: docs/02_PROTOCOL_SPECIFICATION.md Section 1 &
docs/06_IMPLEMENTATION_ROADMAP_AND_TESTING.md Section 2.
"""

from __future__ import annotations

import importlib.util

import hypothesis.strategies as st
import pytest
from hypothesis import assume, given, settings


def _is_available(module_name: str) -> bool:
    try:
        return importlib.util.find_spec(module_name) is not None
    except (ModuleNotFoundError, ValueError):
        return False


HAS_ADSB_BITS = _is_available("adsb.core.bits")

pytestmark = pytest.mark.skipif(
    not HAS_ADSB_BITS, reason="adsb.core.bits not yet implemented (pending Milestone 1)"
)


@pytest.mark.property
@pytest.mark.tier1
@settings(max_examples=500)
@given(
    total_bits=st.sampled_from([56, 112]),
    start=st.integers(min_value=1, max_value=112),
    width=st.integers(min_value=1, max_value=32),
)
def test_bit_slicing_round_trip(total_bits: int, start: int, width: int) -> None:
    """Property: extract_bits(set_bits(val, s, e, x), s, e) == x for all valid ranges."""
    from adsb.core.bits import extract_bits, set_bits

    end = start + width - 1
    assume(end <= total_bits)

    max_field_val = (1 << width) - 1
    field_val = max_field_val // 2  # arbitrary valid test value

    initial_val = 0
    updated_val = set_bits(initial_val, total_bits, start, end, field_val)
    extracted = extract_bits(updated_val, total_bits, start, end)

    assert extracted == field_val, (
        f"Bit round-trip failed: set {field_val} in [{start}..{end}] of {total_bits}b, extracted {extracted}"
    )


@pytest.mark.property
@pytest.mark.tier2
@settings(max_examples=500)
@given(
    total_bits=st.sampled_from([56, 112]),
    initial_val=st.integers(min_value=0, max_value=(1 << 56) - 1),
    start=st.integers(min_value=1, max_value=56),
    width=st.integers(min_value=1, max_value=16),
    field_val=st.integers(min_value=0, max_value=(1 << 16) - 1),
)
def test_bit_slicing_conservation(
    total_bits: int, initial_val: int, start: int, width: int, field_val: int
) -> None:
    """Property: set_bits strictly mutates only bits in [start..end], conserving outside bits."""
    from adsb.core.bits import extract_bits, set_bits

    end = start + width - 1
    assume(end <= total_bits)
    masked_field_val = field_val & ((1 << width) - 1)

    updated_val = set_bits(initial_val, total_bits, start, end, masked_field_val)

    # Check prefix bits (1 .. start - 1) if start > 1
    if start > 1:
        assert extract_bits(updated_val, total_bits, 1, start - 1) == extract_bits(
            initial_val, total_bits, 1, start - 1
        ), "Prefix bits corrupted outside target range"

    # Check suffix bits (end + 1 .. total_bits) if end < total_bits
    if end < total_bits:
        assert extract_bits(updated_val, total_bits, end + 1, total_bits) == extract_bits(
            initial_val, total_bits, end + 1, total_bits
        ), "Suffix bits corrupted outside target range"
