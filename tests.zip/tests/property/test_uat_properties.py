"""Hypothesis Property-Based Tests for 978 MHz UAT Coordinates, Altitudes, and RS FEC."""

from __future__ import annotations

import string

import hypothesis.strategies as st
from hypothesis import given, settings

from adsb.protocol.uat import (
    AltitudeSource,
    ReedSolomonCodec,
    UATStateVector,
    decode_uat_ms,
    decode_uat_sv,
    encode_uat_ms,
    encode_uat_sv,
)


@settings(max_examples=300)
@given(
    lat_deg=st.floats(min_value=-89.9, max_value=89.9),
    lon_deg=st.floats(min_value=-179.9, max_value=179.9),
)
def test_uat_geodetic_coordinates_round_trip(lat_deg: float, lon_deg: float) -> None:
    """Property: 23-bit lat and 24-bit lon roundtrip within 2.5e-5 degrees (~2.5m)."""
    sv = UATStateVector(
        lat_deg=lat_deg,
        lon_deg=lon_deg,
        altitude_ft=10000,
        altitude_source=AltitudeSource.BAROMETRIC,
        nic=8,
        airground_state=0,
    )
    encoded = encode_uat_sv(sv)
    # Prefix 4 dummy bytes for header
    decoded = decode_uat_sv(b"\x00\x00\x00\x00" + encoded)

    assert abs(decoded.lat_deg - lat_deg) < 2.5e-5, f"Lat error for {lat_deg}"
    assert abs(decoded.lon_deg - lon_deg) < 2.5e-5, f"Lon error for {lon_deg}"


@settings(max_examples=300)
@given(
    alt_ft=st.integers(min_value=-1000, max_value=100000),
)
def test_uat_altitude_round_trip(alt_ft: int) -> None:
    """Property: UAT 12-bit altitude roundtrips within 25 ft."""
    sv = UATStateVector(
        lat_deg=0.0,
        lon_deg=0.0,
        altitude_ft=alt_ft,
        altitude_source=AltitudeSource.BAROMETRIC,
        nic=8,
        airground_state=0,
    )
    encoded = encode_uat_sv(sv)
    decoded = decode_uat_sv(b"\x00\x00\x00\x00" + encoded)
    assert decoded.altitude_ft is not None
    assert abs(decoded.altitude_ft - alt_ft) <= 25


@settings(max_examples=200)
@given(
    callsign=st.text(alphabet=string.ascii_uppercase + string.digits, min_size=1, max_size=8),
    cat=st.integers(min_value=0, max_value=39),
)
def test_uat_base40_callsign_property(callsign: str, cat: int) -> None:
    """Property: Base-40 alphanumeric callsigns roundtrip identically."""
    from adsb.protocol.uat import UATModeStatus

    ms = UATModeStatus(emitter_category=cat, callsign=callsign)
    encoded = encode_uat_ms(ms)
    decoded = decode_uat_ms(b"\x00" * 17 + encoded)
    assert decoded.callsign == callsign
    assert decoded.emitter_category == cat


@settings(max_examples=100)
@given(
    msg=st.binary(min_size=18, max_size=18),
    error_count=st.integers(min_value=1, max_value=6),
)
def test_rs30_18_fec_correction_property(msg: bytes, error_count: int) -> None:
    """Property: RS(30,18) corrects up to 6 byte errors on arbitrary 18-byte payloads."""
    codec = ReedSolomonCodec(nsym=12, fcr=120)
    parity = codec.encode(msg)
    codeword = bytearray(msg + parity)

    # Invert error_count bytes
    import random

    rng = random.Random(error_count * 17)
    positions = rng.sample(range(30), error_count)
    for p in positions:
        codeword[p] ^= rng.randint(1, 255)

    corrected_msg, count = codec.decode(bytes(codeword))
    assert count == error_count
    assert corrected_msg == msg
